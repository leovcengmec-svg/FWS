#!/usr/bin/env python3
"""Fetch identity-matched football artwork from Wikimedia Commons.

The synchronizer does not reject artwork based on license category. It prioritizes a
strong entity/title match, records source/author/license metadata when available, and
keeps missing or ambiguous matches as fallbacks. Private-use packaging does not itself
grant redistribution rights. Intended for GitHub Actions with outbound Internet access.
"""
from __future__ import annotations

import argparse
import io
import json
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "android/app/src/main/assets"
IDENTITY = ASSETS / "identity"
CATALOG = ASSETS / "global_world_catalog.json"
VERIFIED = IDENTITY / "verified_assets.json"
SOURCES = IDENTITY / "asset_sources.json"
USER_AGENT = "FootballWorldSimulator-PersonalProject/1.0 (identity asset sync; contact via repository README)"
MAX_FILE_BYTES = 4 * 1024 * 1024
COMPETITION_NAMES = {
    "AFC_CHALLENGE": "AFC Challenge League", "AFC_CHAMPIONS": "AFC Champions League Elite",
    "AFC_CHAMPIONS_TWO": "AFC Champions League Two", "CAF_CHAMPIONS": "CAF Champions League",
    "CAF_CONFEDERATION": "CAF Confederation Cup", "CONCACAF_CARIBBEAN": "CONCACAF Caribbean Cup",
    "CONCACAF_CENTRAL": "CONCACAF Central American Cup", "CONCACAF_CHAMPIONS": "CONCACAF Champions Cup",
    "LIBERTADORES": "CONMEBOL Libertadores", "SUDAMERICANA": "CONMEBOL Sudamericana",
    "OFC_CHAMPIONS": "OFC Champions League", "UEFA_CHAMPIONS": "UEFA Champions League",
    "UEFA_EUROPA": "UEFA Europa League", "UEFA_CONFERENCE": "UEFA Conference League",
}
CONFEDERATION_NAMES = {"AFC":"Asian Football Confederation", "CAF":"Confederation of African Football",
    "CONCACAF":"CONCACAF", "CONMEBOL":"CONMEBOL", "OFC":"Oceania Football Confederation", "UEFA":"UEFA"}
# Names used in these aliases are additional search hints, not an override of the catalog IDs.
ALIASES = {
    "BRA_D1_C1": ["Clube de Regatas do Flamengo", "Flamengo", "Flamengo crest"],
    "BRA_D1_C2": ["Sociedade Esportiva Palmeiras", "Palmeiras", "Palmeiras crest"],
    "BRA_D1_C4": ["Botafogo de Futebol e Regatas", "Botafogo", "Botafogo FR crest"],
    "BRA_D1_C6": ["São Paulo Futebol Clube", "São Paulo", "Sao Paulo FC crest"],
    "BRA_D1_C7": ["Sport Club Corinthians Paulista", "Corinthians", "Corinthians crest"],
    "BRA-1-gremio": ["Grêmio Foot-Ball Porto Alegrense", "Grêmio", "Gremio crest"],
    "BRA-1-santos": ["Santos Futebol Clube", "Santos", "Santos FC crest"],
    "BRA-1-vasco": ["Club de Regatas Vasco da Gama", "Vasco", "Vasco da Gama crest"],
}


def norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def has_mark_context(title: str, description: str = "") -> bool:
    text = norm(title + " " + description).split()
    terms = {"logo", "crest", "escudo", "badge", "emblem", "brasao", "insignia", "shield", "federation", "coat", "arms"}
    return bool(terms.intersection(text)) or "coat of arms" in " ".join(text)


def license_metadata(short: str, url: str) -> tuple[str, str]:
    """Keep license metadata for provenance; license category is not a download filter."""
    return (short.strip() or "Not stated", url.strip())


def http_json(url: str, attempts: int = 4):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(req, timeout=25) as response:
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            if attempt + 1 == attempts:
                raise RuntimeError(f"Wikimedia request failed: {exc}") from exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError("unreachable")


def query_commons(query: str):
    params = urllib.parse.urlencode({
        "action": "query", "format": "json", "generator": "search", "gsrnamespace": 6,
        "gsrsearch": query, "gsrlimit": 8, "prop": "imageinfo", "iiprop": "url|extmetadata",
        "iiurlwidth": 320,
    })
    payload = http_json("https://commons.wikimedia.org/w/api.php?" + params)
    pages = payload.get("query", {}).get("pages", {})
    return list(pages.values())


def query_wikipedia_pages(query: str):
    """Secondary discovery path through Wikipedia article thumbnails; the file is still
    accepted when the file matches the entity; license metadata is recorded when available."""
    params = urllib.parse.urlencode({
        "action": "query", "format": "json", "generator": "search", "gsrnamespace": 0,
        "gsrsearch": query, "gsrlimit": 5, "prop": "pageimages|info", "piprop": "thumbnail",
        "pithumbsize": 320, "inprop": "url",
    })
    payload = http_json("https://en.wikipedia.org/w/api.php?" + params)
    return list(payload.get("query", {}).get("pages", {}).values())


def query_commons_file(file_title: str):
    params = urllib.parse.urlencode({
        "action": "query", "format": "json", "titles": "File:" + file_title,
        "prop": "imageinfo", "iiprop": "url|extmetadata", "iiurlwidth": 320,
    })
    payload = http_json("https://commons.wikimedia.org/w/api.php?" + params)
    return list(payload.get("query", {}).get("pages", {}).values())


def match_score(title: str, entity_name: str, aliases: list[str], kind: str) -> int:
    title_n = norm(title.replace("File:", ""))
    candidate_names = [entity_name] + aliases
    best = 0
    for name in candidate_names:
        name_n = norm(name)
        tokens = [t for t in name_n.split() if t not in {"fc", "cf", "sc", "ac", "club", "football", "futebol", "de", "do", "da", "the"}]
        if not tokens:
            continue
        hits = sum(1 for token in tokens if token in title_n.split())
        if len(tokens) >= 2 and hits == len(tokens):
            score = 100 + len(tokens)
        elif len(tokens) == 1 and hits == 1 and any(x in title_n for x in ("logo", "crest", "escudo", "badge", "emblem", "brasao")):
            # A one-word name is ambiguous. Require a badge/crest term in the file title.
            score = 45
        else:
            score = 0
        if kind in {"competition", "confederation"} and score:
            score += 5
        best = max(best, score)
    return best


def convert_to_webp(raw: bytes, mime: str, destination: Path) -> bool:
    """Convert image to compact transparent WebP; never save untrusted SVG as active content."""
    try:
        from PIL import Image
        if "svg" in mime.lower() or raw.lstrip().startswith(b"<svg") or b"<svg" in raw[:512]:
            import cairosvg
            raw = cairosvg.svg2png(bytestring=raw, output_width=256, output_height=256)
        image = Image.open(io.BytesIO(raw)).convert("RGBA")
        image.thumbnail((192, 192), Image.Resampling.LANCZOS)
        destination.parent.mkdir(parents=True, exist_ok=True)
        image.save(destination, "WEBP", quality=86, method=6)
        return destination.stat().st_size <= 180_000
    except Exception as exc:
        print(f"  skip image conversion: {exc}")
        destination.unlink(missing_ok=True)
        return False


def get_candidates(entity_name: str, aliases: list[str], kind: str, delay: float):
    # Query the catalog name first; broaden only when it has no strong identity match.
    phrases = [entity_name] + aliases
    seen = set()
    for phrase_index, phrase in enumerate(phrases):
        search = f'"{phrase}" (logo OR crest OR escudo OR badge OR emblem)'
        pages = query_commons(search)
        candidates = []
        for page in pages:
            title = page.get("title", "")
            if not title or title in seen:
                continue
            seen.add(title)
            score = match_score(title, entity_name, aliases, kind)
            info_list = page.get("imageinfo", [])
            if not info_list or score < 45:
                continue
            info = info_list[0]
            meta = info.get("extmetadata", {})
            license_short = meta.get("LicenseShortName", {}).get("value", "")
            license_url = meta.get("LicenseUrl", {}).get("value", "")
            description = meta.get("ImageDescription", {}).get("value", "")
            if not has_mark_context(title, description):
                continue
            title_n = norm(title)
            if any(term in title_n.split() for term in ("logo", "crest", "escudo", "badge", "emblem", "brasao")):
                score += 8
            candidates.append((score, title, info, license_short, license_url, description))
        candidates.sort(key=lambda item: item[0], reverse=True)
        if candidates:
            return candidates
        if phrase_index + 1 < len(phrases):
            time.sleep(delay)
    return []


def get_wikipedia_fallback(entity_name: str, aliases: list[str], kind: str, delay: float):
    """Try Wikipedia article thumbnails after Commons search fails, but only embed files
    whose Commons metadata provides provenance when available; license category is not a filter."""
    queries = [f'"{entity_name}" football club logo', f'"{entity_name}" football crest']
    for alias in aliases[:2]:
        queries.append(f'"{alias}" football logo')
    seen = set()
    for query in queries:
        pages = query_wikipedia_pages(query)
        candidates = []
        for page in pages:
            page_title = page.get("title", "")
            page_score = match_score(page_title, entity_name, aliases, kind)
            file_title = page.get("pageimage", "")
            if not file_title or page_score < 45 or file_title in seen:
                continue
            seen.add(file_title)
            try:
                commons_pages = query_commons_file(file_title)
            except Exception:
                time.sleep(delay)
                continue
            for commons_page in commons_pages:
                info_list = commons_page.get("imageinfo", [])
                if not info_list: continue
                info = info_list[0]
                meta = info.get("extmetadata", {})
                license_short = meta.get("LicenseShortName", {}).get("value", "")
                license_url = meta.get("LicenseUrl", {}).get("value", "")
                description = meta.get("ImageDescription", {}).get("value", "")
                if not has_mark_context(commons_page.get("title", file_title), description): continue
                candidates.append((page_score, commons_page.get("title", "File:" + file_title), info,
                                   license_short, license_url, description))
            time.sleep(delay)
        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            return candidates
        time.sleep(delay)
    return []


def build_targets(catalog: dict):
    targets = []
    for cid, club in catalog.get("clubs", {}).items():
        if not isinstance(club, dict): continue
        name = club.get("name") or cid
        targets.append(("club", cid, name, ALIASES.get(cid, [])))
    associations = catalog.get("associations", {})
    teams = catalog.get("national_teams", {})
    for team_key, team in teams.items():
        if not isinstance(team, dict): continue
        team_id = team.get("id", "NT_" + str(team_key))
        country_id = team.get("country_id") or team_key
        association = associations.get(country_id, {}) if isinstance(associations, dict) else {}
        country_name = association.get("name", team.get("name", country_id)) if isinstance(association, dict) else team.get("name", country_id)
        targets.append(("national_team_crest", team_id, country_name + " national football team", []))
    for lid, league in catalog.get("leagues", {}).items():
        if isinstance(league, dict) and league.get("name"):
            targets.append(("league", lid, league["name"], []))
    for cid, comp in catalog.get("competitions", {}).items():
        targets.append(("competition", cid, COMPETITION_NAMES.get(cid, cid.replace("_", " ")), []))
    for cid in catalog.get("confederations", {}):
        targets.append(("confederation", cid, CONFEDERATION_NAMES.get(cid, cid), []))
    # Prioritize major Brazilian clubs and official competitions, then the rest of the club
    # market by prestige, then national teams and leagues. A partial CI run therefore still
    # gives the most visible entities a chance to receive a verified asset.
    priority = {"BRA_D1_C1": 0, "BRA_D1_C2": 1, "BRA_D1_C4": 2, "BRA_D1_C6": 3, "BRA_D1_C7": 4,
                "BRA-1-gremio": 5, "BRA-1-santos": 6, "BRA-1-vasco": 7}
    club_prestige = {cid: float(obj.get("prestige", 0) or 0) for cid, obj in catalog.get("clubs", {}).items() if isinstance(obj, dict)}
    def order(target):
        kind, entity_id, _, _ = target
        if entity_id in priority: return (0, priority[entity_id], entity_id)
        if kind in {"competition", "confederation"}: return (1, 0, entity_id)
        if kind == "club": return (2, -club_prestige.get(entity_id, 0), entity_id)
        if kind == "national_team_crest": return (3, 0, entity_id)
        return (4, 0, entity_id)
    targets.sort(key=order)
    return targets


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-searches", type=int, default=0, help="0 = all catalog entities")
    parser.add_argument("--delay", type=float, default=0.22, help="minimum delay between API searches")
    args = parser.parse_args()
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    verified = json.loads(VERIFIED.read_text(encoding="utf-8")) if VERIFIED.exists() else {"schema_version": 2, "assets": {}}
    verified.setdefault("assets", {})
    sources = json.loads(SOURCES.read_text(encoding="utf-8")) if SOURCES.exists() else {"schema_version": 1, "assets": {}, "missing": []}
    sources.setdefault("assets", {})
    sources.setdefault("missing", [])
    targets = build_targets(catalog)
    if args.max_searches > 0:
        targets = targets[:args.max_searches]
    existing = 0
    fetched = 0
    searched = 0
    missing = []
    used_sources = {item.get("direct_url") for key, item in sources.get("assets", {}).items() if item.get("direct_url")}
    for index, (kind, entity_id, name, aliases) in enumerate(targets, 1):
        key = f"{kind}:{entity_id}"
        current_path = verified["assets"].get(key)
        if current_path and (ASSETS / current_path).is_file() and key in sources.get("assets", {}):
            existing += 1
            continue
        print(f"[{index}/{len(targets)}] {kind} {entity_id}: {name}", flush=True)
        searched += 1
        candidates = []
        try:
            candidates.extend(get_candidates(name, aliases, kind, args.delay))
            if not candidates and (index <= 500 or kind in {"national_team_crest", "competition", "confederation"}):
                print("  Commons search empty; checking Wikipedia article images and associated Commons metadata.", flush=True)
                candidates.extend(get_wikipedia_fallback(name, aliases, kind, args.delay))
        except Exception as exc:
            print(f"  search error: {exc}", flush=True)
            time.sleep(2)
            missing.append({"key": key, "name": name, "reason": "search_error"})
            time.sleep(args.delay)
            continue
        if not candidates:
            missing.append({"key": key, "name": name, "reason": "no_identity_match"})
            time.sleep(args.delay)
            continue
        candidates.sort(key=lambda x: x[0], reverse=True)
        selected = None
        for score, title, info, license_short, license_url, description in candidates:
            url = info.get("thumburl") or info.get("url")
            if not url or url in used_sources: continue
            try:
                request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(request, timeout=30) as response:
                    raw = response.read(MAX_FILE_BYTES + 1)
                    mime = response.headers.get("Content-Type", "")
                if len(raw) > MAX_FILE_BYTES:
                    continue
                slug = re.sub(r"[^A-Za-z0-9_-]+", "_", entity_id).strip("_")[:90]
                folder = {"club":"real_clubs", "national_team_crest":"real_national_teams", "league":"real_leagues",
                          "competition":"real_competitions", "confederation":"real_confederations"}[kind]
                relative = f"identity/{folder}/{slug}.webp"
                destination = ASSETS / relative
                if not convert_to_webp(raw, mime, destination):
                    continue
                selected = {"path": relative, "title": title, "url": info.get("descriptionurl", ""),
                    "direct_url": url, "license": license_short, "license_url": license_url,
                    "author": re.sub(r"<[^>]+>", "", info.get("extmetadata", {}).get("Artist", {}).get("value", ""))[:300],
                    "score": score, "entity_name": name}
                break
            except Exception as exc:
                print(f"  download failed: {exc}", flush=True)
            time.sleep(args.delay)
        if selected:
            verified["assets"][key] = selected["path"]
            sources["assets"][key] = selected
            if selected.get("direct_url"): used_sources.add(selected["direct_url"])
            fetched += 1
        else:
            missing.append({"key": key, "name": name, "reason": "download_or_conversion_failed"})
        time.sleep(args.delay)
        if index % 100 == 0:
            VERIFIED.write_text(json.dumps(verified, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            sources["missing"] = missing
            SOURCES.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    verified["schema_version"] = 2
    sources["missing"] = missing
    sources["summary"] = {"catalog_targets": len(targets), "already_present": existing, "searched_this_run": searched,
                          "newly_downloaded": fetched, "missing_or_unverified": len(missing),
                          "policy": "Strong entity-matched artwork is eligible regardless of license category; source and license metadata are recorded when available."}
    VERIFIED.write_text(json.dumps(verified, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    SOURCES.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    attribution = ["# Attribution for verified football identity artwork", "",
        "Assets below were embedded after identity matching. Source and license metadata are recorded when available; inclusion does not grant redistribution rights.",
        "This report does not grant additional rights over club or federation trademarks; local rules may still apply.", ""]
    for key, item in sorted(sources.get("assets", {}).items()):
        attribution.extend([f"## {key}", f"- File: {item.get('title', 'Unknown')}",
            f"- Source page: {item.get('url', '')}", f"- License: {item.get('license', 'Unknown')} ({item.get('license_url', '')})",
            f"- Author: {item.get('author', 'Not stated')}", f"- Bundled path: {item.get('path', '')}", ""])
    (IDENTITY / "ATTRIBUTION_REAL_ASSETS.md").write_text("\n".join(attribution), encoding="utf-8")
    print(json.dumps(sources["summary"], ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    sys.exit(main())
