import importlib.util
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "tools" / "sync_verified_identity_assets.py"
spec = importlib.util.spec_from_file_location("sync_verified_identity_assets", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_normalization_is_accent_insensitive():
    assert module.norm("São Paulo Futebol Clube") == "sao paulo futebol clube"


def test_asset_candidate_must_look_like_a_crest_or_logo():
    assert module.has_mark_context("File:Palmeiras logo.svg")
    assert module.has_mark_context("File:Flag of Brazil.svg", "Official national football team crest")
    assert not module.has_mark_context("File:Palmeiras stadium photo.jpg", "Football stadium exterior")


def test_license_metadata_is_recorded_without_filtering_asset_eligibility():
    assert module.license_metadata("CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/") == ("CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/")
    assert module.license_metadata("All rights reserved", "") == ("All rights reserved", "")
    assert module.license_metadata("", "") == ("Not stated", "")


def test_matcher_rejects_unrelated_club_and_accepts_named_crest():
    assert module.match_score("File:Palmeiras logo.svg", "Sociedade Esportiva Palmeiras", ["Palmeiras"], "club") >= 45
    assert module.match_score("File:Real Madrid logo.svg", "Palmeiras", [], "club") == 0


def test_catalog_target_builder_covers_all_catalog_clubs():
    catalog = {
        "clubs": {"CLUB_1": {"id": "CLUB_1", "name": "Clube Um"}, "CLUB_2": {"id": "CLUB_2", "name": "Clube Dois"}},
        "associations": {"BRA": {"name": "Brasil"}},
        "national_teams": {"BRA": {"id": "NT_BRA", "country_id": "BRA"}},
        "leagues": {"BRA-1": {"name": "Série A"}},
        "competitions": {"LIBERTADORES": {}},
        "confederations": {"CONMEBOL": {}},
    }
    targets = module.build_targets(catalog)
    keys = {(kind, entity_id) for kind, entity_id, _, _ in targets}
    assert ("club", "CLUB_1") in keys and ("club", "CLUB_2") in keys
    assert ("national_team_crest", "NT_BRA") in keys
    assert ("league", "BRA-1") in keys
    assert ("competition", "LIBERTADORES") in keys
    assert ("confederation", "CONMEBOL") in keys


def test_http_json_uses_persistent_cache_without_network(tmp_path, monkeypatch):
    import hashlib
    url = "https://commons.wikimedia.org/w/api.php?test=cache"
    cache_file = tmp_path / (hashlib.sha256(url.encode("utf-8")).hexdigest() + ".json")
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    cache_file.write_text('{"cached": true}', encoding="utf-8")
    monkeypatch.setattr(module, "HTTP_CACHE", tmp_path)
    monkeypatch.setattr(module.urllib.request, "urlopen", lambda *a, **k: (_ for _ in ()).throw(AssertionError("network must not be called")))
    assert module.http_json(url) == {"cached": True}


def test_http_json_retries_http_429_and_caches_success(tmp_path, monkeypatch):
    import io
    import json
    import urllib.error
    from email.message import Message

    url = "https://commons.wikimedia.org/w/api.php?test=429"
    monkeypatch.setattr(module, "HTTP_CACHE", tmp_path)
    monkeypatch.setattr(module, "MIN_HTTP_INTERVAL", 0)
    monkeypatch.setattr(module, "_LAST_HTTP_REQUEST", 0)
    monkeypatch.setattr(module.time, "sleep", lambda _seconds: None)
    calls = {"n": 0}

    class Response:
        headers = {"Content-Type": "application/json"}
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self): return json.dumps({"ok": True}).encode("utf-8")

    def fake_urlopen(_request, timeout=30):
        calls["n"] += 1
        if calls["n"] == 1:
            headers = Message()
            headers["Retry-After"] = "0"
            raise urllib.error.HTTPError(url, 429, "Too Many Requests", headers, io.BytesIO(b"rate limited"))
        return Response()

    monkeypatch.setattr(module.urllib.request, "urlopen", fake_urlopen)
    assert module.http_json(url, attempts=2) == {"ok": True}
    assert calls["n"] == 2
    assert module.http_json(url, attempts=2) == {"ok": True}
    assert calls["n"] == 2
