import importlib.util
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "tools" / "sync_verified_identity_assets.py"
spec = importlib.util.spec_from_file_location("sync_verified_identity_assets", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_normalization_is_accent_insensitive():
    assert module.norm("São Paulo Futebol Clube") == "sao paulo futebol clube"


def test_asset_candidate_must_look_like_a_crest_or_logo():
    assert module.has_mark_context("File:Palmeiras logo.svg")
    assert module.has_mark_context("File:Flag of Brazil.svg", "Official national football team crest")
    assert not module.has_mark_context("File:Palmeiras stadium photo.jpg", "Football stadium exterior")


def test_license_metadata_is_recorded_without_filtering_asset_eligibility():
    assert module.license_metadata("CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/") == ("CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/")
    assert module.license_metadata("All rights reserved", "") == ("All rights reserved", "")
    assert module.license_metadata("", "") == ("Not stated", "")


def test_matcher_rejects_unrelated_club_and_accepts_named_crest():
    assert module.match_score("File:Palmeiras logo.svg", "Sociedade Esportiva Palmeiras", ["Palmeiras"], "club") >= 45
    assert module.match_score("File:Real Madrid logo.svg", "Palmeiras", [], "club") == 0


def test_catalog_target_builder_covers_all_catalog_clubs():
    catalog = {
        "clubs": {"CLUB_1": {"id": "CLUB_1", "name": "Clube Um"}, "CLUB_2": {"id": "CLUB_2", "name": "Clube Dois"}},
        "associations": {"BRA": {"name": "Brasil"}},
        "national_teams": {"BRA": {"id": "NT_BRA", "country_id": "BRA"}},
        "leagues": {"BRA-1": {"name": "Série A"}},
        "competitions": {"LIBERTADORES": {}},
        "confederations": {"CONMEBOL": {}},
    }
    targets = module.build_targets(catalog)
    keys = {(kind, entity_id) for kind, entity_id, _, _ in targets}
    assert ("club", "CLUB_1") in keys and ("club", "CLUB_2") in keys
    assert ("national_team_crest", "NT_BRA") in keys
    assert ("league", "BRA-1") in keys
    assert ("competition", "LIBERTADORES") in keys
    assert ("confederation", "CONMEBOL") in keys
