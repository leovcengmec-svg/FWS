# Football World Simulator — V227 Visual Polish (V226 Android foundation)

## Direction of the Android experience

V227 refines the Android presentation around the actual FWS concept: one integrated career in which the user begins as an investor, earns capital, acquires and manages clubs, and may later accept national-team invitations based on career prestige. Club and selection are not separate starting modes.

The new-game screen intentionally offers only:
- **Iniciar normal** — start as an investor with a small initial capital.
- **Criar clube do zero** — found a club and enter the same integrated world/career.

## Visual and navigation work

- Football-first home screen with a drawn pitch background, an FWS brand mark, green/gold palette and compact icon-led actions.
- Redesigned career dashboard with a season/career hero panel, capital, prestige, ownership metrics, active career entity, and a prominent season-advance action.
- Country → national team/leagues → league → clubs navigation using the bundled world catalog.
- 194 authentic national flag designs are bundled as optimized offline PNGs and mapped to association IDs; the remaining 17 associations use Unicode flag fallbacks where supported (including a subdivision flag for Wales).
- Generated ID-in-shield PNG placeholders were removed from the UI asset bundle. Club/league/competition detail cards explicitly mark official artwork as unverified until authentic, mapped assets are supplied.
- `identity/verified_assets.json` is an allowlist: the app will only load an image registered there, so an arbitrary placeholder cannot silently be presented as official artwork.
- Club creation form supports country selection and Brazilian state selection; it calls the existing V225 `CreateClubCareer` logic.
- Normal player-facing screens no longer display raw engine JSON or V225/V226 runtime status. Diagnostics remain under Settings.
- Large global club list is searchable and limited to 100 rendered results at once to avoid inflating thousands of views simultaneously.
- Existing V225 save engine remains the source of truth; save data remains on device.

## Starting capital and early progression

A **new normal career** starts with `3.00` in the game's existing monetary units (shown as `R$ 3,00 mi` in the UI). This is intentionally below the current lowest club market values. Three career-income opportunities can be completed once each per season:
- Análise de mercado — `0.65`
- Captação de patrocínio — `0.95`
- Consultoria de gestão — `0.75`

Each completed activity is recorded in the investor finance/history ledgers and adds to the investor's capital. Repeating an opportunity in the same season is rejected. The next season unlocks the opportunities again. After club acquisition, the existing V225 club economy and profit-distribution logic remain authoritative.

## Bundled engine dependencies

The Android Python runtime now bundles the required V225 data dependencies:
- `data/global_world_catalog.json`
- `data/global_league_tier_policy.json`
- `data/v172_4_brazil_state_database.json`

The Brazil state database is required by the existing V225 zero-to-club creation flow and was absent from the previous Android Python bundle. It is now included from the official V225 package, rather than replaced with invented data.

## Identity artwork audit

The earlier 6,325 PNG identity files were generated placeholder badges (for example, a competition abbreviation inside a generic square), not authentic official artwork. They were removed from the display bundle. This update adds 194 offline PNG national flags rendered from the open-source Worldflags package, mapped to the world catalog's association IDs; 17 associations use Unicode flag fallbacks where the local source did not include a matching national/subdivision flag. Source attribution and license are recorded in `assets/identity/ATTRIBUTION_WORLD_FLAGS.md`. Authentic official crests for all 5,530 clubs, national-team emblems, league logos and competition marks are not included in this package; the interface labels these missing identities clearly, and `AssetResolver` only loads assets explicitly registered in `identity/verified_assets.json`. This update does not claim that official club/competition art is complete.

## Identity and gameplay constraints preserved

- 211 associations, 211 national teams, 353 leagues and 5,530 catalog clubs.
- No individual player registration, squad or player-transfer system.
- National-team access remains invitation/prestige based.
- Brazilian club creation uses the existing state competition structure.
- The UI does not invent missing clubs to fill catalog gaps.

## Validation status

Runtime API checks completed locally for: fresh career initialization and initial capital, opportunity rewards, one-completion-per-season enforcement, finance summary, club-market affordability, Brazil zero-to-club creation, dynamic club detail and ownership persistence.

The Android APK must still be built by the existing GitHub Actions workflow and tested on-device. A successful Python/runtime check is not a substitute for a successful Android build or device playtest.

## Integração adicional do motor (29/09/2026)

- O adaptador Android agora expõe a camada de gestão de clubes V195 através de `club_management_status` e `manage_owned_club`.
- A tela de gestão de clubes permite registrar foco estratégico e decisões administrativas, sempre exigindo que o clube pertença à carreira ativa.
- O runtime expõe também `league_standings` para ler tabelas efetivamente produzidas pelo simulador e `world_activity_summary` para resumir a evolução persistida.
- As operações passam pelo motor Python incluído no pacote; a camada Java não replica as regras do jogo.
- A integração continua em andamento: a presença dos módulos e dos contratos Android não deve ser confundida com validação de todas as mecânicas, temporadas ou funcionamento em dispositivo.


### Integração adicional da interface (29/09/2026)
- A página Mundo passa a consultar o resumo de atividade persistido: temporada atual, partidas registradas e temporadas concluídas.
- A página de cada liga consulta a classificação real gravada pelo motor após simulação, mostrando posição, pontos, jogos e saldo de gols para até 10 equipes no quadro compacto; o catálogo completo de clubes continua disponível abaixo.
- Antes da primeira simulação, a tela informa que a classificação ainda não foi gerada; não cria tabela fictícia.
- A temporada mundial ainda precisa de uma decisão de integração entre o adaptador de carreira e o motor global V152/V164. Não se considera concluída a integração do motor até essa conexão e suas dependências serem resolvidas.
- Não foram executados testes completos, build Android ou teste em dispositivo nesta etapa.

### Integração da temporada global (29/09/2026)
- `advance_season` agora delega o ciclo anual ao motor V152, que coordena as fases globais de clubes, competições intercontinentais, torneio mundial quando aplicável, seleções e calendário.
- Após a fase esportiva, a camada Android liquida a economia dos clubes, retorno dos clubes pertencentes ao investidor, economia das seleções e eventos trimestrais, sem chamar o avanço antigo em seguida.
- O adaptador registra no histórico o estado global e as configurações pendentes reportadas pelo motor. Pendências de catálogo não devem ser mascaradas como temporada integralmente validada.
- Esta alteração foi verificada apenas por compilação sintática Python; não foram executados uma temporada real, a suíte completa, o build Android nem teste em dispositivo. A integração deve ser validada antes de ser considerada concluída.


### Integração do motor global V164

O adaptador de carreira encaminha o avanço de temporada para `V164GlobalSeasonMotor`, que encapsula o V152 e valida a cadeia de fases antes de aceitar a temporada. O motor possui rollback atômico quando uma validação falha; por isso, configurações insuficientes podem bloquear o avanço em vez de produzir uma temporada parcialmente integrada. A liquidação econômica continua separada no adaptador Android e ainda exige validação ponta a ponta.


### V226 integration continuation — club management season close
- The V164 global season adapter now closes the V195 club-management performance cycle for each investor-owned club after the completed season's sporting/economic results are settled.
- The completed season is passed explicitly to V194, so management history is associated with the season that just closed. Strategic-focus effects are applied after that season and therefore prepare the club for the next campaign.
- The season response reports the number of owned clubs reviewed and the resulting management records. This wiring is implemented but still awaits full engine regression, Android compilation, and device validation.


### V226 integration continuation — autonomous world and legacy closure

The Android season adapter now closes V205 (world events, reactions, memory and narrative) and V210 (history eras, legacy records, Hall of Fame and career legacy) after the global V164 sporting cycle and seasonal financial settlement. Both integrations receive the completed season explicitly and already guard against duplicate closure for the same season. The advance-season response returns both reports, and the world activity endpoint exposes their persisted status/cycle counts. This is an integration step, not a claim that the full game has passed end-to-end validation.


### Selection management integration (V226 continuation)
The Android runtime now exposes selection management state and persists aggregate strategy/intensity/rotation and preparation-focus decisions through V198, part of the V196–V200 selection career chain. Important lifecycle safeguard: the UI does not call `V200.manage()` because the current V200 snapshot path calls `performance.season_close()`; tactical preference edits therefore use the V198 decision engine directly and do not close a season. This is structural integration, not yet validated by a full Android build or season simulation.

### Selection contract lifecycle integration (V226 continuation)
- Added Android actions to renew the current national-team contract for one season or leave the appointment while preserving career/contract history.
- Added a selection-performance season-close summary to the global season response, evaluated against the completed season before the calendar advances.
- Contract expiry is evaluated against the next season after the global year changes, and its status is included in the season-closure ledger. No match outcomes or prestige gains are fabricated by this closure step.
- Python syntax verification passed. Android compilation, full engine regression, season simulation, and device validation have not yet been run.


### Integração transversal: transação de temporada e salvamento seguro (29/09/2026)
- O ciclo completo chamado pela carreira Android agora só persiste o novo estado depois de concluídas as fases esportivas, liquidação econômica, gestão dos clubes próprios, avaliação da seleção, Mundo Vivo e História/Legado. Uma falha antes da persistência mantém o save anterior.
- `engine.save_io.save_world` escreve o JSON em arquivo temporário no mesmo diretório, sincroniza os dados e substitui o destino com `os.replace`, evitando que uma interrupção durante a gravação deixe o save principal truncado.
- Isso protege a fronteira de persistência, mas não comprova que todos os sistemas do motor estão semanticamente integrados. A compilação sintática Python foi verificada; não foram executados testes de temporada, regressão completa, build Android ou teste em dispositivo, conforme a decisão de reservar a bateria completa para depois da integração.

### Selection-career lifecycle integration (V226 incremental update)
- The Android invitation endpoint continues to use V131's existing eligibility/appointment flow, while mirroring eligible invitations into the V196 offer ledger.
- Accepting a national-team invitation now updates the V196 offer status and creates the corresponding V197 contract if no active contract exists, while retaining V131 unified-career role synchronization.
- Leaving a national-team role closes the V197 contract, preserves career history, clears the active selection, and resynchronizes unified-career roles.
- This is a code integration step only. It has not yet been validated by a full engine regression run, Android build, or device test.

### Integração transversal adicional — carreira de seleções

- Convites exibidos no Android agora oferecem ações explícitas de aceitar ou recusar.
- A recusa passa pelo ciclo V196 e é persistida no histórico da carreira.
- Ao trocar de seleção, o contrato anterior é encerrado antes de criar o novo vínculo, evitando duas seleções com contrato ativo para o mesmo treinador.
- Ao encerrar voluntariamente a carreira de seleção, a oferta/convite ativa recebe estado de encerramento e a função anterior permanece no histórico.
- Esta etapa foi verificada por compilação sintática de todos os módulos Python. A compilação Android, testes completos de temporada e testes em aparelho continuam pendentes.

### V226 integration increment — consequential club-board decisions

The V192 club-board engine now validates supported decision types and applies bounded changes to the club's aggregate attributes: infrastructure investment improves infrastructure quality and management readiness; commercial expansion improves commercial strength; financial consolidation improves a stability indicator without fabricating cash or changing debt ledgers; sporting development improves aggregate sporting strength and management maturity. Every decision records its season and effects in the club and history ledgers. This remains a targeted integration change, not a claim that the full Android game has passed end-to-end testing.


### Correção crítica de desempenho do mundo brasileiro (29/09/2026)
- `BRA-STATE-ONLY` é tratado como cadastro de clubes sem participação estadual anual confirmada, não como uma liga de todos contra todos. Os clubes permanecem no mundo e podem receber vínculo competitivo quando elegíveis; não são eliminados do catálogo.
- A integridade do mundo agora reconhece esses registros como fora da pirâmide até que a participação seja confirmada.
- Verificação local: 13 testes do adaptador passaram (incluindo 2 subtestes). Uma temporada real fechou em 26,47 s, avançou de 2026 para 2027, reportou status `closed`, zero configurações pendentes e 77.736 partidas históricas.
- O save foi otimizado para JSON UTF-8 compactado com gzip e gravação atômica; saves antigos em JSON sem compressão continuam legíveis e são migrados no próximo salvamento. Em uma temporada real, o arquivo persistido ficou com 5.341.852 bytes (aprox. 5,1 MiB), mantendo as 77.736 partidas históricas. A temporada fechou em 21,18 s, avançou 2026→2027 e retornou zero configurações pendentes.
- O APK não foi compilado nesta sessão porque o ambiente local não tem Gradle instalado. O workflow GitHub Actions incluído no ZIP executa a compilação e publica o APK de depuração como artefato; a confirmação final de instalação/execução precisa vir desse build e do aparelho Android.


## Atualização de identidade visual V227 — sincronização de imagens reais

- A interface agora mantém a bandeira nacional como imagem principal da seleção e sobrepõe o emblema real verificado quando ele existir no manifesto.
- As indicações de identidade pendente deixam de aparecer quando há um recurso gráfico verificado carregável.
- Foi incluído `tools/sync_verified_identity_assets.py`, que procura imagens no Wikimedia Commons, valida o vínculo com a entidade e verifica a licença antes de incorporar o arquivo.
- O sincronizador rejeita licenças não comerciais e sem obras derivadas, converte os recursos para WebP compacto e registra atribuição e origem.
- GitHub Actions executa um lote prioritário em push/PR e a varredura completa do catálogo quando iniciada manualmente em **Actions → FWS V226 Android Validation → Run workflow**. O APK compilado e o ZIP com os recursos encontrados são publicados como artefatos.
- O ambiente de edição desta sessão não consegue resolver DNS para baixar os binários da web diretamente; por isso, o pacote entregue inclui a sincronização automática para o runner do GitHub, que tem acesso à Internet. Nenhum emblema não obtido foi declarado como já incluído.
- Limite de entrega: cada APK/ZIP individual deve permanecer abaixo de 25 MB; o workflow verifica o tamanho do APK e separa o pacote-fonte em volumes se necessário.


### Ajuste V227 — busca de identidade sem filtro por categoria de licença

O sincronizador de imagens deixou de bloquear candidatos apenas porque a licença não é aberta ou não foi identificada. A seleção continua exigindo correspondência de identidade e contexto de escudo/logotipo; fonte, autor e licença declarada são registrados quando disponíveis. Isso é voltado ao pacote privado de uso pessoal e não concede direitos de redistribuição nem elimina direitos autorais ou marcas. A busca completa é executada pelo workflow manual do GitHub Actions.
