
## V226 career dashboard integration
- Club Dashboard now reads the live V131 career snapshot through the Android Python bridge.
- It displays capital, prestige/tier, owned clubs, active club and identity asset.
- Owned clubs can be appointed as the active managed club through `V131IntegratedCareer.activate_owned_club()`.
- Selection Dashboard now reads live prestige/tier, active selection, career history and invitation count.
- Selection invitations remain controlled by the authoritative V225 invitation rules.
- No individual-player or transfer system was introduced.
### V226.1 build compatibility correction
- Corrected Android JSON iteration to use the Android `JSONObject.keys()` API.
- Corrected the Chaquopy Java bridge to use `PyObject.callAttr(...)`, which is the supported Chaquopy Java API for invoking module functions.
- No V225 engine logic, IDs, saves, or identity assets were changed.
- The package remains compatible with the closed-ZIP GitHub Actions build model.

