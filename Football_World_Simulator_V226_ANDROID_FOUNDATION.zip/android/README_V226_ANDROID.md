# Football World Simulator — V226 Android Foundation

V226 now contains the first real Android data integration layer while preserving the V225 simulation source as authoritative.

## Status

- V225 simulation source remains authoritative.
- Android UI is a presentation/navigation layer.
- `data/global_world_catalog.json` is bundled as a read-only Android asset projection of the V225 world catalog.
- No individual-player system or player-transfer system is introduced.
- Android build remains GitHub Actions based; Android Studio is not required.
- Official ZIP filename remains `Football_World_Simulator_V226_ANDROID_FOUNDATION.zip`.

## Real data exposed in Android

- 211 associations
- 211 national teams
- 353 leagues
- 5,530 clubs
- 14 competition definitions

The Android layer reads these records locally from the bundled catalog. It does not rewrite the V225 simulation rules.

## Integrated flows

- World → Associations: real V225 catalog entries.
- World → Leagues: real V225 league entries.
- World → Clubs: real V225 club entries.
- Club Mode → Club Market: real V225 club catalog.
- Selection Mode → Selection catalog/status: real V225 national-team count; invitation eligibility remains owned by the V225 prestige/reputation engine.

## Boundary

The match simulation, economy mutations, save mutation, prestige calculations, and autonomous world progression are not duplicated in Android. They remain pending the runtime bridge/integration layer.


### V226 — runtime Python integrado

O V226 agora inclui o próprio código Python do motor V225 dentro do APK por meio do Chaquopy. A camada Android não reimplementa as regras: `FwsPythonRuntime` chama `runtime_api.py`, que instancia `WorldSimulator`, `V131IntegratedCareer` e as rotinas existentes do V225. A sessão é persistida no armazenamento privado do aplicativo.

Fluxos reais adicionados:
- consulta do estado do motor V225;
- inicialização de uma sessão nova usando o catálogo canônico;
- persistência da sessão;
- simulação da temporada seguinte pelo `WorldSimulator` V225;
- retorno de ano, quantidade de ligas processadas/ignoradas e estado da carreira.

O primeiro teste local da ponte executou 2026→2027, processando 348 ligas e ignorando 5 por insuficiência de clubes, sem criar clubes fictícios. O APK oficial desta alteração ainda depende da execução do GitHub Actions.


### V226 career runtime integration
- New Game can initialize/reset a real V225 save through `V131IntegratedCareer`.
- Club Mode reads the real V225 ownership/investor layer and exposes club market entries with the motor's actual market value and capital eligibility.
- Buying a club calls `InvestorCareer.buy_club()` directly; Android does not reproduce ownership rules.
- Selection Mode reads real invitation eligibility from `SelectionCareer` and accepts invitations through the V225 career layer.
- Career state is persisted in the existing V225 save schema.
- No individual player registry or transfer system is introduced.

### V226 visual identity pack
The world catalog now carries a stable visual-identity layer for all core entities: 5,530 clubs, 353 leagues, 211 associations/countries, 211 national teams, 14 competition definitions and 6 confederations. Asset references use stable entity IDs and portable `identity/...` paths.

The current package guarantees 100% visual coverage using generated fallback badges for clubs, leagues, national teams, competitions and confederations. Country entries additionally expose their ISO alpha-2 code and Android flag-emoji fallback. These generated assets are intentionally marked as fallbacks/placeholders so official or licensed assets can later replace them without changing any engine IDs or save data.

No individual-player assets or player system were introduced.

### V226 identity visual integration
The Android presentation layer now resolves the portable identity assets by stable domain IDs. The bundled asset set covers 5,530 clubs, 353 leagues/divisions, 211 countries/associations, 211 national teams, 14 competitions and 6 confederations. World lists display the corresponding visual asset, club market cards display club crests, and selection invitations display the national-team identity. The asset registry remains separate from the V225 simulation engine.

### V226.2 — New Game runtime hardening
- Removed the previous dynamic injection of the V225 career button from `MainActivity`.
- The career initialization button is now declared directly in `screen_new_game.xml`.
- Opening New Game no longer initializes Python/Chaquopy as a side effect.
- `MainActivity.showNewGame()` now binds the screen defensively and provides a programmatic fallback screen if layout inflation or view binding fails.
- The V225 runtime is invoked only by the explicit career initialization action or by downstream screens that actually request engine data.
- No V225 simulation logic or save schema was changed.
