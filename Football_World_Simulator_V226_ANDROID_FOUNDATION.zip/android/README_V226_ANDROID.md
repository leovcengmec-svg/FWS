# Football World Simulator — Android build and test notes

This Android project uses the V225 Python engine through Chaquopy. The user-facing UI has been refined for the V227 visual-polish pass while the delivery ZIP keeps its official filename.

## Build

From GitHub Actions, run **FWS V226 Android Validation**. The workflow runs the Python runtime integration tests and builds the debug APK. The local environment used for this package did not include the Android SDK/Gradle, so this package's APK build has not been claimed as successful.

## Visual identity

- Green/dark stadium theme with gold accents and compact navigation.
- Career dashboard with season, capital, prestige, ownership and a prominent season-advance action.
- Country flags render from association ISO alpha-2 values using Android Unicode flag sequences; England, Scotland and Wales use Unicode subdivision flag sequences where supported. Northern Ireland uses the UK flag because there is no standard separate emoji flag.
- The old generated ID-in-shield images were placeholders, not authentic artwork, and have been removed from the display bundle. Missing club/league/competition crests are explicitly labelled as awaiting verified identity artwork.
- `assets/identity/verified_assets.json` is an allowlist. Only artwork registered there can be loaded as a logo.

## World data

211 associations, 211 national teams, 353 leagues and 5,530 clubs remain in the world catalog. No individual player or transfer system has been introduced.

See the root `README_V226_ANDROID.md` for the full change log and validation notes.
