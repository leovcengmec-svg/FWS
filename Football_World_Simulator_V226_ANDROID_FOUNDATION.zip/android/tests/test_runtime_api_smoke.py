"""Integration smoke tests for the Android adapter over the V225 engine."""
import json
import os
import tempfile
import unittest

_TEST_HOME = tempfile.mkdtemp(prefix="fws-v226-smoke-")
os.environ["HOME"] = _TEST_HOME

import runtime_api  # noqa: E402


class AndroidRuntimeSmokeTests(unittest.TestCase):
    def setUp(self):
        self.summary = json.loads(runtime_api.reset_session())

    def test_save_io_reads_legacy_json_and_writes_compressed_atomic_save(self):
        from engine.save_io import load_world, save_world
        with tempfile.TemporaryDirectory(prefix="fws-save-io-") as directory:
            path = os.path.join(directory, "career.json")
            legacy = {"save_version": 8, "world": {"current_year": 2026}}
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(legacy, handle)
            self.assertEqual(load_world(path), legacy)
            updated = {"save_version": 8, "world": {"current_year": 2027}, "history": [1, 2, 3]}
            save_world(updated, path)
            with open(path, "rb") as handle:
                self.assertEqual(handle.read(2), b"\x1f\x8b")
            self.assertEqual(load_world(path), updated)
            self.assertEqual(sorted(os.listdir(directory)), ["career.json"])

    def test_new_career_has_starting_capital_and_global_world(self):
        self.assertGreater(self.summary["capital"], 0)
        self.assertEqual(self.summary["associations"], 211)
        self.assertEqual(self.summary["national_teams"], 211)
        self.assertEqual(self.summary["leagues"], 353)
        self.assertEqual(self.summary["clubs"], 5530)

    def test_brazil_state_registry_is_not_simulated_as_a_league(self):
        save = runtime_api._load()
        registry = save["world"]["leagues"].get("BRA-STATE-ONLY", {})
        self.assertEqual(registry.get("format"), "registry_only")
        self.assertEqual(registry.get("club_ids", []), [])
        # The entities remain in the global world, but are not fabricated into
        # one enormous league before their actual state competition is resolved.
        self.assertGreaterEqual(sum(
            1 for club in save["world"]["clubs"].values()
            if club.get("state_roster_status") in {
                "registry_or_annual_state_result_required", "registry_alias_state_only"
            }
        ), 500)
        self.assertFalse(any(
            club.get("league_id") == "BRA-STATE-ONLY"
            for club in save["world"]["clubs"].values()
        ))

    def test_opportunity_pays_once_and_updates_finances(self):
        before = json.loads(runtime_api.career_opportunities())
        opportunity = before["opportunities"][0]
        result = json.loads(runtime_api.complete_career_opportunity(opportunity["id"]))
        self.assertGreater(result["capital"], before["capital"])
        with self.assertRaises(ValueError):
            runtime_api.complete_career_opportunity(opportunity["id"])

    def test_club_market_returns_buyable_data_shape(self):
        market = json.loads(runtime_api.club_market(5))
        self.assertEqual(len(market["clubs"]), 5)
        self.assertIn("market_value", market["clubs"][0])
        self.assertIn("can_buy", market["clubs"][0])

    def test_finance_and_history_endpoints_return_valid_json(self):
        finance = json.loads(runtime_api.finance_status())
        history = json.loads(runtime_api.history_summary())
        self.assertIn("capital", finance)
        self.assertIn("matches", history)

    def test_selection_management_is_bound_to_active_national_team(self):
        save = runtime_api._load()
        team_id = next(iter(save["world"]["national_teams"]))
        save.setdefault("careers", {}).setdefault("selection", {})["current_team_id"] = team_id
        from engine.save_io import save_world
        save_world(save, runtime_api.SAVE_PATH)
        result = json.loads(runtime_api.manage_selection("development", 65, "experimental", "development"))
        refreshed = runtime_api._load()["world"]["national_teams"][team_id]
        self.assertEqual(refreshed["selection_management"]["strategy"], "development")
        self.assertEqual(refreshed["selection_preparation"]["focus"], "development")
        self.assertTrue(result["ok"])

    def test_selection_management_requires_active_appointment(self):
        save = runtime_api._load()
        save.setdefault("careers", {}).setdefault("selection", {})["current_team_id"] = None
        from engine.save_io import save_world
        save_world(save, runtime_api.SAVE_PATH)
        with self.assertRaisesRegex(ValueError, "nenhuma seleção está sob gestão"):
            runtime_api.manage_selection("development", 65, "experimental", "development")

    def test_season_gate_rejects_table_rows_for_missing_clubs(self):
        save = runtime_api._load()
        save.setdefault("history", {})["latest_tables"] = {
            "LEAGUE-TEST": [{"club_id": "MISSING-CLUB", "points": 0}]
        }
        with self.assertRaisesRegex(ValueError, "league_table_club_missing_from_world:LEAGUE-TEST"):
            runtime_api._validate_integrated_state(save, completed_season=2025, expected_next_year=2026)

    def test_integrated_state_gate_rejects_broken_career_references(self):
        save = runtime_api._load()
        save.setdefault("careers", {}).setdefault("investor", {})["owned_clubs"] = ["MISSING-CLUB"]
        with self.assertRaisesRegex(ValueError, "owned_club_missing_from_world"):
            runtime_api._validate_integrated_state(save)

    def test_integrated_state_gate_rejects_selection_career_mismatch(self):
        save = runtime_api._load()
        team_id = next(iter(save["world"]["national_teams"]))
        save.setdefault("careers", {}).setdefault("selection", {})["current_team_id"] = team_id
        with self.assertRaisesRegex(ValueError, "active_selection_career_mismatch"):
            runtime_api._validate_integrated_state(save)

    def test_integrated_state_gate_rejects_created_club_not_owned(self):
        save = runtime_api._load()
        save.setdefault("careers", {}).setdefault("investor", {})["created_clubs"] = ["NOT-OWNED"]
        with self.assertRaisesRegex(ValueError, "created_club_missing_from_world"):
            runtime_api._validate_integrated_state(save)

    def test_club_management_decisions_reach_canonical_fields(self):
        created = json.loads(runtime_api.create_club_from_zero(
            "Clube Gestão", "ARG", "Cidade Teste", ""
        ))
        club_id = created["club_id"]
        before = json.loads(runtime_api.club_detail(club_id))
        runtime_api.manage_owned_club(club_id, focus="consolidation", decision="invest_infrastructure")
        after = json.loads(runtime_api.club_detail(club_id))
        self.assertGreaterEqual(after.get("infrastructure_score", 0), before.get("infrastructure_score", 0))
        self.assertEqual(after.get("strategic_focus"), "consolidation")

    def test_create_club_from_zero_repairs_existing_investor_ledgers(self):
        for country_id, state_code in (("ARG", ""), ("BRA", "ES")):
            with self.subTest(country_id=country_id):
                result = json.loads(runtime_api.create_club_from_zero(
                    f"Clube Teste {country_id}", country_id, "Cidade Teste", state_code
                ))
                club_id = result["club_id"]
                save = runtime_api._load()
                investor = save["careers"]["investor"]
                self.assertIn(club_id, investor["owned_clubs"])
                self.assertIn(club_id, investor["created_clubs"])
                self.assertIn(club_id, save["world"]["clubs"])


if __name__ == "__main__":
    unittest.main()
