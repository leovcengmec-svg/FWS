import json
import struct
from pathlib import Path

ANDROID = Path(__file__).resolve().parents[1]
ASSETS = ANDROID / "app" / "src" / "main" / "assets"
IDENTITY = ASSETS / "identity"


def test_country_flag_assets_cover_world_catalog_without_fake_crests():
    catalog = json.loads((ASSETS / "global_world_catalog.json").read_text(encoding="utf-8"))
    manifest = json.loads((IDENTITY / "verified_assets.json").read_text(encoding="utf-8"))
    fallbacks = json.loads((IDENTITY / "flag_fallbacks.json").read_text(encoding="utf-8"))
    associations = catalog["associations"]
    png_ids = {p.stem for p in (IDENTITY / "countries").glob("*.png")}

    assert len(associations) == 211
    assert len(png_ids) == 194
    assert len(fallbacks["fallback_associations"]) == 17
    assert png_ids.isdisjoint({item["id"] for item in fallbacks["fallback_associations"]})
    assert png_ids | {item["id"] for item in fallbacks["fallback_associations"]} == set(associations)

    # The allowlist must contain only mapped country flags, also reused as context on national-team cards.
    for country_id in png_ids:
        expected_path = f"identity/countries/{country_id}.png"
        assert manifest["assets"][f"country:{country_id}"] == expected_path
        assert manifest["assets"][f"national_team:NT_{country_id}"] == expected_path
        assert (ASSETS / expected_path).is_file()
    assert not any(key.startswith(("club:", "league:", "competition:")) for key in manifest["assets"])


def test_flag_pngs_are_valid_and_lightweight_for_android():
    pngs = list((IDENTITY / "countries").glob("*.png"))
    assert len(pngs) == 194
    for path in pngs:
        data = path.read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n", path.name
        width, height = struct.unpack(">II", data[16:24])
        assert width == 192, (path.name, width, height)
        assert 60 <= height <= 192, (path.name, width, height)
        assert len(data) < 100_000, (path.name, len(data))
