# V226 foundation: no custom ProGuard rules yet.
