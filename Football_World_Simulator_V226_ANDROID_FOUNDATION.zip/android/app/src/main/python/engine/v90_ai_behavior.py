"""V90 AI/Behavior Engine.

Produces deterministic, simulation-only club behavior profiles and decision
intents. It does not move cash, ownership, player data or media state.
"""
from __future__ import annotations
import hashlib
from copy import deepcopy

class AIBehaviorEngine:
    VERSION = "V90"
    SCHEMA = 1
    INTENTS = ("compete", "develop", "consolidate", "rebuild", "scout")

    def __init__(self, catalog, seed=90):
        self.catalog = catalog
        self.seed = int(seed)

    def _noise(self, key):
        d=hashlib.sha256(f"{self.seed}:{key}".encode()).digest()
        return int.from_bytes(d[:4], "big") / 0xFFFFFFFF

    @staticmethod
    def _clamp(v, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(v))), 3)

    def profile(self, club, season=2026):
        strength=float(club.get("sporting_strength", club.get("prestige",50)))
        prestige=float(club.get("prestige",50))
        stability=float(club.get("management_stability",50))
        youth=float(club.get("youth_development_capacity",40))
        scouting=float(club.get("scouting_capacity",40))
        n=self._noise(f"profile:{club.get('id')}:{season}")
        ambition=self._clamp(strength*.40+prestige*.35+stability*.10+n*15)
        development=self._clamp(youth*.55+scouting*.35+strength*.10)
        risk=self._clamp(65-stability*.45+(1-n)*18)
        patience=self._clamp(stability*.65+(100-risk)*.35)
        return {"club_id":club.get("id"),"season":int(season),"ambition":ambition,
                "development_bias":development,"risk_tolerance":risk,"patience":patience,
                "decision_seed":n}

    def decide(self, club, season=2026, standings=None):
        p=self.profile(club,season)
        strength=float(club.get("sporting_strength",club.get("prestige",50)))
        rank=None; field=None
        if standings:
            field=len(standings); rank=next((i+1 for i,x in enumerate(standings) if x.get("club_id")==club.get("id")),None)
        if rank and field:
            performance=(field-rank)/max(1,field-1)*100
        else: performance=25.0 + self._noise(f"performance:{club.get('id')}:{season}")*50.0
        gap=p["ambition"]-performance
        archetype=self._noise(f"archetype:{club.get('id')}:{season}")
        if strength<42 and p["patience"]>=52:
            intent="rebuild"
        elif p["risk_tolerance"]<34:
            intent="consolidate"
        elif p["development_bias"]>=58 and strength<68:
            intent="develop"
        elif gap>=15 and p["risk_tolerance"]>=48:
            intent="compete"
        elif archetype>=0.78:
            intent="compete"
        elif archetype<=0.12:
            intent="consolidate"
        elif archetype<=0.30:
            intent="rebuild"
        elif archetype<=0.52:
            intent="develop"
        else:
            intent="scout"
        priorities={"compete": {"sporting":.45,"scouting":.25,"youth":.15,"stability":.15},
                    "develop":{"sporting":.20,"scouting":.30,"youth":.40,"stability":.10},
                    "consolidate":{"sporting":.15,"scouting":.15,"youth":.20,"stability":.50},
                    "rebuild":{"sporting":.20,"scouting":.35,"youth":.30,"stability":.15},
                    "scout":{"sporting":.25,"scouting":.40,"youth":.20,"stability":.15}}[intent]
        return {"club_id":club.get("id"),"season":int(season),"intent":intent,
                "profile":p,"performance_index":round(performance,3),"gap":round(gap,3),
                "priorities":priorities,"effects_deferred_to":["V91","V92"]}

    def initialize_world(self, world_state, season=2026):
        clubs=self.catalog.get("clubs",{})
        decisions={}
        for cid,club in sorted(clubs.items()):
            row=world_state.get("leagues_state",{})
            standings=None
            lid=club.get("league_id")
            if lid in row and row[lid].get("standings"): standings=row[lid]["standings"]
            decisions[cid]=self.decide(club,season,standings)
        return {"schema":self.SCHEMA,"engine":"V90_AIBehavior","season":int(season),
                "clubs":len(decisions),"decisions":decisions,"status":"initialized"}

    def validate(self,state):
        errors=[]
        if state.get("engine")!="V90_AIBehavior": errors.append("wrong engine")
        if state.get("clubs")!=len(state.get("decisions",{})): errors.append("club count mismatch")
        for cid,row in state.get("decisions",{}).items():
            if cid not in self.catalog.get("clubs",{}): errors.append(f"unknown club {cid}")
            if row.get("intent") not in self.INTENTS: errors.append(f"invalid intent {cid}")
            for k in ("ambition","development_bias","risk_tolerance","patience"):
                if not 0<=float(row["profile"][k])<=100: errors.append(f"profile range {cid}:{k}")
        return errors
