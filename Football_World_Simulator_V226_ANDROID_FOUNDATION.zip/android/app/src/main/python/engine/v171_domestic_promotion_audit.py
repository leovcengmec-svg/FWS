"""V171 — Domestic Promotion/Relegation Integrity Audit."""
from __future__ import annotations
from copy import deepcopy
class V171DomesticPromotionAudit:
    VERSION='V171'; SCHEMA=1
    BRA_IDS=('BRA-BR-1','BRA-BR-2','BRA-BR-3','BRA-BR-4','BRA-BR-5','BRA-BR-6','BRA-ACCESS')
    def __init__(self,save): self.save=save
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def _ensure_brazil_schema(self):
        w=self._world(); leagues=w.setdefault('leagues',{})
        defs=[]
        for level,letter in [(1,'A'),(2,'B'),(3,'C'),(4,'D'),(5,'E'),(6,'F')]:
            defs.append((f'BRA-BR-{level}', f'Campeonato Brasileiro Série {letter}', level, 20 if level<=3 else 96))
        defs.append(('BRA-ACCESS','Divisão de Acesso Nacional',7,256))
        for lid,name,level,expected in defs:
            row=leagues.setdefault(lid, {'id':lid,'name':name,'country_id':'BRA','level':level,'tier':'national' if level<=6 else 'access','club_ids':[]})
            row.update({'id':lid,'name':name,'country_id':'BRA','level':level,'tier':'national' if level<=6 else 'access'})
            row.setdefault('club_ids',[])
            row['canonical_brazil_structure']=True
            row['expected_club_count']=expected
            row['population_status']='ready' if len(row['club_ids'])==expected else 'configuration_pending_verified_real_clubs'
            if level==7:
                row.update({'format':'two_legged_single_elimination','promotion_places':4,'promotion_target':'BRA-BR-6','rounds':6,'legs_per_tie':2})
            else:
                row.update({'promotion_places':4 if level>=3 else 0,'relegation_places':4,'relegation_target':f'BRA-BR-{level+1}' if level<6 else 'BRA-ACCESS','format':'double_round_robin' if level<=2 else 'mixed_groups_knockout'})
        # Migrate the existing verified 2026 Brazil D1-D4 aliases into the canonical A-D ids.
        alias_map={'BRA_D1':'BRA-BR-1','BRA_D2':'BRA-BR-2','BRA_D3':'BRA-BR-3','BRA_D4':'BRA-BR-4'}
        for old,new in alias_map.items():
            if old in leagues and new in leagues:
                moved=list(leagues[old].get('club_ids',[]))
                if moved:
                    for cid in moved:
                        if cid not in leagues[new].setdefault('club_ids',[]): leagues[new]['club_ids'].append(cid)
                        if cid in w.get('clubs',{}): w['clubs'][cid]['league_id']=new; w['clubs'][cid]['division']=leagues[new].get('level')
                    leagues[old]['club_ids']=[]
                    leagues[old]['deprecated_alias_for']=new
        w.setdefault('brazil_pyramid',{})['version']='V172_CANONICAL_BRAZIL_A_F_ACCESS'
        w['brazil_pyramid']['status']='population_pending' if any(len(leagues[x[0]].get('club_ids',[]))!=x[3] for x in defs) else 'ready'
        w['brazil_pyramid']['required_total_clubs']=20+20+20+96+96+96+256
        w['brazil_pyramid']['currently_populated']=sum(len(leagues[x[0]].get('club_ids',[])) for x in defs)
        return deepcopy(w['brazil_pyramid'])

    def _audit_country(self,country_id):
        w=self._world(); leagues=sorted([l for l in w.get('leagues',{}).values() if l.get('country_id')==country_id],key=lambda x:int(x.get('level',999))); e=[]
        membership={}
        for l in leagues:
            ids=list(l.get('club_ids',[]))
            if len(ids)!=len(set(ids)): e.append(f'duplicate_club_ids:{l.get("id")}')
            for cid in ids:
                if cid not in w.get('clubs',{}): e.append(f'missing_club:{l.get("id")}:{cid}')
                if cid in membership: e.append(f'club_in_multiple_leagues:{cid}')
                membership[cid]=l.get('id')
        if country_id=='BRA':
            # The canonical Brazil schema must exist even if catalog population is pending.
            ids={l.get('id') for l in leagues}
            missing=set(self.BRA_IDS)-ids
            if missing: e.append('brazil_schema_missing:'+','.join(sorted(missing)))
            canonical={l.get('id'):l for l in leagues}
            for lid in self.BRA_IDS[:6]:
                if lid not in canonical: continue
                expected=20 if int(canonical[lid].get('level',99))<=3 else 96
                if len(canonical[lid].get('club_ids',[])) not in (0,expected): e.append(f'brazil_field_size_invalid:{lid}:{len(canonical[lid].get("club_ids",[]))}')
            if 'BRA-ACCESS' in canonical and len(canonical['BRA-ACCESS'].get('club_ids',[])) not in (0,256): e.append('brazil_access_size_invalid')
        return {'country_id':country_id,'status':'PASS' if not e else 'FAIL','errors':e,'leagues':len(leagues),'clubs_counted':len(membership)}
    def run(self, season=None):
        self._ensure_brazil_schema()
        year=int(self._world().get('current_year',2026)-1 if season is None else season); reports=[]
        countries=sorted(self._world().get('countries',{}))
        for cid in countries: reports.append(self._audit_country(cid))
        errors=[f"{r['country_id']}:{x}" for r in reports for x in r['errors']]
        # Missing Brazil canonical leagues is a configuration/data closure issue, not a fabricated-club license.
        out={'version':self.VERSION,'schema':self.SCHEMA,'season':year,'status':'PASS' if not errors else 'PENDING_DATA','countries':len(reports),'country_reports':reports,'errors':errors,'player_layer_forbidden':True}
        self._history().setdefault('domestic_promotion_audits',[]).append(deepcopy(out));
        if 'players' in self._world() or 'player_transfers' in self._history(): raise ValueError('V171 player systems are forbidden')
        return deepcopy(out)
    def validate(self):
        e=[]
        for r in self._history().get('domestic_promotion_audits',[]):
            if r.get('status') not in ('PASS','PENDING_DATA'): e.append(f'invalid V171 status:{r.get("season")}')
        return e
