"""V199 — Selection performance, prestige and career consequences."""
from __future__ import annotations
from copy import deepcopy
class V199SelectionPerformance:
    VERSION='V199'
    def __init__(self,save): self.save=save; self.career=save.setdefault('careers',{}).setdefault('selection',{}); self.history=save.setdefault('history',{}).setdefault('selection_performance',[])
    @staticmethod
    def clamp(v): return max(0.0,min(100.0,round(float(v),4)))
    def record(self,team_id,result_quality,opponent_strength=50,competition='match',qualified=None,title=False):
        if team_id!=self.career.get('current_team_id'): raise ValueError('a seleção precisa estar sob gestão')
        rq=self.clamp(result_quality); opp=self.clamp(opponent_strength); delta=(rq-opp)*0.12 + (3.0 if title else 0.0) + (2.0 if qualified is True else -2.0 if qualified is False else 0.0)
        before=self.clamp(self.career.get('manager_prestige',0)); after=self.clamp(before+delta); self.career['manager_prestige']=after
        row={'version':self.VERSION,'season':self.save['world'].get('current_year'),'team_id':team_id,'competition':competition,'result_quality':rq,'opponent_strength':opp,'qualified':qualified,'title':bool(title),'prestige_before':before,'prestige_delta':round(after-before,4),'prestige_after':after}
        self.history.append(deepcopy(row)); self.career['history'].append(deepcopy(row)); return row
    def season_close(self,team_id=None):
        tid=team_id or self.career.get('current_team_id'); rows=[r for r in self.history if r.get('team_id')==tid and r.get('season')==self.save['world'].get('current_year')]
        avg=sum(r['result_quality'] for r in rows)/len(rows) if rows else 50.0
        return {'version':self.VERSION,'team_id':tid,'season':self.save['world'].get('current_year'),'matches':len(rows),'average_quality':round(avg,2),'prestige':self.clamp(self.career.get('manager_prestige',0))}
    def validate(self): return []
