"""V208 — Historical records and Hall of Fame, without individual players."""
from __future__ import annotations
from copy import deepcopy

class V208HallOfFame:
    VERSION='V208'
    def __init__(self,save):
        self.save=save; self.history=save.setdefault('history',{})
        self.hof=self.history.setdefault('hall_of_fame',{'clubs':[],'selections':[],'managers':[],'records':[]})

    def rebuild(self):
        rec=self.history.get('legacy_records',{}); clubs=rec.get('clubs',{})
        self.hof['clubs']=sorted([
            {'entity_id':cid,'name':d.get('name',cid),'titles':d.get('titles',0),'continental_titles':d.get('continental_titles',0),'promotions':d.get('promotions',0),'relegations':d.get('relegations',0)}
            for cid,d in clubs.items() if d.get('titles',0) or d.get('continental_titles',0)
        ], key=lambda x:(-int(x['titles']),-int(x['continental_titles']),x['entity_id']))
        self.hof['selections']=sorted([
            {'entity_id':tid,'name':d.get('name',tid),'cycles':d.get('cycles',0),'average_quality':d.get('average_quality',0)}
            for tid,d in rec.get('selections',{}).items() if d.get('cycles',0)
        ], key=lambda x:(-float(x['average_quality']),-int(x['cycles']),x['entity_id']))
        self.hof['managers']=self._manager_records()
        self.hof['records']=self._records()
        self.history['hall_of_fame_version']=self.VERSION
        return deepcopy(self.hof)

    def _manager_records(self):
        careers=self.save.get('careers',{}); out=[]
        sel=careers.get('selection',{}); hist=sel.get('history',[])
        if hist:
            out.append({'career':'selection','manager_id':'player','appointments':len([x for x in hist if x.get('type')=='selection_appointment' or x.get('started_season') is not None]),'prestige':round(float(sel.get('manager_prestige',0)),3)})
        inv=careers.get('investor',{}); tx=inv.get('transactions',[])
        if tx:
            out.append({'career':'investor','manager_id':'player','transactions':len(tx),'owned_clubs':len(inv.get('owned_clubs',[])),'cash':round(float(inv.get('cash',0)),2)})
        return out

    def _records(self):
        world=self.save.get('world',{}); clubs=world.get('clubs',{}); out=[]
        if clubs:
            richest=max(clubs.items(),key=lambda kv:float(kv[1].get('cash',0)))
            strongest=max(clubs.items(),key=lambda kv:float(kv[1].get('sporting_strength',0)))
            out += [{'type':'highest_cash','entity_id':richest[0],'value':round(float(richest[1].get('cash',0)),2)}, {'type':'highest_sporting_strength','entity_id':strongest[0],'value':round(float(strongest[1].get('sporting_strength',0)),3)}]
        return out

    def validate(self):
        return [] if isinstance(self.hof,dict) and all(k in self.hof for k in ('clubs','selections','managers','records')) else ['V208 invalid hall of fame']
