from dataclasses import dataclass
from .match_engine import MatchEngine

@dataclass
class KnockoutMatch:
    competition_id:str
    season:int
    round_no:int
    home_id:str
    away_id:str
    home_goals:int
    away_goals:int
    winner_id:str

class KnockoutTournament:
    def __init__(self, competition_id, season, clubs, engine, seed=0):
        self.competition_id=competition_id
        self.season=season
        self.clubs=clubs[:]
        self.engine=engine
        self.seed=seed
        self.matches=[]

    def _winner(self,a,b,round_no):
        r=self.engine.play(self.competition_id,self.season,round_no,a,b)
        if r.home_goals>r.away_goals: w=a
        elif r.away_goals>r.home_goals: w=b
        else:
            # Deterministic penalty shootout abstraction. No player simulation.
            score=(hash((self.seed,a["id"],b["id"],round_no,self.season)) & 1)
            w=a if score==0 else b
        self.matches.append(KnockoutMatch(
            self.competition_id,self.season,round_no,a["id"],b["id"],
            r.home_goals,r.away_goals,w["id"]))
        return w

    def run(self):
        pool=self.clubs[:]
        round_no=1
        while len(pool)>1:
            next_pool=[]
            for i in range(0,len(pool)-1,2):
                next_pool.append(self._winner(pool[i],pool[i+1],round_no))
            if len(pool)%2:
                next_pool.append(pool[-1])
            pool=next_pool
            round_no+=1
        return pool[0] if pool else None
