"""V92 Media + Reputation Engine.

Derives deterministic media narratives and reputation changes from sporting,
economic, cup and behavioral state. It does not alter economy or historical state.
"""
from __future__ import annotations
import hashlib

class V92MediaReputation:
    VERSION="V92"; SCHEMA=1
    EVENT_TYPES=("title_race","cup_run","promotion","relegation","financial_pressure","breakthrough","setback","routine")
    def __init__(self, catalog, seed=92): self.catalog=catalog; self.seed=int(seed)
    def _noise(self,key):
        d=hashlib.sha256(f"{self.seed}:{key}".encode()).digest()
        return int.from_bytes(d[:4],"big")/0xFFFFFFFF
    @staticmethod
    def _clamp(v,lo=0,hi=100): return round(max(lo,min(hi,float(v))),3)
    def _performance(self, club, standings=None):
        if standings:
            ids=[x.get("club_id") for x in standings]; cid=club.get("id")
            if cid in ids and len(ids)>1: return round((len(ids)-1-ids.index(cid))/(len(ids)-1)*100,3)
        return round(35+self._noise(f"perf:{club.get('id')}:{club.get('season',2026)}")*40,3)
    def assess(self, club, season=2026, standings=None, cup_wins=0):
        perf=self._performance(club,standings)
        strength=float(club.get("sporting_strength",club.get("prestige",50)))
        prestige=float(club.get("prestige",50))
        econ=club.get("last_economy",{}) or {}
        profit=float(econ.get("profit",0))
        distress=bool(club.get("economic_status") in ("distressed","critical") or econ.get("status") in ("distressed","critical"))
        intent=club.get("ai_intent",club.get("intent","consolidate"))
        if cup_wins>0 or perf>=85: et="cup_run" if cup_wins else "title_race"
        elif club.get("promoted") or perf>=70: et="promotion"
        elif club.get("relegated") or perf<=12: et="relegation"
        elif distress: et="financial_pressure"
        elif strength<45 and perf>=65: et="breakthrough"
        elif perf<=30: et="setback"
        else: et="routine"
        impact={"title_race":9,"cup_run":8,"promotion":7,"relegation":-9,"financial_pressure":-7,"breakthrough":6,"setback":-5,"routine":0}[et]
        reputation=self._clamp(prestige + perf*.18 + impact + (2 if profit>0 else -2 if profit<0 else 0))
        media_interest=self._clamp(15+strength*.30+abs(impact)*2.5+self._noise(f"media:{club.get('id')}:{season}")*12)
        sentiment=self._clamp(50+(perf-50)*.42+impact+(3 if intent=="compete" else 0),0,100)
        return {"club_id":club.get("id"),"season":int(season),"event_type":et,"media_interest":media_interest,"sentiment":sentiment,"reputation":reputation,"impact":impact,"cup_wins":int(cup_wins)}
    def generate(self, world_state, ai_state=None, season=2026):
        clubs=world_state.get("clubs",{})
        standings_by_league=world_state.get("leagues_state",{})
        cup_winners={}
        for row in world_state.get("cup_champions",{}).values():
            if row and isinstance(row,list):
                latest=row[-1]; cid=latest.get("club_id")
                if cid: cup_winners[cid]=cup_winners.get(cid,0)+1
        decisions=(ai_state or {}).get("decisions",{})
        reports={}; counts={k:0 for k in self.EVENT_TYPES}
        for cid,club in sorted(clubs.items()):
            c=dict(club); c["ai_intent"]=(decisions.get(cid) or {}).get("intent",c.get("ai_intent","consolidate")); c["season"]=season
            lid=c.get("league_id"); standings=standings_by_league.get(lid,{}).get("standings") if lid in standings_by_league else None
            row=self.assess(c,season,standings,cup_winners.get(cid,0)); reports[cid]=row; counts[row["event_type"]]+=1
        return {"schema":self.SCHEMA,"engine":self.VERSION,"season":int(season),"clubs":len(reports),"reports":reports,"event_counts":counts,"status":"generated"}
    def validate(self,state):
        errors=[]
        if state.get("engine")!=self.VERSION: errors.append("wrong engine")
        if state.get("clubs")!=len(state.get("reports",{})): errors.append("club count mismatch")
        for cid,r in state.get("reports",{}).items():
            if cid not in self.catalog.get("clubs",{}): errors.append(f"unknown club {cid}")
            if r.get("event_type") not in self.EVENT_TYPES: errors.append(f"invalid event {cid}")
            for k in ("media_interest","sentiment","reputation"):
                if not 0<=float(r[k])<=100: errors.append(f"range {cid}:{k}")
        return errors
