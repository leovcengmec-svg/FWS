"""Strategic governance layer for multi-season plans.

Turns a plan into measurable milestones and risk flags. It never creates cash
or changes a match directly; it only organizes and evaluates execution.
"""
class StrategicGovernance:
    MILESTONES = ("launch", "progress", "midpoint", "final")
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_governance", [])

    @staticmethod
    def _clamp(v, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(v))), 4)

    def evaluate(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs: raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else int(season)
        plan = club.get("strategic_plan")
        if not plan:
            return {"club_id": club_id, "season": season, "status": "no_plan"}
        start, end = int(plan["start_season"]), int(plan["end_season"])
        horizon = max(1, end-start+1)
        elapsed = max(0, min(horizon, season-start+1))
        expected = self._clamp(elapsed / horizon * 100.0)
        reviews = [r for r in plan.get("reviews", []) if int(r.get("season", -1)) <= season]
        actual = self._clamp(sum(float(r.get("execution", 0)) for r in reviews) / len(reviews) if reviews else 0.0)
        gap = round(actual-expected, 4)
        quality = self._clamp(club.get("strategic_quality", 50.0))
        risk = self._clamp(50.0 - gap*0.8 + (50.0-quality)*0.35)
        if risk >= 70: risk_level="high"
        elif risk >= 45: risk_level="medium"
        else: risk_level="low"
        if elapsed <= 1: milestone="launch"
        elif elapsed >= horizon: milestone="final"
        elif elapsed >= (horizon+1)//2: milestone="midpoint"
        else: milestone="progress"
        row={"club_id":club_id,"season":season,"milestone":milestone,
             "expected_progress":expected,"actual_execution":actual,"execution_gap":gap,
             "risk_score":risk,"risk_level":risk_level,"strategic_quality":quality}
        club["strategic_governance"] = row
        club.setdefault("strategic_governance_history", []).append(row)
        self.history.append(row)
        return row

    def snapshot(self, club_id):
        club=self.save.get("world",{}).get("clubs",{}).get(club_id)
        if not club: raise ValueError("clube inexistente")
        return club.get("strategic_governance", {"club_id":club_id,"status":"not_evaluated"})
