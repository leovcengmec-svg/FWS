class OwnershipSellerAgents:
    """Automated seller decisions for active ownership-market listings.

    V39 only decides whether to accept, reject, or counter an offer. It never
    moves cash or changes club ownership; final settlement remains V35.
    """
    DEFAULT_PROFILES = {
        'conservative': {'min_ratio': 1.00, 'counter_ratio': 0.96},
        'balanced': {'min_ratio': 0.92, 'counter_ratio': 0.88},
        'distressed': {'min_ratio': 0.75, 'counter_ratio': 0.70},
    }

    def __init__(self, save, marketplace, negotiation, profiles=None):
        self.save = save
        self.marketplace = marketplace
        self.negotiation = negotiation
        self.profiles = profiles or self.DEFAULT_PROFILES.copy()

    def _listing(self, listing_id):
        listing = self.marketplace._listing(listing_id)
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        return listing

    def _offer(self, offer_id):
        for offer in self.marketplace.offers:
            if offer['id'] == offer_id:
                return offer
        raise ValueError('oferta inexistente')

    def _reference_value(self, listing):
        club = self.save['world']['clubs'][listing['club_id']]
        return max(0.1, float(club.get('market_value', listing['asking_price']) or 0.1))

    def evaluate_offer(self, offer_id, profile='balanced'):
        offer = self._offer(offer_id)
        if offer['status'] != 'pending':
            raise ValueError('oferta não está pendente')
        listing = self._listing(offer['listing_id'])
        if listing.get('seller') == 'player':
            raise ValueError('decisão automática não substitui o vendedor jogador')
        if profile not in self.profiles:
            raise ValueError('perfil de vendedor inexistente')
        p = self.profiles[profile]
        reference = self._reference_value(listing)
        ratio = float(offer['price']) / reference
        if ratio >= float(p['min_ratio']):
            decision = 'accept'
            counter_price = None
        elif ratio >= float(p['counter_ratio']):
            decision = 'counter'
            counter_price = round(max(float(offer['price']) + 0.01,
                                      reference * float(p['min_ratio'])), 2)
        else:
            decision = 'reject'
            counter_price = None
        return {
            'offer_id': offer_id, 'listing_id': listing['id'],
            'profile': profile, 'reference_value': round(reference, 2),
            'offer_price': round(float(offer['price']), 2),
            'ratio': round(ratio, 4), 'decision': decision,
            'counter_price': counter_price,
        }

    def decide(self, offer_id, profile='balanced'):
        evaluation = self.evaluate_offer(offer_id, profile)
        if evaluation['decision'] == 'accept':
            return self.negotiation.accept_selected_offer(
                evaluation['listing_id'], offer_id)
        if evaluation['decision'] == 'reject':
            return self.marketplace.respond_offer(offer_id, 'reject')
        return self.negotiation.counter_offer(offer_id, evaluation['counter_price'])
