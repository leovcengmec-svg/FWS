class FinancialHealth:
    """V31: financial health, runway and risk indicators derived from existing cash-flow/liquidity data."""
    def __init__(self, save):
        from .investor_finance import InvestorFinance
        self.save = save
        self.finance = InvestorFinance(save)

    def _avg(self, key, weeks=8):
        rows = self.finance.history[-weeks:]
        if not rows:
            return 0.0
        return sum(float(r.get(key, 0.0)) for r in rows) / len(rows)

    def snapshot(self):
        c = self.finance.career
        cash = float(c.get('cash', 0.0))
        reserve = float(c.get('reserve', 0.0))
        available = self.finance.available_cash()
        avg_flow = self._avg('flow')
        avg_expenses = self._avg('expenses')
        avg_income = self._avg('income')
        runway = None if avg_expenses <= 0 else round(available / avg_expenses, 2)
        debt = float(self.finance.rules.get('weekly_financial_obligation', 0.0))
        debt_ratio = None if avg_income <= 0 else round(debt / avg_income, 4)
        if available <= 0 and avg_flow < 0:
            status = 'critical'
        elif avg_flow < 0:
            status = 'warning'
        elif runway is not None and runway < 12:
            status = 'attention'
        else:
            status = 'stable'
        return {
            'cash': round(cash, 2),
            'reserve': round(reserve, 2),
            'available_cash': available,
            'net_worth': self.finance.calculate_net_worth(),
            'average_weekly_income': round(avg_income, 2),
            'average_weekly_expenses': round(avg_expenses, 2),
            'average_weekly_flow': round(avg_flow, 2),
            'runway_weeks': runway,
            'weekly_debt_obligation': round(debt, 2),
            'debt_to_income': debt_ratio,
            'status': status,
        }

    def alerts(self):
        s = self.snapshot()
        alerts = []
        if s['available_cash'] <= 0:
            alerts.append('available_cash_zero')
        if s['average_weekly_flow'] < 0:
            alerts.append('negative_weekly_flow')
        if s['runway_weeks'] is not None and s['runway_weeks'] < 12:
            alerts.append('low_runway')
        if s['debt_to_income'] is not None and s['debt_to_income'] > 0.35:
            alerts.append('high_debt_service')
        return alerts
