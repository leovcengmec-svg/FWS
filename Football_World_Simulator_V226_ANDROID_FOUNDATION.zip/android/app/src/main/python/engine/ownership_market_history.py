class OwnershipMarketHistory:
    """V43 query/retention layer for ownership-market activity.

    Keeps the transaction/cycle history already produced by V35-V42 and adds
    deterministic summaries without changing settlement rules.
    """
    def __init__(self, save):
        self.save = save

    def transactions(self, club_id=None, status=None):
        rows = self.save.setdefault('history', {}).setdefault('ownership_settlements', [])
        result = list(rows)
        if club_id is not None:
            result = [r for r in result if r.get('club_id') == club_id or r.get('transaction', {}).get('club_id') == club_id]
        if status is not None:
            result = [r for r in result if r.get('status') == status]
        return result

    def cycles(self):
        return list(self.save.setdefault('history', {}).setdefault('ownership_market_cycles', []))

    def club_summary(self, club_id):
        tx = self.transactions(club_id=club_id, status='settled')
        prices = []
        owners = []
        for row in tx:
            price = row.get('price')
            if price is None:
                price = row.get('transaction', {}).get('price')
            if price is not None:
                prices.append(float(price))
            if row.get('new_owner') is not None:
                owners.append(row['new_owner'])
            elif row.get('transaction', {}).get('owner') is not None:
                owners.append(row['transaction']['owner'])
        return {
            'club_id': club_id,
            'transactions': len(tx),
            'total_volume': round(sum(prices), 2),
            'last_price': round(prices[-1], 2) if prices else None,
            'owner_changes': owners,
        }

    def portfolio_summary(self):
        tx = self.transactions(status='settled')
        volume = 0.0
        clubs = set()
        for row in tx:
            price = row.get('price')
            if price is None:
                price = row.get('transaction', {}).get('price')
            if price is not None:
                volume += float(price)
            club_id = row.get('club_id') or row.get('transaction', {}).get('club_id')
            if club_id is not None:
                clubs.add(club_id)
        return {
            'settled_transactions': len(tx),
            'total_volume': round(volume, 2),
            'clubs_traded': len(clubs),
        }
