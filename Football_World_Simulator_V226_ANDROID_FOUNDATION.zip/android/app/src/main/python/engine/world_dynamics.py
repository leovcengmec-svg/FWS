"""V89 world dynamics core.

Builds a deterministic, catalog-backed seasonal state.  It deliberately keeps
future simulation state separate from the verified world database: generated
sporting strength, fixtures and results are simulation outputs, not source data.
"""
from __future__ import annotations
import hashlib
from dataclasses import dataclass
from typing import Dict, List, Tuple
from .match_engine import MatchEngine

@dataclass
class Fixture:
    round_no: int
    home_id: str
    away_id: str

class WorldDynamics:
    SCHEMA = 1

    def __init__(self, catalog: dict, seed: int = 89):
        self.catalog = catalog
        self.seed = int(seed)

    def _clubs_for_league(self, league_id: str) -> List[dict]:
        return sorted(
            [c for c in self.catalog.get("clubs", {}).values() if c.get("league_id") == league_id],
            key=lambda c: c.get("id", ""),
        )

    def _strength(self, club_id: str, league: dict) -> float:
        raw = hashlib.sha256(f"{self.seed}:{club_id}".encode()).digest()
        variation = int.from_bytes(raw[:2], "big") / 65535.0
        # Simulation-only baseline. It never overwrites source/catalog data.
        coefficient = float(league.get("coefficient", 50.0))
        return round(max(1.0, min(99.0, coefficient * 0.75 + variation * 24.0)), 3)

    @staticmethod
    def _round_robin(ids: List[str]) -> List[List[Tuple[str, str]]]:
        teams = list(ids)
        if len(teams) < 2:
            return []
        if len(teams) % 2:
            teams.append(None)
        n = len(teams)
        rotation = teams[:]
        first = []
        for r in range(n - 1):
            games = []
            for i in range(n // 2):
                a, b = rotation[i], rotation[n - 1 - i]
                if a and b:
                    games.append((a, b) if r % 2 == 0 else (b, a))
            first.append(games)
            rotation = [rotation[0]] + [rotation[-1]] + rotation[1:-1]
        return first + [[(b, a) for a, b in rnd] for rnd in first]

    def initialize_season(self, season: int) -> dict:
        leagues = {}
        for lid, league in sorted(self.catalog.get("leagues", {}).items()):
            clubs = self._clubs_for_league(lid)
            ids = [c["id"] for c in clubs]
            leagues[lid] = {
                "league_id": lid,
                "country_id": league.get("country_id"),
                "level": league.get("level", 1),
                "season": int(season),
                "club_ids": ids,
                "fixture_rounds": max(0, (len(ids) - 1 + len(ids) % 2) * 2),
                "format": league.get("format", "double_round_robin"),
                "status": "scheduled" if len(ids) >= 2 else "insufficient_clubs",
                "table": {
                    cid: {"club_id": cid, "played": 0, "wins": 0, "draws": 0,
                          "losses": 0, "gf": 0, "ga": 0, "gd": 0, "points": 0,
                          "strength": self._strength(cid, league)}
                    for cid in ids
                },
            }
        return {
            "schema": self.SCHEMA,
            "engine": "V89_WorldDynamics",
            "season": int(season),
            "status": "initialized",
            "countries": len(self.catalog.get("associations", {})),
            "leagues": len(leagues),
            "clubs": len(self.catalog.get("clubs", {})),
            "leagues_state": leagues,
            "promotions_relegations": [],
            "cup_results": [],
            "continental_results": [],
        }

    def fixtures(self, league_id: str, season: int) -> List[Fixture]:
        league = self.catalog["leagues"][league_id]
        ids = [c["id"] for c in self._clubs_for_league(league_id)]
        rounds = self._round_robin(ids)
        return [Fixture(i + 1, h, a) for i, games in enumerate(rounds) for h, a in games]

    def simulate_league(self, state: dict, league_id: str, seed_offset: int = 0) -> dict:
        row = state["leagues_state"][league_id]
        if len(row["club_ids"]) < 2:
            row["status"] = "insufficient_clubs"
            return row
        engine = MatchEngine(self.seed + int(seed_offset))
        league = self.catalog["leagues"][league_id]
        clubs = {c["id"]: dict(c) for c in self._clubs_for_league(league_id)}
        for cid, table in row["table"].items():
            clubs[cid].update({"attack": table["strength"], "defense": table["strength"], "prestige": table["strength"]})
        for fixture in self.fixtures(league_id, state["season"]):
            result = engine.play(league_id, state["season"], fixture.round_no, clubs[fixture.home_id], clubs[fixture.away_id])
            h, a = row["table"][fixture.home_id], row["table"][fixture.away_id]
            h["played"] += 1; a["played"] += 1
            h["gf"] += result.home_goals; h["ga"] += result.away_goals
            a["gf"] += result.away_goals; a["ga"] += result.home_goals
            if result.home_goals > result.away_goals:
                h["wins"] += 1; h["points"] += 3; a["losses"] += 1
            elif result.home_goals < result.away_goals:
                a["wins"] += 1; a["points"] += 3; h["losses"] += 1
            else:
                h["draws"] += 1; a["draws"] += 1; h["points"] += 1; a["points"] += 1
            h["gd"] = h["gf"] - h["ga"]; a["gd"] = a["gf"] - a["ga"]
        standings = sorted(row["table"].values(), key=lambda x: (-x["points"], -x["gd"], -x["gf"], x["club_id"]))
        row["status"] = "completed"
        row["standings"] = standings
        return row

    def apply_promotion_relegation(self, state: dict, places: int = 2) -> List[dict]:
        changes = []
        by_country: Dict[str, List[dict]] = {}
        for lid, league in self.catalog.get("leagues", {}).items():
            by_country.setdefault(league.get("country_id"), []).append(league)
        for country, leagues in by_country.items():
            leagues.sort(key=lambda x: x.get("level", 999))
            for upper, lower in zip(leagues, leagues[1:]):
                up = state["leagues_state"].get(upper["id"], {}).get("standings", [])
                lo = state["leagues_state"].get(lower["id"], {}).get("standings", [])
                if len(up) < places or len(lo) < places:
                    continue
                relegated = [x["club_id"] for x in up[-places:]]
                promoted = [x["club_id"] for x in lo[:places]]
                changes.append({"country_id": country, "from": upper["id"], "to": lower["id"],
                                "relegated": relegated, "promoted": promoted})
        state["promotions_relegations"] = changes
        return changes
