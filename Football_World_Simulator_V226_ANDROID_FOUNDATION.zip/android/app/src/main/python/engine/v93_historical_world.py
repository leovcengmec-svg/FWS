"""V93 Historical World Engine: append-only seasonal memory."""
from __future__ import annotations
from copy import deepcopy

class V93HistoricalWorld:
    VERSION='V93'; SCHEMA=1
    def __init__(self, save):
        self.save=save
        self.history=save.setdefault('history',{})
        self.history.setdefault('world_seasons',[])
        self.history.setdefault('club_records',{})

    def close_season(self, season, league_results, cup_results=None, continental_results=None, movements=None, events=None):
        season=int(season)
        if any(int(r.get('season',-1))==season for r in self.history['world_seasons']):
            raise ValueError(f'season {season} already closed')
        cups={k:v for k,v in (cup_results or {}).items() if v}
        row={'season':season,'status':'closed','league_champions':{lid:t[0]['club_id'] for lid,t in league_results.items() if t},
             'runners_up':{lid:t[1]['club_id'] for lid,t in league_results.items() if len(t)>1},
             'final_standings':deepcopy(league_results),'cup_champions':deepcopy(cups),
             'continental_champions':deepcopy(continental_results or {}),'promotions_relegations':deepcopy(movements or []),
             'events':deepcopy(events or []),'source':'simulated_historical'}
        self.history['world_seasons'].append(row); self.history['world_seasons'].sort(key=lambda x:x['season'])
        for lid,table in league_results.items():
            for pos,entry in enumerate(table,1):
                cid=entry['club_id']; rec=self.history['club_records'].setdefault(cid,{'seasons':[],'titles':0,'cups':0})
                rec['seasons'].append({'season':season,'league_id':lid,'position':pos,'points':entry.get('points',0)})
                if pos==1: rec['titles']+=1
        for cid in cups.values():
            rec=self.history['club_records'].setdefault(cid,{'seasons':[],'titles':0,'cups':0}); rec['cups']+=1
        return deepcopy(row)

    def validate(self):
        errors=[]; rows=self.history.get('world_seasons',[]); seasons=[r.get('season') for r in rows]
        if seasons!=sorted(set(seasons)): errors.append('historical seasons must be unique and ordered')
        for r in rows:
            if r.get('status')!='closed': errors.append(f"season not closed: {r.get('season')}")
            if r.get('source') not in ('real_historical','simulated_historical','unknown'): errors.append('invalid historical source')
        return errors
