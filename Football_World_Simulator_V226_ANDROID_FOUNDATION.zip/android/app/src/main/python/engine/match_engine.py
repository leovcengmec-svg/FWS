"""Authoritative aggregate football match engine.

No individual-player simulation is used.  Match outcomes emerge from bounded
club/selection attributes plus match context and a seeded stochastic process.
"""
from dataclasses import dataclass
import math
import random


@dataclass
class MatchResult:
    competition_id: str
    season: int
    round_no: int
    home_id: str
    away_id: str
    home_goals: int
    away_goals: int
    winner_id: str | None = None
    outcome: str = "draw"
    home_win_probability: float = 0.0
    draw_probability: float = 0.0
    away_win_probability: float = 0.0
    home_xg: float = 0.0
    away_xg: float = 0.0


class MatchEngine:
    """Authoritative engine for deciding regulation match outcomes.

    Strength influences probability; it never guarantees an outcome.  The
    engine is deliberately aggregate: attack, defense, sporting strength,
    prestige and sporting form are club/selection attributes, not players.
    """

    def __init__(self, seed=None, home_advantage=0.22, max_lambda=3.8):
        self.rng = random.Random(seed)
        self.home_advantage = float(home_advantage)
        self.max_lambda = float(max_lambda)

    @staticmethod
    def _clamp(value, lo, hi):
        return max(lo, min(hi, float(value)))

    def _poisson(self, lam):
        lam = self._clamp(lam, 0.05, self.max_lambda)
        limit = math.exp(-lam)
        k, p = 0, 1.0
        while p > limit:
            k += 1
            p *= self.rng.random()
        return k - 1

    def _team_xg(self, team, opponent, home=False, context=None):
        context = context or {}
        attack = self._clamp(team.get("attack", 50), 1, 99)
        defense = self._clamp(opponent.get("defense", 50), 1, 99)
        strength = self._clamp(team.get("sporting_strength", 55), 1, 99)
        prestige = self._clamp(team.get("prestige", 50), 1, 99)
        form = self._clamp(team.get("sporting_form", 50), 0, 100)

        # Base attacking opportunity.  Each signal is intentionally bounded.
        xg = 1.18 + (attack - defense) * 0.022
        xg += (strength - 55) * 0.006
        xg += (form - 50) * 0.0025
        xg += (prestige - 50) * 0.0015
        if home:
            xg += self.home_advantage

        importance = self._clamp(context.get("importance", 0), 0, 100)
        knockout = bool(context.get("knockout", False))
        decisive = bool(context.get("decisive", False))
        # High-stakes matches are slightly tighter; they do not determine the
        # result and do not create artificial winners.
        if knockout:
            xg *= 0.96
        if decisive:
            xg *= 0.97
        xg *= 1.0 - importance * 0.00015
        return self._clamp(xg, 0.15, self.max_lambda)

    def _probabilities_from_xg(self, home_xg, away_xg):
        # Exact 1/X/2 probabilities from the independent Poisson model.
        home = away = draw = 0.0
        max_goals = int(self.max_lambda + 7)
        home_probs = [math.exp(-home_xg) * home_xg ** i / math.factorial(i) for i in range(max_goals + 1)]
        away_probs = [math.exp(-away_xg) * away_xg ** i / math.factorial(i) for i in range(max_goals + 1)]
        for h, hp in enumerate(home_probs):
            for a, ap in enumerate(away_probs):
                p = hp * ap
                if h > a:
                    home += p
                elif h < a:
                    away += p
                else:
                    draw += p
        total = home + draw + away
        if total <= 0:
            return 1 / 3, 1 / 3, 1 / 3
        return home / total, draw / total, away / total

    def play(self, competition_id, season, round_no, home, away, context=None):
        context = context or {}
        h_xg = self._team_xg(home, away, home=True, context=context)
        a_xg = self._team_xg(away, home, home=False, context=context)
        hp, dp, ap = self._probabilities_from_xg(h_xg, a_xg)
        hg, ag = self._poisson(h_xg), self._poisson(a_xg)
        if hg > ag:
            winner, outcome = home["id"], "home"
        elif ag > hg:
            winner, outcome = away["id"], "away"
        else:
            winner, outcome = None, "draw"
        return MatchResult(
            competition_id, season, round_no, home["id"], away["id"], hg, ag,
            winner, outcome, round(hp, 6), round(dp, 6), round(ap, 6),
            round(h_xg, 4), round(a_xg, 4)
        )
