class NationalTeamWindow:
    """Represents dates reserved for national teams; clubs can be protected from fixtures."""
    def __init__(self, start_date, end_date, name):
        self.start_date=start_date
        self.end_date=end_date
        self.name=name

    def as_dict(self):
        return {"start_date":self.start_date,"end_date":self.end_date,"name":self.name}
