class WeeklyCashFlow:
    """V28: explicit weekly investor income, recurring expenses and flow ledger."""
    def __init__(self, save):
        from .investor_finance import InvestorFinance
        self.finance = InvestorFinance(save)
        self.save = save

    def settle(self, week, year=None):
        return self.finance.settle_week(week, year)

    def current(self):
        c = self.finance.career
        return {
            'weekly_income': float(c.get('weekly_income', 0.0)),
            'weekly_expenses': float(c.get('weekly_expenses', 0.0)),
            'weekly_flow': float(c.get('weekly_flow', 0.0)),
        }
