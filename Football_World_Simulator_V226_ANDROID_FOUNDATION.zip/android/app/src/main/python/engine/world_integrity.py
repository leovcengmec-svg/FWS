"""Cross-module integrity checks for a playable world."""
from .world_registry import WorldRegistry
from .competition_registry import CompetitionRegistry


def validate_world(save):
    registry = WorldRegistry(save)
    errors = registry.validate()
    errors.extend(CompetitionRegistry(save).validate())
    # Confederation consistency between countries and leagues.
    for league in registry.leagues.values():
        country = registry.countries.get(league.get("country_id"), {})
        if not country:
            continue
        if league.get("confederation") and league["confederation"] != country.get("confederation"):
            errors.append(f"league {league['id']} confederation mismatch")
    return errors


def assert_world_integrity(save):
    errors = validate_world(save)
    if errors:
        raise ValueError("World integrity failed: " + "; ".join(errors))
    return True
