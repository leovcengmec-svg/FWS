"""High-level world season coordinator.

The coordinator composes existing sporting engines instead of duplicating them.
It validates the world before and after the season and records a compact report.
"""
from .world_bootstrap import WorldBootstrap
from .world_registry import WorldRegistry
from .world_integrity import assert_world_integrity
from .promotion import PromotionRelegation


class WorldSeason:
    def __init__(self, save, simulator):
        self.save = save
        self.simulator = simulator

    def prepare(self):
        WorldBootstrap(self.save).prepare()
        return WorldRegistry(self.save).summary()

    def run(self):
        self.prepare()
        year = self.save["world"]["current_year"]
        result = self.simulator.simulate_full_season()
        # Promotion/relegation is intentionally after the sporting tables and before
        # the year advances, matching the established world simulator semantics.
        movement = {}
        places = self.save.get("simulation", {}).get("promotion_relegation_places", 4)
        for country_id in self.save["world"].get("countries", {}):
            changes = PromotionRelegation(places).apply_country(self.save, country_id)
            if changes:
                movement[country_id] = changes
        WorldBootstrap(self.save).prepare()
        assert_world_integrity(self.save)
        report = {
            "season": year,
            "leagues_simulated": len(result or {}),
            "promotions_relegations": movement,
            "world_summary": WorldRegistry(self.save).summary(),
        }
        self.save.setdefault("history", {}).setdefault("world_seasons", []).append(report)
        return report
