"""V165 — Global Season Checkpoint & Audit Ledger.

V165 is a persistence/audit wrapper above the approved V164 season motor. It
adds deterministic input/output signatures, phase checkpoints and continuity
checks between closed seasons. It never executes competition engines directly
and never creates an individual-player layer.
"""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy

from .v164_global_season_motor import V164GlobalSeasonMotor
from .world_integrity import assert_world_integrity


class V165GlobalSeasonCheckpoint:
    VERSION = "V165"
    SCHEMA = 1

    def __init__(self, save, seed=165):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("global_season_checkpoints", [])

    @staticmethod
    def _digest(value):
        payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _input_signature(self, season, advance_year, club_context, association_context, career_results):
        return self._digest({
            "season": int(season),
            "advance_year": bool(advance_year),
            "seed": self.seed,
            "current_year_before": int(self._world().get("current_year", 2026)),
            "current_round_before": int(self._world().get("current_round", 0)),
            "club_context": club_context,
            "association_context": association_context,
            "career_results": career_results,
            "engine": "V164GlobalSeasonMotor",
        })

    def _result_signature(self, result):
        # The V164 report is the authoritative season boundary. Hashing the
        # returned report makes the checkpoint portable without duplicating the
        # entire world save inside history.
        return self._digest(result)

    @staticmethod
    def _phase_checkpoint(motor):
        return [
            {
                "order": int(p["order"]),
                "phase": p["phase"],
                "status": p["status"],
            }
            for p in motor.get("phases", [])
        ]

    def run_season(self, *, season=None, advance_year=True, club_context=None,
                   association_context=None, career_results=None):
        year = int(self._world().get("current_year", 2026) if season is None else season)
        if any(int(r.get("season", -1)) == year for r in self._ledger()):
            raise ValueError(f"V165 season {year} already checkpointed")

        input_signature = self._input_signature(
            year, advance_year, club_context, association_context, career_results
        )

        # V164 owns the atomic rollback boundary and the actual season
        # execution. V165 only records the completed boundary after V164 closes.
        result = V164GlobalSeasonMotor(self.save, seed=self.seed + 164).run_season(
            season=year,
            advance_year=advance_year,
            club_context=club_context,
            association_context=association_context,
            career_results=career_results,
        )

        assert_world_integrity(self.save)
        if "players" in self._world() or "player_transfers" in self._history():
            raise ValueError("V165 must not contain an individual player layer")

        motor = result.get("season_motor", {})
        if motor.get("version") != "V164" or motor.get("status") != "completed":
            raise ValueError("V165 requires a completed V164 season motor")

        checkpoint = {
            "version": self.VERSION,
            "schema": self.SCHEMA,
            "season": year,
            "status": "closed",
            "input_signature": input_signature,
            "result_signature": self._result_signature(result),
            "engine": "V164GlobalSeasonMotor",
            "engine_version": "V164",
            "seed": self.seed + 164,
            "world_year_before": year,
            "world_year_after": int(self._world().get("current_year", year)),
            "dependency_chain": list(motor.get("dependency_chain", [])),
            "phases": self._phase_checkpoint(motor),
            "player_layer_forbidden": True,
        }
        self._ledger().append(deepcopy(checkpoint))
        self._world()["global_season_checkpoint_version"] = self.VERSION
        self._world()["global_season_checkpoint_status"] = "validated"

        result = deepcopy(result)
        result["season_checkpoint"] = deepcopy(checkpoint)
        return result

    def validate(self):
        errors = []
        rows = self._ledger()
        seasons = [int(r.get("season", -1)) for r in rows]
        if len(seasons) != len(set(seasons)):
            errors.append("V165 seasons must be unique")
        for row in rows:
            season = int(row.get("season", -1))
            if row.get("version") != self.VERSION:
                errors.append(f"wrong_version:{season}")
            if row.get("status") != "closed":
                errors.append(f"checkpoint_not_closed:{season}")
            if row.get("engine_version") != "V164":
                errors.append(f"wrong_engine_version:{season}")
            if not isinstance(row.get("input_signature"), str) or len(row["input_signature"]) != 64:
                errors.append(f"invalid_input_signature:{season}")
            if not isinstance(row.get("result_signature"), str) or len(row["result_signature"]) != 64:
                errors.append(f"invalid_result_signature:{season}")
            if row.get("dependency_chain") != list(V164GlobalSeasonMotor.PHASES):
                errors.append(f"dependency_chain_invalid:{season}")
            if len(row.get("phases", [])) != len(V164GlobalSeasonMotor.PHASES):
                errors.append(f"phase_count_invalid:{season}")
            if any(p.get("status") not in ("completed", "COMPLETE", "closed", "valid", "not_due") for p in row.get("phases", [])):
                errors.append(f"phase_status_invalid:{season}")
            if row.get("world_year_after") not in (season, season + 1):
                errors.append(f"world_year_after_invalid:{season}")

        if seasons:
            ordered = sorted(seasons)
            for previous, current in zip(ordered, ordered[1:]):
                if current != previous + 1:
                    errors.append(f"season_gap:{previous}->{current}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("player_system_forbidden")
        return errors
