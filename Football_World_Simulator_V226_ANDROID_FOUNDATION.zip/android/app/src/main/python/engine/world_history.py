"""Season-level historical ledger for the football world."""


class WorldHistoryLedger:
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {})
        self.history.setdefault("world_seasons", [])

    def record_world_season(self, season, league_results, cup_winners,
                            continental_champions, movements):
        row = {
            "season": season,
            "league_champions": {
                lid: table[0]["club_id"] for lid, table in league_results.items() if table
            },
            "cup_champions": {cid: club for cid, club in cup_winners.items() if club},
            "continental_champions": dict(continental_champions),
            "promotions_relegations": movements,
        }
        # Re-running the same season replaces its ledger row instead of
        # duplicating history.
        rows = [r for r in self.history["world_seasons"] if r.get("season") != season]
        rows.append(row)
        rows.sort(key=lambda r: r["season"])
        self.history["world_seasons"] = rows
        self.history.setdefault("seasons", {})[str(season)] = row
        return row
