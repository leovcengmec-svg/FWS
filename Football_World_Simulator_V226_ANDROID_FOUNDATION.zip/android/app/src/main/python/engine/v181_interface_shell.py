"""V181 — Interface & Experience shell.

Provides a stable, data-first navigation model for the playable game. It does
not replace any existing engine; it exposes the state needed by a UI layer.
"""
from __future__ import annotations
from copy import deepcopy

class V181InterfaceShell:
    VERSION='V181'
    MENUS=('home','career','clubs','selection','calendar','world','history','settings')
    def __init__(self, save): self.save=save
    def start(self):
        rt=self.save.setdefault('runtime',{})
        rt.setdefault('interface',{})
        rt['interface'].update({'version':self.VERSION,'screen':'home','tutorial_seen':False})
        return self.dashboard()
    def navigate(self, screen):
        if screen not in self.MENUS: raise ValueError('invalid interface screen')
        self.save.setdefault('runtime',{}).setdefault('interface',{})['screen']=screen
        return self.dashboard()
    def dashboard(self):
        career=self.save.get('careers',{}); inv=career.get('investor',{}); sel=career.get('selection',{})
        return {'version':self.VERSION,'screen':self.save.get('runtime',{}).get('interface',{}).get('screen','home'),
                'year':self.save.get('world',{}).get('current_year'),'capital':round(float(inv.get('cash',0)),2),
                'owned_clubs':list(inv.get('owned_clubs',[])),'created_clubs':list(inv.get('created_clubs',[])),
                'selection_id':sel.get('current_team_id'),'prestige':float(sel.get('manager_prestige',0)),
                'notifications':len(self.save.get('history',{}).get('notifications',[]))}
    def show_tutorial(self):
        self.save.setdefault('runtime',{}).setdefault('interface',{})['tutorial_seen']=True
        return ['investor','clubs','selection','calendar','world','history']
