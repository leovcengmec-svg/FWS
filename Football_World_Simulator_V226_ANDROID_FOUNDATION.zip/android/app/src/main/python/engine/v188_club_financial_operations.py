"""V188 — Club cash flow, budgets, debt and financial risk."""
from __future__ import annotations
from copy import deepcopy
class V188ClubFinancialOperations:
    VERSION='V188'
    def __init__(self, save): self.save=save
    def set_budget(self, club_id, amount):
        c=self.save['world']['clubs'][club_id]; amount=float(amount)
        if amount<0: raise ValueError('budget cannot be negative')
        c['season_budget']=round(amount,2); return c['season_budget']
    def record_cashflow(self, club_id, revenue=0, expense=0, category='operations'):
        c=self.save['world']['clubs'][club_id]; revenue=float(revenue); expense=float(expense)
        if revenue<0 or expense<0: raise ValueError('cash flow values must be non-negative')
        c['cash']=round(float(c.get('cash',0))+revenue-expense,2)
        row={'season':self.save['world'].get('current_year'),'revenue':revenue,'expense':expense,'net':revenue-expense,'category':category,'cash_after':c['cash']}
        c.setdefault('cashflow_ledger',[]).append(row)
        c['financial_status']='distressed' if c['cash']<0 else ('tight' if c['cash']<1 else 'stable')
        return deepcopy(row)
    def settle(self):
        rows=[]
        for cid,c in self.save.get('world',{}).get('clubs',{}).items():
            budget=float(c.get('season_budget',0)); base=max(0.1,float(c.get('market_value',0)))
            revenue=round(base*0.08,3); expense=round(budget if budget else base*0.05,3)
            rows.append(self.record_cashflow(cid,revenue,expense,'season_settlement'))
        self.save.setdefault('history',{}).setdefault('investor_finance',[]).append({'season':self.save['world'].get('current_year'),'clubs':len(rows)})
        return rows
    def validate(self): return [f'nonfinite_cash:{cid}' for cid,c in self.save.get('world',{}).get('clubs',{}).items() if not isinstance(c.get('cash',0),(int,float))]
