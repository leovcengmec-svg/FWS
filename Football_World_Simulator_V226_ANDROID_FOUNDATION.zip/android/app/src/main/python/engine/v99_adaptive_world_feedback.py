"""V99 — Adaptive World & Feedback.

Adds a bounded feedback/adaptation layer on top of the V98 decision cycle.
It converts observable consequences into board confidence, adaptive pressure,
momentum and the next recommended priority. It does not create players, free
money, guaranteed sporting outcomes or a second match engine.
"""
from __future__ import annotations
from copy import deepcopy

from .v98_decision_consequence_cycle import V98DecisionConsequenceCycle


class V99AdaptiveWorldFeedback(V98DecisionConsequenceCycle):
    VERSION = "V99"
    PRIORITIES = ("sporting", "infrastructure", "commercial", "youth_base", "scouting", "debt", "reserve", "balanced")

    @staticmethod
    def _clamp(value, low=0.0, high=100.0):
        return round(max(low, min(high, float(value))), 3)

    def initialize(self, starting_cash=None, manager_prestige=None):
        super().initialize(starting_cash, manager_prestige)
        self.save.setdefault("careers", {}).setdefault("adaptive_feedback", {
            "version": self.VERSION, "history": []
        })
        return self.snapshot()

    def apply_feedback(self, club_id=None, cycle=None):
        """Translate the latest decision consequences into bounded adaptation."""
        cycle = cycle or self.decision_cycle_snapshot().get("latest")
        if not cycle:
            raise ValueError("nenhum ciclo de decisão disponível para feedback")
        club_id = club_id or cycle.get("club_id")
        if not club_id or club_id not in self.save.get("world", {}).get("clubs", {}):
            raise ValueError("clube inválido para feedback")
        club = self.save["world"]["clubs"][club_id]

        effectiveness = cycle.get("effectiveness") or {}
        review = cycle.get("review") or {}
        strategic = cycle.get("strategic") or {}
        score = float(effectiveness.get("score", effectiveness.get("effectiveness", 50.0)))
        quality = float(strategic.get("quality", strategic.get("strategic_quality", 50.0)))
        action = str(review.get("action", "monitor"))

        previous = float(club.get("board_confidence", 50.0))
        delta = (score - 50.0) * 0.18 + (quality - 50.0) * 0.08
        if action not in ("monitor", "maintain", "none", ""):
            delta -= 2.0
        confidence = self._clamp(previous + delta)
        pressure = self._clamp(100.0 - confidence)
        momentum = self._clamp(float(club.get("adaptive_momentum", 50.0)) * 0.7 + score * 0.3)

        focus = str(cycle.get("strategic", {}).get("focus", cycle.get("focus", {}).get("focus", "balanced")))
        if confidence < 40 or pressure >= 60:
            priority = "reserve" if float(club.get("cash", 0.0)) < 20.0 else "debt"
        elif momentum >= 65:
            priority = focus if focus in self.PRIORITIES else "sporting"
        else:
            priority = focus if focus in self.PRIORITIES else "balanced"

        club["board_confidence"] = confidence
        club["adaptive_pressure"] = pressure
        club["adaptive_momentum"] = momentum
        club["adaptive_priority"] = priority

        row = {
            "version": self.VERSION,
            "club_id": club_id,
            "season": self.save["world"].get("current_year"),
            "previous_confidence": round(previous, 3),
            "confidence": confidence,
            "pressure": pressure,
            "momentum": momentum,
            "priority": priority,
            "source_effectiveness": round(score, 3),
            "source_strategic_quality": round(quality, 3),
            "review_action": action,
        }
        state = self.save["careers"]["adaptive_feedback"]
        state["version"] = self.VERSION
        state["history"].append(deepcopy(row))
        return row

    def adaptive_snapshot(self, club_id=None):
        if not club_id:
            club_id = self.active.active.active_entities().get("club_id")
        if not club_id or club_id not in self.save.get("world", {}).get("clubs", {}):
            raise ValueError("nenhum clube válido sob gestão ativa")
        club = self.save["world"]["clubs"][club_id]
        return {
            "version": self.VERSION,
            "club_id": club_id,
            "board_confidence": float(club.get("board_confidence", 50.0)),
            "pressure": float(club.get("adaptive_pressure", 50.0)),
            "momentum": float(club.get("adaptive_momentum", 50.0)),
            "priority": club.get("adaptive_priority", "balanced"),
        }

    def validate(self):
        errors = super().validate()
        state = self.save.get("careers", {}).get("adaptive_feedback", {})
        if state and state.get("version") != self.VERSION:
            errors.append("wrong adaptive feedback version")
        for row in state.get("history", []):
            if row.get("version") != self.VERSION:
                errors.append("invalid adaptive feedback history version")
                break
            for key in ("confidence", "pressure", "momentum"):
                if not 0.0 <= float(row.get(key, -1)) <= 100.0:
                    errors.append(f"adaptive {key} out of range")
        return errors
