"""Multi-season strategic planning layer.

Plans are bounded and advisory: they organize priorities and measure execution
against them. They never create cash or alter a match directly.
"""
class StrategicPlanningEngine:
    HORIZONS = (1, 2, 3)
    FOCUSES = ("balanced", "sporting", "commercial", "development", "consolidation")

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_plans", [])

    @staticmethod
    def _clamp(v):
        return round(max(0.0, min(100.0, float(v))), 4)

    def create_plan(self, club_id, focus, horizon=3, target_quality=70.0, season=None):
        if focus not in self.FOCUSES:
            raise ValueError("foco estratégico inválido")
        if int(horizon) not in self.HORIZONS:
            raise ValueError("horizonte inválido")
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        season = self.save.get("world", {}).get("current_year") if season is None else season
        plan = {"club_id": club_id, "start_season": int(season), "horizon": int(horizon),
                "end_season": int(season) + int(horizon) - 1, "focus": focus,
                "target_quality": self._clamp(target_quality), "status": "active",
                "reviews": []}
        club = clubs[club_id]
        club["strategic_plan"] = plan
        club.setdefault("strategic_plan_history", []).append(plan.copy())
        self.history.append({"type":"plan_created", **plan})
        return plan

    def review(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        plan = club.get("strategic_plan")
        if not plan:
            return {"club_id":club_id,"season":season,"status":"no_plan"}
        quality = float(club.get("strategic_quality", 50.0))
        target = float(plan.get("target_quality", 70.0))
        execution = self._clamp(100.0 - abs(quality-target)*2.0)
        deviation = round(quality-target, 4)
        row = {"club_id":club_id,"season":int(season),"focus":plan["focus"],
               "quality":round(quality,4),"target_quality":round(target,4),
               "execution":execution,"deviation":deviation,"status":plan.get("status","active")}
        plan.setdefault("reviews", []).append(row)
        self.history.append({"type":"plan_review", **row})
        if int(season) >= int(plan["end_season"]):
            plan["status"] = "completed"
        return row

    def snapshot(self, club_id):
        club = self.save.get("world", {}).get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        plan = club.get("strategic_plan")
        if not plan:
            return {"club_id":club_id,"active":False}
        return {"club_id":club_id,"active":plan.get("status")=="active",
                "focus":plan.get("focus"),"horizon":plan.get("horizon"),
                "start_season":plan.get("start_season"),"end_season":plan.get("end_season"),
                "target_quality":plan.get("target_quality"),
                "reviews":len(plan.get("reviews",[]))}
