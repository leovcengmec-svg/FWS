"""V169 — Multi-year World Simulation Stress Harness."""
from __future__ import annotations
import pickle
from copy import deepcopy
from .v167_global_season_integrity_gate import V167GlobalSeasonIntegrityGate
from .v168_world_state_persistence import V168WorldStatePersistence
from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity

class V169WorldSimulationStress:
    VERSION="V169"; SCHEMA=1
    def __init__(self, save, seed=169): self.save=save; self.seed=int(seed)
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def _audit(self, season):
        w=self._world(); h=self._history(); e=[]
        if len(w.get('countries',{}))!=211: e.append(f"country_count:{len(w.get('countries',{}))}")
        if len(w.get('leagues',{})) < 349: e.append(f"league_count_below_baseline:{len(w.get('leagues',{}))}")
        if len(w.get('clubs',{})) < 4744: e.append(f"club_count_below_baseline:{len(w.get('clubs',{}))}")
        if 'players' in w or 'player_transfers' in h: e.append('player_system_forbidden')
        seen={}
        for lid,l in w.get('leagues',{}).items():
            for cid in l.get('club_ids',[]):
                if cid not in w.get('clubs',{}): e.append(f'missing_club:{lid}:{cid}')
                if cid in seen and seen[cid]!=lid: e.append(f'duplicate_membership:{cid}:{seen[cid]}:{lid}')
                seen[cid]=lid
        for cid,c in w.get('clubs',{}).items():
            lid=c.get('league_id')
            if lid and cid not in w.get('leagues',{}).get(lid,{}).get('club_ids',[]): e.append(f'club_membership_mismatch:{cid}:{lid}')
        if int(w.get('current_year',-1)) != season+1: e.append('year_not_advanced')
        if not any(int(x.get('season',-1))==season and x.get('status')=='accepted' for x in h.get('global_season_integrity_gate',[])): e.append('missing_integrity_acceptance')
        return e
    def run(self, seasons=3, start_season=None, seed=None):
        count=int(seasons)
        if count<1: raise ValueError('V169 seasons must be >= 1')
        WorldBootstrap(self.save).prepare(); assert_world_integrity(self.save)
        start=int(self._world().get('current_year',2026) if start_season is None else start_season)
        snap=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL); rows=[]; engine_seed=self.seed if seed is None else int(seed)
        try:
            if int(self._world().get('current_year'))!=start: raise ValueError('V169 start year mismatch')
            for i in range(count):
                season=start+i
                result=V167GlobalSeasonIntegrityGate(self.save,seed=engine_seed+i).run_season(season=season)
                errs=self._audit(season)
                if errs: raise ValueError('V169 stress audit failed: '+ '; '.join(errs))
                rows.append({'season':season,'next_year':result['next_year'],'status':'PASS','super_world':None if result.get('super_world') is None else result['super_world'].get('status')})
            assert_world_integrity(self.save)
            persistence=V168WorldStatePersistence(self.save).validate()
            if persistence: raise ValueError('V169 persistence audit failed: '+ '; '.join(persistence))
            out={'version':self.VERSION,'schema':self.SCHEMA,'status':'completed','start_season':start,'seasons_requested':count,'final_current_year':int(self._world()['current_year']),'rows':rows,'persistence':'PASS','player_layer_forbidden':True}
            self._history().setdefault('world_simulation_stress',[]).append(deepcopy(out)); self._world()['world_simulation_stress_status']='validated'; return deepcopy(out)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snap)); raise
    def validate(self):
        e=[]
        for r in self._history().get('world_simulation_stress',[]):
            if r.get('version')!=self.VERSION or r.get('status')!='completed': e.append('invalid_stress_row')
            if r.get('persistence')!='PASS': e.append('stress_persistence_not_passed')
            if any(x.get('status')!='PASS' for x in r.get('rows',[])): e.append('stress_season_failed')
        if 'players' in self._world() or 'player_transfers' in self._history(): e.append('player_system_forbidden')
        return e
