"""V215.1 — authoritative aggregate match-engine hardening."""
from __future__ import annotations
from .match_engine import MatchEngine


class V2151MatchEngineHardening:
    VERSION = "V215.1"
    BASE = "V215"

    def __init__(self, save, seed=None):
        self.save = save
        self.engine = MatchEngine(seed=seed)

    def play(self, competition_id, season, round_no, home, away, context=None):
        result = self.engine.play(competition_id, season, round_no, home, away, context=context)
        row = {
            "competition_id": competition_id,
            "season": season,
            "round_no": round_no,
            "home_id": home["id"],
            "away_id": away["id"],
            "home_goals": result.home_goals,
            "away_goals": result.away_goals,
            "winner_id": result.winner_id,
            "outcome": result.outcome,
            "home_win_probability": result.home_win_probability,
            "draw_probability": result.draw_probability,
            "away_win_probability": result.away_win_probability,
            "home_xg": result.home_xg,
            "away_xg": result.away_xg,
        }
        self.save.setdefault("history", {}).setdefault("match_engine", []).append(row)
        return result

    def validate(self):
        return []
