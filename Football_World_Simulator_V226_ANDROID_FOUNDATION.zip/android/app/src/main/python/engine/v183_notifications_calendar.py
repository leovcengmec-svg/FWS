"""V183 — Calendar, notifications and decision inbox."""
from __future__ import annotations
from copy import deepcopy

class V183NotificationsCalendar:
    VERSION='V183'
    def __init__(self,save): self.save=save
    def notify(self, kind, title, message, priority='normal', payload=None):
        row={'id':f"N{len(self.save.setdefault('history',{}).setdefault('notifications',[]))+1:06d}",
             'kind':kind,'title':title,'message':message,'priority':priority,'year':self.save.get('world',{}).get('current_year'),
             'payload':deepcopy(payload or {}),'read':False}
        self.save['history']['notifications'].append(row); return deepcopy(row)
    def inbox(self, unread_only=False):
        rows=self.save.get('history',{}).get('notifications',[])
        if unread_only: rows=[r for r in rows if not r.get('read')]
        return deepcopy(rows)
    def mark_read(self, notification_id):
        for r in self.save.setdefault('history',{}).setdefault('notifications',[]):
            if r['id']==notification_id: r['read']=True; return deepcopy(r)
        raise ValueError('notification not found')
    def upcoming(self, limit=20):
        fixtures=self.save.get('calendar',{}).get('fixtures',[])
        return deepcopy(sorted(fixtures,key=lambda x:(str(x.get('date','')),str(x.get('id',''))))[:int(limit)])
