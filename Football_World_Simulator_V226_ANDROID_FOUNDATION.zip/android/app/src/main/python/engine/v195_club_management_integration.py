from .v191_club_strategy import V191ClubStrategy
from .v192_club_board import V192ClubBoard
from .v193_club_staff import V193ClubStaff
from .v194_club_performance import V194ClubPerformance
class V195ClubManagementIntegration:
    VERSION='V195'; CHAIN=['V191','V192','V193','V194','V195']
    def __init__(self,save): self.save=save; self.strategy=V191ClubStrategy(save); self.board=V192ClubBoard(save); self.staff=V193ClubStaff(save); self.performance=V194ClubPerformance(save)
    def manage(self,club_id,focus=None,decision=None):
        owned=self.save.setdefault('careers',{}).setdefault('investor',{}).setdefault('owned_clubs',[])
        if club_id not in owned: raise ValueError('clube precisa pertencer ao investidor')
        if focus: self.strategy.set_focus(club_id,focus)
        if decision: self.board.decision(club_id,decision)
        return self.snapshot(club_id)
    def close_season(self,club_id): return self.performance.apply(club_id)
    def snapshot(self,club_id):
        c=self.save['world']['clubs'][club_id]; return {'version':self.VERSION,'club_id':club_id,'focus':c.get('strategic_focus','balanced'),'board_confidence':c.get('board_confidence',50),'board_status':c.get('board_status','stable'),'staff':c.get('staff',{}),'performance_modifier':c.get('management_performance_modifier',1.0)}
    def validate(self): return self.strategy.validate()+self.board.validate()+self.staff.validate()+self.performance.validate()
