"""V225 — Final distributable release manifest."""
from __future__ import annotations
import copy, hashlib, json
class V225FinalRelease:
    VERSION="V225"
    def __init__(self, save, root): self.save=save; self.root=root
    def run(self):
        validation=self.save.get("release",{}).get("v224_validation",{})
        if validation.get("status")!="ready": raise RuntimeError("V224 release gate is not ready")
        files=[]
        for p in self.root.rglob("*"):
            if p.is_file() and not any(part in {".pytest_cache","__pycache__"} for part in p.parts):
                files.append(str(p.relative_to(self.root)))
        files.sort()
        digest=hashlib.sha256("\n".join(files).encode()).hexdigest()
        manifest={"version":self.VERSION,"status":"release-ready","file_count":len(files),"tree_sha256":digest,
                  "base":"V220","player_system":False,"features":{"optimization":True,"recovery":True,"clean_install":True,"assets":True,"interface_contract":True,"tutorial_contract":True,"balance_gate":True,"tests":True}}
        self.save.setdefault("release",{})["final_manifest"]=copy.deepcopy(manifest)
        return manifest
