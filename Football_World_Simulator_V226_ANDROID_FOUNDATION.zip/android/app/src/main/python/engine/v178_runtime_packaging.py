"""V178 — Runtime session, portable save and restore boundary."""
from __future__ import annotations
from copy import deepcopy
import pickle
from .v168_world_state_persistence import V168WorldStatePersistence
from .v177_release_hardening import V177ReleaseHardening

class V178RuntimePackaging:
    VERSION='V178'; SCHEMA=1
    def __init__(self,save): self.save=save
    def start(self):
        V177ReleaseHardening(self.save).run()
        self.save.setdefault('runtime',{})['status']='ready'
        self.save['runtime']['version']=self.VERSION
        self.save['runtime'].setdefault('active_session',{'turn':0,'last_action':None})
        return deepcopy(self.save['runtime'])
    def export_bytes(self):
        V177ReleaseHardening(self.save).run()
        return V168WorldStatePersistence(self.save).export_bytes()
    def restore_bytes(self,data):
        restored=V168WorldStatePersistence.decode(data)
        self.save.clear(); self.save.update(restored)
        self.start()
        return self.save
    def checkpoint(self,action=None):
        rt=self.save.setdefault('runtime',{}); session=rt.setdefault('active_session',{'turn':0,'last_action':None})
        session['turn']=int(session.get('turn',0))+1; session['last_action']=action
        return deepcopy(session)
    def validate(self):
        errors=V177ReleaseHardening(self.save).validate()
        if self.save.get('runtime',{}).get('version') not in (None,self.VERSION): errors.append('runtime_version_invalid')
        return sorted(set(errors))
