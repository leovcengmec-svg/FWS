"""V161 — World Cup 64-Team Format Correction.

Restores the approved FWS V127 World Cup architecture that was accidentally
regressed by V158's qualification layer:
- 64 national teams;
- 8 groups of 8;
- 7 single round-robin group rounds;
- top 4 per group to a 32-team knockout;
- 48 direct places + 32-team global playoff -> 16 winners -> 64.

The V158 international calendar, match-based four-year qualification cycles,
continental championships, Nations League and 8-friendlies rule are preserved.
No player layer is introduced.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .v158_global_selection_calendar import V158GlobalSelectionCalendar
from .v127_world_cup_64 import V127WorldCup64
from .match_engine import MatchEngine


class V161WorldCup64Correction(V158GlobalSelectionCalendar):
    VERSION = "V161"
    WORLD_CUP_SIZE = 64
    WORLD_CUP_GROUPS = 8
    WORLD_CUP_GROUP_SIZE = 8
    WORLD_CUP_GROUP_ROUNDS = 7
    WORLD_CUP_GROUP_QUALIFIERS = 4
    WORLD_CUP_KNOCKOUT = 32

    # Frozen from V127: 48 direct places.
    WC_DIRECT_ALLOCATION = {
        "UEFA": 14,
        "CAF": 10,
        "AFC": 9,
        "CONCACAF": 7,
        "CONMEBOL": 6,
        "OFC": 2,
    }
    # Frozen from V127: 32 global playoff entries -> 16 winners.
    WC_PLAYOFF_ALLOCATION = {
        "UEFA": 3,
        "CONMEBOL": 3,
        "CONCACAF": 5,
        "AFC": 7,
        "CAF": 9,
        "OFC": 5,
    }

    @staticmethod
    def _round_robin_pairs(group):
        if len(group) != 8 or len(set(group)) != 8:
            raise ValueError("World Cup group must contain exactly 8 unique teams")
        arr=list(group); rounds=[]
        for _ in range(7):
            rounds.append([(arr[i], arr[-1-i]) for i in range(4)])
            arr=[arr[0], arr[-1], *arr[1:-1]]
        return rounds

    @classmethod
    def _wc_access_order(cls, ids, points):
        return sorted(ids, key=lambda x: (-points.get(x, 0), x))

    def _resolve_64_from_cycle(self, year, cycle, teams, seed):
        direct, playoff_entries, details = [], [], {}
        for conf in self.CONFEDS:
            ids = teams.get(conf, [])
            order = self._wc_access_order(ids, cycle["points"])
            d = self.WC_DIRECT_ALLOCATION[conf]
            p = self.WC_PLAYOFF_ALLOCATION[conf]
            if len(order) < d + p:
                raise ValueError(f"World Cup access incomplete for {conf}: need {d+p}, have {len(order)}")
            d_ids = order[:d]
            p_ids = order[d:d+p]
            direct.extend(d_ids)
            playoff_entries.extend(p_ids)
            details[conf] = {
                "direct_slots": d,
                "direct_qualified": d_ids,
                "playoff_entries": p,
                "playoff_teams": p_ids,
                "method": "four_year_match_qualification",
            }

        if len(direct) != 48 or len(set(direct)) != 48:
            raise ValueError("World Cup direct access did not close at 48")
        if len(playoff_entries) != 32 or len(set(playoff_entries)) != 32:
            raise ValueError("World Cup global playoff field did not close at 32")

        ordered = list(playoff_entries)
        ordered.sort(key=lambda tid: hashlib.sha256(f"V161:{seed}:{year}:{tid}".encode()).hexdigest())
        national_teams = self.save["world"]["national_teams"]
        winners, playoff_matches = [], []
        for i in range(0, 32, 2):
            a, b = ordered[i], ordered[i + 1]
            ta, tb = self._team(dict(national_teams[a])), self._team(dict(national_teams[b]))
            ta["id"], tb["id"] = a, b
            result = MatchEngine(int(seed) + 70000 + i).play("FWS_WORLD_CUP_PLAYOFF", year, 1, ta, tb)
            if result.home_goals > result.away_goals:
                winner = a
            elif result.away_goals > result.home_goals:
                winner = b
            else:
                digest = hashlib.sha256(f"V161-PO:{seed}:{year}:{a}:{b}".encode()).digest()
                winner = a if digest[0] % 2 == 0 else b
            winners.append(winner)
            playoff_matches.append({
                "competition_id": "FWS_WORLD_CUP_PLAYOFF",
                "season": year,
                "round_no": 1,
                "home_id": a,
                "away_id": b,
                "home_goals": result.home_goals,
                "away_goals": result.away_goals,
                "winner": winner,
            })

        qualified = direct + winners
        if len(winners) != 16 or len(qualified) != 64 or len(set(qualified)) != 64:
            raise ValueError("World Cup final field did not close at 64")

        return {
            "version": self.VERSION,
            "season": year,
            "qualified": qualified,
            "direct_qualified": direct,
            "global_playoff_entries": playoff_entries,
            "global_playoff_winners": winners,
            "global_playoff_matches": playoff_matches,
            "details": details,
            "direct_total": 48,
            "playoff_entry_total": 32,
            "playoff_qualification_total": 16,
            "final_field_total": 64,
            "method": "four_year_match_qualification",
        }

    def simulate_world_cup_qualification(self, season):
        # Preserve V158 cycle accumulation; only replace the final access/field
        # closure with the V127-approved 64-team architecture.
        self._ensure_state()
        y = int(season)
        target = 2030 if 2026 <= y <= 2029 else 2034 if 2030 <= y <= 2033 else 2038 if 2034 <= y <= 2037 else None
        if target is None:
            return None
        if y == 2026:
            q = V127WorldCup64.qualify_world_cup(self, y, 161)
            q["version"] = self.VERSION
            q["method"] = "initial_ranking_bootstrap_v127_64"
            self.save["world"]["world_cup_qualification"] = deepcopy(q)
            self.save["world"]["selection_calendar"]["world_cup_qualification_cycles"]["2030"] = {
                "target_year": 2030, "started": 2026, "matches": [], "points": {}, "qualified": None, "status": "open"
            }
        cycle = self._wc_cycle(target)
        teams = self._teams_by_conf()
        all_matches = []
        for ci, conf in enumerate(self.CONFEDS):
            ids = teams.get(conf, [])
            if not ids:
                continue
            matches, pts = self._play_round_robin(
                f"FWS_{conf}_WORLD_CUP_QUALIFIERS_{target}", y, ids,
                16100 + ci * 1000 + y, rounds=2
            )
            all_matches.extend(matches)
            for tid, val in pts.items():
                cycle["points"][tid] = int(cycle["points"].get(tid, 0)) + int(val)
        cycle["matches"].extend(all_matches)
        cycle["last_season"] = y
        if y == target - 1:
            q = self._resolve_64_from_cycle(target, cycle, teams, 161)
            cycle["qualified"] = q["qualified"]
            cycle["details"] = q["details"]
            cycle["status"] = "qualified"
            self.save["world"]["world_cup_qualification"] = deepcopy(q)
            self.save["history"].setdefault("world_cup_qualification", []).append(deepcopy(q))
        return {
            "version": self.VERSION,
            "season": y,
            "target_world_cup": target,
            "status": cycle["status"],
            "match_count": len(all_matches),
            "qualified": cycle.get("qualified"),
        }

    def qualify_world_cup(self, season=None, seed=161):
        self._ensure_state()
        year = int(season or self.save["world"].get("current_year", 2026))
        q = self.save["world"].get("world_cup_qualification")
        if year == 2026:
            if not q or len(q.get("qualified", [])) != 64:
                q = V127WorldCup64.qualify_world_cup(self, year, seed)
                q["version"] = self.VERSION
                q["method"] = "initial_ranking_bootstrap_v127_64"
                self.save["world"]["world_cup_qualification"] = deepcopy(q)
            return deepcopy(q)
        if isinstance(q, dict) and int(q.get("season", 0)) == year and len(q.get("qualified", [])) == 64:
            return deepcopy(q)
        raise ValueError(f"World Cup {year} has no completed four-year 64-team qualification ledger")

    def simulate_world_cup(self, season=None, seed=161):
        # V127 is the authoritative tournament execution format: 64 -> 8x8 -> 32 -> KO.
        return V127WorldCup64.simulate_world_cup(self, season=season, seed=seed)

    def advance_cycle(self, season=None, seed=161):
        self._ensure_state()
        year = int(season or self.save["world"].get("current_year", 2026))
        self.build_ranking(year)
        wcq = self.simulate_world_cup_qualification(year)
        contq = self.simulate_continental_qualification(year)
        continental = self.simulate_continental_championships(year, seed=seed)
        nl = self.simulate_nations_league(year)
        friendlies = self.simulate_friendlies(year, seed=seed)
        wc = None
        if year in self.WORLD_CUP_YEARS:
            if year == 2026:
                wc = self.simulate_world_cup(year, seed=seed)
                wc["qualification_method"] = "initial_ranking_bootstrap_v127_64"
            elif year in (2030, 2034, 2038):
                q = self.save["world"].get("world_cup_qualification")
                if not q or int(q.get("season", 0)) != year or len(q.get("qualified", [])) != 64:
                    raise ValueError(f"World Cup {year} missing completed 64-team qualification ledger")
                wc = self.simulate_world_cup(year, seed=seed)
                wc["qualification_method"] = "four_year_match_qualification_v127_64"
        result = {
            "version": self.VERSION,
            "season": year,
            "calendar": self.calendar_for_year(year),
            "world_cup_qualification": wcq,
            "continental_qualification": contq,
            "continental": continental,
            "nations_league": nl,
            "friendlies": friendlies,
            "world_cup": wc,
            "status": "COMPLETE",
        }
        self.save["world"]["national_team_cycle"]["last_completed"] = deepcopy(result)
        self.save["history"]["selection_calendar"].append(deepcopy(result))
        return result

    def validate(self):
        errors = []
        q = self.save.get("world", {}).get("world_cup_qualification")
        if q:
            if q.get("direct_total") != 48 or len(q.get("direct_qualified", [])) != 48:
                errors.append("V161 World Cup direct access must contain 48 teams")
            if q.get("playoff_entry_total") != 32 or len(q.get("global_playoff_entries", [])) != 32:
                errors.append("V161 World Cup global playoff must contain 32 entries")
            if q.get("playoff_qualification_total") != 16 or len(q.get("global_playoff_winners", [])) != 16:
                errors.append("V161 World Cup global playoff must produce 16 winners")
            if len(q.get("qualified", [])) != 64 or len(set(q.get("qualified", []))) != 64:
                errors.append("V161 World Cup qualification field must contain 64 unique teams")
        wc = self.save.get("world", {}).get("world_cup")
        if wc:
            if len(wc.get("qualified", [])) != 64 or len(set(wc.get("qualified", []))) != 64:
                errors.append("V161 World Cup field invalid")
            if len(wc.get("groups", [])) != 8 or any(len(g.get("table", [])) != 8 for g in wc.get("groups", [])):
                errors.append("V161 World Cup must contain 8 groups of 8")
            if wc.get("group_rounds") != 7 or wc.get("group_matches_count") != 224:
                errors.append("V161 World Cup group stage must contain 224 matches over 7 rounds")
            if len(wc.get("qualified_to_knockout", [])) != 32:
                errors.append("V161 World Cup knockout field must contain 32 teams")
            if wc.get("knockout_match_count") != 31:
                errors.append("V161 World Cup knockout must contain 31 matches")
        return errors
