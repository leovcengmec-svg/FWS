class Governance:
    """V27: governance profile controls financial exposure without changing match outcomes."""
    PROFILES = {
        'conservative': {'income_multiplier': 0.80, 'expense_multiplier': 0.85, 'risk_multiplier': 0.80},
        'balanced': {'income_multiplier': 1.00, 'expense_multiplier': 1.00, 'risk_multiplier': 1.00},
        'aggressive': {'income_multiplier': 1.20, 'expense_multiplier': 1.15, 'risk_multiplier': 1.20},
    }

    def __init__(self, save):
        self.save = save
        self.rules = save.setdefault('config_runtime', {}).setdefault('investor_finance', {})
        self.rules.setdefault('governance_profile', 'balanced')

    def set_profile(self, profile):
        if profile not in self.PROFILES:
            raise ValueError('perfil de governança inválido')
        self.rules['governance_profile'] = profile
        return self.PROFILES[profile].copy()

    def profile(self):
        name = self.rules.get('governance_profile', 'balanced')
        if name not in self.PROFILES:
            raise ValueError('perfil de governança inválido')
        return self.PROFILES[name].copy()

    def apply_income(self, amount):
        return float(amount) * self.profile()['income_multiplier']

    def apply_expenses(self, amount):
        return float(amount) * self.profile()['expense_multiplier']
