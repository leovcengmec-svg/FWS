from .match_engine import MatchEngine

class LeagueSeason:
    def __init__(self, league, clubs, season, seed=None, engine=None):
        self.league = league
        self.clubs = clubs
        self.season = season
        self.engine = engine or MatchEngine(seed)
        self.matches = []
        self.table = {c["id"]:{
            "club_id":c["id"],"played":0,"wins":0,"draws":0,"losses":0,
            "gf":0,"ga":0,"gd":0,"points":0
        } for c in clubs}

    def schedule(self):
        teams = self.clubs[:]
        if len(teams) % 2: teams.append(None)
        n = len(teams)
        rotation = teams[:]
        first_leg=[]
        for r in range(n-1):
            games=[]
            for i in range(n//2):
                a,b=rotation[i],rotation[n-1-i]
                if a and b:
                    games.append((a,b) if r % 2 == 0 else (b,a))
            first_leg.append(games)
            rotation=[rotation[0]]+[rotation[-1]]+rotation[1:-1]
        return first_leg + [[(b,a) for a,b in rnd] for rnd in first_leg]

    def play(self):
        for rnd,games in enumerate(self.schedule(),1):
            for home,away in games:
                result=self.engine.play(self.league,self.season,rnd,home,away)
                self.matches.append(result)
                self._apply(result)
        return self.standings()

    def _apply(self,m):
        h,a=self.table[m.home_id],self.table[m.away_id]
        h["played"]+=1; a["played"]+=1
        h["gf"]+=m.home_goals; h["ga"]+=m.away_goals
        a["gf"]+=m.away_goals; a["ga"]+=m.home_goals
        if m.home_goals>m.away_goals:
            h["wins"]+=1; h["points"]+=3; a["losses"]+=1
        elif m.home_goals<m.away_goals:
            a["wins"]+=1; a["points"]+=3; h["losses"]+=1
        else:
            h["draws"]+=1; a["draws"]+=1; h["points"]+=1; a["points"]+=1
        h["gd"]=h["gf"]-h["ga"]; a["gd"]=a["gf"]-a["ga"]

    def standings(self):
        return sorted(self.table.values(), key=lambda x:(-x["points"],-x["gd"],-x["gf"],x["club_id"]))
