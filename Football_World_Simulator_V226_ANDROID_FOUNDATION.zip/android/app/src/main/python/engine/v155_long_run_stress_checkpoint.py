from __future__ import annotations
import json
from copy import deepcopy
from pathlib import Path
from .v154_long_run_world_simulation import V154LongRunWorldSimulation

class V155LongRunStressCheckpoint:
    VERSION = "V155"
    TARGET_SEASONS = 10
    TARGET_FINAL_YEAR = 2036

    def __init__(self, save, checkpoint_path=None, seed=155):
        self.save = save
        self.seed = int(seed)
        self.checkpoint_path = Path(checkpoint_path) if checkpoint_path else None

    def _ledger(self):
        return self.save.setdefault("history", {}).setdefault("v155_stress_checkpoints", [])

    def _write_checkpoint(self, row):
        if not self.checkpoint_path:
            return
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": self.VERSION, "last_completed_season": row["season"], "current_year": row["next_year"], "row": row}
        self.checkpoint_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))

    def run_block(self, seasons=1, start_season=None):
        world = self.save.setdefault("world", {})
        start = int(world.get("current_year", 2026) if start_season is None else start_season)
        rows = []
        for i in range(int(seasons)):
            season = start + i
            result = V154LongRunWorldSimulation(self.save, seed=self.seed + season).run(start_season=season, seasons=1)
            row = deepcopy(result["seasons"][0])
            row["checkpoint_version"] = self.VERSION
            self._ledger().append(deepcopy(row))
            self._write_checkpoint(row)
            rows.append(row)
        return {"version": self.VERSION, "status": "completed", "start_season": start, "seasons": rows, "current_year": int(world.get("current_year", -1)), "target_final_year": self.TARGET_FINAL_YEAR}

    def resume(self, seasons=1):
        return self.run_block(seasons=seasons, start_season=None)

    def validate(self):
        errors=[]
        rows=self._ledger()
        for r in rows:
            if r.get("checkpoint_version") != self.VERSION: errors.append(f"wrong_version:{r.get('season')}")
            if r.get("status") != "closed": errors.append(f"not_closed:{r.get('season')}")
            if r.get("intercontinental") != "completed": errors.append(f"intercontinental:{r.get('season')}")
            if r.get("national_team") != "COMPLETE": errors.append(f"national_team:{r.get('season')}")
            if r.get("continental_completed") != r.get("continental_competitions"): errors.append(f"continental:{r.get('season')}")
        if "players" in self.save.get("world", {}) or "player_transfers" in self.save.get("history", {}): errors.append("player_layer_forbidden")
        return errors
