"""V130 — Complete Autonomous AI Engine.

Autonomous decision cycle for clubs and associations. The engine models only
aggregate entities and management state: no individual players, squads or
player-transfer market are created or modified.

Cycle:
    state -> analysis -> decision -> consequence -> new state -> next decision

The engine is deterministic for a given seed, entity id and season. It records
append-only decisions and consequences and can be run repeatedly by season.
"""
from __future__ import annotations

import hashlib
from copy import deepcopy


class V130AutonomousAI:
    VERSION = "V130"
    SCHEMA = 1
    INTENTS = ("compete", "develop", "consolidate", "rebuild")
    MANAGEMENT_ACTIONS = ("maintain", "change_management")
    STRATEGIES = ("sporting", "financial", "infrastructure", "balanced")

    DEFAULTS = {
        "min_score": 1.0,
        "max_score": 100.0,
        "decision_noise": 12.0,
        "change_management_threshold": 72.0,
        "financial_reserve_ratio": 0.20,
        "investment_ratio_compete": 0.12,
        "investment_ratio_develop": 0.16,
        "investment_ratio_consolidate": 0.07,
        "investment_ratio_rebuild": 0.10,
    }

    def __init__(self, save, seed=130, config=None):
        self.save = save
        self.seed = int(seed)
        self.config = {**self.DEFAULTS, **(config or {})}

    def _world(self):
        return self.save.setdefault("world", {})

    def _clubs(self):
        return self._world().setdefault("clubs", {})

    def _associations(self):
        return self._world().setdefault("associations", {})

    def _history(self):
        return self.save.setdefault("history", {}).setdefault("ai_autonomous", [])

    def _noise(self, key):
        digest = hashlib.sha256(f"{self.seed}:{key}".encode("utf-8")).digest()
        return int.from_bytes(digest[:8], "big") / float(2**64 - 1)

    @staticmethod
    def _clamp(value, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(value))), 4)

    @staticmethod
    def _number(value, default=0.0):
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(default)

    def _club_analysis(self, club, season, context):
        strength = self._number(club.get("sporting_strength", club.get("strength", 50)))
        infrastructure = self._number(club.get("infrastructure", 50))
        reputation = self._number(club.get("reputation", 50))
        stability = self._number(club.get("management_stability", 60))
        cash = self._number(club.get("cash", club.get("balance", 0)))
        debt = max(0.0, self._number(club.get("debt", 0)))
        revenue = max(1.0, self._number(club.get("annual_revenue", club.get("revenue", 100))))
        position = context.get("league_position")
        league_size = max(1, int(context.get("league_size", 20)))
        if position is None:
            performance = self._number(context.get("performance_index", 50))
        else:
            performance = self._clamp((league_size + 1 - int(position)) / league_size * 100)
        financial_health = self._clamp(50 + (cash / revenue) * 35 - (debt / revenue) * 45)
        pressure = self._clamp(
            100 - performance * 0.55 + max(0.0, 60 - financial_health) * 0.35
            + max(0.0, 55 - stability) * 0.25
        )
        ambition = self._clamp(strength * 0.35 + reputation * 0.30 + performance * 0.20 + stability * 0.15)
        development_need = self._clamp(
            (100 - infrastructure) * 0.45 + max(0.0, 65 - strength) * 0.35 + max(0.0, 55 - reputation) * 0.20
        )
        n = self._noise(f"club:{club.get('id')}:{season}:analysis")
        return {
            "strength": self._clamp(strength, 1, 100),
            "infrastructure": self._clamp(infrastructure, 1, 100),
            "reputation": self._clamp(reputation, 1, 100),
            "management_stability": self._clamp(stability, 1, 100),
            "financial_health": financial_health,
            "performance_index": performance,
            "pressure": pressure,
            "ambition": ambition,
            "development_need": development_need,
            "noise": round(n, 6),
        }

    def _choose_intent(self, analysis):
        if analysis["financial_health"] < 30:
            return "consolidate"
        if analysis["strength"] < 40 and analysis["development_need"] >= 55:
            return "rebuild"
        if analysis["development_need"] >= 58:
            return "develop"
        if analysis["pressure"] >= 72 and analysis["ambition"] >= 58:
            return "compete"
        if analysis["financial_health"] >= 70 and analysis["ambition"] >= 65:
            return "compete"
        if analysis["development_need"] >= 40:
            return "develop"
        return "consolidate"

    def _strategy_for(self, intent, analysis):
        if intent == "compete":
            return "sporting"
        if intent == "develop":
            return "infrastructure"
        if intent == "consolidate":
            return "financial"
        if analysis["financial_health"] < 45:
            return "financial"
        return "balanced"

    def decide_club(self, club_id, season=None, context=None):
        clubs = self._clubs()
        if club_id not in clubs:
            raise KeyError(f"unknown club: {club_id}")
        season = int(season or self._world().get("current_year", 2026))
        context = context or {}
        club = clubs[club_id]
        analysis = self._club_analysis(club, season, context)
        intent = self._choose_intent(analysis)
        strategy = self._strategy_for(intent, analysis)
        change_score = analysis["pressure"] * 0.55 + (100 - analysis["management_stability"]) * 0.45
        management_action = "change_management" if change_score >= self.config["change_management_threshold"] else "maintain"
        if management_action == "change_management":
            # Aggregate management only; no individual staff/player records.
            consequence_management = self._clamp(analysis["management_stability"] + 8)
        else:
            consequence_management = self._clamp(analysis["management_stability"] + 1.5)

        ratios = {
            "compete": self.config["investment_ratio_compete"],
            "develop": self.config["investment_ratio_develop"],
            "consolidate": self.config["investment_ratio_consolidate"],
            "rebuild": self.config["investment_ratio_rebuild"],
        }
        investment_ratio = ratios[intent]
        available = max(0.0, analysis["financial_health"] / 100.0 * 100.0)
        planned_investment = round(available * investment_ratio, 4)
        if intent == "consolidate":
            reserve_ratio = self.config["financial_reserve_ratio"]
        else:
            reserve_ratio = max(0.10, self.config["financial_reserve_ratio"] - 0.04)
        priorities = {
            "sporting": 1.0 if strategy == "sporting" else 0.35,
            "infrastructure": 1.0 if strategy == "infrastructure" else 0.40,
            "financial_reserve": reserve_ratio,
            "risk": round(self._clamp(100 - analysis["financial_health"]), 4),
        }
        return {
            "entity_type": "club",
            "entity_id": club_id,
            "season": season,
            "intent": intent,
            "strategy": strategy,
            "management_action": management_action,
            "analysis": analysis,
            "planned_investment": planned_investment,
            "priorities": priorities,
            "decision_seed": analysis["noise"],
            "status": "decided",
        }

    def apply_club_decision(self, decision):
        club_id = decision["entity_id"]
        club = self._clubs()[club_id]
        before = {
            "management_stability": self._number(club.get("management_stability", 60)),
            "investment_plan": self._number(club.get("ai_planned_investment", 0)),
            "ai_intent": club.get("ai_intent"),
            "ai_strategy": club.get("ai_strategy"),
        }
        club["management_stability"] = decision["management_action"] == "change_management" and self._clamp(
            before["management_stability"] + 8
        ) or self._clamp(before["management_stability"] + 1.5)
        club["ai_intent"] = decision["intent"]
        club["ai_strategy"] = decision["strategy"]
        club["ai_planned_investment"] = decision["planned_investment"]
        club["ai_risk_tolerance"] = self._clamp(100 - decision["analysis"]["financial_health"])
        consequence = {
            "entity_type": "club",
            "entity_id": club_id,
            "season": decision["season"],
            "decision": decision["intent"],
            "management_action": decision["management_action"],
            "planned_investment": decision["planned_investment"],
            "strategy": decision["strategy"],
            "before": before,
            "after": {
                "management_stability": club["management_stability"],
                "ai_planned_investment": club["ai_planned_investment"],
                "ai_intent": club["ai_intent"],
                "ai_strategy": club["ai_strategy"],
            },
            "effects": ["management_state_updated", "investment_plan_updated", "strategy_state_updated"],
        }
        return consequence

    def _association_analysis(self, association, season, context):
        strength = self._number(association.get("sporting_strength", 50))
        infrastructure = self._number(association.get("infrastructure", 50))
        reputation = self._number(association.get("reputation", 50))
        coefficient = self._number(association.get("coefficient", association.get("continental_coefficient", 0)))
        performance = self._number(context.get("performance", association.get("recent_performance", 50)))
        stability = self._number(association.get("management_stability", 60))
        development_need = self._clamp((100 - infrastructure) * .45 + (100 - strength) * .35 + (100 - reputation) * .20)
        global_pressure = self._clamp((100 - performance) * .65 + max(0, 50 - stability) * .35)
        return {
            "strength": self._clamp(strength, 1, 100),
            "infrastructure": self._clamp(infrastructure, 1, 100),
            "reputation": self._clamp(reputation, 1, 100),
            "coefficient": coefficient,
            "performance": self._clamp(performance),
            "management_stability": self._clamp(stability, 1, 100),
            "development_need": development_need,
            "global_pressure": global_pressure,
            "noise": round(self._noise(f"association:{association.get('id')}:{season}:analysis"), 6),
        }

    def decide_association(self, association_id, season=None, context=None):
        associations = self._associations()
        if association_id not in associations:
            raise KeyError(f"unknown association: {association_id}")
        season = int(season or self._world().get("current_year", 2026))
        context = context or {}
        association = associations[association_id]
        a = self._association_analysis(association, season, context)
        if a["development_need"] >= 60:
            intent = "develop"
            strategy = "infrastructure"
        elif a["global_pressure"] >= 70:
            intent = "rebuild"
            strategy = "balanced"
        elif a["performance"] >= 70:
            intent = "compete"
            strategy = "sporting"
        else:
            intent = "consolidate"
            strategy = "financial"
        management_action = "change_management" if a["global_pressure"] >= self.config["change_management_threshold"] else "maintain"
        return {
            "entity_type": "association",
            "entity_id": association_id,
            "season": season,
            "intent": intent,
            "strategy": strategy,
            "management_action": management_action,
            "analysis": a,
            "planned_investment": round(a["development_need"] / 100 * 10, 4),
            "status": "decided",
        }

    def apply_association_decision(self, decision):
        association = self._associations()[decision["entity_id"]]
        old = self._number(association.get("management_stability", 60))
        association["management_stability"] = self._clamp(old + (8 if decision["management_action"] == "change_management" else 1.5))
        association["ai_intent"] = decision["intent"]
        association["ai_strategy"] = decision["strategy"]
        association["ai_planned_investment"] = decision["planned_investment"]
        return {
            "entity_type": "association",
            "entity_id": decision["entity_id"],
            "season": decision["season"],
            "decision": decision["intent"],
            "management_action": decision["management_action"],
            "strategy": decision["strategy"],
            "planned_investment": decision["planned_investment"],
            "effects": ["management_state_updated", "investment_plan_updated", "strategy_state_updated"],
        }

    def run_cycle(self, season=None, club_context=None, association_context=None):
        season = int(season or self._world().get("current_year", 2026))
        club_context = club_context or {}
        association_context = association_context or {}
        cycle = {"version": self.VERSION, "season": season, "clubs": [], "associations": [], "status": "completed"}
        for cid in sorted(self._clubs()):
            decision = self.decide_club(cid, season, club_context.get(cid, {}))
            cycle["clubs"].append({"decision": deepcopy(decision), "consequence": self.apply_club_decision(decision)})
        for aid in sorted(self._associations()):
            decision = self.decide_association(aid, season, association_context.get(aid, {}))
            cycle["associations"].append({"decision": deepcopy(decision), "consequence": self.apply_association_decision(decision)})
        self._history().append(deepcopy(cycle))
        self._world()["ai_autonomous"] = deepcopy(cycle)
        return cycle

    def validate(self):
        errors = []
        for collection_name, collection in (("club", self._clubs()), ("association", self._associations())):
            for entity_id, entity in collection.items():
                if "ai_intent" in entity and entity["ai_intent"] not in self.INTENTS:
                    errors.append(f"V130 invalid intent {collection_name}:{entity_id}")
                if "ai_strategy" in entity and entity["ai_strategy"] not in self.STRATEGIES:
                    errors.append(f"V130 invalid strategy {collection_name}:{entity_id}")
                if "management_stability" in entity and not 1 <= self._number(entity["management_stability"]) <= 100:
                    errors.append(f"V130 management stability out of range {collection_name}:{entity_id}")
                if "ai_planned_investment" in entity and self._number(entity["ai_planned_investment"]) < 0:
                    errors.append(f"V130 negative planned investment {collection_name}:{entity_id}")
        if "players" in self._world():
            errors.append("V130 must not create a player layer")
        return errors
