"""V112 — Continental Competition Framework.

Defines the FWS continental pyramid and its qualification-first execution rules.
Existing official competitions keep their real identities; FWS-only competitions
use explicit fictional identities. Direct places are coefficient-driven with a
maximum per association/league and NO minimum-one-place rule. Remaining places
are filled through preliminary qualification before the league phase starts.
"""
from __future__ import annotations
from copy import deepcopy


class V112ContinentalCompetitionFramework:
    VERSION = "V112"

    FORMAT_36 = {
        "field_size": 36,
        "league_phase_size": 36,
        "post_league_direct": 8,
        "post_league_playoff_entries": 16,
        "post_league_playoff_qualifiers": 8,
        "knockout_size": 16,
        "description": "qualification to 36 -> league phase -> 8 direct + 16 playoff -> 8 winners -> 16 knockout",
    }
    FORMAT_16 = {
        "field_size": 16,
        "league_phase_size": 16,
        "post_league_direct": 4,
        "post_league_playoff_entries": 8,
        "post_league_playoff_qualifiers": 4,
        "knockout_size": 8,
        "description": "qualification to 16 -> league phase -> 4 direct + 8 playoff -> 4 winners -> 8 knockout",
    }
    FORMAT_72 = {
        "field_size": 72,
        "groups": 2,
        "group_size": 36,
        "post_league_direct_per_group": 8,
        "post_league_playoff_entries_per_group": 16,
        "post_league_playoff_qualifiers_per_group": 8,
        "league_phase_size": 72,
        "knockout_size": 32,
        "description": "qualification to 72 -> 2 groups of 36; each 8 direct + 16 playoff -> 16; 32 knockout",
    }

    # Official competitions use their real names. Extra FWS competitions have
    # deliberately distinct fictional identities.
    PLANS = {
        "UEFA": [
            ("UEFA_CHAMPIONS", "UEFA Champions League", 72, "official", "level_1"),
            ("UEFA_EUROPA", "UEFA Europa League", 36, "official", "level_2"),
            ("UEFA_CONFERENCE", "UEFA Conference League", 36, "official", "level_3"),
            ("UEFA_CONTINENTAL_LEAGUE", "UEFA Continental League", 36, "fws", "extra"),
        ],
        "CONMEBOL": [
            ("LIBERTADORES", "Copa Libertadores", 36, "official", "level_1"),
            ("SUDAMERICANA", "Copa Sudamericana", 36, "official", "level_2"),
            ("CONMEBOL_CONTINENTAL", "CONMEBOL Continental League", 16, "fws", "extra"),
            ("CONMEBOL_DEVELOPMENT", "CONMEBOL Development Cup", 16, "fws", "extra"),
        ],
        "AFC": [
            ("AFC_CHAMPIONS", "AFC Champions League Elite", 36, "official", "level_1"),
            ("AFC_CHAMPIONS_TWO", "AFC Champions League Two", 36, "official", "level_2"),
            ("AFC_CHALLENGE", "AFC Challenge League", 36, "official", "level_3"),
            ("AFC_CONTINENTAL", "AFC Continental League", 16, "fws", "extra"),
        ],
        "CAF": [
            ("CAF_CHAMPIONS", "CAF Champions League", 36, "official", "level_1"),
            ("CAF_CONFEDERATION", "CAF Confederation Cup", 36, "official", "level_2"),
            ("CAF_CONTINENTAL", "CAF Continental League", 36, "fws", "level_3"),
            ("CAF_DEVELOPMENT", "CAF Development Cup", 36, "fws", "extra"),
        ],
        "CONCACAF": [
            ("CONCACAF_CHAMPIONS", "CONCACAF Champions Cup", 36, "official", "level_1"),
            ("CONCACAF_CENTRAL", "Central American Cup", 36, "official", "level_2"),
            ("CONCACAF_CONTINENTAL", "CONCACAF Continental League", 16, "fws", "extra"),
            ("CONCACAF_DEVELOPMENT", "CONCACAF Development Cup", 16, "fws", "extra"),
            # Caribbean Cup remains a real regional competition, but is not
            # forced into the four-main-competition pyramid above.
            ("CONCACAF_CARIBBEAN", "Caribbean Cup", 10, "official", "regional_feeder"),
        ],
        "OFC": [
            ("OFC_CHAMPIONS", "OFC Champions League", 36, "official", "level_1"),
            ("OFC_CONTINENTAL", "OFC Continental League", 16, "fws", "extra"),
            ("OFC_DEVELOPMENT", "OFC Development Cup", 16, "fws", "extra"),
        ],
    }

    def __init__(self, save):
        self.save = save

    @classmethod
    def format_for_size(cls, size):
        size = int(size)
        if size == 72:
            return deepcopy(cls.FORMAT_72)
        if size == 36:
            return deepcopy(cls.FORMAT_36)
        if size == 16:
            return deepcopy(cls.FORMAT_16)
        raise ValueError(f"unsupported V112 competition size: {size}")

    @staticmethod
    def allocate_direct_places(competition_size, leagues, max_direct=6):
        """Coefficient allocation with a cap and NO minimum-one-place rule."""
        if competition_size <= 0 or not leagues:
            return []
        slots = {l["id"]: 0 for l in leagues}
        remaining = int(competition_size)
        while remaining:
            candidates = [l for l in leagues if slots[l["id"]] < max_direct]
            if not candidates:
                break
            candidates.sort(
                key=lambda l: (
                    float(l.get("coefficient", 1.0)) / (slots[l["id"]] + 1),
                    float(l.get("coefficient", 1.0)),
                    str(l["id"]),
                ),
                reverse=True,
            )
            chosen = candidates[0]
            slots[chosen["id"]] += 1
            remaining -= 1
        return [{"league_id": lid, "direct_slots": n} for lid, n in slots.items() if n > 0]

    @staticmethod
    def qualification_plan(size):
        fmt = V112ContinentalCompetitionFramework.format_for_size(size)
        if size == 72:
            return {
                "entry_qualification": "coefficient_direct_slots_then_existing_preliminary_rounds",
                "league_phase_size": 72,
                "groups": 2,
                "group_size": 36,
                "post_league_direct": 16,
                "post_league_playoff_entries": 32,
                "post_league_playoff_qualifiers": 16,
                "knockout_size": 32,
            }
        return {
            "entry_qualification": "coefficient_direct_slots_then_existing_preliminary_rounds",
            "league_phase_size": fmt["league_phase_size"],
            "post_league_direct": fmt["post_league_direct"],
            "post_league_playoff_entries": fmt["post_league_playoff_entries"],
            "post_league_playoff_qualifiers": fmt["post_league_playoff_qualifiers"],
            "knockout_size": fmt["knockout_size"],
        }

    def build_registry(self):
        return {
            cid: {
                "id": cid,
                "name": name,
                "size": size,
                "default_size": size,
                "enabled": True,
                "official": kind == "official",
                "identity_type": kind,
                "tier": tier,
                "intercontinental_eligible": tier != "regional_feeder",
                "confederation": conf,
                "qualification": self.qualification_plan(size) if size in (16, 36, 72) else {"type": "regional_feeder"},
                "league_phase_after_qualification": True,
            }
            for conf, rows in self.PLANS.items()
            for cid, name, size, kind, tier in rows
        }

    def apply(self):
        continental = self.save.setdefault("continental", {})
        # Permanent V112 rule: no mandatory minimum slot per league.
        continental["min_direct_slots"] = 0
        continental["max_direct_slots"] = 6
        continental["distribution_mode"] = "balanced_coefficient_capped"
        continental["qualification_order"] = ["direct_entry", "entry_preliminary", "league_phase", "post_league_direct", "post_league_preliminary", "knockout"]
        continental["continental_framework_version"] = self.VERSION
        continental["competitions"] = self.build_registry()

        world = self.save.setdefault("world", {})
        registry = world.setdefault("competitions", {})
        for cid, cfg in continental["competitions"].items():
            row = dict(cfg)
            row["type"] = "continental_club"
            registry[cid] = row
        world["continental_framework"] = {
            "version": self.VERSION,
            "qualification_rule": "direct_entry_slots_by_coefficient_with_cap_then_existing_preliminary_rounds_before_league_phase",
            "no_minimum_one_slot_rule": True,
            "competitions_by_confederation": {
                conf: [cid for cid, *_ in rows] for conf, rows in self.PLANS.items()
            },
            "formats": {
                "36": deepcopy(self.FORMAT_36),
                "16": deepcopy(self.FORMAT_16),
                "72": deepcopy(self.FORMAT_72),
            },
        }
        return deepcopy(world["continental_framework"])

    def validate(self):
        errors = []
        continental = self.save.get("continental", {})
        if continental.get("min_direct_slots") != 0:
            errors.append("V112 minimum direct slots must be zero")
        if continental.get("max_direct_slots") != 6:
            errors.append("V112 maximum direct slots must be six")
        if continental.get("qualification_order") != ["direct_entry", "entry_preliminary", "league_phase", "post_league_direct", "post_league_preliminary", "knockout"]:
            errors.append("V112 qualification order mismatch")
        framework = self.save.get("world", {}).get("continental_framework", {})
        if framework.get("version") != self.VERSION:
            errors.append("missing V112 continental framework")
        registry = continental.get("competitions", {})
        for conf, rows in self.PLANS.items():
            for cid, name, size, kind, tier in rows:
                if cid not in registry:
                    errors.append(f"missing competition {cid}")
                    continue
                if registry[cid].get("name") != name:
                    errors.append(f"wrong competition name {cid}")
                if registry[cid].get("size") != size:
                    errors.append(f"wrong competition size {cid}")
                if registry[cid].get("official") != (kind == "official"):
                    errors.append(f"wrong identity type {cid}")
        return errors
