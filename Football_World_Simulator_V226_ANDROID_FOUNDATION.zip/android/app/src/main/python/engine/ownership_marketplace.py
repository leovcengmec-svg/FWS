class OwnershipMarketplace:
    """Listings and offers layered above the V35 atomic ownership settlement.

    This layer does not move cash or ownership by itself. Accepted offers are
    converted into V35 transaction settlements, keeping financial effects atomic.
    """
    def __init__(self, save):
        self.save = save
        history = save.setdefault('history', {})
        self.listings = history.setdefault('ownership_listings', [])
        self.offers = history.setdefault('ownership_offers', [])
        self.runtime = save.setdefault('runtime', {})
        self.runtime.setdefault('ownership_marketplace', {'next_id': 1})

    def _club(self, club_id):
        clubs = self.save.setdefault('world', {}).setdefault('clubs', {})
        if club_id not in clubs:
            raise ValueError('clube inexistente')
        return clubs[club_id]

    def _next_id(self, prefix):
        n = int(self.runtime['ownership_marketplace'].get('next_id', 1))
        self.runtime['ownership_marketplace']['next_id'] = n + 1
        return f'{prefix}_{n}'

    def list_club(self, club_id, asking_price=None, seller='player'):
        club = self._club(club_id)
        owner_type = club.get('owner_type', 'ai')
        owner_id = club.get('owner_id')
        if seller == 'player':
            if owner_type != 'user_investor' or owner_id != 'player':
                raise ValueError('somente clube do investidor pode ser listado pelo jogador')
        elif owner_type == 'user_investor' and seller != 'player':
            raise ValueError('vendedor incompatível com proprietário')
        for item in self.listings:
            if item['club_id'] == club_id and item['status'] == 'active':
                raise ValueError('clube já possui anúncio ativo')
        price = float(club.get('market_value', 0.1) or 0.1) if asking_price is None else float(asking_price)
        if price <= 0:
            raise ValueError('preço inválido')
        listing = {
            'id': self._next_id('listing'), 'club_id': club_id,
            'asking_price': round(price, 2), 'seller': seller,
            'owner_id': owner_id, 'status': 'active',
            'season': self.save.get('world', {}).get('current_year')
        }
        self.listings.append(listing)
        return listing.copy()

    def cancel_listing(self, listing_id):
        listing = self._listing(listing_id)
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        listing['status'] = 'cancelled'
        return listing.copy()

    def _listing(self, listing_id):
        for item in self.listings:
            if item['id'] == listing_id:
                return item
        raise ValueError('anúncio inexistente')

    def make_offer(self, listing_id, buyer='player', price=None):
        listing = self._listing(listing_id)
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        offer_price = listing['asking_price'] if price is None else float(price)
        if offer_price <= 0:
            raise ValueError('preço da oferta inválido')
        offer = {
            'id': self._next_id('offer'), 'listing_id': listing_id,
            'club_id': listing['club_id'], 'buyer': buyer,
            'price': round(offer_price, 2), 'status': 'pending',
            'season': self.save.get('world', {}).get('current_year')
        }
        self.offers.append(offer)
        return offer.copy()

    def respond_offer(self, offer_id, decision):
        offer = next((x for x in self.offers if x['id'] == offer_id), None)
        if offer is None:
            raise ValueError('oferta inexistente')
        if offer['status'] != 'pending':
            raise ValueError('oferta já encerrada')
        decision = str(decision).lower()
        if decision not in {'accept', 'reject'}:
            raise ValueError('decisão inválida')
        offer['status'] = 'accepted' if decision == 'accept' else 'rejected'
        return offer.copy()

    def accepted_offer(self, offer_id):
        offer = next((x for x in self.offers if x['id'] == offer_id), None)
        if offer is None:
            raise ValueError('oferta inexistente')
        if offer['status'] != 'accepted':
            raise ValueError('oferta não aceita')
        listing = self._listing(offer['listing_id'])
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        listing['status'] = 'sold'
        return {'listing': listing.copy(), 'offer': offer.copy()}
