"""V143 — Domestic league roster integrity and season preflight.

This module does not invent or add clubs. It classifies each domestic league
according to the V142 access rule and blocks mathematically impossible
seasons (fewer than 8 active clubs) while preserving Brazil canonical aliases.
"""
from dataclasses import dataclass
from typing import Dict, Any, List

BRAZIL_ALIASES = {"BRA_D2", "BRA_D3", "BRA_D4"}

@dataclass(frozen=True)
class LeagueRosterAudit:
    league_id: str
    club_count: int
    status: str
    access_mode: str
    reason: str


def classify_league(league: Dict[str, Any], club_count: int) -> LeagueRosterAudit:
    lid = league["id"]
    if lid in BRAZIL_ALIASES:
        return LeagueRosterAudit(lid, club_count, "canonical_alias", "brazil_exception", "Brazil canonical alias; handled by Brazilian rules")
    if club_count < 8:
        return LeagueRosterAudit(lid, club_count, "roster_incomplete", "blocked", "fewer than 8 active clubs cannot support 4 relegations and 4 accesses")
    if club_count < 12:
        return LeagueRosterAudit(lid, club_count, "valid", "four_direct", "8–11 clubs: four direct accesses and four relegations")
    return LeagueRosterAudit(lid, club_count, "valid", "three_direct_plus_playoff", "12+ clubs: three direct accesses plus 4th–7th playoff and four relegations")


def audit_catalog(catalog: Dict[str, Any]) -> Dict[str, Any]:
    leagues = catalog.get("leagues", {})
    clubs = catalog.get("clubs", {})
    rows: List[Dict[str, Any]] = []
    for lid, league in leagues.items():
        league = dict(league)
        league["id"] = lid
        n = sum(1 for c in clubs.values() if c.get("active", True) and c.get("league_id") == lid)
        a = classify_league(league, n)
        rows.append({"league_id": a.league_id, "club_count": a.club_count, "status": a.status, "access_mode": a.access_mode, "reason": a.reason})
    return {
        "version": "V143",
        "title": "Domestic League Roster Integrity",
        "total_leagues": len(rows),
        "valid_leagues": sum(r["status"] == "valid" for r in rows),
        "roster_incomplete_leagues": sum(r["status"] == "roster_incomplete" for r in rows),
        "canonical_aliases": sum(r["status"] == "canonical_alias" for r in rows),
        "four_direct_leagues": sum(r["access_mode"] == "four_direct" for r in rows),
        "playoff_leagues": sum(r["access_mode"] == "three_direct_plus_playoff" for r in rows),
        "rows": rows,
    }


def assert_season_ready(audit: Dict[str, Any]) -> None:
    bad = [r for r in audit["rows"] if r["status"] == "roster_incomplete"]
    if bad:
        ids = ", ".join(r["league_id"] for r in bad[:10])
        more = "..." if len(bad) > 10 else ""
        raise ValueError(f"DOMESTIC_ROSTER_INCOMPLETE: {len(bad)} leagues require verified real-club restoration ({ids}{more})")
