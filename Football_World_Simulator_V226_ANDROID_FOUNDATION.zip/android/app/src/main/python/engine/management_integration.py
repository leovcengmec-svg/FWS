"""Connects bounded management effects to existing club systems.

The integration changes capacity inputs used by later seasonal systems. It never
writes match outcomes and never directly changes sporting strength.
"""

class ManagementIntegration:
    LIMITS = {
        "infrastructure": 0.35,
        "commercial": 0.30,
        "youth_base": 0.25,
        "scouting": 0.25,
        "sporting": 0.20,
        "debt": 0.20,
        "reserve": 0.20,
    }

    def __init__(self, save, effects_engine):
        self.save = save
        self.effects = effects_engine
        self.history = save.setdefault("history", {}).setdefault("management_integration", [])

    @staticmethod
    def _bounded(value, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(value))), 4)

    def apply(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        effects = self.effects.snapshot(club_id)
        changed = {}

        infra = float(effects.get("infrastructure", 0.0))
        if infra:
            old = float(club.get("infrastructure_score", 40.0))
            club["infrastructure_score"] = self._bounded(old + infra * self.LIMITS["infrastructure"])
            changed["infrastructure_score"] = {"old": old, "new": club["infrastructure_score"]}
            if "stadium_capacity" in club:
                old_cap = float(club["stadium_capacity"])
                club["stadium_capacity"] = round(max(100.0, old_cap * (1 + infra * 0.0008)), 2)
                changed["stadium_capacity"] = {"old": old_cap, "new": club["stadium_capacity"]}

        commercial = float(effects.get("commercial", 0.0))
        if commercial:
            old = float(club.get("marketing_level", 40.0))
            club["marketing_level"] = self._bounded(old + commercial * self.LIMITS["commercial"])
            changed["marketing_level"] = {"old": old, "new": club["marketing_level"]}

        youth = float(effects.get("youth_base", 0.0))
        scouting = float(effects.get("scouting", 0.0))
        if youth:
            old = float(club.get("youth_development_capacity", 40.0))
            club["youth_development_capacity"] = self._bounded(old + youth * self.LIMITS["youth_base"])
            changed["youth_development_capacity"] = {"old": old, "new": club["youth_development_capacity"]}
        if scouting:
            old = float(club.get("scouting_capacity", 40.0))
            club["scouting_capacity"] = self._bounded(old + scouting * self.LIMITS["scouting"])
            changed["scouting_capacity"] = {"old": old, "new": club["scouting_capacity"]}

        sporting = float(effects.get("sporting", 0.0))
        if sporting:
            old = float(club.get("sporting_management_capacity", 40.0))
            club["sporting_management_capacity"] = self._bounded(old + sporting * self.LIMITS["sporting"])
            changed["sporting_management_capacity"] = {"old": old, "new": club["sporting_management_capacity"]}

        debt = float(effects.get("debt", 0.0))
        reserve = float(effects.get("reserve", 0.0))
        if debt:
            old = float(club.get("debt_management_capacity", 40.0))
            club["debt_management_capacity"] = self._bounded(old + debt * self.LIMITS["debt"])
            changed["debt_management_capacity"] = {"old": old, "new": club["debt_management_capacity"]}
        if reserve:
            old = float(club.get("reserve_strength", 40.0))
            club["reserve_strength"] = self._bounded(old + reserve * self.LIMITS["reserve"])
            changed["reserve_strength"] = {"old": old, "new": club["reserve_strength"]}

        # Keep a compact capability snapshot so downstream engines can consume
        # the same integrated state and the season history remains auditable.
        row = {"club_id": club_id, "season": season, "changed": changed,
               "management_readiness": effects.get("management_readiness", 0.0),
               "capabilities": {k: club.get(k) for k in (
                   "infrastructure_score", "marketing_level", "youth_development_capacity",
                   "scouting_capacity", "sporting_management_capacity",
                   "debt_management_capacity", "reserve_strength"
               )}}
        self.history.append(row)
        club.setdefault("management_integration_history", []).append(row)
        return row
