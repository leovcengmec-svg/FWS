from __future__ import annotations
from .domestic_cup import DomesticCup

class NationalCupEngine:
    """Runs every configured domestic cup for a country without collapsing them into one cup."""
    def __init__(self, catalog, registry, match_engine):
        self.catalog=catalog; self.registry=registry; self.engine=match_engine

    def eligible_clubs(self, country_id, cup):
        lo,hi=cup.get('min_level',1),cup.get('max_level',99)
        league_ids=[l['id'] for l in self.catalog.get('leagues',{}).values()
                    if l.get('country_id')==country_id and lo<=int(l.get('level',99))<=hi]
        clubs=[c for c in self.catalog.get('clubs',{}).values() if c.get('league_id') in set(league_ids)]
        return sorted(clubs,key=lambda c:c.get('id',''))

    def run_country(self, country_id, season, history):
        cups=self.registry.get('countries',{}).get(country_id,{}).get('cups',[])
        winners={}; matches=[]
        for cup in cups:
            clubs=self.eligible_clubs(country_id,cup)
            if len(clubs)<2: continue
            obj=DomesticCup(cup['id'],season,clubs,self.engine)
            winner=obj.play()
            if winner:
                winners[cup['id']]={'club_id':winner['id'],'primary_for_continental':bool(cup.get('primary_for_continental'))}
                matches.extend([r.__dict__ for r in obj.results])
                history.setdefault('cup_champions',{}).setdefault(cup['id'],[]).append({'season':season,'club_id':winner['id']})
        return winners,matches
