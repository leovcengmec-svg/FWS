class PortfolioGovernance:
    """V34: portfolio concentration and decision-support guardrails for the investor."""
    def __init__(self, save):
        from .financial_risk import FinancialRisk
        self.save = save
        self.risk = FinancialRisk(save)

    def snapshot(self):
        s = self.risk.snapshot()
        clubs = self.risk._clubs()
        values = sorted((float(c.get('market_value', 0) or 0), c.get('id', cid))
                        for cid, c in self.save.get('world', {}).get('clubs', {}).items()
                        if cid in self.risk.finance.career.get('owned_clubs', []))
        total = sum(v for v, _ in values)
        top_value = values[-1][0] if values else 0.0
        concentration = None if total <= 0 else round(top_value / total, 4)
        club_count = len(clubs)
        recommended_buffer = round(max(0.0, s['owned_club_value'] * 0.10), 2)
        available = s['available_cash']
        liquidity_buffer_ok = available >= recommended_buffer
        if concentration is not None and concentration > .70:
            concentration_level = 'high'
        elif concentration is not None and concentration > .50:
            concentration_level = 'medium'
        else:
            concentration_level = 'low'
        return {
            'owned_clubs': club_count,
            'top_club_share': concentration,
            'concentration_level': concentration_level,
            'recommended_liquidity_buffer': recommended_buffer,
            'liquidity_buffer_ok': liquidity_buffer_ok,
            'risk_level': s['risk_level'],
            'available_cash': available,
            'owned_club_value': s['owned_club_value'],
        }

    def decision_flags(self):
        s = self.snapshot()
        flags = []
        if s['concentration_level'] == 'high':
            flags.append('portfolio_concentration')
        if not s['liquidity_buffer_ok']:
            flags.append('liquidity_buffer_below_10pct_of_assets')
        if s['risk_level'] == 'high':
            flags.append('portfolio_risk_high')
        return flags
