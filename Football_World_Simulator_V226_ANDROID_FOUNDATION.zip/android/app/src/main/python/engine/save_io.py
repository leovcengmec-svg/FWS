"""Atomic, compact and compressed JSON save I/O with legacy JSON compatibility."""
import gzip
import json
import os
import tempfile
from pathlib import Path

_GZIP_MAGIC = b"\x1f\x8b"


def save_world(save, path):
    """Persist a save atomically as gzip-compressed UTF-8 JSON.

    Existing plain-JSON saves remain readable through ``load_world``. The file
    extension is intentionally unchanged so existing Android save paths migrate
    transparently on their next successful save.
    """
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(save, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressed = gzip.compress(payload, compresslevel=6, mtime=0)
    fd, temporary_name = tempfile.mkstemp(
        prefix=destination.name + ".", suffix=".tmp", dir=str(destination.parent)
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(compressed)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    finally:
        try:
            if temporary.exists():
                temporary.unlink()
        except OSError:
            pass


def load_world(path):
    """Load either a compressed save or a legacy plain-JSON save."""
    raw = Path(path).read_bytes()
    if raw.startswith(_GZIP_MAGIC):
        raw = gzip.decompress(raw)
    return json.loads(raw.decode("utf-8"))
