"""V145 — Global domestic roster restoration and final-division queue.

- Minimum 10 active real clubs per ordinary league.
- No synthetic clubs.
- Fill deficits only with real clubs already in the same country's verified pool.
- Four extra real clubs are a separate FIFO waiting pool, not forced into an
  active league. They enter the final division through the annual transition.
- If the catalog lacks enough real clubs, record the exact external collection
  requirement instead of fabricating names.
- Brazil D2/D3/D4 aliases remain untouched.
"""
from __future__ import annotations
import json
from pathlib import Path
from collections import defaultdict

BRAZIL_ALIASES={"BRA_D2","BRA_D3","BRA_D4"}
MIN_CLUBS=10
EXTRA_QUEUE=4

def league_clubs(c):
    out=defaultdict(list)
    for cid,x in c.get('clubs',{}).items():
        if x.get('active',True): out[x.get('league_id')].append(cid)
    return out

def country_leagues(c):
    out=defaultdict(list)
    for lid,l in c.get('leagues',{}).items():
        if lid not in BRAZIL_ALIASES: out[l.get('country_id')].append(lid)
    for k in out: out[k].sort(key=lambda lid:(c['leagues'][lid].get('level',999),lid))
    return out

def rebuild_reverse_indexes(c):
    lc=league_clubs(c)
    for lid,l in c.get('leagues',{}).items():
        if lid in BRAZIL_ALIASES:
            continue
        ids=sorted(lc.get(lid,[]))
        l['club_ids']=ids
        l['club_count']=len(ids)

def build_plan(c):
    lc=league_clubs(c); by=country_leagues(c)
    moves=[]; queues={}; summaries={}
    for country,lids in sorted(by.items()):
        counts={lid:len(lc.get(lid,[])) for lid in lids}
        total=sum(counts.values()); deficit=sum(max(0,MIN_CLUBS-n) for n in counts.values())
        working=dict(counts)
        cmoves=[]
        for target in lids:
            need=max(0,MIN_CLUBS-working[target])
            while need:
                donors=[d for d in lids if d!=target and working[d]>MIN_CLUBS]
                # Prefer lower divisions as donor for a higher-level deficit.
                donors.sort(key=lambda d:(-c['leagues'][d].get('level',999),d))
                if not donors: break
                donor=donors[0]
                cmoves.append((donor,target)); working[donor]-=1; working[target]+=1; need-=1
        unresolved=[lid for lid in lids if working[lid]<MIN_CLUBS]
        # Four extra clubs are only taken from genuine surplus beyond 10/league.
        extra_candidates=[]
        for lid in sorted(lids,key=lambda d:(-c['leagues'][d].get('level',999),d)):
            surplus=working[lid]-MIN_CLUBS
            extra_candidates.extend([(lid)]*max(0,surplus))
        extra_sources=extra_candidates[:EXTRA_QUEUE]
        queue_external=max(0,EXTRA_QUEUE-len(extra_sources))
        for donor in extra_sources:
            # club will be detached from active league and placed in waiting pool
            cmoves.append((donor,'__WAITING_POOL__'))
            working[donor]-=1
        for donor,target in cmoves:
            moves.append({'country_id':country,'from_league':donor,'to_league':target,'type':'internal_rebalance' if target!='__WAITING_POOL__' else 'final_waiting_pool'})
        queues[country]={'size':len(extra_sources),'external_slots_needed':queue_external,'club_ids':[], 'status':'ready' if queue_external==0 else 'requires_external_real_club_collection','policy':'FIFO; first 4 waiting enter when 4 final-division clubs are relegated; remaining waiting clubs persist to next season'}
        summaries[country]={
            'league_count':len(lids),'before_total_clubs':total,
            'minimum_active_clubs_required':MIN_CLUBS*len(lids),
            'initial_deficit':deficit,'internal_rebalance_moves':sum(1 for x in cmoves if x[1]!='__WAITING_POOL__'),
            'waiting_pool_real_clubs_available':len(extra_sources),'waiting_pool_external_slots_needed':queue_external,
            'unresolved_leagues':unresolved,
            'status':'complete_internal' if not unresolved and queue_external==0 else 'external_real_collection_required',
            'final_division':lids[-1] if lids else None
        }
        # store chosen source leagues; actual IDs selected during apply
        queues[country]['source_leagues']=extra_sources
    return moves,summaries,queues

def apply(c, moves, queues):
    lc=league_clubs(c); applied=[]
    for row in moves:
        donor=row['from_league']; target=row['to_league']
        if target=='__WAITING_POOL__':
            cid=sorted(lc[donor])[-1]
            c['clubs'][cid]['active']=False
            c['clubs'][cid]['status']='waiting_final_division'
            c['clubs'][cid]['waiting_for_league']=country_leagues(c)[row['country_id']][-1]
            lc[donor].remove(cid)
            queues[row['country_id']]['club_ids'].append(cid)
            applied.append({**row,'club_id':cid,'club_name':c['clubs'][cid].get('name')})
        else:
            cid=sorted(lc[donor])[-1]
            c['clubs'][cid]['league_id']=target
            lc[donor].remove(cid); lc[target].append(cid)
            applied.append({**row,'club_id':cid,'club_name':c['clubs'][cid].get('name')})
    # Make waiting queues explicit in catalog metadata.
    c.setdefault('final_division_waiting_queues',{})
    for country,q in queues.items():
        c['final_division_waiting_queues'][country]={
            'club_ids':q['club_ids'], 'external_slots_needed':q['external_slots_needed'],
            'policy':'FIFO; first 4 enter when 4 final-division clubs are relegated; remaining waiting clubs persist to next season'
        }
    rebuild_reverse_indexes(c)
    return applied

def audit(c):
    lc=league_clubs(c); rows=[]
    for lid,l in c['leagues'].items():
        if lid in BRAZIL_ALIASES: continue
        n=len(lc.get(lid,[])); rows.append({'league_id':lid,'country_id':l.get('country_id'),'level':l.get('level'),'active_clubs':n,'meets_minimum':n>=MIN_CLUBS})
    return rows

def main(base, out_file):
    base=Path(base); c=json.loads((base/'data/global_world_catalog.json').read_text())
    moves,summaries,queues=build_plan(c); applied=apply(c,moves,queues); rows=audit(c); failed=[r for r in rows if not r['meets_minimum']]
    report={'version':'V145','policy':{'minimum_clubs_per_league':MIN_CLUBS,'extra_waiting_clubs_per_country':EXTRA_QUEUE,'no_synthetic_clubs':True,'waiting_queue':'FIFO','annual_transition':'4 relegated leave; first 4 waiting enter; remaining waiting persist; new verified clubs append','brazil_aliases_untouched':True,'source_priority':['existing_verified_real_club','verified_access_division_club','verified_amateur_club']},'moves':applied,'countries':summaries,'waiting_queues':queues,'league_audit':rows,'remaining_under_10':failed,'total_moves':len(applied),'leagues_below_10_after':len(failed)}
    (base/'data/v145_global_roster_restoration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    (base/'data/global_world_catalog.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
    Path(out_file).write_text(json.dumps({'version':'V145','total_moves':len(applied),'remaining_under_10':len(failed)},indent=2))
    return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('base');p.add_argument('output');a=p.parse_args();print(json.dumps(main(a.base,a.output),indent=2))
