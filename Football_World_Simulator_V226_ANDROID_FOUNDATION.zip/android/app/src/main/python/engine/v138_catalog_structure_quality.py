"""V138 - Real-world domestic structure quality audit.

Removes only records that are provably synthetic placeholders from the active
world catalog. They are quarantined, not silently converted into real clubs.
"""
from __future__ import annotations
from copy import deepcopy
import re

class V138CatalogStructureQuality:
    VERSION = "V138"
    SYNTHETIC_NAME = re.compile(r"^.+ Clube \d+-\d+$")

    def identify_synthetic(self, catalog: dict):
        return sorted(cid for cid, club in catalog.get("clubs", {}).items()
                      if self.SYNTHETIC_NAME.match(str(club.get("name", "")).strip()))

    def normalize(self, catalog: dict) -> dict:
        out = deepcopy(catalog)
        clubs = out.setdefault("clubs", {})
        leagues = out.setdefault("leagues", {})
        ids = self.identify_synthetic(out)
        quarantine = out.setdefault("quarantine", {})
        qclubs = quarantine.setdefault("synthetic_clubs", {})
        for cid in ids:
            qclubs[cid] = clubs.pop(cid)
        for league in leagues.values():
            league["club_ids"] = [cid for cid in league.get("club_ids", []) if cid in clubs]
            league["club_count"] = len(league["club_ids"])
        coverage = out.setdefault("coverage", {})
        coverage["total_clubs"] = len(clubs)
        coverage["active_clubs"] = len(clubs)
        coverage["quarantined_synthetic_clubs"] = len(qclubs)
        coverage["clubs_empty_leagues"] = sum(1 for l in leagues.values() if not l.get("club_ids"))
        out.setdefault("integrity", {})["catalog_structure_quality_version"] = self.VERSION
        out["version"] = self.VERSION
        return out

    def validate(self, catalog: dict):
        errors=[]
        clubs=catalog.get("clubs",{}); leagues=catalog.get("leagues",{})
        for cid,c in clubs.items():
            if c.get('status') == 'waiting_final_division':
                continue
            if self.SYNTHETIC_NAME.match(str(c.get("name","")).strip()):
                errors.append({"type":"active_synthetic_club","club_id":cid,"name":c.get("name")})
            lid=c.get("league_id")
            if lid not in leagues:
                errors.append({"type":"club_missing_league","club_id":cid,"league_id":lid})
            elif cid not in leagues[lid].get("club_ids",[]):
                errors.append({"type":"club_reverse_index_missing","club_id":cid,"league_id":lid})
        for lid,l in leagues.items():
            if l.get("club_count") != len(l.get("club_ids",[])):
                errors.append({"type":"league_count_mismatch","league_id":lid})
            for cid in l.get("club_ids",[]):
                if cid not in clubs:
                    errors.append({"type":"league_unknown_club","league_id":lid,"club_id":cid})
                elif clubs[cid].get("country_id") != l.get("country_id"):
                    errors.append({"type":"country_mismatch","league_id":lid,"club_id":cid})
        return {"valid":not errors,"error_count":len(errors),"errors":errors,
                "active_clubs":len(clubs),"leagues":len(leagues),
                "quarantined_synthetic_clubs":len(catalog.get("quarantine",{}).get("synthetic_clubs",{}))}
