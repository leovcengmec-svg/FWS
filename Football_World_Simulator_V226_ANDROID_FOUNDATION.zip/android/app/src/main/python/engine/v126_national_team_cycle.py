"""V126 — FWS National Team Complete International Cycle.

Aggregate national-team engine: ranking, international windows, confederation
championships, World Cup qualification, World Cup finals and append-only history.
No individual players or player transfer systems are introduced.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from .v125_super_world_club_championship import V125SuperWorldClubChampionship
from .match_engine import MatchEngine

class V126NationalTeamCycle(V125SuperWorldClubChampionship):
    VERSION = "V126"
    WORLD_CUP = "FWS_WORLD_CUP"
    WORLD_CUP_SIZE = 48
    WORLD_CUP_GROUPS = 12
    WORLD_CUP_GROUP_SIZE = 4
    WORLD_CUP_KNOCKOUT = 32
    WC_ALLOCATION = {"UEFA":16,"AFC":8,"CAF":9,"CONMEBOL":6,"CONCACAF":6,"OFC":1,"INTERCONTINENTAL":2}
    CONTINENTAL_FORMATS = {
        "UEFA":{"size":24,"groups":6,"knockout":16,"cycle_anchor":2028},
        "CONMEBOL":{"size":16,"groups":4,"knockout":8,"cycle_anchor":2028},
        "AFC":{"size":24,"groups":6,"knockout":16,"cycle_anchor":2027},
        "CAF":{"size":24,"groups":6,"knockout":16,"cycle_anchor":2027},
        "CONCACAF":{"size":16,"groups":4,"knockout":8,"cycle_anchor":2027},
        "OFC":{"size":8,"groups":2,"knockout":4,"cycle_anchor":2028},
    }
    WINDOW_NAMES = ("MARCH","JUNE","SEPTEMBER","OCTOBER","NOVEMBER")

    def _team(self, team):
        t=dict(team)
        # Internal simulation IDs are association keys (e.g. AFG), not display/entity IDs.
        s=float(t.get("strength",50.0))
        t.setdefault("attack", s); t.setdefault("defense", s); t.setdefault("prestige", s)
        return t

    def _ensure_state(self):
        w=self.save.setdefault("world",{})
        w.setdefault("national_team_ranking", {})
        w.setdefault("national_team_ranking_history", [])
        w.setdefault("national_team_cycle", {"version":self.VERSION,"windows":[],"competitions":[]})
        h=self.save.setdefault("history",{})
        h.setdefault("national_team_matches", [])
        h.setdefault("national_team_competitions", [])
        h.setdefault("national_team_ranking", [])

    def build_ranking(self, season=None):
        self._ensure_state(); year=season or self.save["world"].get("current_year",2026)
        rows=[]
        for tid,t in self.save["world"].get("national_teams",{}).items():
            s=float(t.get("strength",50)); form=float(t.get("form",0)); rep=float(t.get("global_reputation",t.get("prestige",50)))
            prior=float(t.get("national_ranking_points",1000))
            points=max(1, prior + (s-50)*1.7 + form*2.0 + (rep-50)*0.25)
            t["national_ranking_points"]=round(points,4)
            rows.append({"team_id":tid,"association_id":t.get("association_id"),"name":t.get("name",tid),"confederation":t.get("confederation"),"points":round(points,4),"strength":round(s,2)})
        rows.sort(key=lambda r:(-r["points"],r["team_id"]))
        for i,r in enumerate(rows,1): r["rank"]=i
        ranking={"version":self.VERSION,"season":year,"teams":rows}
        self.save["world"]["national_team_ranking"]=deepcopy(ranking)
        self.save["world"]["national_team_ranking_history"].append(deepcopy(ranking))
        self.save["history"]["national_team_ranking"].append(deepcopy(ranking))
        return ranking

    def _play_match(self, competition, season, round_no, a, b, seed):
        aa=self._team(a); bb=self._team(b)
        r=MatchEngine(seed).play(competition,season,round_no,aa,bb)
        row={"competition_id":competition,"season":season,"round_no":round_no,"home_id":a["id"],"away_id":b["id"],"home_goals":r.home_goals,"away_goals":r.away_goals}
        self.save["history"]["national_team_matches"].append(deepcopy(row))
        if r.home_goals>r.away_goals:return a,row,3,0
        if r.away_goals>r.home_goals:return b,row,0,3
        return None,row,1,1

    def simulate_windows(self, season=None, windows=None, seed=126):
        self._ensure_state(); year=season or self.save["world"].get("current_year",2026); names=tuple(windows or self.WINDOW_NAMES)
        teams={k:self._team(v) for k,v in self.save["world"].get("national_teams",{}).items()}
        ranking=self.build_ranking(year); ordered=[r["team_id"] for r in ranking["teams"]]
        rows=[]
        for wi,name in enumerate(names,1):
            matches=[]
            for ci,conf in enumerate(("UEFA","AFC","CAF","CONMEBOL","CONCACAF","OFC")):
                ids=[tid for tid in ordered if teams[tid].get("confederation")==conf]
                # One deterministic opponent per team per window; odd teams leave one bye.
                offset=(wi+ci)%max(1,len(ids))
                rotated=ids[offset:]+ids[:offset]
                for j in range(0,len(rotated)-1,2):
                    a,b=teams[rotated[j]],teams[rotated[j+1]]
                    _,match,pa,pb=self._play_match("FWS_INTERNATIONAL_WINDOW",year,wi,a,b,int(seed)+wi*10000+ci*100+j)
                    matches.append(match)
                    a["form"]=max(-10,min(10,a.get("form",0)+(pa-1)*0.6)); b["form"]=max(-10,min(10,b.get("form",0)+(pb-1)*0.6))
            self.build_ranking(year)
            event={"version":self.VERSION,"season":year,"window":name,"round":wi,"match_count":len(matches),"matches":matches}
            self.save["world"]["national_team_cycle"]["windows"].append(deepcopy(event)); rows.append(event)
        return rows

    @staticmethod
    def _groups(ids, group_count):
        groups=[[] for _ in range(group_count)]
        for i,tid in enumerate(ids): groups[i%group_count].append(tid)
        return groups

    def _tournament(self, competition_id, season, confederation, ids, size, groups, knockout, seed):
        if len(ids)!=size or len(set(ids))!=size: raise ValueError(f"{competition_id}: invalid field size")
        teams={k:self._team(v) for k,v in self.save["world"]["national_teams"].items()}
        for k,t in teams.items(): t["id"]=k
        gs=self._groups(ids,groups); tables=[]; matches=[]
        for gi,g in enumerate(gs,1):
            pts={x:0 for x in g}
            for rnd,(x,y) in enumerate(((g[0],g[1]),(g[2],g[3]),(g[0],g[2])) if len(g)==4 else [],1):
                _,m,px,py=self._play_match(competition_id,season,rnd,teams[x],teams[y],seed+gi*100+rnd); matches.append(m); pts[x]+=px; pts[y]+=py
            ordered=sorted(g,key=lambda x:(-pts[x],x)); tables.append({"group":gi,"table":[{"team_id":x,"points":pts[x],"position":p+1} for p,x in enumerate(ordered)]})
        qualified=[]
        for tab in tables: qualified.extend([r["team_id"] for r in tab["table"][:2]])
        if size == 24 and knockout == 16:
            thirds = [tab["table"][2] for tab in tables]
            thirds.sort(key=lambda r:(-r["points"], r["team_id"]))
            qualified.extend([r["team_id"] for r in thirds[:4]])
        qualified=qualified[:knockout]
        round_ids=qualified; knockout_rows=[]; rnd=1
        while len(round_ids)>1:
            nxt=[]
            for i in range(0,len(round_ids),2):
                a,b=teams[round_ids[i]],teams[round_ids[i+1]]
                winner,m,pa,pb=self._play_match(competition_id,season,100+rnd,a,b,seed+9000+rnd*100+i); knockout_rows.append(m)
                if winner is None: winner=a if hashlib.sha256(f"{seed}:{a['id']}:{b['id']}".encode()).digest()[0]%2==0 else b
                nxt.append(winner["id"])
            round_ids=nxt; rnd+=1
        champion=round_ids[0] if round_ids else None
        return {"version":self.VERSION,"competition_id":competition_id,"season":season,"confederation":confederation,"field":ids,"groups":tables,"matches":matches,"knockout_matches":knockout_rows,"champion":champion}

    def simulate_continental_championships(self, season=None, seed=126):
        self._ensure_state(); year=season or self.save["world"].get("current_year",2026); ranking=self.build_ranking(year); out=[]
        for conf,cfg in self.CONTINENTAL_FORMATS.items():
            if (year-cfg["cycle_anchor"])%4!=0: continue
            ids=[r["team_id"] for r in ranking["teams"] if r["confederation"]==conf][:cfg["size"]]
            if len(ids)<cfg["size"]: continue
            comp=self._tournament(f"FWS_{conf}_NATIONS",year,conf,ids,cfg["size"],cfg["groups"],cfg["knockout"],seed+len(out)*1000)
            self.save["history"]["national_team_competitions"].append(deepcopy(comp)); self.save["world"]["national_team_cycle"]["competitions"].append(deepcopy(comp)); out.append(comp)
        return out

    def qualify_world_cup(self, season=None, seed=126):
        self._ensure_state(); year=season or self.save["world"].get("current_year",2026); ranking=self.build_ranking(year); qualified=[]; details={}
        for conf,slots in self.WC_ALLOCATION.items():
            if conf=="INTERCONTINENTAL": continue
            ids=[r["team_id"] for r in ranking["teams"] if r["confederation"]==conf]
            chosen=ids[:slots]; qualified.extend(chosen); details[conf]={"slots":slots,"qualified":chosen,"method":"ranking_qualification"}
        # Two intercontinental places are resolved by a six-team ranking playoff pool.
        pool=[r["team_id"] for r in ranking["teams"] if r["team_id"] not in qualified][:6]
        pool=pool[:max(2,len(pool))]; qualified.extend(pool[:2]); details["INTERCONTINENTAL"]={"slots":2,"qualified":pool[:2],"method":"ranking_playoff_pool"}
        if len(qualified)!=48: raise ValueError("World Cup qualification did not close at 48")
        result={"version":self.VERSION,"season":year,"qualified":qualified,"details":details}
        self.save["world"]["world_cup_qualification"]=deepcopy(result); self.save["history"].setdefault("world_cup_qualification",[]).append(deepcopy(result)); return result

    def simulate_world_cup(self, season=None, seed=126):
        self._ensure_state(); year=season or self.save["world"].get("current_year",2026)
        q=self.qualify_world_cup(year,seed); teams={k:self._team(v) for k,v in self.save["world"]["national_teams"].items()};
        for k,t in teams.items(): t["id"]=k
        ids=q["qualified"]
        groups=self._groups(ids,12); tables=[]; matches=[]
        for gi,g in enumerate(groups,1):
            pts={x:0 for x in g}
            for rnd,(a,b) in enumerate(((g[0],g[1]),(g[2],g[3]),(g[0],g[2])),1):
                _,m,pa,pb=self._play_match(self.WORLD_CUP,year,rnd,teams[a],teams[b],seed+gi*100+rnd); matches.append(m); pts[a]+=pa; pts[b]+=pb
            ordered=sorted(g,key=lambda x:(-pts[x],x)); tables.append([{"team_id":x,"points":pts[x],"position":p+1} for p,x in enumerate(ordered)])
        qualified32=[]
        for t in tables: qualified32.extend([r["team_id"] for r in t[:2]])
        third=[t[2]["team_id"] for t in tables]; qualified32.extend(third[:8])
        round_ids=qualified32; ko=[]; rnd=1
        while len(round_ids)>1:
            nxt=[]
            for i in range(0,len(round_ids),2):
                a,b=teams[round_ids[i]],teams[round_ids[i+1]]; winner,m,_,_=self._play_match(self.WORLD_CUP,year,100+rnd,a,b,seed+50000+rnd*100+i); ko.append(m)
                if winner is None: winner=a if hashlib.sha256(f"WC:{year}:{a['id']}:{b['id']}".encode()).digest()[0]%2==0 else b
                nxt.append(winner["id"])
            round_ids=nxt; rnd+=1
        champion=round_ids[0]
        result={"version":self.VERSION,"competition_id":self.WORLD_CUP,"season":year,"qualified":ids,"groups":tables,"group_matches":matches,"knockout_matches":ko,"champion":champion}
        self.save["history"].setdefault("world_champions",[]).append({"season":year,"national_team_id":champion}); self.save["world"]["world_cup"] = deepcopy(result); return result

    def advance_cycle(self, season=None, seed=126):
        year=season or self.save["world"].get("current_year",2026); self._ensure_state(); self.build_ranking(year); windows=self.simulate_windows(year,seed=seed); continental=self.simulate_continental_championships(year,seed=seed); wc=None
        if (year-2026)%4==0: wc=self.simulate_world_cup(year,seed=seed)
        result={"version":self.VERSION,"season":year,"windows":windows,"continental":continental,"world_cup":wc,"status":"COMPLETE"}
        self.save["world"]["national_team_cycle"]["last_completed"]=deepcopy(result); self.save.setdefault("history",{}).setdefault("national_team_cycles",[]).append(deepcopy(result)); return result

    def validate(self):
        self._ensure_state(); errors=[]; ranking=self.save["world"].get("national_team_ranking")
        if ranking and ranking.get("version")!=self.VERSION: errors.append("wrong V126 ranking version")
        if ranking and len(ranking.get("teams",[]))!=211: errors.append("V126 ranking must contain 211 national teams")
        for r in (ranking or {}).get("teams",[]):
            if r.get("rank",0)<1: errors.append("invalid V126 ranking rank")
        wc=self.save["world"].get("world_cup")
        if wc:
            if len(wc.get("qualified",[]))!=48 or len(set(wc.get("qualified",[])))!=48: errors.append("V126 World Cup field invalid")
            if wc.get("champion") not in wc.get("qualified",[]): errors.append("V126 World Cup champion invalid")
        return errors
