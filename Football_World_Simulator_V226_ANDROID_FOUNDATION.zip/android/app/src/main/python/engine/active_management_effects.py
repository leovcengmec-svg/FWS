"""Seasonal consequences of executive club investment decisions.

Effects are gradual, bounded management capabilities. They never directly add
match-result points, attack/defense, or guaranteed wins.
"""

class ActiveManagementEffects:
    RATES = {
        "infrastructure": 0.015,
        "commercial": 0.018,
        "youth_base": 0.014,
        "scouting": 0.013,
        "sporting": 0.012,
        "debt": 0.010,
        "reserve": 0.008,
    }

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("active_management_effects", [])

    def apply_season(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        effects = club.setdefault("management_effects", {})
        spending = club.get("management_spending", {})
        applied = {}
        for category, rate in self.RATES.items():
            amount = max(0.0, float(spending.get(category, 0.0)))
            previous = float(effects.get(category, 0.0))
            gain = round(amount * rate, 4)
            effects[category] = round(min(100.0, previous + gain), 4)
            applied[category] = {"spending_base": round(amount, 2), "gain": gain, "score": effects[category]}
        # A bounded readiness score summarizes management capacity, not sporting strength.
        readiness = sum(float(effects.get(k, 0.0)) for k in self.RATES) / len(self.RATES)
        effects["management_readiness"] = round(min(100.0, readiness), 4)
        record = {"club_id": club_id, "season": season, "applied": applied,
                  "management_readiness": effects["management_readiness"]}
        self.history.append(record)
        club.setdefault("management_effect_history", []).append(record)
        return record

    def snapshot(self, club_id):
        club = self.save.get("world", {}).get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        return dict(club.get("management_effects", {}))
