from __future__ import annotations
import copy

class V88WorldDatabaseAssets:
    VERSION = 'V88'

    def __init__(self, catalog, assets):
        self.catalog = catalog
        self.assets = assets

    def _asset_key(self, owner_type, owner_id, kind):
        return f'{owner_type}:{owner_id}:{kind}'

    def consolidate(self):
        assets = self.assets.setdefault('assets', {})
        added = 0
        def ensure(owner_type, owner_id, kind, status='pending_verification'):
            nonlocal added
            key = self._asset_key(owner_type, owner_id, kind)
            if key not in assets:
                assets[key] = {
                    'id': key, 'owner_type': owner_type, 'owner_id': owner_id,
                    'kind': kind, 'uri': None, 'source': None,
                    'status': status, 'checksum': None,
                    'license': 'verify source/license before redistribution',
                    'schema_version': 2,
                }
                added += 1
        for oid in self.catalog.get('associations', {}):
            ensure('association', oid, 'flag')
        for oid in self.catalog.get('leagues', {}):
            ensure('league', oid, 'logo')
        for oid in self.catalog.get('clubs', {}):
            ensure('club', oid, 'crest')
        self.assets['version'] = self.VERSION
        return added

    def validate(self):
        errors=[]
        assets=self.assets.get('assets',{})
        expected=[('association',k,'flag') for k in self.catalog.get('associations',{})]
        expected += [('league',k,'logo') for k in self.catalog.get('leagues',{})]
        expected += [('club',k,'crest') for k in self.catalog.get('clubs',{})]
        for owner_type, owner_id, kind in expected:
            key=self._asset_key(owner_type,owner_id,kind)
            if key not in assets: errors.append(f'missing asset reference: {key}')
        for key,a in assets.items():
            if a.get('id') != key: errors.append(f'asset key/id mismatch: {key}')
            if a.get('owner_type') not in {'association','league','club','country','national_team','competition','confederation'}:
                errors.append(f'invalid owner_type: {key}')
            if a.get('status') not in {'verified','remote_ready','missing','placeholder','pending_verification'}:
                errors.append(f'invalid status: {key}')
            if a.get('status') in {'verified','remote_ready'} and not a.get('uri'):
                errors.append(f'active asset without uri: {key}')
        return errors

    def summary(self):
        assets=self.assets.get('assets',{})
        return {
            'version': self.assets.get('version'),
            'expected_associations': len(self.catalog.get('associations',{})),
            'expected_leagues': len(self.catalog.get('leagues',{})),
            'expected_clubs': len(self.catalog.get('clubs',{})),
            'total_assets': len(assets),
            'status_counts': {s:sum(1 for a in assets.values() if a.get('status')==s) for s in ['verified','remote_ready','pending_verification','missing','placeholder']},
        }
