"""V186 — Investor finance core.
No player-level systems are introduced; all finance is person/club level.
"""
from __future__ import annotations
from copy import deepcopy

class V186InvestorFinance:
    VERSION='V186'
    def __init__(self, save): self.save=save; self.save.setdefault('careers',{}).setdefault('investor',{'cash':0.0,'owned_clubs':[],'transactions':[]})
    @property
    def investor(self): return self.save['careers']['investor']
    def deposit(self, amount, reason='capital_injection'):
        amount=float(amount)
        if amount<=0: raise ValueError('amount must be positive')
        self.investor['cash']=round(float(self.investor.get('cash',0))+amount,2)
        self._tx('deposit',amount,None,reason); return self.investor['cash']
    def withdraw(self, amount, reason='withdrawal'):
        amount=float(amount)
        if amount<=0 or amount>float(self.investor.get('cash',0)): raise ValueError('insufficient investor cash')
        self.investor['cash']=round(float(self.investor['cash'])-amount,2); self._tx('withdraw',amount,None,reason); return self.investor['cash']
    def _tx(self, kind, amount, club_id, reason):
        self.investor.setdefault('transactions',[]).append({'type':kind,'amount':round(float(amount),2),'club_id':club_id,'reason':reason,'season':self.save.get('world',{}).get('current_year')})
    def portfolio(self):
        clubs=self.save.get('world',{}).get('clubs',{}); ids=list(dict.fromkeys(self.investor.get('owned_clubs',[])))
        rows=[deepcopy(clubs[c]) for c in ids if c in clubs]
        return {'cash':float(self.investor.get('cash',0)), 'owned_clubs':len(rows), 'portfolio_value':round(sum(float(c.get('market_value',0)) for c in rows),2),'clubs':rows}
    def invest(self, club_id, amount, category='infrastructure'):
        amount=float(amount); club=self.save.get('world',{}).get('clubs',{}).get(club_id)
        if not club or amount<=0 or amount>float(self.investor.get('cash',0)): raise ValueError('invalid club or investment')
        self.investor['cash']=round(float(self.investor['cash'])-amount,2)
        club['investment_ledger']=club.setdefault('investment_ledger',[])
        club['investment_ledger'].append({'amount':round(amount,2),'category':category,'season':self.save['world'].get('current_year')})
        club['cash']=round(float(club.get('cash',0))+amount,2)
        multiplier={'infrastructure':1.08,'sport':1.05,'commercial':1.06,'stability':1.03}.get(category,1.04)
        club['market_value']=round(max(0,float(club.get('market_value',0))*multiplier),3)
        self._tx('investment',amount,club_id,category)
        return {'club_id':club_id,'amount':amount,'category':category,'market_value':club['market_value']}
    def validate(self):
        return [] if float(self.investor.get('cash',0))>=0 else ['negative_investor_cash']
