"""V118 — Continental Competition Rules Configuration.

Separates the continental structure already approved from unresolved competition
parameters. V118 does not invent match counts or legs; it provides a validated,
versioned configuration contract that later rules can fill explicitly.
"""
from __future__ import annotations
from copy import deepcopy
from .v117_continental_season_integration import V117ContinentalSeasonIntegration


class V118ContinentalRulesConfiguration(V117ContinentalSeasonIntegration):
    VERSION = "V118"
    REQUIRED_KEYS = (
        "league_phase_matches_per_club",
        "post_league_playoff_legs",
        "knockout_legs",
        "knockout_pairing",
    )
    ALLOWED_PAIRINGS = ("seeded", "adjacent")
    SUPPORTED_SIZES = (16, 36, 72)

    @classmethod
    def rules_contract(cls, size):
        size = int(size)
        if size not in cls.SUPPORTED_SIZES:
            raise ValueError("continental competition size must be 16, 36 or 72")
        if size == 72:
            return {
                "size": 72,
                "league_phase_structure": "2_groups_of_36",
                "post_league_direct": 16,
                "post_league_playoff_entries": 32,
                "post_league_playoff_qualifiers": 16,
                "knockout_size": 32,
            }
        if size == 36:
            return {
                "size": 36,
                "league_phase_structure": "single_36",
                "post_league_direct": 8,
                "post_league_playoff_entries": 16,
                "post_league_playoff_qualifiers": 8,
                "knockout_size": 16,
            }
        return {
            "size": 16,
            "league_phase_structure": "single_16",
            "post_league_direct": 4,
            "post_league_playoff_entries": 8,
            "post_league_playoff_qualifiers": 4,
            "knockout_size": 8,
        }

    @classmethod
    def validate_competition_rules(cls, competition):
        errors = []
        size = competition.get("size", competition.get("default_size"))
        try:
            contract = cls.rules_contract(size)
        except (TypeError, ValueError) as exc:
            return [str(exc)]
        if int(competition.get("knockout_size", contract["knockout_size"])) != contract["knockout_size"]:
            errors.append("knockout_size does not match continental format")
        for key in cls.REQUIRED_KEYS:
            if key not in competition:
                errors.append(f"missing {key}")
        if competition.get("league_phase_matches_per_club") is not None:
            try:
                if int(competition["league_phase_matches_per_club"]) <= 0:
                    errors.append("league_phase_matches_per_club must be positive")
            except (TypeError, ValueError):
                errors.append("league_phase_matches_per_club must be an integer")
        for key in ("post_league_playoff_legs", "knockout_legs"):
            if competition.get(key) is not None:
                try:
                    if int(competition[key]) <= 0:
                        errors.append(f"{key} must be positive")
                except (TypeError, ValueError):
                    errors.append(f"{key} must be an integer")
        if competition.get("knockout_pairing") is not None and competition["knockout_pairing"] not in cls.ALLOWED_PAIRINGS:
            errors.append("unsupported knockout_pairing")
        return errors

    def apply(self):
        # Preserve pre-existing custom competition definitions before the V112
        # framework rebuilds its canonical registry. This prevents unrelated
        # configuration/data loss while still keeping the approved framework.
        prior = deepcopy(self.save.get("continental", {}).get("competitions", {}))
        prior_world = deepcopy(self.save.get("world", {}).get("competitions", {}))
        super().apply()
        canonical = self.save.setdefault("continental", {}).setdefault("competitions", {})
        for cid, old_cfg in prior.items():
            if cid not in canonical:
                canonical[cid] = old_cfg
        world_registry = self.save.setdefault("world", {}).setdefault("competitions", {})
        for cid, old_cfg in prior_world.items():
            if cid not in world_registry and old_cfg.get("type") == "continental_club":
                world_registry[cid] = old_cfg
        world = self.save.setdefault("world", {})
        registry = self.save.setdefault("continental", {}).setdefault("competitions", {})
        for cid, cfg in registry.items():
            size = int(cfg.get("size", cfg.get("default_size", 0)))
            if size in self.SUPPORTED_SIZES:
                cfg["v118_rules_contract"] = self.rules_contract(size)
                cfg["rules_configuration_version"] = self.VERSION
                # Explicit None means deliberately unresolved; never guess a value.
                cfg.setdefault("league_phase_matches_per_club", None)
                cfg.setdefault("post_league_playoff_legs", None)
                cfg.setdefault("knockout_legs", None)
                cfg.setdefault("knockout_pairing", None)
                world.setdefault("competitions", {}).setdefault(cid, {}).update({
                    "v118_rules_contract": deepcopy(cfg["v118_rules_contract"]),
                    "rules_configuration_version": self.VERSION,
                })
        world["continental_rules_configuration"] = {
            "version": self.VERSION,
            "principle": "approved_structure_explicit_parameters_only",
            "unresolved_parameters_are_null": True,
            "supported_sizes": list(self.SUPPORTED_SIZES),
            "required_parameters": list(self.REQUIRED_KEYS),
            "allowed_knockout_pairings": list(self.ALLOWED_PAIRINGS),
        }
        self.save.setdefault("continental", {})["rules_configuration_version"] = self.VERSION
        return deepcopy(world["continental_rules_configuration"])

    def validate(self):
        errors = super().validate()
        fw = self.save.get("world", {}).get("continental_rules_configuration", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V118 continental rules configuration version")
        for cid, cfg in self.save.get("continental", {}).get("competitions", {}).items():
            size = cfg.get("size", cfg.get("default_size"))
            if size in self.SUPPORTED_SIZES:
                contract = cfg.get("v118_rules_contract")
                if contract != self.rules_contract(size):
                    errors.append(f"V118 contract mismatch: {cid}")
                # Validation is strict only when a value is supplied; None is an explicit pending state.
                supplied = {k: cfg.get(k) for k in self.REQUIRED_KEYS}
                for key, value in supplied.items():
                    if value is not None and key == "knockout_pairing" and value not in self.ALLOWED_PAIRINGS:
                        errors.append(f"invalid knockout pairing: {cid}")
        return errors
