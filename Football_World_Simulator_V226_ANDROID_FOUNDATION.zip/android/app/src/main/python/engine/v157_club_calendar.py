"""V157 — Global Club Calendar & Super World qualification correction.

Approved FWS club calendar:
- 2026 is the game start year; the first Super World is after the 2026-2029 cycle.
- Club seasons, continental competitions and the annual Intercontinental run every year.
- Super World occurs after the fourth year of each cycle: 2029, 2033, 2037...
- Each four-year cycle creates 56 direct places:
    48 continental places = 12 Level-1/Level-2 competitions x 4 years
     4 Intercontinental champions = 1 x 4 years
     4 continental-performance coefficient places
- A champion repeats -> runner-up receives that year's explicit place, for both Level 1 and Level 2.
- If repeated finalists leave fewer than 52 unique explicit qualifiers, the continental
  performance coefficient fills the missing places until 56 direct clubs are reached.
- The remaining 32 clubs are the preliminary field; 32 -> 16 -> 8 complete the 64-club field.

This layer is aggregate club simulation only. No player registry, squad or transfer system exists.
"""
from __future__ import annotations
from copy import deepcopy
from collections import defaultdict
import hashlib

from .v125_super_world_club_championship import V125SuperWorldClubChampionship
from .v107_global_club_ranking import V107GlobalClubRanking
from .v108_global_club_world_draw import V108GlobalClubWorldDraw


class V157ClubCalendar(V125SuperWorldClubChampionship):
    VERSION = "V157"
    SUPER_WORLD_FIRST_YEAR = 2029
    SUPER_WORLD_CYCLE_YEARS = 4
    DIRECT_ENTRIES = 56
    PRELIMINARY_ENTRIES = 32
    PRELIMINARY_QUALIFYING_PLACES = 8
    CONTINENTAL_DIRECT_PER_YEAR = 12
    INTERCONTINENTAL_DIRECT_PER_YEAR = 1
    CONTINENTAL_CYCLE_PLACES = 48
    INTERCONTINENTAL_CYCLE_PLACES = 4
    COEFFICIENT_DIRECT_PLACES = 4
    EXPLICIT_DIRECT_TARGET = 52
    GROUP_FIELD_SIZE = 64
    # V112 has OFC Continental League tagged as an FWS extra. For the new
    # 12-per-year SMC access rule it is the OFC Level-2 continental slot.
    LEVEL2_QUALIFICATION_OVERRIDES = {"OFC_CONTINENTAL"}

    @classmethod
    def is_super_world_year(cls, year: int) -> bool:
        year = int(year)
        return year >= cls.SUPER_WORLD_FIRST_YEAR and (year - cls.SUPER_WORLD_FIRST_YEAR) % cls.SUPER_WORLD_CYCLE_YEARS == 0

    @classmethod
    def cycle_bounds_for_super_world(cls, year: int):
        year = int(year)
        if not cls.is_super_world_year(year):
            return None
        return year - cls.SUPER_WORLD_CYCLE_YEARS + 1, year

    @staticmethod
    def _catalog(save):
        return save.get("catalog") or {"clubs": {}, "competitions": {}}

    @staticmethod
    def _tier12(catalog):
        """Return the 12 approved continental Level-1/Level-2 competitions."""
        rows = []
        for cid, cfg in catalog.get("competitions", {}).items():
            tier = cfg.get("tier")
            if cid in V157ClubCalendar.LEVEL2_QUALIFICATION_OVERRIDES:
                tier = "level_2"
            if tier in ("level_1", "level_2") and (cfg.get("official", True) or cid in V157ClubCalendar.LEVEL2_QUALIFICATION_OVERRIDES):
                rows.append((str(cfg.get("confederation", "")), str(tier), str(cid)))
        rows.sort(key=lambda x: (x[0], 0 if x[1] == "level_1" else 1, x[2]))
        return [cid for _, _, cid in rows]

    @staticmethod
    def _runner_up_from_competition(row):
        ko = row.get("knockout", {}) if isinstance(row, dict) else {}
        rounds = ko.get("rounds", []) if isinstance(ko, dict) else []
        if rounds:
            final_round = rounds[-1] or {}
            ids = []
            for match in final_round.get("matches", []) or []:
                for key in ("home_id", "away_id"):
                    cid = match.get(key)
                    if cid and cid not in ids:
                        ids.append(cid)
            champion = row.get("champion")
            for cid in ids:
                if cid != champion:
                    return cid
        # Legacy/fallback shapes may store a final match directly.
        matches = ko.get("matches", []) if isinstance(ko, dict) else []
        if matches:
            final = matches[-1]
            champion = row.get("champion")
            for key in ("home_id", "away_id"):
                cid = final.get(key)
                if cid and cid != champion:
                    return cid
        return None

    @staticmethod
    def _runner_up_from_intercontinental(row):
        matches = row.get("knockout_matches", []) if isinstance(row, dict) else []
        if not matches:
            finalists = row.get("finalists", [])
            champion = row.get("champion")
            return next((x for x in finalists if x and x != champion), None)
        final = max(matches, key=lambda m: int(m.get("round_no", 0)))
        champion = row.get("champion")
        for key in ("home_id", "away_id"):
            cid = final.get(key)
            if cid and cid != champion:
                return cid
        return None

    def _continental_results_by_year(self, start_year, end_year):
        by_year = {}
        for row in self.save.get("history", {}).get("global_competition_cycles", []) or []:
            year = int(row.get("season", -1))
            if not (start_year <= year <= end_year):
                continue
            competitions = row.get("continental", {}).get("competitions", {})
            by_year[year] = competitions if isinstance(competitions, dict) else {}
        # Compatibility with saves that only retained the latest V151 history list.
        if not by_year:
            for row in self.save.get("history", {}).get("continental_season", []) or []:
                year = int(row.get("season", -1))
                if start_year <= year <= end_year:
                    by_year[year] = row.get("competitions", {})
        return by_year

    def _intercontinental_results_by_year(self, start_year, end_year):
        out = {}
        for row in self.save.get("history", {}).get("intercontinental", []) or []:
            year = int(row.get("season", -1))
            if start_year <= year <= end_year:
                out[year] = row
        for row in self.save.get("world", {}).get("intercontinental_execution_history", []) or []:
            year = int(row.get("season", -1))
            if start_year <= year <= end_year:
                out.setdefault(year, row)
        return out

    @staticmethod
    def _competition_performance_points(row, tier):
        """Deterministic continental coefficient contribution for one season."""
        weight = {"level_1": 2.0, "level_2": 1.5}.get(tier, 1.0)
        scores = defaultdict(float)
        ko = row.get("knockout", {}) if isinstance(row, dict) else {}
        phases = []
        lp = row.get("league_phase", []) if isinstance(row, dict) else []
        phases.extend(lp if isinstance(lp, list) else [lp])
        if isinstance(row.get("post_league"), dict):
            phases.append(row["post_league"])
        rounds = ko.get("rounds", []) if isinstance(ko, dict) else []
        for phase in phases:
            for match in phase.get("matches", []) if isinstance(phase, dict) else []:
                V157ClubCalendar._score_match(scores, match, weight)
            for group in phase.get("group_results", []) if isinstance(phase, dict) else []:
                for match in group.get("matches", []) or []:
                    V157ClubCalendar._score_match(scores, match, weight)
        for round_row in rounds:
            for match in round_row.get("matches", []) or []:
                V157ClubCalendar._score_match(scores, match, weight)
        champion = row.get("champion")
        if champion:
            scores[champion] += 10.0 * weight
        runner = V157ClubCalendar._runner_up_from_competition(row)
        if runner:
            scores[runner] += 6.0 * weight
        return scores

    @staticmethod
    def _score_match(scores, match, weight):
        home = match.get("home_id")
        away = match.get("away_id")
        if not home or not away:
            return
        hg = match.get("home_goals")
        ag = match.get("away_goals")
        if hg is None or ag is None:
            winner = match.get("winner_id")
            if winner == home:
                scores[home] += 3.0 * weight
            elif winner == away:
                scores[away] += 3.0 * weight
            return
        hg, ag = int(hg), int(ag)
        if hg > ag:
            scores[home] += 3.0 * weight
        elif ag > hg:
            scores[away] += 3.0 * weight
        else:
            scores[home] += 1.0 * weight
            scores[away] += 1.0 * weight

    def _continental_coefficient(self, start_year, end_year):
        catalog = self._catalog(self.save)
        tiers = {cid: cfg.get("tier", "extra") for cid, cfg in catalog.get("competitions", {}).items()}
        scores = defaultdict(float)
        yearly = self._continental_results_by_year(start_year, end_year)
        for year, competitions in yearly.items():
            for cid, row in competitions.items():
                if row.get("status") != "completed":
                    continue
                scores.update(self._competition_performance_points(row, tiers.get(cid, "extra")))
        # Stable deterministic fallback only breaks true ties; it is not a substitute
        # for continental performance.
        for cid in catalog.get("clubs", {}):
            digest = hashlib.sha256(f"V157:{start_year}:{end_year}:{cid}".encode()).digest()
            scores[cid] += digest[0] / 255000.0
        return scores

    def build_super_world_qualification(self, season=None, cycle_years=4, seed=157):
        year = int(season if season is not None else self.save.setdefault("world", {}).get("current_year", 2026))
        if not self.is_super_world_year(year):
            return None
        start_year, end_year = self.cycle_bounds_for_super_world(year)
        catalog = self._catalog(self.save)
        clubs = catalog.get("clubs", {})
        if len(clubs) < self.DIRECT_ENTRIES + self.PRELIMINARY_ENTRIES:
            raise ValueError("verified club catalog does not contain enough clubs for the Super World field")

        tiers = {cid: ("level_2" if cid in self.LEVEL2_QUALIFICATION_OVERRIDES else cfg.get("tier")) for cid, cfg in catalog.get("competitions", {}).items()}
        approved12 = [cid for cid in self._tier12(catalog) if cid in tiers]
        if len(approved12) != self.CONTINENTAL_DIRECT_PER_YEAR:
            raise ValueError(f"V157 requires exactly 12 Level-1/Level-2 continental competitions, found {len(approved12)}")

        used = set()
        explicit = []
        annual_records = []
        continental_years = self._continental_results_by_year(start_year, end_year)

        for y in range(start_year, end_year + 1):
            competitions = continental_years.get(y, {})
            selected_year = []
            for comp_id in approved12:
                row = competitions.get(comp_id, {})
                champion = row.get("champion")
                runner = self._runner_up_from_competition(row)
                chosen = None
                if champion in clubs and champion not in used:
                    chosen = champion
                elif runner in clubs and runner not in used:
                    chosen = runner
                if chosen:
                    used.add(chosen)
                    explicit.append({"club_id": chosen, "source": "continental", "competition_id": comp_id, "season": y, "qualification": "champion" if chosen == champion else "runner_up"})
                    selected_year.append(chosen)
            annual_records.append({"season": y, "continental_slots": self.CONTINENTAL_DIRECT_PER_YEAR, "selected": selected_year})

        inter_history = self._intercontinental_results_by_year(start_year, end_year)
        for y in range(start_year, end_year + 1):
            row = inter_history.get(y, {})
            champion = row.get("champion")
            runner = self._runner_up_from_intercontinental(row)
            chosen = champion if champion in clubs and champion not in used else (runner if runner in clubs and runner not in used else None)
            if chosen:
                used.add(chosen)
                explicit.append({"club_id": chosen, "source": "intercontinental", "season": y, "qualification": "champion" if chosen == champion else "runner_up"})

        coefficient = self._continental_coefficient(start_year, end_year)
        ranking = sorted(clubs, key=lambda cid: (-coefficient[cid], str(cid)))
        coeff_direct = []
        for cid in ranking:
            if cid in used:
                continue
            coeff_direct.append(cid)
            used.add(cid)
            if len(coeff_direct) == self.COEFFICIENT_DIRECT_PLACES:
                break

        # Repeated champions/finalists can reduce the 52 explicit places. The
        # coefficient therefore continues filling direct places until 56.
        direct = list(explicit)
        for cid in coeff_direct:
            direct.append({"club_id": cid, "source": "continental_coefficient", "qualification": "coefficient_top4"})
        while len(direct) < self.DIRECT_ENTRIES:
            cid = next((x for x in ranking if x not in used), None)
            if cid is None:
                raise ValueError("unable to complete 56 direct Super World qualifiers")
            used.add(cid)
            direct.append({"club_id": cid, "source": "continental_coefficient", "qualification": "coefficient_fill"})

        preliminary = []
        for cid in ranking:
            if cid in used:
                continue
            preliminary.append({"club_id": cid, "source": "continental_coefficient", "qualification": "preliminary_coefficient"})
            if len(preliminary) == self.PRELIMINARY_ENTRIES:
                break
        if len(preliminary) != self.PRELIMINARY_ENTRIES:
            raise ValueError("unable to complete 32-club Super World preliminary field")

        qualification = {
            "version": self.VERSION,
            "competition_id": self.COMPETITION_ID,
            "cycle_start": start_year,
            "cycle_end": end_year,
            "super_world_year": year,
            "cycle_years": 4,
            "direct_entries": 56,
            "direct_breakdown": {
                "continental_level_1_2": 48,
                "intercontinental": 4,
                "coefficient": 4,
                "coefficient_fill_due_repetitions": max(0, 56 - len(explicit) - 4),
            },
            "explicit_unique_before_coefficient": len(explicit),
            "preliminary_entries": 32,
            "preliminary_qualifying_places": 8,
            "group_field_size": 64,
            "direct": [dict(r, club_name=clubs[r["club_id"]].get("name", r["club_id"])) for r in direct],
            "preliminary": [dict(r, club_name=clubs[r["club_id"]].get("name", r["club_id"])) for r in preliminary],
            "annual_records": annual_records,
            "coefficient_ranking": [{"club_id": cid, "score": round(coefficient[cid], 6)} for cid in ranking[:self.DIRECT_ENTRIES + self.PRELIMINARY_ENTRIES]],
            "status": "qualified",
        }
        world = self.save.setdefault("world", {})
        world["super_world_qualification"] = deepcopy(qualification)
        world.setdefault("super_world_qualification_history", []).append(deepcopy(qualification))
        return deepcopy(qualification)

    def run_super_world(self, season=None, cycle_years=4, seed=157):
        world = self.save.setdefault("world", {})
        year = int(season if season is not None else world.get("current_year", 2026))
        if not self.is_super_world_year(year):
            world["super_world_execution"] = None
            return None

        qualification = self.build_super_world_qualification(year, cycle_years, seed - 1)
        catalog = self._catalog_from_save()
        direct = [self._playable_club(catalog, r["club_id"], year, seed) for r in qualification["direct"]]
        preliminary = [self._playable_club(catalog, r["club_id"], year, seed) for r in qualification["preliminary"]]

        prelim_pool = list(preliminary); prelim_matches = []; round_no = 1
        while len(prelim_pool) > 8:
            next_pool = []
            for i in range(0, len(prelim_pool), 2):
                winner, row = self._single_knockout_match(prelim_pool[i], prelim_pool[i + 1], year, seed + 1, round_no, i)
                next_pool.append(winner); prelim_matches.append(row)
            prelim_pool = next_pool; round_no += 1
        winners8 = prelim_pool
        group_field = []; seen = set()
        for club in direct + winners8:
            if club["id"] not in seen:
                group_field.append(club); seen.add(club["id"])
        if len(group_field) != 64:
            raise ValueError("Super World must have exactly 64 unique group-stage clubs")

        ranking = V107GlobalClubRanking.build_global_club_ranking(self, season=year)
        pots = V107GlobalClubRanking._seed_four_pots(group_field, ranking)
        groups = V108GlobalClubWorldDraw._balanced_groups(pots)
        groups, group_matches = self._group_stage_three_rounds([club for group in groups for club in group["clubs"]], year, seed + 7)
        knockout_field = [club for group in groups for club in group["qualified"]]
        if len(knockout_field) != 32 or len({c["id"] for c in knockout_field}) != 32:
            raise ValueError("Super World playoff field must contain exactly 32 unique clubs")
        champion, knockout_matches, knockout_rounds = self._knockout_32_to_champion(knockout_field, year, seed + 17)

        execution = {
            "version": self.VERSION, "competition_id": self.COMPETITION_ID, "season": year, "status": "completed",
            "format": "64_clubs_16_groups_x4_3_rounds->32_playoffs->16->8->4->2->champion",
            "cycle": {"start": qualification["cycle_start"], "end": qualification["cycle_end"], "years": 4},
            "access": {"direct_entries": 56, "preliminary_entries": 32, "preliminary_qualifying_places": 8, "group_entries": 64},
            "qualification": {"direct": 56, "preliminary": 32, "preliminary_qualifiers": 8},
            "preliminary_matches": prelim_matches, "preliminary_winners": [c["id"] for c in winners8],
            "seeding": {"model": "4_ranking_pots_confederation_balanced", "pots": [[c["id"] for c in p] for p in pots]},
            "groups": groups, "group_count": 16, "group_size": 4, "group_rounds": 3, "group_matches": group_matches,
            "playoff_entries": 32, "knockout_entries": 32, "knockout_rounds": knockout_rounds,
            "knockout_round_names": ["round_of_32", "round_of_16", "quarter_final", "semi_final", "final"],
            "knockout_matches": knockout_matches, "champion": champion["id"],
        }
        world["super_world_execution"] = deepcopy(execution)
        world.setdefault("super_world_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("super_world", []).append(deepcopy(execution))
        return deepcopy(execution)

    def validate(self):
        errors = [e for e in super().validate() if not str(e).startswith("wrong V125 Super World execution version")]
        q = self.save.get("world", {}).get("super_world_qualification")
        if q:
            if q.get("version") != self.VERSION:
                errors.append("wrong V157 super world qualification version")
            if q.get("super_world_year") not in (None, int(q.get("cycle_end", 0))):
                errors.append("V157 super world year must follow the four-year cycle")
            if q.get("direct_entries") != 56 or len(q.get("direct", [])) != 56:
                errors.append("V157 direct field must contain 56 clubs")
            if q.get("preliminary_entries") != 32 or len(q.get("preliminary", [])) != 32:
                errors.append("V157 preliminary field must contain 32 clubs")
            ids = [x.get("club_id") for x in q.get("direct", []) + q.get("preliminary", [])]
            if len(ids) != 88 or len(set(ids)) != 88:
                errors.append("V157 direct and preliminary source fields must be 88 unique clubs")
        return errors
