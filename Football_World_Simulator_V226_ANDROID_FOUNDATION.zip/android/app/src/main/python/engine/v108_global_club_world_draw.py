"""V108 — Global Club World Draw Balance."""
from __future__ import annotations
from copy import deepcopy
from .v107_global_club_ranking import V107GlobalClubRanking

class V108GlobalClubWorldDraw(V107GlobalClubRanking):
    VERSION = "V108"
    @staticmethod
    def _confederation(club):
        return club.get("confederation") or club.get("confederation_id") or club.get("confederation_code") or "UNKNOWN"
    @classmethod
    def _balanced_groups(cls, pots):
        groups=[{"group":i+1,"clubs":[],"qualified":[]} for i in range(16)]
        for pot in pots:
            remaining=list(pot)
            for group in groups:
                ranked=sorted(remaining,key=lambda c:(sum(cls._confederation(x)==cls._confederation(c) and cls._confederation(c)!="UNKNOWN" for x in group["clubs"]),c["id"]))
                pick=ranked[0]; group["clubs"].append(pick); remaining.remove(pick)
        return groups
    @classmethod
    def _confederation_collisions(cls,groups):
        total=0
        for g in groups:
            confs=[cls._confederation(c) for c in g["clubs"]]
            total += sum(confs[i]==confs[j] and confs[i]!="UNKNOWN" for i in range(4) for j in range(i+1,4))
        return total
    def run_super_world(self,season=None,cycle_years=4,seed=108):
        execution=super().run_super_world(season,cycle_years,seed)
        if not execution:return None
        ranking=self.build_global_club_ranking(season=execution["season"])
        field=[c for g in execution.get("groups",[]) for c in g.get("clubs",[])]
        pots=self._seed_four_pots(field,ranking); groups=self._balanced_groups(pots); group_matches=[]
        for g in groups:
            rebuilt,matches=self._groups(g["clubs"],1,4,self.SUPER_WORLD_ID,execution["season"],seed+300+g["group"])
            g["qualified"]=rebuilt[0]["qualified"]; g["table"]=rebuilt[0].get("table",[]); g["matches"]=rebuilt[0].get("matches",[]); group_matches.extend(matches)
        knockout_field=[c for g in groups for c in g["qualified"]]
        champion,knockout_matches=self._knockout(knockout_field,self.SUPER_WORLD_ID,execution["season"],seed+500)
        execution=deepcopy(execution); execution["version"]=self.VERSION
        execution["seeding"]={"model":"4_ranking_pots_confederation_balanced","pots":[[c["id"] for c in p] for p in pots]}
        execution["draw_balance"]={"model":"greedy_confederation_balance","confederation_collisions":self._confederation_collisions(groups)}
        execution["groups"]=groups; execution["group_matches"]=group_matches; execution["knockout_entries"]=len(knockout_field); execution["knockout_matches"]=knockout_matches; execution["champion"]=champion["id"] if champion else None
        world=self.save.setdefault("world",{}); world["super_world_execution"]=deepcopy(execution); world.setdefault("super_world_execution_history",[]).append(deepcopy(execution)); self.save.setdefault("history",{}).setdefault("super_world",[]).append(deepcopy(execution))
        return deepcopy(execution)
    def validate(self):
        errors=super().validate(); execution=self.save.get("world",{}).get("super_world_execution")
        if execution and execution.get("version")==self.VERSION:
            if execution.get("seeding",{}).get("model")!="4_ranking_pots_confederation_balanced":errors.append("V108 draw model mismatch")
            if len(execution.get("groups",[]))!=16:errors.append("V108 requires 16 groups")
            if any(len(g.get("clubs",[]))!=4 for g in execution.get("groups",[])):errors.append("V108 groups must contain 4 clubs")
            if any(len(g.get("qualified",[]))!=2 for g in execution.get("groups",[])):errors.append("V108 groups must qualify 2 clubs")
        return errors
