"""Season-following views for the active club and national team."""
from collections import defaultdict
from engine.active_management import ActiveManagement


class ActiveSeason:
    def __init__(self, save):
        self.save = save
        self.active = ActiveManagement(save)

    def _all_matches(self):
        h = self.save.setdefault("history", {})
        rows = []
        seen = set()
        for key in ("season_matches", "competition_matches", "national_team_matches"):
            for m in h.get(key, []):
                marker = (key, m.get("season"), m.get("competition", m.get("competition_id")),
                          m.get("round", m.get("round_no")), m.get("date"), m.get("home_id"), m.get("away_id"))
                if marker not in seen:
                    seen.add(marker); rows.append(m)
        return rows

    def dashboard(self, season=None):
        season = self.save["world"].get("current_year") if season is None else season
        entities = self.active.active_entities()
        club = self.active.club_trajectory(entities["club_id"], season) if entities["club_id"] else None
        selection = self.active.selection_trajectory(entities["selection_id"], season) if entities["selection_id"] else None
        return {"season": season, "club": club, "selection": selection,
                "simultaneous_management": entities["simultaneous_management"],
                "agenda": self.active.active_schedule(season)}

    def competition_summary(self, entity_id, season=None, is_selection=False):
        season = self.save["world"].get("current_year") if season is None else season
        matches = (self.active.selection_matches(entity_id, season) if is_selection
                   else self.active.club_matches(entity_id, season))
        out = {}
        for m in matches:
            comp = m["competition"]
            row = out.setdefault(comp, {"matches": 0, "wins": 0, "draws": 0, "losses": 0, "goals_for": 0, "goals_against": 0})
            row["matches"] += 1
            home = m.get("home_id") == entity_id
            gf, ga = (m.get("home_goals"), m.get("away_goals")) if home else (m.get("away_goals"), m.get("home_goals"))
            if gf is None or ga is None: continue
            row["goals_for"] += gf; row["goals_against"] += ga
            if gf > ga: row["wins"] += 1
            elif gf == ga: row["draws"] += 1
            else: row["losses"] += 1
        return out
