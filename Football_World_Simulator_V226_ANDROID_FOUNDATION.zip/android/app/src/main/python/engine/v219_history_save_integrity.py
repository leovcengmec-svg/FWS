"""V219 — Historical ledger and save/load integrity."""
from __future__ import annotations
from copy import deepcopy
import json, hashlib
class V219HistorySaveIntegrity:
    VERSION="V219"
    def __init__(self,save): self.save=save
    def close(self,season=None):
        world=self.save.setdefault("world",{}); hist=self.save.setdefault("history",{})
        year=int(world.get("current_year",2026) if season is None else season)
        clubs=world.get("clubs",{}) if isinstance(world.get("clubs",{}),dict) else {}
        rec={"version":self.VERSION,"season":year,"clubs":len(clubs),
             "world_year":year,"history_lengths":{k:len(v) for k,v in hist.items() if isinstance(v,list)}}
        hist.setdefault("long_term_history",[]).append(deepcopy(rec))
        self.save.setdefault("integrity",{})["last_v219_hash"]=self.digest()
        world["history_save_integrity_version"]=self.VERSION
        return deepcopy(rec)
    def digest(self):
        # Canonical JSON excludes volatile integrity hash itself.
        root=deepcopy(self.save); root.get("integrity",{}).pop("last_v219_hash",None)
        raw=json.dumps(root,sort_keys=True,separators=(",",":"),ensure_ascii=False,default=str).encode()
        return hashlib.sha256(raw).hexdigest()
    def roundtrip(self):
        raw=json.dumps(self.save,sort_keys=True,separators=(",",":"),ensure_ascii=False,default=str)
        loaded=json.loads(raw)
        return loaded
    def validate(self):
        errors=[]
        try: clone=self.roundtrip()
        except Exception as e: return [f"roundtrip:{e}"]
        if clone.get("world",{}).get("current_year")!=self.save.get("world",{}).get("current_year"): errors.append("year mismatch")
        if "players" in clone.get("world",{}): errors.append("player layer present")
        return errors
