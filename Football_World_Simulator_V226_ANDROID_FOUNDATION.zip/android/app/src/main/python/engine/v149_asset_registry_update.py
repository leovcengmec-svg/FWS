from __future__ import annotations
import json
from pathlib import Path

def main(base):
    base=Path(base)
    catalog=json.loads((base/'data/global_world_catalog.json').read_text())
    p=base/'data/global_asset_registry.json'
    reg=json.loads(p.read_text())
    assets=reg.setdefault('assets',{})
    added=0
    for cid,c in catalog['clubs'].items():
        if not cid.startswith('V149_'): continue
        aid=f'club:{cid}:crest'
        if aid in assets: continue
        assets[aid]={
            'id':aid,'kind':'crest','owner_id':cid,'owner_type':'club',
            'source':'V149 verified real-club restoration; crest source pending license verification',
            'status':'pending_verification','uri':None,'checksum':None,'license':'verify source/license before redistribution','schema_version':2
        }
        added+=1
    reg['version']='V149'; reg['schema_version']=2
    p.write_text(json.dumps(reg,ensure_ascii=False,indent=2))
    return added
if __name__=='__main__':
 print(main('/mnt/data/work149'))
