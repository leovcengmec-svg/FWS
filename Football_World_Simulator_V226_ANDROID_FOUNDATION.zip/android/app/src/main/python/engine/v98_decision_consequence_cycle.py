"""V98 — Decision & Consequence Cycle.

Connects the existing executive/strategic decision systems into one auditable
cycle. It does not create a new sporting engine, money, players, or guaranteed
match outcomes. Decisions flow through already implemented budget, management
effects, strategic quality, review and effectiveness systems.
"""
from __future__ import annotations
from copy import deepcopy

from .v97_career_power_hub import V97CareerPowerHub


class V98DecisionConsequenceCycle(V97CareerPowerHub):
    VERSION = "V98"

    def initialize(self, starting_cash=None, manager_prestige=None):
        snap = super().initialize(starting_cash, manager_prestige)
        self.save.setdefault("careers", {}).setdefault("decision_cycle", {
            "version": self.VERSION, "history": []
        })
        return self.snapshot()

    def execute_decision_cycle(
        self,
        focus="balanced",
        horizon=1,
        target_quality=70.0,
        allocations=None,
        club_id=None,
    ):
        """Apply one complete executive decision cycle to the active owned club."""
        club_id = club_id or self.active.active.active_entities().get("club_id")
        if not club_id:
            raise ValueError("nenhum clube próprio está sob gestão ativa")
        executive = self.active

        focus_row = executive.set_strategic_focus(focus)
        plan = executive.strategic_plan(focus, horizon=horizon, target_quality=target_quality)

        allocations = allocations or {}
        budget = None
        execution = None
        if allocations:
            budget = executive.allocate_club_budget(allocations)
            execution = executive.execute_budget(budget)

        strategic = executive.strategic.evaluate(club_id, self.save["world"].get("current_year"))
        effects = executive.apply_club_season_effects(
            club_id, self.save["world"].get("current_year")
        )
        governance = executive.strategic_governance_snapshot(club_id)
        review = executive.strategic_review(club_id)
        lifecycle = None
        if review.get("action") != "monitor" or review.get("status") == "open":
            lifecycle = executive.initialize_strategic_action(
                len(self.save["world"]["clubs"][club_id].get("strategic_review_actions", [])) - 1,
                club_id,
            )
        effectiveness = executive.evaluate_strategic_effectiveness(
            club_id, self.save["world"].get("current_year")
        )

        row = {
            "version": self.VERSION,
            "club_id": club_id,
            "season": self.save["world"].get("current_year"),
            "focus": focus_row,
            "plan": plan,
            "budget": budget,
            "execution": execution,
            "strategic": strategic,
            "management_effects": effects,
            "governance": governance,
            "review": review,
            "lifecycle": lifecycle,
            "effectiveness": effectiveness,
        }
        cycle = self.save.setdefault("careers", {}).setdefault("decision_cycle", {
            "version": self.VERSION, "history": []
        })
        cycle["version"] = self.VERSION
        cycle["history"].append(deepcopy(row))
        return row

    def decision_cycle_snapshot(self):
        cycle = self.save.setdefault("careers", {}).setdefault("decision_cycle", {
            "version": self.VERSION, "history": []
        })
        return {
            "version": self.VERSION,
            "cycles": len(cycle.get("history", [])),
            "latest": deepcopy(cycle.get("history", [])[-1]) if cycle.get("history") else None,
        }

    def validate(self):
        errors = super().validate()
        cycle = self.save.get("careers", {}).get("decision_cycle", {})
        if cycle and cycle.get("version") != self.VERSION:
            errors.append("wrong decision cycle version")
        for row in cycle.get("history", []):
            if row.get("version") != self.VERSION:
                errors.append("invalid decision cycle history version")
                break
        return errors
