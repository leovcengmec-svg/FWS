"""V221 — Release optimization and runtime safety."""
from __future__ import annotations
import copy, math, time

class V221ReleaseOptimization:
    VERSION = "V221"
    def __init__(self, save):
        self.save = save
    def run(self):
        started = time.perf_counter()
        world = self.save.setdefault("world", {})
        clubs = world.get("clubs", {})
        if not isinstance(clubs, dict):
            raise ValueError("world.clubs must be a mapping")
        # Normalize only safe runtime defaults; never delete user/world data.
        for cid, club in clubs.items():
            if not isinstance(club, dict):
                raise ValueError(f"club {cid} is not an object")
            for key, default in (("sporting_strength",50.0),("sporting_form",50.0),("prestige",50.0),("cash",100.0)):
                value = float(club.get(key, default))
                if not math.isfinite(value): raise ValueError(f"{cid}:{key} nonfinite")
                club[key] = value
        self.save.setdefault("runtime", {})["optimization"] = {
            "version": self.VERSION, "clubs_indexed": len(clubs),
            "history_indexed": sum(len(v) for v in self.save.get("history",{}).values() if isinstance(v,list)),
            "elapsed_ms": round((time.perf_counter()-started)*1000, 3)
        }
        return copy.deepcopy(self.save["runtime"]["optimization"])
    def validate(self):
        r=self.save.get("runtime",{}).get("optimization",{})
        return [] if r.get("version")==self.VERSION else ["optimization metadata missing"]
