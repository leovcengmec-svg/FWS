class ContractMarket:
    """Time-limited broadcast and sponsorship contracts for clubs and selections."""
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('commercial_contracts', [])

    def _contracts(self):
        return self.save.setdefault('market', {}).setdefault('commercial_contracts', [])

    def sign_club_contract(self, club_id, kind, annual_value, duration=3, partner='market'):
        if kind not in ('broadcast', 'sponsorship'):
            raise ValueError('tipo de contrato inválido')
        if annual_value <= 0 or duration <= 0:
            raise ValueError('valor/duração inválidos')
        start = int(self.save['world']['current_year'])
        contract = {'contract_id': f'{club_id}:{kind}:{start}:{len(self._contracts())+1}', 'entity_type':'club', 'entity_id':club_id,
                    'kind':kind, 'annual_value':round(float(annual_value),2), 'start_season':start,
                    'end_season':start+int(duration)-1, 'partner':partner, 'status':'active'}
        self._contracts().append(contract); return contract

    def sign_selection_contract(self, team_id, kind, annual_value, duration=3, partner='market'):
        if kind not in ('broadcast', 'sponsorship'):
            raise ValueError('tipo de contrato inválido')
        if annual_value <= 0 or duration <= 0:
            raise ValueError('valor/duração inválidos')
        start=int(self.save['world']['current_year'])
        contract={'contract_id':f'{team_id}:{kind}:{start}:{len(self._contracts())+1}', 'entity_type':'selection','entity_id':team_id,
                  'kind':kind,'annual_value':round(float(annual_value),2),'start_season':start,
                  'end_season':start+int(duration)-1,'partner':partner,'status':'active'}
        self._contracts().append(contract); return contract

    def active(self, entity_type, entity_id):
        season=int(self.save['world']['current_year'])
        return [c for c in self._contracts() if c['entity_type']==entity_type and c['entity_id']==entity_id and c['start_season']<=season<=c['end_season'] and c.get('status')=='active']

    def annual_revenue(self, entity_type, entity_id):
        return round(sum(float(c['annual_value']) for c in self.active(entity_type, entity_id)),2)

    def advance_season(self):
        season=int(self.save['world']['current_year'])
        changed=[]
        for c in self._contracts():
            if c.get('status')=='active' and season > int(c['end_season']):
                c['status']='expired'; changed.append(c['contract_id'])
        self.history.append({'season':season,'expired':changed,'active_count':sum(c.get('status')=='active' for c in self._contracts())})
        return changed

    def renew(self, contract_id, annual_value=None, duration=3):
        found=next((c for c in self._contracts() if c['contract_id']==contract_id),None)
        if not found: raise ValueError('contrato não encontrado')
        if duration<=0: raise ValueError('duração inválida')
        value=float(annual_value if annual_value is not None else found['annual_value'])
        if value<=0: raise ValueError('valor inválido')
        found['annual_value']=round(value,2); found['start_season']=int(self.save['world']['current_year']); found['end_season']=found['start_season']+int(duration)-1; found['status']='active'
        return found
