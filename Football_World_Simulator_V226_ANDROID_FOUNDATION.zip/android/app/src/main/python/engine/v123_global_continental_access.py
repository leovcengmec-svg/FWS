"""V123 — Global Continental Access Engine.

Closes the continental-access architecture introduced by V121/V122 without
inventing association quotas, clubs, or redistribution outcomes.

The engine is configuration-driven: each competition supplies its capacity and
its explicit access slots. Duplicate clubs are resolved by slot priority;
released slots may only be reassigned to explicitly supplied eligible clubs.
Qualification/parachute events are append-only and capacity is validated before
an access list can be locked.
"""
from __future__ import annotations
from copy import deepcopy
from .v122_continental_slot_matrix import V122ContinentalSlotMatrix


class V123GlobalContinentalAccess(V122ContinentalSlotMatrix):
    VERSION = "V123"

    STATUS_VALID = "valid"
    STATUS_PENDING = "configuration_pending"
    STATUS_INVALID = "invalid"

    DEFAULT_PRIORITY = {
        "TITLEHOLDER": 10,
        "DIRECT": 20,
        "DOMESTIC_POSITION": 30,
        "CUP": 40,
        "QUALIFICATION": 50,
        "REALLOCATION": 60,
        "PARACHUTE": 70,
    }

    def build_access_list(self, competition, slots, eligible_clubs=None):
        """Build and validate one competition's access list.

        No club is created or inferred. If a slot has no club yet, it remains
        pending. If two slots contain the same club, the highest-priority slot
        is retained and the duplicate slot is released for explicit reallocation.
        """
        capacity = int(competition.get("size", competition.get("capacity", 0)))
        eligible = set(eligible_clubs or [])
        rows = deepcopy(slots or [])
        errors = []
        used = {}
        for i, row in enumerate(rows):
            row.setdefault("slot_id", f"{competition.get('id', 'COMP')}:S{i + 1}")
            row.setdefault("status", "assigned" if row.get("club_id") else "pending")
            row.setdefault("priority", self.DEFAULT_PRIORITY.get(str(row.get("source_type", "")).upper(), 999))
            aid = row.get("association_id")
            cid = row.get("club_id")
            if not row.get("competition_id"):
                row["competition_id"] = competition.get("id")
            if cid:
                if eligible and cid not in eligible:
                    errors.append(f"club not eligible for supplied access list: {cid}")
                used.setdefault(cid, []).append(row)

        released = []
        for cid, dupes in used.items():
            if len(dupes) <= 1:
                continue
            dupes.sort(key=lambda r: (int(r.get("priority", 999)), str(r.get("slot_id"))))
            keep = dupes[0]
            for row in dupes[1:]:
                row["club_id"] = None
                row["status"] = "released_duplicate"
                row["released_reason"] = f"duplicate club retained in {keep['slot_id']}"
                released.append(row["slot_id"])

        assigned = [r for r in rows if r.get("club_id")]
        if len(assigned) > capacity:
            errors.append("occupied slots exceed competition capacity")

        status = self.STATUS_INVALID if errors else self.STATUS_VALID
        if not assigned or len(assigned) < capacity:
            status = self.STATUS_PENDING if not errors else status

        return {
            "version": self.VERSION,
            "competition_id": competition.get("id"),
            "capacity": capacity,
            "occupied": len(assigned),
            "available": max(0, capacity - len(assigned)),
            "slots": rows,
            "released_duplicate_slots": released,
            "status": status,
            "errors": errors,
        }

    @staticmethod
    def reallocate(access_list, candidates_by_slot):
        """Fill released/pending slots only from explicit candidate lists."""
        out = deepcopy(access_list)
        used = {r.get("club_id") for r in out["slots"] if r.get("club_id")}
        unresolved = []
        for row in out["slots"]:
            if row.get("club_id"):
                continue
            candidates = list(candidates_by_slot.get(row["slot_id"], []))
            chosen = next((c for c in candidates if c not in used), None)
            if chosen is None:
                unresolved.append(row["slot_id"])
                continue
            row["club_id"] = chosen
            row["status"] = "reallocated"
            used.add(chosen)
        out["occupied"] = sum(1 for r in out["slots"] if r.get("club_id"))
        out["available"] = max(0, out["capacity"] - out["occupied"])
        out["unresolved_slots"] = unresolved
        if unresolved:
            out["status"] = V123GlobalContinentalAccess.STATUS_PENDING
            out.setdefault("errors", []).append("no explicit eligible replacement for released/pending slot")
        elif out["occupied"] == out["capacity"] and not out.get("errors"):
            out["status"] = V123GlobalContinentalAccess.STATUS_VALID
        return out

    @staticmethod
    def validate_capacity(competitions):
        errors = []
        for cid, row in competitions.items() if isinstance(competitions, dict) else ((r.get("competition_id"), r) for r in competitions):
            capacity = int(row.get("capacity", row.get("size", 0)))
            occupied = int(row.get("occupied", 0))
            if occupied < 0:
                errors.append(f"negative occupancy: {cid}")
            if occupied > capacity:
                errors.append(f"capacity exceeded: {cid}")
        return errors

    @staticmethod
    def validate_unique_clubs(competitions):
        seen = {}
        errors = []
        rows = competitions.values() if isinstance(competitions, dict) else competitions
        for comp in rows:
            cid = comp.get("competition_id")
            for slot in comp.get("slots", []):
                club = slot.get("club_id")
                if not club:
                    continue
                key = club
                if key in seen and seen[key] != (cid, slot.get("slot_id")):
                    errors.append(f"club appears more than once in continental access state: {club}")
                else:
                    seen[key] = (cid, slot.get("slot_id"))
        return errors

    @staticmethod
    def validate_round_closure(entries, expected_qualifiers):
        """Validate an even knockout/qualification field without inventing byes."""
        n = len(entries)
        expected = int(expected_qualifiers)
        if expected < 0 or expected > n:
            return ["invalid expected qualifier count"]
        if n and n % 2:
            return ["qualification field is odd; explicit bye configuration required"]
        if n // 2 != expected and n:
            return [f"round does not close: {n} entrants produce {n // 2}, expected {expected}"]
        return []

    @staticmethod
    def record_event(world, event):
        history = world.setdefault("continental_access_history", [])
        row = deepcopy(event)
        row.setdefault("event_index", len(history) + 1)
        history.append(row)
        return row

    def build_global_access_state(self, competitions, access_lists):
        state = {"version": self.VERSION, "competitions": {}, "errors": [], "status": self.STATUS_VALID}
        for comp in competitions:
            cid = comp["id"]
            if cid not in access_lists:
                row = {
                    "competition_id": cid,
                    "capacity": int(comp.get("size", 0)),
                    "occupied": 0,
                    "slots": [],
                    "status": self.STATUS_PENDING,
                    "missing_configuration": ["access_list"],
                }
            else:
                row = deepcopy(access_lists[cid])
            state["competitions"][cid] = row
        state["errors"].extend(self.validate_capacity(state["competitions"]))
        state["errors"].extend(self.validate_unique_clubs(state["competitions"]))
        if state["errors"]:
            state["status"] = self.STATUS_INVALID
        elif any(r.get("status") == self.STATUS_PENDING for r in state["competitions"].values()):
            state["status"] = self.STATUS_PENDING
        return state

    def lock_access(self, state):
        """Persist an access state only when it is fully valid."""
        if state.get("status") != self.STATUS_VALID:
            raise ValueError("ACCESS_LOCK_BLOCKED: continental access state is not valid")
        world = self.save.setdefault("world", {})
        locked = deepcopy(state)
        locked["status"] = "ACCESS_LOCKED"
        world["continental_access_locked"] = locked
        self.record_event(world, {
            "type": "ACCESS_LOCKED",
            "version": self.VERSION,
            "competitions": sorted(locked.get("competitions", {}).keys()),
        })
        return deepcopy(locked)

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["global_continental_access_engine"] = {
            "version": self.VERSION,
            "base_version": "V122",
            "status": "configuration_driven",
            "no_invented_clubs": True,
            "no_invented_association_quotas": True,
            "duplicate_resolution": "priority_then_explicit_reallocation",
            "parachute_is_separate_from_reallocation": True,
            "capacity_validation_required": True,
            "round_closure_required": True,
            "access_lock_requires_valid_state": True,
            "history_append_only": True,
            "supports_confederations": ["UEFA", "CONMEBOL", "AFC", "CAF", "CONCACAF", "OFC"],
        }
        return deepcopy(world["global_continental_access_engine"])

    def validate(self):
        errors = super().validate()
        cfg = self.save.get("world", {}).get("global_continental_access_engine", {})
        if cfg and cfg.get("version") != self.VERSION:
            errors.append("wrong V123 global access engine version")
        if cfg and not cfg.get("no_invented_clubs"):
            errors.append("V123 must prohibit invented clubs")
        if cfg and not cfg.get("capacity_validation_required"):
            errors.append("V123 capacity validation is mandatory")
        return errors
