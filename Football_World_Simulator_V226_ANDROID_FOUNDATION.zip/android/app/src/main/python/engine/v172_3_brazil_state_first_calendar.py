"""V172.3 — Brazil state-first roster and annual Access qualification.

The state pyramid is the persistent club base. The 256-place national Access
league is selected every season from state championship performance, excluding
clubs already participating in Brazil national Series A-F. It is not a fixed
club list.
"""
from __future__ import annotations
from copy import deepcopy

VERSION = "V172.3"
ACCESS_SIZE = 256
MAX_STATE_DIVISIONS = 3
NATIONAL_LEVELS = {"BRA-BR-1","BRA-BR-2","BRA-BR-3","BRA-BR-4","BRA-BR-5","BRA-BR-6"}

class V1723BrazilStateFirstCalendar:
    VERSION = VERSION

    def __init__(self, save):
        self.save = save

    @staticmethod
    def rank_access_candidates(state_results, national_club_ids, eligible_ids):
        """Return the annual top 256 by state performance.

        state_results maps club_id to a dict containing at least a numeric
        performance_score. Ties are resolved deterministically by points,
        goal_difference, goals_for and club_id when supplied.
        """
        national = set(national_club_ids)
        rows = []
        for cid, result in state_results.items():
            if cid not in eligible_ids or cid in national:
                continue
            score = float(result.get("performance_score", 0.0))
            rows.append((score, float(result.get("points", 0)), float(result.get("goal_difference", 0)), float(result.get("goals_for", 0)), cid))
        rows.sort(key=lambda x: (-x[0], -x[1], -x[2], -x[3], x[4]))
        return [x[4] for x in rows[:ACCESS_SIZE]]

    def run(self, catalog, state_results=None, national_club_ids=None, season=None):
        world = self.save.setdefault("world", {})
        history = self.save.setdefault("history", {})
        state_db = history.setdefault("brazil_state_first_calendar", {})
        season = int(season or catalog.get("season", 2026))
        national_club_ids = set(national_club_ids or [])
        eligible_ids = set(catalog.get("all_club_ids", []))

        if state_results is None:
            access_ids = []
            status = "awaiting_state_results"
        else:
            access_ids = self.rank_access_candidates(state_results, national_club_ids, eligible_ids)
            if len(access_ids) != ACCESS_SIZE:
                raise ValueError(f"state_performance_must_select_{ACCESS_SIZE}_clubs")
            status = "qualified"

        world["brazil_state_first_calendar_version"] = VERSION
        world["brazil_state_first_calendar"] = {
            "season": season,
            "sequence": [
                "BRA_STATE_CHAMPIONSHIPS",
                "BRA_ACCESS_SELECTION_256",
                "GLOBAL_NATIONAL_LEAGUES",
                "CONTINENTAL_COMPETITIONS",
                "INTERCONTINENTAL_COMPETITIONS",
                "OTHER_COMPETITIONS",
            ],
            "national_brazil_ladder": ["BRA-BR-1","BRA-BR-2","BRA-BR-3","BRA-BR-4","BRA-BR-5","BRA-BR-6","BRA-ACCESS"],
            "access_selection": {
                "size": ACCESS_SIZE,
                "source": "state_championship_performance",
                "excludes_national_series_A_to_F": True,
                "annual_reselection": True,
                "four_extra_rule": False,
                "status": status,
                "club_ids": access_ids,
            },
        }
        state_db["version"] = VERSION
        state_db["season"] = season
        state_db["status"] = status
        state_db["access_club_ids"] = access_ids
        return deepcopy(world["brazil_state_first_calendar"])

    @staticmethod
    def validate_catalog(catalog):
        errors=[]
        if catalog.get("version") != VERSION: errors.append("invalid_version")
        if len(catalog.get("states",{})) != 27: errors.append("all_27_ufs_required")
        if catalog.get("club_total") != 607: errors.append("expected_607_brazil_clubs")
        for uf,row in catalog.get("states",{}).items():
            if len(row.get("divisions",[])) > MAX_STATE_DIVISIONS: errors.append(f"too_many_divisions:{uf}")
            ids=[cid for d in row.get("divisions",[]) for cid in d.get("club_ids",[])]
            if len(ids)!=len(set(ids)): errors.append(f"duplicate_state_club:{uf}")
            if len(ids)!=row.get("club_count"): errors.append(f"state_count_mismatch:{uf}")
        es=catalog.get("states",{}).get("ES",{})
        es_names={x.get("name") for d in es.get("divisions",[]) for x in catalog.get("club_records",[]) if x.get("id") in set(d.get("club_ids",[]))}
        required={"Aracruz FC ES","Linhares FC ES","Bagos FC ES","Vila do Riacho FC ES","Barra do Riacho FC ES"}
        if not required.issubset(set(catalog.get("es_requested_names",[]))): errors.append("requested_es_names_missing")
        access=catalog.get("national_access",{})
        if access.get("selection_mode")!="annual_state_performance": errors.append("access_not_dynamic")
        if access.get("size")!=ACCESS_SIZE: errors.append("access_size_not_256")
        if access.get("four_extra_rule") is not False: errors.append("four_extra_rule_not_disabled")
        return errors
