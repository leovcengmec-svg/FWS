"""V142 size-aware domestic pyramid rules.

Non-Brazil national leagues use one common FWS domestic format:
- double round robin (home and away);
- 4 relegations from every non-final division;
- 3 direct promotions from the division below;
- one additional promotion decided by a two-leg playoff among places 4-7;
- only the final modeled division has four external access slots instead of a
  modeled lower league;
- a country with only one modeled league follows the same final-division rule:
  four clubs are relegated and four verified external clubs replace them.

Brazil is explicitly excluded: its previously defined real/special pyramid is
left untouched, including the existing Série E/F/access rules.

The four "extra teams" exist ONLY for the final modeled division of each
non-Brazil country. They are real-club eligibility slots. They are NOT
fabricated clubs and they do NOT enter the fixture list until the season
transition. A slot is populated only when a verified real club is available
for that national pyramid's external access pool.
"""
from __future__ import annotations

import copy
import hashlib
from typing import Dict, List, Tuple

from .match_engine import MatchEngine

BRAZIL_IDS = {"BRA"}
BRAZIL_ALIAS_PREFIXES = ("BRA_D",)

RULE_VERSION = "V142_SIZE_AWARE_DOMESTIC_PYRAMID"
PLAYOFF_MIN_CLUBS = 12
EXTRA_POOL_SIZE = 4
RELEGATION_PLACES = 4
DIRECT_PROMOTION_PLACES = 3
PLAYOFF_FIELD = (4, 5, 6, 7)
PLAYOFF_LEGS = 2


def is_brazil_league(league: dict) -> bool:
    country = league.get("country_id")
    lid = str(league.get("id", ""))
    return country in BRAZIL_IDS or lid.startswith(BRAZIL_ALIAS_PREFIXES)


def is_canonical_league(league: dict) -> bool:
    return not is_brazil_league(league)


def apply_catalog_policy(catalog: dict) -> dict:
    """Apply V140 metadata to a catalog without changing club membership."""
    out = copy.deepcopy(catalog)
    pending = []
    configured = 0
    for lid, league in out.get("leagues", {}).items():
        if is_brazil_league(league):
            continue

        configured += 1
        levels = [x for x in out.get("leagues", {}).values()
                  if x.get("country_id") == league.get("country_id")]
        max_level = max((int(x.get("level", 0)) for x in levels), default=league.get("level", 1))
        level = int(league.get("level", 1))
        is_last = level == max_level

        league["format"] = "double_round_robin"
        league["legs"] = 2
        league["domestic_rule_version"] = RULE_VERSION
        league["relegation_places"] = RELEGATION_PLACES
        club_count = len(league.get("club_ids", []))
        size_allows_playoff = club_count >= PLAYOFF_MIN_CLUBS
        playoff_enabled = level > 1 and not is_last and size_allows_playoff
        direct_places = DIRECT_PROMOTION_PLACES if playoff_enabled else (4 if level > 1 else 0)
        league["promotion_direct_places"] = direct_places
        league["promotion_total_places"] = 0 if level == 1 else 4
        league["promotion_playoff"] = {
            "enabled": playoff_enabled,
            "positions": list(PLAYOFF_FIELD) if playoff_enabled else [],
            "legs": PLAYOFF_LEGS if playoff_enabled else 0,
            "promotion_places": 1 if playoff_enabled else 0,
            "pairings": [[4, 7], [5, 6]] if playoff_enabled else [],
            "final": True if playoff_enabled else False,
            "threshold_clubs": PLAYOFF_MIN_CLUBS,
            "club_count": club_count,
            "rule": "3_direct_plus_playoff" if playoff_enabled else ("4_direct_no_playoff" if level > 1 else "not_applicable"),
        }
        league["extra_pool_size"] = EXTRA_POOL_SIZE if is_last else 0
        league["extra_pool_role"] = "verified_real_club_access_slots" if is_last else "not_applicable"
        league["extra_club_ids"] = list(league.get("extra_club_ids", []))[:EXTRA_POOL_SIZE] if is_last else []
        league["extra_pool_status"] = (
            "ready" if is_last and len(league["extra_club_ids"]) == EXTRA_POOL_SIZE
            else ("awaiting_verified_real_clubs" if is_last else "not_applicable")
        )
        league["last_division"] = is_last
        league["external_access_slots"] = EXTRA_POOL_SIZE if is_last else 0
        league["single_league_country"] = len(levels) == 1
        league["final_division_transition"] = (
            "four_relegated_replaced_by_four_external_verified_real_clubs" if is_last
            else "four_relegated_replaced_by_four_promoted_from_lower_division"
        )
        if is_last or level == 1:
            league["promotion_playoff_status"] = "not_applicable_final_division"
        elif club_count < PLAYOFF_MIN_CLUBS:
            league["promotion_playoff_status"] = "not_applicable_under_12_clubs_four_direct_promotions"
        elif club_count < 7:
            league["promotion_playoff_status"] = "configuration_pending_insufficient_field"
            pending.append({"league_id": lid, "reason": "fewer_than_7_active_clubs"})
        else:
            league["promotion_playoff_status"] = "ready"

    out.setdefault("domestic_pyramid", {})
    out["domestic_pyramid"].update({
        "version": RULE_VERSION,
        "scope": "all_non_brazil_national_leagues",
        "format": "double_round_robin",
        "legs": 2,
        "relegation_places": RELEGATION_PLACES,
        "direct_promotion_places": DIRECT_PROMOTION_PLACES,
        "promotion_total_places": 4,
        "promotion_playoff_positions": list(PLAYOFF_FIELD),
        "promotion_playoff_legs": PLAYOFF_LEGS,
        "promotion_playoff_minimum_clubs": PLAYOFF_MIN_CLUBS,
        "under_threshold_promotion_rule": "4_direct_promotions_no_playoff",
        "extra_pool_size": EXTRA_POOL_SIZE,
        "extra_pool_scope": "last_division_only",
        "last_division_external_access_slots": EXTRA_POOL_SIZE,
        "single_league_country_rule": "four_relegated_replaced_by_four_external_verified_real_clubs",
        "brazil_exception": "preserve_existing_brazil_pyramid",
        "pending_playoff_leagues": pending,
        "configured_league_count": configured,
    })
    return out


def _seed_for(seed: int, country_id: str, league_id: str, round_no: int) -> int:
    raw = f"{seed}:{country_id}:{league_id}:{round_no}".encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "big")


def _club_map(save: dict, ids: List[str]) -> Dict[str, dict]:
    return {cid: save["world"]["clubs"][cid] for cid in ids if cid in save["world"]["clubs"]}


def _two_leg_tie(save: dict, competition_id: str, season: int, home_id: str,
                 away_id: str, seed: int, round_base: int) -> Tuple[str, List[dict]]:
    """Play a two-leg tie and return winner + serialized match records."""
    clubs = _club_map(save, [home_id, away_id])
    if len(clubs) != 2:
        raise ValueError("V142 playoff tie references missing club")
    engine = MatchEngine(_seed_for(seed, str(save["world"].get("current_year")), competition_id, round_base))
    legs = [(home_id, away_id), (away_id, home_id)]
    aggregate = {home_id: 0, away_id: 0}
    matches = []
    for idx, (h, a) in enumerate(legs, 1):
        result = engine.play(competition_id, season, round_base + idx - 1, clubs[h], clubs[a])
        aggregate[h] += result.home_goals
        aggregate[a] += result.away_goals
        matches.append(result.__dict__.copy())
    if aggregate[home_id] == aggregate[away_id]:
        # Deterministic penalty/tie-break proxy; no player-level system exists.
        key = f"{seed}:{competition_id}:{home_id}:{away_id}".encode()
        winner = home_id if int.from_bytes(hashlib.sha256(key).digest()[:4], "big") % 2 == 0 else away_id
        tiebreak = "penalty_shootout_seeded"
    else:
        winner = home_id if aggregate[home_id] > aggregate[away_id] else away_id
        tiebreak = "aggregate_score"
    return winner, matches


def run_promotion_playoff(save: dict, lower_league: dict, standings: List[dict], seed: int = 140) -> dict:
    """Resolve the 4th-7th playoff into one promoted club.

    The playoff is two-legged in both semifinals and final. It requires seven
    ranked clubs in the lower division; otherwise no promotion is fabricated.
    """
    field = standings[3:7]
    if len(field) < 4:
        return {"status": "configuration_pending_insufficient_field", "winner": None, "matches": []}
    ids = [r["club_id"] for r in field]
    if len(set(ids)) != 4:
        return {"status": "invalid_duplicate_playoff_field", "winner": None, "matches": []}

    by_pos = {4: ids[0], 5: ids[1], 6: ids[2], 7: ids[3]}
    matches = []
    w1, m = _two_leg_tie(save, f"{lower_league['id']}:PROMOTION_PLAYOFF:SF1",
                          save["world"]["current_year"], by_pos[4], by_pos[7], seed, 1)
    matches.extend(m)
    w2, m = _two_leg_tie(save, f"{lower_league['id']}:PROMOTION_PLAYOFF:SF2",
                          save["world"]["current_year"], by_pos[5], by_pos[6], seed, 10)
    matches.extend(m)
    final_winner, m = _two_leg_tie(save, f"{lower_league['id']}:PROMOTION_PLAYOFF:FINAL",
                                   save["world"]["current_year"], w1, w2, seed, 20)
    matches.extend(m)
    return {
        "status": "completed",
        "winner": final_winner,
        "field": ids,
        "semifinal_winners": [w1, w2],
        "matches": matches,
        "legs_per_tie": PLAYOFF_LEGS,
    }
