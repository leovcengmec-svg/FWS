"""Canonical schema helpers for the real-world database layer.

The simulator can run with a small test seed, but production data must obey the
same contracts: stable IDs, explicit hierarchy, and deterministic references.
"""
from dataclasses import dataclass
from typing import Any, Dict, Iterable

REQUIRED_COUNTRY = ("id", "name", "confederation")
REQUIRED_LEAGUE = ("id", "name", "country_id", "level")
REQUIRED_CLUB = ("id", "name", "country_id", "league_id")
REQUIRED_NATIONAL = ("id", "name", "country_id", "confederation")


def _check_ids(rows: Iterable[Dict[str, Any]], label: str):
    errors = []
    seen = set()
    for row in rows:
        rid = row.get("id")
        if not rid:
            errors.append(f"{label} missing id")
        elif rid in seen:
            errors.append(f"duplicate {label} id {rid}")
        else:
            seen.add(rid)
    return errors


def validate_dataset(dataset: Dict[str, Any], required_collections=None) -> list[str]:
    """Validate a database payload without mutating it."""
    errors = []
    if required_collections is None:
        required_collections = ("countries", "leagues", "clubs", "national_teams")
    collections = {
        "countries": REQUIRED_COUNTRY,
        "leagues": REQUIRED_LEAGUE,
        "clubs": REQUIRED_CLUB,
        "national_teams": REQUIRED_NATIONAL,
    }
    rows_by_type = {}
    for key, required in collections.items():
        if key not in required_collections:
            continue
        rows = dataset.get(key, [])
        if not isinstance(rows, list):
            errors.append(f"{key} must be a list")
            rows = []
        rows_by_type[key] = rows
        errors.extend(_check_ids(rows, key[:-1] if key.endswith("s") else key))
        for i, row in enumerate(rows):
            for field in required:
                if field not in row or row[field] in (None, ""):
                    errors.append(f"{key}[{i}] missing {field}")
    country_ids = {r.get("id") for r in rows_by_type.get("countries", [])}
    league_ids = {r.get("id") for r in rows_by_type.get("leagues", [])}
    club_ids = {r.get("id") for r in rows_by_type.get("clubs", [])}
    for league in rows_by_type.get("leagues", []):
        if country_ids and league.get("country_id") not in country_ids:
            errors.append(f"league {league.get('id')} references unknown country")
    for club in rows_by_type.get("clubs", []):
        if country_ids and club.get("country_id") not in country_ids:
            errors.append(f"club {club.get('id')} references unknown country")
        if club.get("league_id") not in league_ids:
            errors.append(f"club {club.get('id')} references unknown league")
    for team in rows_by_type.get("national_teams", []):
        if team.get("country_id") not in country_ids:
            errors.append(f"national team {team.get('id')} references unknown country")
    return errors


@dataclass(frozen=True)
class DatasetSummary:
    countries: int
    leagues: int
    clubs: int
    national_teams: int

    def as_dict(self):
        return self.__dict__.copy()
