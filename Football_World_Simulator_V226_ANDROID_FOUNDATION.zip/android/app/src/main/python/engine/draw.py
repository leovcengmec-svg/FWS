import random

class CompetitionDraw:
    def __init__(self, seed=0):
        self.rng=random.Random(seed)

    def groups(self, clubs, group_count, restrictions=None):
        restrictions=restrictions or (lambda club,group: True)
        groups=[[] for _ in range(group_count)]
        pool=clubs[:]
        self.rng.shuffle(pool)
        for club in pool:
            placed=False
            order=list(range(group_count)); self.rng.shuffle(order)
            for i in sorted(order,key=lambda x:len(groups[x])):
                if restrictions(club,groups[i]):
                    groups[i].append(club); placed=True; break
            if not placed: raise ValueError("No valid draw placement under restrictions")
        return {f"G{i+1}":g for i,g in enumerate(groups)}
