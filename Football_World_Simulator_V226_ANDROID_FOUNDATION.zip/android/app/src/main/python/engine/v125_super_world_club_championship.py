"""V125 — FWS Super World Club Championship.

Closes Block 1 of the remaining roadmap. The Super World is a proprietary
FWS competition with exactly 64 clubs: 16 groups of four, three group-stage
rounds, the top two from each group (32) entering a single-leg knockout,
then 32 -> 16 -> 8 -> 4 -> 2 -> champion.

This layer preserves the existing V104 access/qualification model (56 direct
+ 32 preliminary entrants -> 8 qualifiers) but replaces the execution format
with the final user-defined competition structure. The engine is aggregate:
there is no individual-player registry or player transfer system.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .v124_continental_access_cycle import V124ContinentalAccessCycle
from .v104_super_world_qualification import V104SuperWorldQualification
from .v107_global_club_ranking import V107GlobalClubRanking
from .v108_global_club_world_draw import V108GlobalClubWorldDraw
from .match_engine import MatchEngine


class V125SuperWorldClubChampionship(V124ContinentalAccessCycle):
    VERSION = "V125"
    COMPETITION_ID = "FWS_SUPER_WORLD_CLUB"
    GROUP_COUNT = 16
    GROUP_SIZE = 4
    GROUP_ROUNDS = 3
    KNOCKOUT_START = 32

    def build_super_world_qualification(self, season=None, cycle_years=4, seed=125):
        """Reuse the established V104 access model without mutating its version."""
        result = V104SuperWorldQualification.build_super_world_qualification(
            self, season=season, cycle_years=cycle_years, seed=seed
        )
        result = deepcopy(result)
        result["version"] = self.VERSION
        result["competition_id"] = self.COMPETITION_ID
        world = self.save.setdefault("world", {})
        world["super_world_qualification"] = deepcopy(result)
        world.setdefault("super_world_qualification_history", []).append(deepcopy(result))
        return result

    @staticmethod
    def _playable_club(catalog, club_id, season, seed):
        club = dict(catalog["clubs"][club_id])
        if "attack" not in club or "defense" not in club:
            digest = hashlib.sha256(f"V125:{seed}:{season}:{club_id}".encode()).digest()
            strength = 45.0 + (digest[0] / 255.0) * 30.0
            club.setdefault("attack", strength)
            club.setdefault("defense", strength)
            club.setdefault("prestige", strength)
        return club

    @classmethod
    def _group_stage_three_rounds(cls, clubs, season, seed):
        if len(clubs) != 64 or len({c["id"] for c in clubs}) != 64:
            raise ValueError("Super World group field must contain exactly 64 unique clubs")
        ranking = sorted(clubs, key=lambda c: c["id"])
        groups = [{"group": i + 1, "clubs": [], "matches": [], "qualified": [], "table": []}
                  for i in range(cls.GROUP_COUNT)]
        # Four pots, one club from each pot per group. The actual pot ordering is
        # already produced by V107/V108; this fallback only guarantees structure.
        for i, club in enumerate(ranking):
            groups[i % cls.GROUP_COUNT]["clubs"].append(club)

        all_matches = []
        for group in groups:
            a, b, c, d = group["clubs"]
            pairings = [
                (a, b), (c, d),
                (a, c), (d, b),
                (a, d), (b, c),
            ]
            points = {x["id"]: 0 for x in group["clubs"]}
            for round_no, pair_slice in enumerate((pairings[0:2], pairings[2:4], pairings[4:6]), 1):
                for index, (home, away) in enumerate(pair_slice):
                    engine = MatchEngine(int(seed) + group["group"] * 1000 + round_no * 101 + index)
                    result = engine.play(cls.COMPETITION_ID, season, round_no, home, away)
                    if result.home_goals > result.away_goals:
                        points[home["id"]] += 3
                    elif result.away_goals > result.home_goals:
                        points[away["id"]] += 3
                    else:
                        points[home["id"]] += 1
                        points[away["id"]] += 1
                    row = {
                        "competition_id": cls.COMPETITION_ID,
                        "season": season,
                        "group": group["group"],
                        "round_no": round_no,
                        "home_id": home["id"],
                        "away_id": away["id"],
                        "home_goals": result.home_goals,
                        "away_goals": result.away_goals,
                    }
                    group["matches"].append(row)
                    all_matches.append(row)
            ordered = sorted(points.items(), key=lambda x: (-x[1], x[0]))
            group["table"] = [{"club_id": cid, "points": pts, "position": pos}
                               for pos, (cid, pts) in enumerate(ordered, 1)]
            group["qualified"] = [next(c for c in group["clubs"] if c["id"] == cid)
                                   for cid, _ in ordered[:2]]
        return groups, all_matches

    @staticmethod
    def _single_knockout_match(home, away, season, seed, round_no, index):
        engine = MatchEngine(int(seed) + round_no * 1009 + index)
        result = engine.play(V125SuperWorldClubChampionship.COMPETITION_ID,
                             season, round_no, home, away)
        if result.home_goals > result.away_goals:
            winner = home
        elif result.away_goals > result.home_goals:
            winner = away
        else:
            digest = hashlib.sha256(
                f"V125:{seed}:{season}:{round_no}:{home['id']}:{away['id']}".encode()
            ).digest()
            winner = home if digest[0] % 2 == 0 else away
        return winner, {
            "competition_id": V125SuperWorldClubChampionship.COMPETITION_ID,
            "season": season,
            "round_no": round_no,
            "home_id": home["id"],
            "away_id": away["id"],
            "home_goals": result.home_goals,
            "away_goals": result.away_goals,
            "decision": "extra_time_or_penalties_if_tied",
            "winner_id": winner["id"],
        }

    @classmethod
    def _knockout_32_to_champion(cls, clubs, season, seed):
        expected = [32, 16, 8, 4, 2, 1]
        pool = list(clubs)
        matches = []
        round_sizes = []
        round_no = 1
        while len(pool) > 1:
            round_sizes.append(len(pool))
            next_pool = []
            for i in range(0, len(pool), 2):
                winner, row = cls._single_knockout_match(pool[i], pool[i + 1], season,
                                                          seed, round_no, i)
                next_pool.append(winner)
                matches.append(row)
            pool = next_pool
            round_no += 1
        round_sizes.append(1)
        if round_sizes != expected:
            raise ValueError(f"Super World knockout closure invalid: {round_sizes}")
        return pool[0], matches, round_sizes

    def run_super_world(self, season=None, cycle_years=4, seed=125):
        world = self.save.setdefault("world", {})
        year = int(season if season is not None else world.get("current_year", 2026))
        if year % int(cycle_years) != 0:
            world["super_world_execution"] = None
            return None

        qualification = self.build_super_world_qualification(year, cycle_years, seed - 1)
        catalog = self._catalog_from_save()
        direct = [self._playable_club(catalog, r["club_id"], year, seed)
                  for r in qualification["direct"]]
        preliminary = [self._playable_club(catalog, r["club_id"], year, seed)
                       for r in qualification["preliminary"]]

        # Exactly 32 preliminary entrants -> 8 group-stage places.
        prelim_pool = list(preliminary)
        prelim_matches = []
        round_no = 1
        while len(prelim_pool) > 8:
            next_pool = []
            for i in range(0, len(prelim_pool), 2):
                winner, row = self._single_knockout_match(prelim_pool[i], prelim_pool[i + 1],
                                                          year, seed + 1, round_no, i)
                next_pool.append(winner)
                prelim_matches.append(row)
            prelim_pool = next_pool
            round_no += 1
        winners8 = prelim_pool
        group_field = []
        seen = set()
        for club in direct + winners8:
            if club["id"] not in seen:
                group_field.append(club); seen.add(club["id"])
        if len(group_field) != 64:
            raise ValueError("Super World must have exactly 64 unique group-stage clubs")

        ranking = V107GlobalClubRanking.build_global_club_ranking(self, season=year)
        pots = V107GlobalClubRanking._seed_four_pots(group_field, ranking)
        groups = V108GlobalClubWorldDraw._balanced_groups(pots)
        groups, group_matches = self._group_stage_three_rounds(
            [club for group in groups for club in group["clubs"]], year, seed + 7
        )

        knockout_field = [club for group in groups for club in group["qualified"]]
        if len(knockout_field) != 32 or len({c["id"] for c in knockout_field}) != 32:
            raise ValueError("Super World playoff field must contain exactly 32 unique clubs")
        champion, knockout_matches, knockout_rounds = self._knockout_32_to_champion(
            knockout_field, year, seed + 17
        )

        execution = {
            "version": self.VERSION,
            "competition_id": self.COMPETITION_ID,
            "season": year,
            "status": "completed",
            "format": "64_clubs_16_groups_x4_3_rounds->32_playoffs->16->8->4->2->champion",
            "access": {
                "direct_entries": 56,
                "preliminary_entries": 32,
                "preliminary_qualifying_places": 8,
                "group_entries": 64,
            },
            "preliminary_matches": prelim_matches,
            "preliminary_winners": [c["id"] for c in winners8],
            "seeding": {"model": "4_ranking_pots_confederation_balanced",
                        "pots": [[c["id"] for c in p] for p in pots]},
            "groups": groups,
            "group_count": 16,
            "group_size": 4,
            "group_rounds": 3,
            "group_matches": group_matches,
            "playoff_entries": 32,
            "knockout_entries": 32,
            "knockout_rounds": knockout_rounds,
            "knockout_round_names": ["round_of_32", "round_of_16", "quarter_final",
                                     "semi_final", "final"],
            "knockout_matches": knockout_matches,
            "champion": champion["id"],
        }
        world["super_world_execution"] = deepcopy(execution)
        world.setdefault("super_world_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("super_world", []).append(deepcopy(execution))
        return deepcopy(execution)

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["super_world_championship_engine"] = {
            "version": self.VERSION,
            "base_version": "V124",
            "competition_id": self.COMPETITION_ID,
            "group_stage": {"clubs": 64, "groups": 16, "clubs_per_group": 4, "rounds": 3,
                             "qualifiers_per_group": 2},
            "knockout": [32, 16, 8, 4, 2, 1],
            "single_leg_knockout": True,
            "aggregate_match_engine": True,
            "no_individual_players": True,
            "no_player_transfer_system": True,
            "history_append_only": True,
        }
        return deepcopy(world["super_world_championship_engine"])

    def validate(self):
        errors = super().validate()
        cfg = self.save.get("world", {}).get("super_world_championship_engine", {})
        if cfg and cfg.get("version") != self.VERSION:
            errors.append("wrong V125 Super World engine version")
        if cfg:
            gs = cfg.get("group_stage", {})
            if gs.get("clubs") != 64 or gs.get("groups") != 16 or gs.get("clubs_per_group") != 4 or gs.get("rounds") != 3:
                errors.append("V125 Super World group format invalid")
            if cfg.get("knockout") != [32, 16, 8, 4, 2, 1]:
                errors.append("V125 Super World knockout format invalid")
        execution = self.save.get("world", {}).get("super_world_execution")
        if execution:
            if execution.get("version") != self.VERSION:
                errors.append("wrong V125 Super World execution version")
            if execution.get("group_count") != 16 or execution.get("group_size") != 4 or execution.get("group_rounds") != 3:
                errors.append("V125 Super World group structure invalid")
            groups = execution.get("groups", [])
            if len(groups) != 16 or any(len(g.get("clubs", [])) != 4 for g in groups):
                errors.append("V125 Super World requires 16 groups of 4")
            if any(len(g.get("matches", [])) != 6 for g in groups):
                errors.append("V125 Super World requires 6 matches per group")
            if any({m.get("round_no") for m in g.get("matches", [])} != {1, 2, 3} for g in groups):
                errors.append("V125 Super World requires exactly 3 group rounds")
            ids = [c.get("id") for g in groups for c in g.get("clubs", [])]
            if len(ids) != 64 or len(set(ids)) != 64:
                errors.append("V125 Super World group field must contain 64 unique clubs")
            ko = execution.get("knockout_entries")
            if ko != 32 or execution.get("knockout_rounds") != [32, 16, 8, 4, 2, 1]:
                errors.append("V125 Super World knockout closure invalid")
            if not execution.get("champion"):
                errors.append("V125 Super World must produce a champion")
        return errors
