"""V150 — Master World Cycle.

V150 is the single annual orchestration boundary for the current FWS runtime.
It does not replace the established engines. It composes the sporting world
cycle (GlobalSeasonCycle) with the V133 aggregate annual integration layer,
using one season/year transaction and one master ledger row.

Order:
    bootstrap/integrity -> domestic/continental/promotion -> V133 annual
    integration -> final integrity -> one year advance -> master ledger.

No individual player or player-transfer layer is introduced.
"""
from __future__ import annotations

import pickle

from copy import deepcopy

from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity
from .season_world_cycle import GlobalSeasonCycle
from .world_simulator import WorldSimulator
from .v133_world_integration import V133WorldIntegration


class V150MasterWorldCycle:
    VERSION = "V150"
    SCHEMA = 1

    def __init__(self, save, seed=150):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("master_world_cycles", [])

    def _assert_no_player_layer(self):
        if "players" in self._world():
            raise ValueError("V150 must not contain an individual player layer")
        if "player_transfers" in self._history():
            raise ValueError("V150 must not contain a player transfer history")

    def run_season(self, *, advance_year=True, club_context=None,
                   association_context=None, competitions=None,
                   career_results=None):
        year = int(self._world().get("current_year", 2026))
        if any(int(row.get("season", -1)) == year for row in self._ledger()):
            raise ValueError(f"V150 season {year} already integrated")

        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            self._assert_no_player_layer()
            WorldBootstrap(self.save).prepare()
            assert_world_integrity(self.save)

            # Sporting layer: keep the established domestic/continental engines
            # authoritative. Do not advance the year yet; V133 must close the
            # same season rather than accidentally creating a second year.
            simulator = WorldSimulator(self.save, seed=self.seed)
            sporting = GlobalSeasonCycle(self.save, simulator).run(advance_year=False)

            # Aggregate world integration layer: economy, autonomous AI,
            # development, career consequences and historical close.
            integration = V133WorldIntegration(self.save, seed=self.seed + 133).run_season(
                year,
                club_context=club_context or {},
                association_context=association_context or {},
                competitions=competitions or {},
                career_results=career_results or {},
                advance_year=False,
            )

            self._assert_no_player_layer()
            assert_world_integrity(self.save)

            next_year = year + 1 if advance_year else year
            self._world()["current_year"] = next_year
            self._world()["current_round"] = 0

            row = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "season": year,
                "status": "closed",
                "next_year": next_year,
                "sporting_version": "GlobalSeasonCycle",
                "integration_version": "V133",
                "sporting": deepcopy(sporting),
                "integration": deepcopy(integration),
            }
            self._ledger().append(deepcopy(row))
            self._world()["master_cycle_status"] = "closed"
            self._world()["master_cycle_version"] = self.VERSION
            return deepcopy(row)
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        rows = self._ledger()
        seasons = [int(r.get("season", -1)) for r in rows]
        if len(seasons) != len(set(seasons)):
            errors.append("V150 master seasons must be unique")
        for row in rows:
            if row.get("version") != self.VERSION or row.get("status") != "closed":
                errors.append(f"V150 invalid master cycle: {row.get('season')}")
            if row.get("sporting_version") != "GlobalSeasonCycle":
                errors.append(f"V150 missing sporting link: {row.get('season')}")
            if row.get("integration_version") != "V133":
                errors.append(f"V150 missing V133 link: {row.get('season')}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("V150 player systems are forbidden")
        return errors
