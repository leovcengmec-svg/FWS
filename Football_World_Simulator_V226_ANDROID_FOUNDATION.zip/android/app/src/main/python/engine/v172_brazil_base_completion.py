"""V172.1 Brazil base completion and cup inventory."""
from __future__ import annotations

TOTAL_PYRAMID_CLUBS = 604
ACCESS_CLUBS = 256
EXTRA_CLUB_RULE = False
ES_SUFFIX = " ES"

def validate_brazil(save):
    errors=[]
    leagues=save.get("world",{}).get("brazil_leagues",{})
    if leagues.get("BRA-BR-5",{}).get("club_count") != 96: errors.append("BRA-BR-5 must have 96 clubs")
    if leagues.get("BRA-BR-6",{}).get("club_count") != 96: errors.append("BRA-BR-6 must have 96 clubs")
    if leagues.get("BRA-ACCESS",{}).get("club_count") != 256: errors.append("BRA-ACCESS must have 256 clubs")
    if leagues.get("BRA-ACCESS",{}).get("four_extra_rule") is not False: errors.append("Brazil four-extra-club rule must be disabled")
    return errors

def normalize_es_name(name):
    return name.replace("-ES", " ES") if name.endswith("-ES") else (name if name.endswith(" ES") else name)
