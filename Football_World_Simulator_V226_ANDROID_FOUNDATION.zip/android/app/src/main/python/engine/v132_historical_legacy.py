"""V132 — World History & Legacy Engine.

Closes Block 7 with an immutable, append-only historical ledger that consolidates
world seasons, clubs, associations, competitions and the user's career.  The
ledger is deliberately separate from live state: historical rows are never
replaced or rewritten when a season is closed again.

No individual-player history or player-transfer history is created.
"""
from __future__ import annotations

from copy import deepcopy


class V132HistoricalLegacy:
    VERSION = "V132"
    SCHEMA = 1

    def __init__(self, save):
        self.save = save
        history = save.setdefault("history", {})
        self.ledger = history.setdefault(
            "world_legacy",
            {
                "schema": self.SCHEMA,
                "seasons": [],
                "events": [],
                "club_legacy": {},
                "association_legacy": {},
                "career_legacy": [],
            },
        )
        self.ledger.setdefault("schema", self.SCHEMA)
        self.ledger.setdefault("seasons", [])
        self.ledger.setdefault("events", [])
        self.ledger.setdefault("club_legacy", {})
        self.ledger.setdefault("association_legacy", {})
        self.ledger.setdefault("career_legacy", [])

    @staticmethod
    def _copy(value):
        return deepcopy(value)

    @staticmethod
    def _season_id(season):
        return int(season)

    def record_season(self, season, *, competitions=None, clubs=None,
                      associations=None, career=None, summary=None):
        """Append one closed-season snapshot; a season can never be overwritten."""
        season = self._season_id(season)
        if any(int(row["season"]) == season for row in self.ledger["seasons"]):
            raise ValueError(f"historical season {season} already recorded")

        row = {
            "version": self.VERSION,
            "season": season,
            "status": "closed",
            "competitions": self._copy(competitions or {}),
            "clubs": self._copy(clubs or {}),
            "associations": self._copy(associations or {}),
            "career": self._copy(career or {}),
            "summary": self._copy(summary or {}),
        }
        self.ledger["seasons"].append(row)
        self.ledger["seasons"].sort(key=lambda item: item["season"])
        self._update_rollups(row)
        return self._copy(row)

    def _update_rollups(self, row):
        season = row["season"]
        for club_id, data in row["clubs"].items():
            rec = self.ledger["club_legacy"].setdefault(
                club_id,
                {"seasons": [], "titles": 0, "continental_titles": 0,
                 "promotions": 0, "relegations": 0},
            )
            rec["seasons"].append({"season": season, **self._copy(data)})
            rec["seasons"].sort(key=lambda item: item["season"])
            rec["titles"] += int(data.get("titles", 0))
            rec["continental_titles"] += int(data.get("continental_titles", 0))
            rec["promotions"] += int(data.get("promotions", 0))
            rec["relegations"] += int(data.get("relegations", 0))

        for association_id, data in row["associations"].items():
            rec = self.ledger["association_legacy"].setdefault(
                association_id,
                {"seasons": [], "titles": 0, "continental_titles": 0},
            )
            rec["seasons"].append({"season": season, **self._copy(data)})
            rec["seasons"].sort(key=lambda item: item["season"])
            rec["titles"] += int(data.get("titles", 0))
            rec["continental_titles"] += int(data.get("continental_titles", 0))

        career = row.get("career") or {}
        if career:
            self.ledger["career_legacy"].append(
                {"season": season, **self._copy(career)}
            )
            self.ledger["career_legacy"].sort(key=lambda item: item["season"])

    def record_event(self, event_id, event_type, season, payload=None):
        """Append a named historical event; duplicate IDs are rejected."""
        event_id = str(event_id)
        if any(str(event.get("event_id")) == event_id for event in self.ledger["events"]):
            raise ValueError(f"historical event {event_id} already recorded")
        event = {
            "version": self.VERSION,
            "event_id": event_id,
            "event_type": str(event_type),
            "season": self._season_id(season),
            "payload": self._copy(payload or {}),
        }
        self.ledger["events"].append(event)
        self.ledger["events"].sort(key=lambda item: (item["season"], item["event_id"]))
        return self._copy(event)

    def club_legacy(self, club_id):
        return self._copy(self.ledger["club_legacy"].get(str(club_id), {
            "seasons": [], "titles": 0, "continental_titles": 0,
            "promotions": 0, "relegations": 0,
        }))

    def association_legacy(self, association_id):
        return self._copy(self.ledger["association_legacy"].get(str(association_id), {
            "seasons": [], "titles": 0, "continental_titles": 0,
        }))

    def career_legacy(self):
        return self._copy(self.ledger["career_legacy"])

    def timeline(self, entity_id=None, event_type=None):
        rows = self.ledger["events"]
        if entity_id is not None:
            entity_id = str(entity_id)
            rows = [r for r in rows if str(r.get("payload", {}).get("entity_id")) == entity_id]
        if event_type is not None:
            rows = [r for r in rows if r.get("event_type") == event_type]
        return self._copy(rows)

    def validate(self):
        errors = []
        seasons = [int(r.get("season")) for r in self.ledger.get("seasons", [])]
        if seasons != sorted(set(seasons)):
            errors.append("V132 historical seasons must be unique and ordered")
        event_ids = [str(r.get("event_id")) for r in self.ledger.get("events", [])]
        if len(event_ids) != len(set(event_ids)):
            errors.append("V132 historical event IDs must be unique")
        if any(r.get("status") != "closed" for r in self.ledger.get("seasons", [])):
            errors.append("V132 every historical season must be closed")
        for row in self.ledger.get("seasons", []):
            if "version" not in row or row["version"] != self.VERSION:
                errors.append(f"V132 invalid season version: {row.get('season')}")
        return errors
