"""V136 - Global catalog integrity and bidirectional club/league indexing."""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy


class V136CatalogIntegrity:
    VERSION = "V136"

    def normalize(self, catalog: dict) -> dict:
        out = deepcopy(catalog)
        clubs = out.get("clubs", {})
        leagues = out.get("leagues", {})
        by_league = defaultdict(list)
        for club_id, club in clubs.items():
            if club.get('status') == 'waiting_final_division':
                continue
            league_id = club.get("league_id")
            if league_id in leagues:
                by_league[league_id].append(club_id)
        for league_id, league in leagues.items():
            league["club_ids"] = sorted(by_league.get(league_id, []))
            league["club_count"] = len(league["club_ids"])
            if league["club_count"] > 0 and league.get("data_status") == "clubs_pending":
                league["data_status"] = "clubs_indexed"
        out.setdefault("integrity", {})["catalog_index_version"] = self.VERSION
        return out

    def validate(self, catalog: dict) -> dict:
        clubs = catalog.get("clubs", {})
        leagues = catalog.get("leagues", {})
        errors = []
        for league_id, league in leagues.items():
            ids = league.get("club_ids", [])
            if len(ids) != len(set(ids)):
                errors.append({"type": "duplicate_club_id", "league_id": league_id})
            for club_id in ids:
                club = clubs.get(club_id)
                if club is None:
                    errors.append({"type": "missing_club", "league_id": league_id, "club_id": club_id})
                    continue
                if club.get("league_id") != league_id and league.get("canonical_competition_id") != club.get("league_id"):
                    errors.append({"type": "league_backref_mismatch", "league_id": league_id, "club_id": club_id})
                if club.get("country_id") != league.get("country_id"):
                    errors.append({"type": "country_mismatch", "league_id": league_id, "club_id": club_id})
        indexed = set()
        for league in leagues.values():
            indexed.update(league.get("club_ids", []))
        for club_id, club in clubs.items():
            if club.get('status') == 'waiting_final_division':
                continue
            league_id = club.get("league_id")
            if league_id not in leagues:
                errors.append({"type": "missing_league", "club_id": club_id, "league_id": league_id})
            elif club_id not in leagues[league_id].get("club_ids", []):
                errors.append({"type": "orphan_club_index", "club_id": club_id, "league_id": league_id})
        return {"valid": not errors, "error_count": len(errors), "errors": errors}
