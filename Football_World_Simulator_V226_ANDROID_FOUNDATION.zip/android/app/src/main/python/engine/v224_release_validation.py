"""V224 — Full release validation gate."""
from __future__ import annotations
import copy, json, math
from .v221_release_optimization import V221ReleaseOptimization
from .v222_recovery_integrity import V222RecoveryIntegrity
class V224ReleaseValidation:
    VERSION="V224"
    def __init__(self, save, root): self.save=save; self.root=root
    def run(self):
        errors=[]
        errors += V221ReleaseOptimization(self.save).validate() if self.save.get("runtime",{}).get("optimization") else ["V221 not executed"]
        errors += V222RecoveryIntegrity(self.save).validate() if self.save.get("runtime",{}).get("checkpoint") else ["V222 not executed"]
        for cid,c in (self.save.get("world",{}).get("clubs",{}) or {}).items():
            for k in ("sporting_strength","sporting_form","prestige","cash"):
                try: x=float(c.get(k,0))
                except Exception: errors.append(f"{cid}:{k}:invalid"); continue
                if not math.isfinite(x): errors.append(f"{cid}:{k}:nonfinite")
        if "players" in self.save.get("world",{}): errors.append("player layer present")
        if "player_transfers" in self.save.get("history",{}): errors.append("player transfer layer present")
        result={"version":self.VERSION,"status":"ready" if not errors else "failed","errors":errors,
                "engine_files":len(list((self.root/"engine").glob("*.py"))),"test_files":len(list((self.root/"tests").glob("*.py")))}
        self.save.setdefault("release",{})["v224_validation"]=copy.deepcopy(result)
        return result
