"""Lifecycle for strategic corrective actions.

Actions remain administrative and auditable. Progress is derived from existing
club strategic state; this layer never creates cash or changes match odds.
"""
class StrategicActionLifecycle:
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_action_lifecycle", [])

    @staticmethod
    def _clamp(v):
        return round(max(0.0, min(100.0, float(v))), 4)

    def _club(self, club_id):
        club = self.save.get("world", {}).get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        return club

    def initialize(self, club_id, action_id, season=None):
        club = self._club(club_id)
        actions = club.get("strategic_review_actions", [])
        if not 0 <= int(action_id) < len(actions):
            raise ValueError("ação estratégica inexistente")
        action = actions[int(action_id)]
        if action.get("action") == "rebaseline" or action.get("status") == "no_plan":
            return action
        season = self.save["world"].get("current_year") if season is None else int(season)
        if "lifecycle" in action:
            return action
        risk = float(action.get("risk_score", 50.0))
        gap = float(action.get("execution_gap", 0.0))
        duration = 1 if action.get("priority") == "low" else (2 if action.get("priority") == "medium" else 3)
        action["lifecycle"] = {
            "start_season": season, "due_season": season + duration,
            "target_progress": self._clamp(100.0 if action.get("action") == "monitor" else 80.0),
            "progress": 0.0, "baseline_quality": self._clamp(club.get("strategic_quality", 50.0)),
            "baseline_state": {
                "strategic_quality": self._clamp(club.get("strategic_quality", 50.0)),
                "cash": round(float(club.get("cash", 0.0)), 2),
                "prestige": self._clamp(club.get("prestige", 0.0)),
                "sporting_strength": self._clamp(club.get("sporting_strength", 0.0)),
                "identity_score": self._clamp(club.get("identity_score", 0.0)),
            },
            "risk_baseline": self._clamp(risk), "gap_baseline": round(gap, 4),
            "status": "pending", "reviews": []
        }
        self.history.append({"type":"initialized", "club_id":club_id,"action_id":int(action_id),"season":season})
        return action

    def advance(self, club_id, season=None):
        club = self._club(club_id)
        season = self.save["world"].get("current_year") if season is None else int(season)
        actions = club.get("strategic_review_actions", [])
        changed = []
        for idx, action in enumerate(actions):
            lc = action.get("lifecycle")
            if not lc or lc.get("status") in ("completed", "cancelled"):
                continue
            quality = self._clamp(club.get("strategic_quality", 50.0))
            baseline = float(lc.get("baseline_quality", quality))
            gain = max(0.0, quality - baseline)
            progress = self._clamp(lc.get("progress", 0.0) + min(40.0, gain * 1.5 + 5.0))
            lc["progress"] = progress
            lc["reviews"].append({"season":season,"quality":quality,"progress":progress})
            lc["status"] = "completed" if progress >= float(lc.get("target_progress",80.0)) else "in_progress"
            if lc["status"] != "completed" and season > int(lc["due_season"]):
                lc["status"] = "overdue"
                action["priority"] = "high"
            changed.append({"action_id":idx,"status":lc["status"],"progress":progress,"due_season":lc["due_season"]})
            self.history.append({"type":"progress","club_id":club_id,"season":season,**changed[-1]})
        return changed

    def snapshot(self, club_id):
        club = self._club(club_id)
        actions = club.get("strategic_review_actions", [])
        lifecycles = [a["lifecycle"] for a in actions if "lifecycle" in a]
        return {
            "club_id": club_id,
            "total": len(lifecycles),
            "pending": sum(x.get("status")=="pending" for x in lifecycles),
            "in_progress": sum(x.get("status")=="in_progress" for x in lifecycles),
            "completed": sum(x.get("status")=="completed" for x in lifecycles),
            "overdue": sum(x.get("status")=="overdue" for x in lifecycles),
            "average_progress": round(sum(float(x.get("progress",0)) for x in lifecycles)/len(lifecycles),4) if lifecycles else 0.0,
            "latest": lifecycles[-1] if lifecycles else None,
        }
