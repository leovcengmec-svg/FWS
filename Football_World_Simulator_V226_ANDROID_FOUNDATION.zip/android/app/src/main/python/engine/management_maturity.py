"""Long-term maturity and resilience derived from integrated management capacities.

This layer summarizes structural capabilities into bounded maturity/resilience
scores. It does not modify match outcomes directly and does not create free cash.
"""

class ManagementMaturity:
    CATEGORIES = (
        "infrastructure_score", "marketing_level", "youth_development_capacity",
        "scouting_capacity", "sporting_management_capacity",
        "debt_management_capacity", "reserve_strength",
    )

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("management_maturity", [])

    @staticmethod
    def _clamp(value, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(value))), 4)

    def evaluate(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        values = {k: self._clamp(club.get(k, 40.0)) for k in self.CATEGORIES}
        structural = sum(values[k] for k in self.CATEGORIES[:5]) / 5.0
        financial = (values["debt_management_capacity"] + values["reserve_strength"]) / 2.0
        maturity = self._clamp(structural * 0.70 + financial * 0.30)
        resilience = self._clamp(financial * 0.65 + structural * 0.35)
        if maturity >= 80: tier = "elite"
        elif maturity >= 65: tier = "advanced"
        elif maturity >= 50: tier = "established"
        elif maturity >= 35: tier = "developing"
        else: tier = "fragile"
        club["management_maturity"] = maturity
        club["management_resilience"] = resilience
        club["management_maturity_tier"] = tier
        row = {
            "club_id": club_id, "season": season,
            "maturity": maturity, "resilience": resilience,
            "tier": tier, "structural_score": round(structural, 4),
            "financial_score": round(financial, 4), "capabilities": values,
        }
        self.history.append(row)
        club.setdefault("management_maturity_history", []).append(row)
        return row
