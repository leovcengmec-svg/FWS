class OwnershipMarketCycle:
    """Controlled end-to-end ownership-market cycle.

    V42 orchestrates existing V36-V41 layers without duplicating their rules:
    buyers evaluate, offers are created, non-player sellers decide, and only
    accepted offers are sent to V40 settlement. Player sellers are never
    auto-decided. Counter-offers remain pending for a later cycle.
    """
    def __init__(self, save, marketplace, buyers, sellers, settlement):
        self.save = save
        self.marketplace = marketplace
        self.buyers = buyers
        self.sellers = sellers
        self.settlement = settlement
        self.history = save.setdefault('history', {}).setdefault('ownership_market_cycles', [])

    def _active_listings(self):
        return [x for x in self.marketplace.listings if x['status'] == 'active']

    def run(self, max_offers_per_listing=None, seller_profile='balanced'):
        summary = {'listings': 0, 'offers_created': 0, 'decisions': 0,
                   'accepted': 0, 'rejected': 0, 'countered': 0,
                   'settled': 0, 'deferred': 0, 'skipped_player_sellers': 0,
                   'details': []}
        for listing in list(self._active_listings()):
            summary['listings'] += 1
            created = self.buyers.generate_offers(listing['id'], max_offers=max_offers_per_listing)
            summary['offers_created'] += len(created)
            for offer in created:
                seller = listing.get('seller')
                if seller == 'player':
                    summary['skipped_player_sellers'] += 1
                    summary['details'].append({'offer_id': offer['id'], 'status': 'awaiting_player'})
                    continue
                decision = self.sellers.decide(offer['id'], profile=seller_profile)
                summary['decisions'] += 1
                action = decision.get('offer', {}).get('status') if 'offer' in decision else decision.get('status')
                if action == 'accepted':
                    summary['accepted'] += 1
                    result = self.settlement.settle(offer['id'])
                    if result['status'] == 'settled':
                        summary['settled'] += 1
                    else:
                        summary['deferred'] += 1
                    summary['details'].append({'offer_id': offer['id'], 'decision': 'accepted', 'settlement': result})
                elif action == 'rejected':
                    summary['rejected'] += 1
                    summary['details'].append({'offer_id': offer['id'], 'decision': 'rejected'})
                else:
                    summary['countered'] += 1
                    summary['details'].append({'offer_id': offer['id'], 'decision': 'countered'})
        summary['status'] = 'completed'
        self.history.append(summary.copy())
        return summary
