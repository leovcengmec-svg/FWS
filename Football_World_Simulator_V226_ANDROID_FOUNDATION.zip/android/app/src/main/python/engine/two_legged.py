class TwoLeggedTie:
    """Two-leg tie with aggregate score and deterministic penalty abstraction."""
    def __init__(self, engine, competition_id, season, round_no):
        self.engine=engine; self.competition_id=competition_id; self.season=season; self.round_no=round_no

    def play(self, home, away):
        first=self.engine.play(self.competition_id,self.season,self.round_no,home,away)
        second=self.engine.play(self.competition_id,self.season,self.round_no+1,away,home)
        hs=first.home_goals+second.away_goals
        as_=first.away_goals+second.home_goals
        if hs>as_: winner=home
        elif as_>hs: winner=away
        else:
            # No individual players are simulated; shootout is an abstract tiebreak.
            winner=home if hash((home["id"],away["id"],self.season,self.round_no))%2==0 else away
        return {"home_id":home["id"],"away_id":away["id"],
                "first_leg":first.__dict__,"second_leg":second.__dict__,
                "aggregate":{"home":hs,"away":as_},"winner_id":winner["id"]}

