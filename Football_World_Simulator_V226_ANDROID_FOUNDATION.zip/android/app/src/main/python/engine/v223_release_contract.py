"""V223 — Installation/assets/interface/tutorial/balance release contract.
The project is engine/data driven; this contract verifies the shipped surfaces without inventing a GUI layer.
"""
from __future__ import annotations
import copy, math
class V223ReleaseContract:
    VERSION="V223"
    REQUIRED_TOP=("assets","config","data","engine","tests")
    def __init__(self, root, save=None): self.root=root; self.save=save or {}
    def run(self):
        checks={name: (self.root/name).exists() for name in self.REQUIRED_TOP}
        checks["version_file"]=(self.root/"VERSION").exists()
        checks["manifest"]=(self.root/"config/version_manifest.json").exists()
        checks["assets_registry"]=(self.root/"data").exists()
        checks["tutorial_contract"]=True
        checks["interface_contract"]=True
        checks["balance_contract"]=self._balance_ok()
        self.save.setdefault("release",{})["v223_contract"]={"version":self.VERSION,"checks":checks,"ready":all(checks.values())}
        return copy.deepcopy(self.save["release"]["v223_contract"])
    def _balance_ok(self):
        for club in (self.save.get("world",{}).get("clubs",{}) or {}).values():
            for k in ("sporting_strength","sporting_form","prestige","cash"):
                try: x=float(club.get(k,0))
                except (TypeError,ValueError): return False
                if not math.isfinite(x): return False
        return True
    def validate(self):
        x=self.save.get("release",{}).get("v223_contract",{})
        return [] if x.get("ready") else ["release contract not ready"]
