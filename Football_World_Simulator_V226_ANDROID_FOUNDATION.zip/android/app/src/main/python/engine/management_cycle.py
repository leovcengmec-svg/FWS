"""Long-term management cycle and continuity layer.

Converts repeated management quality into a bounded momentum/stability signal.
It is deliberately slow-moving: it never changes match outcomes directly and
never creates cash. Downstream engines may use it only as a small efficiency
input between seasons.
"""

class ManagementCycle:
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("management_cycles", [])

    @staticmethod
    def _clamp(value, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(value))), 4)

    def evaluate(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        maturity = self._clamp(club.get("management_maturity", 40.0))
        resilience = self._clamp(club.get("management_resilience", 40.0))
        prior = [r for r in club.get("management_maturity_history", []) if r.get("season", -1) < season][-3:]
        prior_avg = sum(float(r.get("maturity", 40.0)) for r in prior) / len(prior) if prior else maturity
        consistency = self._clamp(100.0 - abs(maturity - prior_avg) * 2.0)
        momentum = self._clamp(50.0 + (maturity - prior_avg) * 1.5 + (resilience - 50.0) * 0.25)
        stability = self._clamp(consistency * 0.60 + resilience * 0.40)
        cycle = {
            "club_id": club_id, "season": season,
            "momentum": momentum, "stability": stability,
            "consistency": consistency, "prior_maturity": round(prior_avg, 4),
            "maturity": maturity, "resilience": resilience,
        }
        club["management_momentum"] = momentum
        club["management_stability"] = stability
        club["management_consistency"] = consistency
        club.setdefault("management_cycle_history", []).append(cycle)
        self.history.append(cycle)
        return cycle

    def efficiency_modifier(self, club, floor=0.96, ceiling=1.04):
        momentum = self._clamp(club.get("management_momentum", 50.0))
        stability = self._clamp(club.get("management_stability", 50.0))
        modifier = 1.0 + ((momentum - 50.0) * 0.0004) + ((stability - 50.0) * 0.0002)
        return self._clamp(modifier, floor, ceiling)
