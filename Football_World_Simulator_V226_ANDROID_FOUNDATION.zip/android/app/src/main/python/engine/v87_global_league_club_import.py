"""V87: closure importer for the final 21 country league/club packs."""
import copy
class V87LeagueClubImporter:
    REQUIRED_LEAGUE_KEYS={"id","country_id","level","name","data_status"}
    REQUIRED_CLUB_KEYS={"id","country_id","league_id","name","data_status"}
    def __init__(self,catalog,completeness,manifest): self.catalog=catalog; self.completeness=completeness; self.manifest=manifest
    def _validate_tier_policy(self,p):
        if p.get("status") not in ("verified","partial"): return [f"{p['country_id']}: unsupported pack status"]
        levels=sorted(x.get("level") for x in p.get("leagues",[])); real=int(p.get("real_levels_checked",len(levels))); g=p.get("league_system_group")
        if g=="small" and levels!=[1]: return [f"{p['country_id']}: small league system must contain exactly division 1"]
        if g=="intermediate" and real>=2 and levels!=[1,2]: return [f"{p['country_id']}: intermediate league system must contain divisions 1 and 2"]
        if g in ("top_confederation","top_five"):
            if real<=2 and levels!=list(range(1,real+1)): return [f"{p['country_id']}: top group must preserve all real levels"]
            if real>=3 and not (3<=len(levels)<=5): return [f"{p['country_id']}: top group must contain 3-5 divisions"]
        return []
    def validate(self):
        errors=[]; seen_countries=set(); seen_names=set()
        for p in self.manifest.get("packs",[]):
            cid=p["country_id"]
            if cid in seen_countries: errors.append(f"{cid}: duplicate country pack")
            seen_countries.add(cid); errors+=self._validate_tier_policy(p); lids=set()
            for l in p.get("leagues",[]):
                miss=self.REQUIRED_LEAGUE_KEYS-set(l)
                if miss: errors.append(f"{cid}: league missing {sorted(miss)}")
                if l["id"] in self.catalog["leagues"]: errors.append(f"{cid}: duplicate league id {l['id']}")
                lids.add(l["id"])
            for c in p.get("clubs",[]):
                miss=self.REQUIRED_CLUB_KEYS-set(c)
                if miss: errors.append(f"{cid}: club missing {sorted(miss)}")
                if c["id"] in self.catalog["clubs"]: errors.append(f"{cid}: duplicate club id {c['id']}")
                if c["name"].casefold() in seen_names: errors.append(f"{cid}: duplicate club name {c['name']}")
                seen_names.add(c["name"].casefold())
                if c["league_id"] not in lids and c["league_id"] not in self.catalog["leagues"]: errors.append(f"{cid}: unknown league {c['league_id']}")
        return errors
    def apply(self):
        e=self.validate()
        if e: raise ValueError("; ".join(e))
        applied=[]
        for p in self.manifest.get("packs",[]):
            cid=p["country_id"]
            for l in p.get("leagues",[]): self.catalog["leagues"][l["id"]]=copy.deepcopy(l)
            for c in p.get("clubs",[]): self.catalog["clubs"][c["id"]]=copy.deepcopy(c)
            self.catalog["associations"][cid]["league_pack_status"]=p.get("status")
            self.catalog["associations"][cid]["club_pack_status"]=p.get("status")
            applied.append(cid)
        self.catalog["version"]="V87"; self.completeness["version"]="V87"; return applied
