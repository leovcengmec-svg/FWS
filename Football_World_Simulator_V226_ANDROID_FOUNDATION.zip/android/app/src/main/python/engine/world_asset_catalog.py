"""V72 asset catalog and integrity service."""
from __future__ import annotations
import copy


class WorldAssetCatalog:
    SCHEMA_VERSION = 2
    OWNER_TYPES = {"association", "national_team", "country", "league", "club", "competition", "confederation"}
    KINDS = {"flag", "crest", "logo", "banner", "icon"}
    STATUSES = {"verified", "remote_ready", "missing", "placeholder", "pending_verification"}

    def __init__(self, assets=None):
        self.assets = copy.deepcopy(assets or {})

    def register(self, owner_type, owner_id, kind, *, uri=None, source=None,
                 status="pending_verification", checksum=None, license_info=None):
        if owner_type not in self.OWNER_TYPES:
            raise ValueError(f"unsupported owner type: {owner_type}")
        if kind not in self.KINDS:
            raise ValueError(f"unsupported asset kind: {kind}")
        if status not in self.STATUSES:
            raise ValueError(f"unsupported asset status: {status}")
        key = f"{owner_type}:{owner_id}:{kind}"
        self.assets[key] = {
            "id": key,
            "owner_type": owner_type,
            "owner_id": owner_id,
            "kind": kind,
            "uri": uri,
            "source": source,
            "status": status,
            "checksum": checksum,
            "license": license_info,
            "schema_version": self.SCHEMA_VERSION,
        }
        return copy.deepcopy(self.assets[key])

    def get(self, owner_type, owner_id, kind):
        return self.assets.get(f"{owner_type}:{owner_id}:{kind}")

    def validate(self, catalog=None):
        errors = []
        for key, asset in self.assets.items():
            if asset.get("id") != key:
                errors.append(f"asset key/id mismatch: {key}")
            if asset.get("owner_type") not in self.OWNER_TYPES:
                errors.append(f"asset {key} invalid owner_type")
            if asset.get("kind") not in self.KINDS:
                errors.append(f"asset {key} invalid kind")
            if asset.get("status") not in self.STATUSES:
                errors.append(f"asset {key} invalid status")
            if asset.get("status") in {"verified", "remote_ready"} and not asset.get("uri"):
                errors.append(f"asset {key} active without uri")
            if catalog is not None:
                owner_map = {
                    "association": catalog.associations,
                    "country": catalog.associations,
                    "national_team": catalog.national_teams,
                    "league": catalog.leagues,
                    "club": catalog.clubs,
                    "competition": catalog.competitions,
                    "confederation": catalog.catalog.get("confederations", {}),
                }.get(asset.get("owner_type"), {})
                owner_id = asset.get("owner_id")
                if owner_id not in owner_map:
                    aliases = catalog.catalog.get("club_identity_aliases", {}) if asset.get("owner_type") == "club" else {}
                    alias = aliases.get(owner_id)
                    canonical_id = alias.get("canonical_id") if isinstance(alias, dict) else None
                    if canonical_id not in owner_map:
                        errors.append(f"asset {key} orphan owner")
        return errors

    def summary(self):
        by_kind, by_status = {}, {}
        for asset in self.assets.values():
            by_kind[asset["kind"]] = by_kind.get(asset["kind"], 0) + 1
            by_status[asset["status"]] = by_status.get(asset["status"], 0) + 1
        return {"total": len(self.assets), "by_kind": by_kind, "by_status": by_status}
