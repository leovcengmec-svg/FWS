"""V135: completion of the 35 previously club-empty league records.

This layer does not invent clubs. It validates that each previously empty
league now has at least one real, explicitly imported club and that every
club points back to the correct league/country.
"""

TARGET_LEAGUES = (
    'KAZ_D2','IDN_D2','IRQ_D2','KUW_D2','MKD_D2','KGZ_D2','MAS_D2','MOZ_D2',
    'MYA_D2','NAM_D2','NGA_D2','OMA_D2','PAN_D2','PAR_D2','PER_D2','PLE_D2',
    'POL_D2','ROU_D2','RUS_D2','RWA_D2','SDN_D2','SEN_D2','SRB_D2','SSD_D2',
    'SUI_D2','SYR_D2','TAN_D2','THA_D2','TOG_D2','TUN_D2','UKR_D2','UZB_D2',
    'VEN_D2','VIE_D2','ZAM_D2'
)


class V135LeagueClubCompletion:
    def __init__(self, catalog):
        self.catalog = catalog

    def audit(self):
        leagues = self.catalog.get('leagues', {})
        clubs = self.catalog.get('clubs', {})
        errors = []
        report = {}
        for league_id in TARGET_LEAGUES:
            league = leagues.get(league_id)
            if not league:
                errors.append(f'missing league: {league_id}')
                continue
            members = [c for c in clubs.values() if c.get('league_id') == league_id]
            if not members:
                errors.append(f'empty league: {league_id}')
                continue
            bad_country = [c['id'] for c in members if c.get('country_id') != league.get('country_id')]
            if bad_country:
                errors.append(f'country mismatch {league_id}: {bad_country}')
            duplicate_ids = len({c['id'] for c in members}) != len(members)
            if duplicate_ids:
                errors.append(f'duplicate club ids: {league_id}')
            report[league_id] = {
                'club_count': len(members),
                'status': league.get('data_status'),
                'verified_source_version': league.get('clubs_source_version'),
            }
        return {'valid': not errors, 'errors': errors, 'leagues': report}
