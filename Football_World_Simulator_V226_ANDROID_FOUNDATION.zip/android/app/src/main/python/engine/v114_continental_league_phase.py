"""V114 — Continental League Phase Engine.

Adds an executable, configurable league-phase layer after V113 entry
qualification. It deliberately does not freeze a number of matches per club;
the competition definition must provide ``league_phase_matches_per_club``.
The engine is deterministic and works on simulation-only club copies.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from .match_engine import MatchEngine
from .v113_continental_entry_qualification import V113ContinentalEntryQualification


class V114ContinentalLeaguePhase(V113ContinentalEntryQualification):
    VERSION = "V114"

    def run_league_phase(self, competition, entries, *, season=2026, seed=114):
        comp = dict(competition)
        size = int(comp.get("size", comp.get("default_size", 0)))
        if len(entries) != size:
            raise ValueError("league phase requires a complete V113 entry field")
        matches_per_club = comp.get("league_phase_matches_per_club")
        if matches_per_club is None:
            raise ValueError("league_phase_matches_per_club must be configured")
        matches_per_club = int(matches_per_club)
        if matches_per_club <= 0 or matches_per_club >= size:
            raise ValueError("league_phase_matches_per_club must be between 1 and field_size-1")
        if (size * matches_per_club) % 2:
            raise ValueError("field_size * matches_per_club must be even")

        clubs = []
        for e in entries:
            cid = e["club_id"] if isinstance(e, dict) else e
            coeff = float(e.get("league_coefficient", 50.0)) if isinstance(e, dict) else 50.0
            strength = max(1.0, min(99.0, coeff))
            clubs.append({"id": cid, "attack": strength, "defense": strength, "prestige": strength})

        schedule = self._balanced_schedule([c["id"] for c in clubs], matches_per_club)
        standings = {c["id"]: {"club_id": c["id"], "played": 0, "wins": 0, "draws": 0, "losses": 0,
                               "goals_for": 0, "goals_against": 0, "goal_difference": 0,
                               "points": 0} for c in clubs}
        matches = []
        club_map = {c["id"]: c for c in clubs}
        for index, (home_id, away_id) in enumerate(schedule):
            round_no = index // max(1, size // 2) + 1
            engine = MatchEngine(int(seed) + round_no * 1009 + index)
            result = engine.play(comp.get("id", "CONTINENTAL"), int(season), round_no,
                                 club_map[home_id], club_map[away_id])
            hg, ag = int(result.home_goals), int(result.away_goals)
            h, a = standings[home_id], standings[away_id]
            h["played"] += 1; a["played"] += 1
            h["goals_for"] += hg; h["goals_against"] += ag
            a["goals_for"] += ag; a["goals_against"] += hg
            if hg > ag:
                h["wins"] += 1; a["losses"] += 1; h["points"] += 3
            elif ag > hg:
                a["wins"] += 1; h["losses"] += 1; a["points"] += 3
            else:
                h["draws"] += 1; a["draws"] += 1; h["points"] += 1; a["points"] += 1
            h["goal_difference"] = h["goals_for"] - h["goals_against"]
            a["goal_difference"] = a["goals_for"] - a["goals_against"]
            matches.append({"competition_id": comp.get("id"), "season": int(season),
                            "round_no": round_no, "home_id": home_id, "away_id": away_id,
                            "home_goals": hg, "away_goals": ag})

        ordered = sorted(standings.values(), key=lambda r: (-r["points"], -r["goal_difference"],
                                                             -r["goals_for"], str(r["club_id"])))
        for pos, row in enumerate(ordered, 1):
            row["position"] = pos
        return {"version": self.VERSION, "competition_id": comp.get("id"), "season": int(season),
                "field_size": size, "matches_per_club": matches_per_club,
                "match_count": len(matches), "matches": matches, "standings": ordered}

    @staticmethod
    def _balanced_schedule(club_ids, matches_per_club):
        """Deterministically select opponents from a circle schedule.

        The full circle schedule is generated, then the first requested rounds
        are retained. Home/away alternates by round. This is an engine rule,
        not a frozen competition format: the requested round count remains
        supplied by each competition definition.
        """
        ids = list(club_ids)
        n = len(ids)
        if n % 2:
            ids.append(None)
            n += 1
        rounds = n - 1
        fixed = ids[0]
        rotating = ids[1:]
        pairs = []
        for r in range(rounds):
            arr = [fixed] + rotating
            half = n // 2
            for i in range(half):
                a, b = arr[i], arr[-1-i]
                if a is None or b is None:
                    continue
                if r % 2:
                    a, b = b, a
                pairs.append((a, b))
            rotating = [rotating[-1]] + rotating[:-1]
        games_by_club = {cid: [] for cid in club_ids}
        selected = []
        for home, away in pairs:
            if len(games_by_club[home]) >= matches_per_club or len(games_by_club[away]) >= matches_per_club:
                continue
            games_by_club[home].append(away); games_by_club[away].append(home)
            selected.append((home, away))
            if all(len(v) == matches_per_club for v in games_by_club.values()):
                break
        if not all(len(v) == matches_per_club for v in games_by_club.values()):
            raise ValueError("unable to construct a balanced league-phase schedule")
        return selected

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_league_phase_framework"] = {
            "version": self.VERSION,
            "base_version": "V113",
            "execution_order": ["entry_qualification", "league_phase", "post_league_phase"],
            "matches_per_club_is_configurable": True,
            "schedule_is_not_frozen": True,
            "no_catalog_mutation": True,
        }
        self.save.setdefault("continental", {})["league_phase_version"] = self.VERSION
        return deepcopy(world["continental_league_phase_framework"])

    def validate(self):
        errors = super().validate()
        fw = self.save.get("world", {}).get("continental_league_phase_framework", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V114 league phase framework version")
        execution = self.save.get("world", {}).get("continental_league_phase")
        if execution and execution.get("version") != self.VERSION:
            errors.append("wrong V114 league phase execution version")
        return errors
