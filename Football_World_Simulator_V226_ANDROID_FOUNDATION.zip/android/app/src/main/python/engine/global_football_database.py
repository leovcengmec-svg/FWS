"""Global football data-pack registry and deterministic coverage manager.

This layer deliberately separates source discovery from verified simulation data.
A discovered source never becomes playable world data until a pack is validated.
"""
import copy
import json
from pathlib import Path

class GlobalFootballDatabase:
    SCHEMA_VERSION = 1
    STATUS_ORDER = {"verified": 0, "candidate": 1, "pending": 2}

    def __init__(self, catalog, source_registry):
        self.catalog = catalog
        self.registry = source_registry

    @classmethod
    def from_files(cls, catalog_path, registry_path):
        catalog = json.loads(Path(catalog_path).read_text(encoding="utf-8"))
        registry = json.loads(Path(registry_path).read_text(encoding="utf-8"))
        return cls(catalog, registry)

    def association_status(self, association_id):
        row = self.registry["associations"].get(association_id)
        if row is None:
            raise KeyError(association_id)
        return copy.deepcopy(row)

    def pending(self, confederation=None):
        rows = list(self.registry["associations"].values())
        if confederation:
            rows = [r for r in rows if r["confederation"] == confederation]
        return sorted((r for r in rows if r["club_pack_status"] != "verified"),
                      key=lambda r: (r["priority"], r["association_id"]))

    def verified_counts(self):
        rows = list(self.registry["associations"].values())
        return {
            "associations": len(rows),
            "verified_club_packs": sum(r["club_pack_status"] == "verified" for r in rows),
            "verified_league_packs": sum(r["league_pack_status"] == "verified" for r in rows),
            "pending_club_packs": sum(r["club_pack_status"] != "verified" for r in rows),
            "pending_league_packs": sum(r["league_pack_status"] != "verified" for r in rows),
        }

    def source_candidates(self):
        return copy.deepcopy(self.registry["sources"])

    def queue(self, limit=None):
        rows = self.pending()
        return rows if limit is None else rows[:limit]
