"""V198 — Aggregate selection-management decisions."""
from __future__ import annotations
from copy import deepcopy
class V198SelectionDecisions:
    VERSION='V198'
    OPTIONS={'strategy':('balanced','aggressive','conservative','development'),'intensity':range(0,101),'rotation_policy':('balanced','stable','experimental')}
    def __init__(self,save): self.save=save; self.career=save.setdefault('careers',{}).setdefault('selection',{}); self.history=save.setdefault('history',{}).setdefault('selection_decisions',[])
    def _team(self,team_id=None):
        tid=team_id or self.career.get('current_team_id')
        if not tid or tid not in self.save['world'].get('national_teams',{}): raise ValueError('nenhuma seleção nacional está sob gestão')
        return tid,self.save['world']['national_teams'][tid]
    def set_strategy(self,strategy,intensity=50,rotation_policy='balanced'):
        tid,t=self._team();
        if strategy not in self.OPTIONS['strategy']: raise ValueError('estratégia inválida')
        intensity=max(0,min(100,int(intensity)))
        if rotation_policy not in self.OPTIONS['rotation_policy']: raise ValueError('política de rotação inválida')
        t['selection_management']={'strategy':strategy,'intensity':intensity,'rotation_policy':rotation_policy}
        row={'version':self.VERSION,'season':self.save['world'].get('current_year'),'team_id':tid,'strategy':strategy,'intensity':intensity,'rotation_policy':rotation_policy}; self.history.append(deepcopy(row)); return row
    def prepare(self,team_id=None,focus='competition'):
        tid,t=self._team(team_id); focus=str(focus); allowed=('competition','qualification','development','friendlies')
        if focus not in allowed: raise ValueError('foco de preparação inválido')
        t['selection_preparation']={'focus':focus,'season':self.save['world'].get('current_year')}
        row={'version':self.VERSION,'season':self.save['world'].get('current_year'),'team_id':tid,'focus':focus}; self.history.append(deepcopy(row)); return row
    def snapshot(self,team_id=None):
        tid,t=self._team(team_id); return {'version':self.VERSION,'team_id':tid,'management':deepcopy(t.get('selection_management',{})),'preparation':deepcopy(t.get('selection_preparation',{}))}
    def validate(self): return []
