"""V131 — Integrated User Career.

Integrates the user's existing ownership, club-management and invitation-based
national-team career into one auditable career state without creating an
individual-player simulation. Ownership and management remain separate.

Career roles:
    investor -> may own clubs
    club_manager -> may actively manage an owned club
    national_manager -> requires an invitation accepted through SelectionCareer

The aggregate autonomous AI remains responsible for the rest of the world.
User-controlled clubs/selections are explicitly excluded from an autonomous
club/association decision pass so the two control layers cannot overwrite each
other.
"""
from __future__ import annotations

from copy import deepcopy
import random

from .v97_career_power_hub import V97CareerPowerHub
from .v130_ai_autonomous import V130AutonomousAI


class V131IntegratedCareer(V97CareerPowerHub):
    VERSION = "V131"
    CAREER_TIERS = (
        (20, "EMERGING"),
        (40, "REGIONAL"),
        (60, "INTERNATIONAL"),
        (80, "ELITE"),
        (101, "WORLD"),
    )

    def initialize(self, starting_cash=None, manager_prestige=None):
        super().initialize(starting_cash, manager_prestige)
        # SelectionDevelopment in older layers accepts an RNG object but V97
        # may construct it with None. Give V131 a deterministic RNG so selection
        # development is executable and reproducible without altering old saves.
        if getattr(self.selection.development, "rng", None) is None:
            self.selection.development.rng = random.Random(131)
        careers = self.save.setdefault("careers", {})
        # V97 creates the investor dictionary with a zero cash default before
        # checking the optional starting value. V131 repairs that initialization
        # edge case only for a genuinely fresh investor record, preserving any
        # existing balance/transactions from older saves.
        investor = careers.setdefault("investor", {"cash": 0.0, "owned_clubs": [], "transactions": [], "created_clubs": []})
        if starting_cash is not None and not investor.get("transactions") and not investor.get("owned_clubs") and float(investor.get("cash", 0.0)) == 0.0:
            investor["cash"] = float(starting_cash)
        integrated = careers.setdefault(
            "integrated",
            {
                "version": self.VERSION,
                "status": "available",
                "prestige": 0.0,
                "history": [],
                "club_history": [],
                "selection_history": [],
            },
        )
        integrated["version"] = self.VERSION
        # SelectionCareer remains the legacy source for invitation eligibility;
        # a newly created integrated profile adopts the existing legacy prestige
        # so initializing V131 never erases progress from an older save.
        legacy_prestige = self._clamp(self.selection.career.get("manager_prestige", 0.0))
        if not integrated.get("history") and float(integrated.get("prestige", 0.0)) == 0.0 and legacy_prestige > 0.0:
            integrated["prestige"] = legacy_prestige
        integrated["prestige"] = self._clamp(integrated.get("prestige", legacy_prestige))
        self.selection.career["manager_prestige"] = integrated["prestige"]
        self._sync_roles()
        return self.snapshot()

    @staticmethod
    def _clamp(value, low=0.0, high=100.0):
        return round(max(low, min(high, float(value))), 4)

    @classmethod
    def tier_for(cls, prestige):
        p = float(prestige)
        for limit, tier in cls.CAREER_TIERS:
            if p < limit:
                return tier
        return "WORLD"

    def _integrated(self):
        return self.save.setdefault("careers", {}).setdefault(
            "integrated",
            {"version": self.VERSION, "status": "available", "prestige": 0.0,
             "history": [], "club_history": [], "selection_history": []},
        )

    def _sync_roles(self):
        integrated = self._integrated()
        active = self.active.active.active_entities()
        club = active.get("club_id")
        selection = active.get("selection_id")
        if club and selection:
            status = "dual_role"
        elif club:
            status = "club_manager"
        elif selection:
            status = "national_manager"
        else:
            status = "available"
        integrated["status"] = status
        integrated["active_club_id"] = club
        integrated["active_selection_id"] = selection
        integrated["tier"] = self.tier_for(integrated.get("prestige", 0.0))
        return integrated

    def career_snapshot(self):
        integrated = self._sync_roles()
        return {
            "version": self.VERSION,
            "status": integrated["status"],
            "prestige": integrated["prestige"],
            "tier": integrated["tier"],
            "active_club_id": integrated.get("active_club_id"),
            "active_selection_id": integrated.get("active_selection_id"),
            "owned_clubs": list(self.investor.career.get("owned_clubs", [])),
            "selection_invitations": list(self.selection.career.get("invitations", [])),
            "history_count": len(integrated.get("history", [])),
        }

    def _apply_prestige_delta(self, delta, season, source, entity_id, details=None):
        integrated = self._integrated()
        before = self._clamp(integrated.get("prestige", 0.0))
        after = self._clamp(before + float(delta))
        integrated["prestige"] = after
        self.selection.career["manager_prestige"] = after
        row = {
            "version": self.VERSION,
            "season": int(season),
            "source": source,
            "entity_id": entity_id,
            "prestige_before": before,
            "prestige_delta": round(after - before, 4),
            "prestige_after": after,
            "tier_after": self.tier_for(after),
            "details": deepcopy(details or {}),
        }
        integrated["history"].append(deepcopy(row))
        return row

    def activate_owned_club(self, club_id):
        result = super().activate_owned_club(club_id)
        row = {
            "version": self.VERSION,
            "season": self.save["world"].get("current_year"),
            "type": "club_appointment",
            "club_id": result,
            "role": "club_manager",
        }
        self._integrated()["club_history"].append(deepcopy(row))
        self._sync_roles()
        return result

    def leave_club(self):
        result = self.active.active.leave_club()
        if result:
            self._integrated()["club_history"].append({
                "version": self.VERSION,
                "season": self.save["world"].get("current_year"),
                "type": "club_exit",
                "club_id": result,
            })
        self._sync_roles()
        return result

    def accept_selection_invitation(self, team_id):
        result = super().accept_selection_invitation(team_id)
        self._integrated()["selection_history"].append({
            "version": self.VERSION,
            "season": self.save["world"].get("current_year"),
            "type": "selection_appointment",
            "selection_id": result,
            "role": "national_manager",
        })
        self._sync_roles()
        return result

    def leave_selection(self):
        result = self.active.active.leave_selection()
        if result:
            self._integrated()["selection_history"].append({
                "version": self.VERSION,
                "season": self.save["world"].get("current_year"),
                "type": "selection_exit",
                "selection_id": result,
            })
        self._sync_roles()
        return result

    def record_club_season(self, club_id, season=None, league_position=None,
                           league_size=20, continental_success=0.0, title=False,
                           objective_quality=None):
        """Update career prestige from an aggregate club season result.

        No individual player statistics are used. The bounded delta rewards
        sporting/continental success and objective delivery and penalizes poor
        placement. It is deliberately modest so one season cannot jump several
        career tiers by itself.
        """
        if club_id not in self.investor.career.get("owned_clubs", []):
            raise ValueError("o clube precisa pertencer ao investidor")
        season = int(season or self.save["world"].get("current_year", 2026))
        size = max(1, int(league_size))
        if league_position is None:
            placement = 50.0
        else:
            pos = max(1, min(size, int(league_position)))
            placement = (size + 1 - pos) / size * 100.0
        delta = (placement - 50.0) * 0.06
        delta += self._clamp(continental_success, 0, 100) * 0.025
        if title:
            delta += 2.5
        if objective_quality is not None:
            delta += (self._clamp(objective_quality) - 50.0) * 0.025
        row = self._apply_prestige_delta(
            delta, season, "club", club_id,
            {
                "league_position": league_position,
                "league_size": size,
                "placement_score": round(placement, 3),
                "continental_success": self._clamp(continental_success),
                "title": bool(title),
                "objective_quality": None if objective_quality is None else self._clamp(objective_quality),
            },
        )
        return row

    def set_selection_strategy(self, strategy, intensity=50, rotation_policy="balanced"):
        team_id=self.selection.career.get("current_team_id")
        if not team_id: raise ValueError("nenhuma seleção nacional está sob gestão")
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.set_selection_strategy(self.save, team_id, strategy, intensity, rotation_policy)

    def invest_in_selection(self, amount, category="training"):
        team_id=self.selection.career.get("current_team_id")
        if not team_id: raise ValueError("nenhuma seleção nacional está sob gestão")
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.invest_selection(self.save, team_id, amount, category, "player")

    def record_selection_cycle(self, result_quality, opponent_strength=50, season=None):
        season = int(season or self.save["world"].get("current_year", 2026))
        team_id = self.selection.career.get("current_team_id")
        if not team_id:
            raise ValueError("nenhuma seleção nacional está sob gestão")
        before = self._clamp(self._integrated().get("prestige", 0.0))
        after = self.selection.finish_cycle(float(result_quality), float(opponent_strength))
        self._integrated()["prestige"] = self._clamp(after)
        # Keep the legacy field numerically identical to the integrated profile
        # after clamping, preventing floating-point drift between the two layers.
        self.selection.career["manager_prestige"] = self._integrated()["prestige"]
        # SelectionCareer already computes the legacy prestige change. Record
        # exactly that change here rather than applying a second delta.
        row = {
            "version": self.VERSION,
            "season": season,
            "source": "selection",
            "entity_id": team_id,
            "prestige_before": before,
            "prestige_delta": round(self._integrated()["prestige"] - before, 4),
            "prestige_after": self._integrated()["prestige"],
            "tier_after": self.tier_for(self._integrated()["prestige"]),
            "details": {
                "result_quality": float(result_quality),
                "opponent_strength": float(opponent_strength),
            },
        }
        self._integrated()["history"].append(deepcopy(row))
        self._sync_roles()
        return row

    def autonomous_world_cycle(self, season=None, club_context=None, association_context=None, seed=131):
        """Run V130 only over entities not controlled by the user.

        This preserves autonomous world behavior while preventing an AI pass
        from overwriting a club currently under user management or a national
        association currently represented by the user's controlled selection.
        """
        season = int(season or self.save["world"].get("current_year", 2026))
        self._sync_roles()
        active_club = self._integrated().get("active_club_id")
        active_selection = self._integrated().get("active_selection_id")
        ai = V130AutonomousAI(self.save, seed=seed)
        club_context = club_context or {}
        association_context = association_context or {}
        cycle = {"version": self.VERSION, "season": season, "clubs": [], "associations": [], "skipped": [], "status": "completed"}
        for cid in sorted(self.save.get("world", {}).get("clubs", {})):
            if cid == active_club:
                cycle["skipped"].append({"entity_type": "club", "entity_id": cid, "reason": "user_controlled"})
                continue
            decision = ai.decide_club(cid, season, club_context.get(cid, {}))
            cycle["clubs"].append({"decision": deepcopy(decision), "consequence": ai.apply_club_decision(decision)})
        for aid in sorted(self.save.get("world", {}).get("associations", {})):
            # A national-team career controls a national association when the
            # association id is explicitly linked by the team record.
            team = self.save.get("world", {}).get("national_teams", {}).get(active_selection, {}) if active_selection else {}
            controlled_assoc = team.get("association_id")
            if controlled_assoc == aid:
                cycle["skipped"].append({"entity_type": "association", "entity_id": aid, "reason": "user_controlled"})
                continue
            decision = ai.decide_association(aid, season, association_context.get(aid, {}))
            cycle["associations"].append({"decision": deepcopy(decision), "consequence": ai.apply_association_decision(decision)})
        self.save.setdefault("history", {}).setdefault("integrated_career_ai", []).append(deepcopy(cycle))
        return cycle

    def validate(self):
        errors = super().validate()
        integrated = self.save.get("careers", {}).get("integrated", {})
        if integrated and integrated.get("version") != self.VERSION:
            errors.append("wrong integrated career version")
        prestige = float(integrated.get("prestige", 0.0)) if integrated else 0.0
        if not 0.0 <= prestige <= 100.0:
            errors.append("integrated career prestige out of range")
        if integrated and integrated.get("tier") != self.tier_for(prestige):
            errors.append("integrated career tier mismatch")
        if "players" in self.save.get("world", {}):
            errors.append("V131 must not create a player layer")
        for row in integrated.get("history", []):
            if row.get("version") != self.VERSION:
                errors.append("invalid integrated career history version")
        return errors
