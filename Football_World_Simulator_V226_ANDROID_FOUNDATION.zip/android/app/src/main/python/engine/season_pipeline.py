from .domestic_cup import DomesticCup
from .continental import ContinentalAccessEngine
from .continental_qualification import QualificationEngine
from .continental_season import ContinentalSeason
from .coefficient import CoefficientEngine
from .national_cup_engine import NationalCupEngine

class SeasonPipeline:
    """Runs the connected competition chain without assuming every country has the same structure."""
    def __init__(self, save, simulator, national_cup_registry=None):
        self.save=save
        self.sim=simulator
        self.access=ContinentalAccessEngine(
            save.get("continental",{}).get("min_direct_slots",1),
            save.get("continental",{}).get("max_direct_slots",6)
        )
        self.national_cup_registry = national_cup_registry
        self.coeff=CoefficientEngine(
            save.get("coefficients",{}).get("window_seasons",5),
            save.get("coefficients",{}).get("decay",.75)
        )

    def domestic_phase(self):
        league_results=self.sim.simulate_all_leagues()
        cup_winners={}
        season=self.save["world"]["current_year"]
        if self.national_cup_registry:
            engine=NationalCupEngine(self.save["world"], self.national_cup_registry, self.sim.engine)
            for country_id in self.save["world"].get("countries",{}):
                winners,matches=engine.run_country(country_id, season, self.save.setdefault("history",{}))
                self.save.setdefault("history",{}).setdefault("competition_matches",[]).extend(matches)
                for cup_id,row in winners.items():
                    if row.get("primary_for_continental"):
                        cup_winners[cup_id]=self.save["world"]["clubs"][row["club_id"]]
        else:
            # Backward-compatible V89 behavior for older saves/tests.
            for country_id,country in self.save["world"].get("countries",{}).items():
                top=[l for l in self.save["world"]["leagues"].values()
                     if l["country_id"]==country_id and l["level"]==1]
                if not top: continue
                league=top[0]
                clubs=[self.save["world"]["clubs"][cid] for cid in league["club_ids"]]
                if len(clubs)>=2:
                    cup=DomesticCup(f"{country_id}_CUP",season,clubs,self.sim.engine)
                    winner=cup.play()
                    if winner: cup_winners[league["id"]]=winner
                    self.save.setdefault("history",{}).setdefault("competition_matches",[]).extend(
                        [r.__dict__ for r in cup.results])
                    self.save.setdefault("history",{}).setdefault("cup_champions",{}).setdefault(
                        f"{country_id}_CUP",[]).append({"season":season,"club_id":winner.get("id") if isinstance(winner,dict) else (winner.id if winner else None)})
        return league_results,cup_winners

    def continental_phase(self, competition_id, size=None):
        cfg=self.save["world"].get("competitions",{}).get(competition_id)
        if not cfg:
            return None
        if size is not None: cfg["size"]=size
        all_leagues=list(self.save["world"]["leagues"].values())
        confederation=cfg.get("confederation")
        countries=self.save["world"].get("countries",{})
        leagues=[l for l in all_leagues if countries.get(l.get("country_id"),{}).get("confederation") == confederation]
        tables=self.save["history"].get("latest_tables",{})
        cups=self.save["history"].get("cup_champions",{})
        cup_winners={lid:rows[-1]["club_id"] for lid,rows in cups.items() if rows}
        entries=QualificationEngine(self.access).build_entries(cfg,leagues,tables,cup_winners)
        season=ContinentalSeason(self.save,cfg,entries,self.sim.engine)
        champion=season.run()
        self.save.setdefault("history",{}).setdefault("continental_champions",{}).setdefault(
            competition_id,[]).append({"season":self.save["world"]["current_year"],
                                        "club_id":champion["id"] if champion else None,
                                        "entry_count":len(entries),
                                        "matches":season.matches})
        return champion

    def run(self):
        leagues,cups=self.domestic_phase()
        for cid,comp in self.save["world"].get("competitions",{}).items():
            if comp.get("enabled",False) and comp.get("type")=="continental_club":
                self.continental_phase(cid)
        return leagues
