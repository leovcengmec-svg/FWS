"""V214 — World Depth: durable club ecosystem profiles."""
from __future__ import annotations
from copy import deepcopy

class V214ClubEcosystems:
    VERSION='V214'
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}); self.data=self.history.setdefault('club_depth',{})
    def build(self,season=None):
        w=self.save.setdefault('world',{}); year=int(w.get('current_year',2026) if season is None else season); memory=w.get('world_memory',{}); clubs=w.get('clubs',{}); out={}
        for cid,c in sorted(clubs.items()):
            m=memory.get(cid,{}) if isinstance(memory,dict) else {}; traj=m.get('trajectory',[]); age=len(traj); consistency=0
            if len(traj)>=2:
                vals=[float(x.get('sporting_strength',50)) for x in traj]; avg=sum(vals)/len(vals); consistency=max(0,100-(max(vals)-min(vals)))
            else: avg=float(c.get('sporting_strength',50)); consistency=50
            maturity=min(100,age*8+float(c.get('management_maturity',40))*.35); ecosystem=round(min(100,avg*.45+consistency*.25+maturity*.30),3)
            out[cid]={'club_id':cid,'name':c.get('name',cid),'season':year,'memory_seasons':age,'sporting_average':round(avg,3),'consistency_score':round(consistency,3),'maturity_score':round(maturity,3),'ecosystem_depth':ecosystem}
        self.data.update({'version':self.VERSION,'season':year,'clubs':out}); self.history.setdefault('club_depth_cycles',[]).append({'version':self.VERSION,'season':year,'clubs':len(out)})
        return deepcopy(out)
    def club(self,club_id): return deepcopy(self.data.get('clubs',{}).get(str(club_id),{}))
    def validate(self): return [] if isinstance(self.data.get('clubs',{}),dict) else ['V214 invalid clubs']
