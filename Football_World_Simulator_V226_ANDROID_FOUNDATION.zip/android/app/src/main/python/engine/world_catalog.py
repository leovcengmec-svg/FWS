"""Canonical global world catalog for the Football World Simulator.

V72 keeps the complete FIFA association universe separate from the currently
loaded simulation packs. This prevents unverified club/league data from being
silently invented while giving the UI and import pipeline a stable global
registry to work against.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path


class WorldCatalog:
    SCHEMA_VERSION = 2

    def __init__(self, catalog):
        self.catalog = copy.deepcopy(catalog)
        self.associations = self.catalog.get("associations", {})
        self.national_teams = self.catalog.get("national_teams", {})
        self.leagues = self.catalog.get("leagues", {})
        self.clubs = self.catalog.get("clubs", {})
        self.competitions = self.catalog.get("competitions", {})

    @classmethod
    def from_file(cls, path):
        return cls(json.loads(Path(path).read_text(encoding="utf-8")))

    def association(self, association_id):
        return self.associations.get(association_id)

    def national_team(self, association_id):
        return self.national_teams.get(association_id)

    def coverage(self):
        return copy.deepcopy(self.catalog.get("coverage", {}))

    def asset_manifest(self):
        return copy.deepcopy(self.catalog.get("assets", {}))

    def validate(self):
        errors = []
        if len(self.associations) != 211:
            errors.append(f"expected 211 associations, got {len(self.associations)}")
        if len(self.national_teams) != 211:
            errors.append(f"expected 211 national teams, got {len(self.national_teams)}")
        for aid, association in self.associations.items():
            if association.get("id") != aid:
                errors.append(f"association id mismatch: {aid}")
            if not association.get("confederation"):
                errors.append(f"association {aid} missing confederation")
            team = self.national_teams.get(aid)
            if not team:
                errors.append(f"association {aid} missing national team")
            else:
                if team.get("country_id") != aid:
                    errors.append(f"national team {aid} country mismatch")
                if team.get("confederation") != association.get("confederation"):
                    errors.append(f"national team {aid} confederation mismatch")
        for lid, league in self.leagues.items():
            if league.get("id") != lid:
                errors.append(f"league id mismatch: {lid}")
            if league.get("country_id") not in self.associations:
                errors.append(f"league {lid} references unknown association")
        for cid, club in self.clubs.items():
            if club.get("id") != cid:
                errors.append(f"club id mismatch: {cid}")
            if club.get("country_id") not in self.associations:
                errors.append(f"club {cid} references unknown association")
            if club.get("league_id") not in self.leagues:
                waiting = self.catalog.get("final_division_waiting_queues", {})
                queued = any(cid in q.get("club_ids", []) for q in waiting.values() if isinstance(q, dict))
                if not (club.get("league_id") is None and queued):
                    errors.append(f"club {cid} references unknown league")
        return errors

    def snapshot(self):
        return {
            "schema_version": self.SCHEMA_VERSION,
            "associations": len(self.associations),
            "national_teams": len(self.national_teams),
            "leagues": len(self.leagues),
            "clubs": len(self.clubs),
            "competitions": len(self.competitions),
            "coverage": self.coverage(),
        }
