class ContinentalAccess:
    def __init__(self, min_direct=1, max_direct=6):
        self.min_direct=min_direct; self.max_direct=max_direct

    def allocate(self, competition_size, leagues):
        leagues=sorted(leagues,key=lambda x:(-x.get("coefficient",1),x["id"]))
        if not leagues:return []
        slots={l["id"]:min(self.min_direct,competition_size) for l in leagues}
        remaining=max(0,competition_size-sum(slots.values()))
        # Weighted marginal allocation. The cap prevents one league from consuming the field.
        while remaining:
            candidates=[l for l in leagues if slots[l["id"]]<self.max_direct]
            if not candidates: break
            candidates.sort(key=lambda l:(l.get("coefficient",1)/(slots[l["id"]]+1)),reverse=True)
            slots[candidates[0]["id"]]+=1
            remaining-=1
        return [{"league_id":lid,"direct_slots":n} for lid,n in slots.items()]
