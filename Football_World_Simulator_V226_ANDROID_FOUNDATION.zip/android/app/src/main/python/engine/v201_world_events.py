"""V201 — World Alive: autonomous aggregate world events."""
from __future__ import annotations
import hashlib, pickle
from copy import deepcopy

class V201WorldEvents:
    VERSION='V201'; TYPES=('breakthrough','financial_pressure','infrastructure','reputation_shift','competition_pressure')
    def __init__(self,save,seed=201): self.save=save; self.seed=int(seed)
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def _noise(self,key):
        d=hashlib.sha256(f'{self.seed}:{key}'.encode()).digest(); return int.from_bytes(d[:8],'big')/float(2**64-1)
    @staticmethod
    def _clamp(v): return round(max(0,min(100,float(v))),3)
    def generate(self,season=None):
        w=self._world(); h=self._history(); year=int(w.get('current_year',2026) if season is None else season)
        if 'players' in w or 'player_transfers' in h: raise ValueError('V201 refuses forbidden player systems')
        snap=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        try:
            events=[]
            clubs=w.get('clubs',{})
            for cid,c in sorted(clubs.items()):
                n=self._noise(f'{cid}:{year}')
                strength=float(c.get('sporting_strength',50)); cash=float(c.get('cash',50)); prestige=float(c.get('prestige',50))
                if cash < 20 or n < .07: typ='financial_pressure'; magnitude=-min(4.0,max(0.5,(20-cash)*.12)) if cash<20 else -1.0
                elif n < .16: typ='breakthrough'; magnitude=1.5+(n*.8)
                elif n < .24: typ='infrastructure'; magnitude=1.0+(strength/100)
                elif n < .32: typ='reputation_shift'; magnitude=(strength-prestige)*.035
                else: continue
                event={'version':self.VERSION,'season':year,'event_id':f'{year}:{cid}:{len(events)}','entity_id':cid,'entity_type':'club','type':typ,'magnitude':round(magnitude,3),'severity':'major' if abs(magnitude)>=2.5 else 'minor'}
                events.append(event)
            h.setdefault('world_events',[]).extend(deepcopy(events)); w['world_alive_version']=self.VERSION; w['world_alive_status']='events_generated'; w['world_alive_last_season']=year
            return deepcopy(events)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snap)); raise
    def validate(self):
        w=self._world(); h=self._history(); e=[]
        if 'players' in w or 'player_transfers' in h: e.append('player_system_forbidden')
        for r in h.get('world_events',[]):
            if r.get('version')!=self.VERSION or r.get('entity_type')!='club': e.append('invalid_event')
            if r.get('type') not in self.TYPES: e.append('invalid_event_type')
        return sorted(set(e))
