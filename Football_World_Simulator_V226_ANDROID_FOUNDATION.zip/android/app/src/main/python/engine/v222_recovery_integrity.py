"""V222 — Save recovery, checkpointing and corruption-safe restore."""
from __future__ import annotations
import copy, hashlib, json
class V222RecoveryIntegrity:
    VERSION="V222"
    def __init__(self, save): self.save=save
    def _digest(self, obj):
        return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False,default=str).encode()).hexdigest()
    def checkpoint(self):
        payload=copy.deepcopy(self.save)
        digest=self._digest(payload)
        self.save.setdefault("runtime",{})["checkpoint"]={"version":self.VERSION,"digest":digest}
        return {"version":self.VERSION,"digest":digest,"payload":payload}
    def restore(self, checkpoint):
        if not isinstance(checkpoint,dict) or "payload" not in checkpoint or "digest" not in checkpoint:
            raise ValueError("invalid checkpoint")
        if self._digest(checkpoint["payload"]) != checkpoint["digest"]:
            raise ValueError("checkpoint digest mismatch")
        self.save.clear(); self.save.update(copy.deepcopy(checkpoint["payload"]))
        self.save.setdefault("runtime",{})["last_restore"]={"version":self.VERSION,"status":"recovered"}
        return self.save
    def validate(self):
        c=self.save.get("runtime",{}).get("checkpoint",{})
        return [] if c.get("version")==self.VERSION and c.get("digest") else ["checkpoint metadata missing"]
