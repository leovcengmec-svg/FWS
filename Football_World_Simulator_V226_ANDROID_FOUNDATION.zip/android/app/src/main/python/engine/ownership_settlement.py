class OwnershipSettlement:
    """Final settlement bridge for accepted marketplace offers.

    Negotiation decides the deal; this layer is the only V40 entry point that
    attempts to move cash/ownership. It delegates player transactions to V35
    and keeps AI-only deals pending when no seller financial ledger exists.
    """
    def __init__(self, save, marketplace, transaction):
        self.save = save
        self.marketplace = marketplace
        self.transaction = transaction
        self.history = save.setdefault('history', {}).setdefault('ownership_settlements', [])
        from engine.ownership_owner_accounts import OwnershipOwnerAccounts
        from engine.ownership_transition_effects import OwnershipTransitionEffects
        self.owner_accounts = OwnershipOwnerAccounts(save)
        self.transition_effects = OwnershipTransitionEffects(save)

    def _offer(self, offer_id):
        for offer in self.marketplace.offers:
            if offer['id'] == offer_id:
                return offer
        raise ValueError('oferta inexistente')

    def settle(self, offer_id):
        offer = self._offer(offer_id)
        if offer['status'] != 'accepted':
            raise ValueError('oferta não está aceita')
        listing = self.marketplace._listing(offer['listing_id'])
        if listing['status'] != 'sold':
            raise ValueError('anúncio não está aguardando liquidação')

        buyer = offer['buyer']
        seller = listing.get('seller')
        club_id = offer['club_id']

        # Player buyer: V35 remains the authoritative atomic purchase path.
        if buyer == 'player':
            event = self.transaction.buy_from_market(club_id, offer['price'])
            result = {'status': 'settled', 'mode': 'player_buyer', 'transaction': event}
            self.history.append({'offer_id': offer_id, **result})
            offer['status'] = 'settled'
            self.transition_effects.apply(club_id, 'player')
            return result

        # Player seller + AI buyer: use V35 sale for the player's cash side,
        # then bind the resulting club to the named AI buyer. AI capital is
        # checked before changing any state, keeping the operation atomic from
        # the caller's perspective.
        if seller == 'player':
            agents = self.save.setdefault('runtime', {}).setdefault('ownership_market_agents', {})
            if buyer not in agents:
                return self._defer(offer, 'comprador_ai_sem_perfil_financeiro')
            profile = agents[buyer]
            fee_rate = float(self.transaction.rules.get('transaction_fee_rate', 0.01))
            price = float(offer['price'])
            total = round(price * (1.0 + fee_rate), 2)
            if float(profile.get('capital', 0.0)) < total:
                return self._defer(offer, 'capital_ai_insuficiente')

            # Execute player sale only after AI affordability is confirmed.
            event = self.transaction.sell_to_market(club_id, price)
            profile['capital'] = round(float(profile.get('capital', 0.0)) - total, 2)
            club = self.save['world']['clubs'][club_id]
            club['owner_type'] = 'ai_investor'
            club['owner_id'] = buyer
            offer['status'] = 'settled'
            self.transition_effects.apply(club_id, buyer)
            result = {'status': 'settled', 'mode': 'ai_buyer_player_seller',
                      'transaction': event, 'buyer_capital_after': profile['capital']}
            self.history.append({'offer_id': offer_id, **result})
            return result

        # AI/external to AI: V41 settles only when the seller has an explicit
        # financial ledger. Never invent a balance for an owner.
        if seller not in self.owner_accounts.accounts:
            return self._defer(offer, 'liquidacao_ai_ai_requer_conta_do_vendedor')
        seller_account = self.owner_accounts.accounts[seller]
        fee_rate = float(self.transaction.rules.get('transaction_fee_rate', 0.01))
        price = float(offer['price'])
        fee = round(price * fee_rate, 2)
        seller_net = round(price - fee, 2)
        buyer_profile = self.save.setdefault('runtime', {}).setdefault('ownership_market_agents', {}).get(buyer)
        if buyer_profile is None:
            return self._defer(offer, 'comprador_ai_sem_perfil_financeiro')
        buyer_total = round(price + fee, 2)
        if float(buyer_profile.get('capital', 0.0)) < buyer_total:
            return self._defer(offer, 'capital_ai_insuficiente')

        seller_account['capital'] = round(float(seller_account.get('capital', 0.0)) + seller_net, 2)
        buyer_profile['capital'] = round(float(buyer_profile.get('capital', 0.0)) - buyer_total, 2)
        club = self.save['world']['clubs'][club_id]
        old_owner = club.get('owner_id')
        club['owner_type'] = 'ai_investor'
        club['owner_id'] = buyer
        offer['status'] = 'settled'
        self.transition_effects.apply(club_id, buyer)
        result = {'status': 'settled', 'mode': 'ai_buyer_ai_seller',
                  'club_id': club_id, 'price': round(price, 2), 'fee': fee,
                  'seller_net': seller_net, 'buyer_total': buyer_total,
                  'old_owner': old_owner, 'new_owner': buyer,
                  'buyer_capital_after': buyer_profile['capital'],
                  'seller_capital_after': seller_account['capital']}
        self.history.append({'offer_id': offer_id, **result})
        return result

    def _defer(self, offer, reason):
        result = {'status': 'deferred', 'offer_id': offer['id'], 'reason': reason}
        self.history.append(result.copy())
        return result
