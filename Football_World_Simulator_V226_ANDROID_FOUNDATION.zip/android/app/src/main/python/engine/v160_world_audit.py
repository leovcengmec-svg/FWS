"""V160 — Integrated World Architecture Audit.

Read-only audit plus runtime ownership checks for the approved V157/V158 world
competition architecture. V160 does not add a new sporting format; it closes
an integration gap found during the audit by requiring V112's full continental
registry to be materialized by V151 on every clean runtime.
"""
from __future__ import annotations
import json
from pathlib import Path
from .v112_continental_competition_framework import V112ContinentalCompetitionFramework
from .v157_club_calendar import V157ClubCalendar
from .v158_global_selection_calendar import V158GlobalSelectionCalendar
from .world_database import load_global_simulation
from .v151_global_competition_integration import V151GlobalCompetitionIntegration

ROOT = Path(__file__).resolve().parents[1]

class V160WorldAudit:
    VERSION = "V160"
    EXPECTED_CONFEDS = ("UEFA", "CONMEBOL", "AFC", "CAF", "CONCACAF", "OFC")
    EXPECTED_COUNTRIES = 211
    EXPECTED_CLUBS = 5530
    EXPECTED_LEAGUES = 353
    EXPECTED_CONTINENTAL_COMPETITIONS = 24
    EXPECTED_DIRECT_SMC = 56
    EXPECTED_PRELIMINARY_SMC = 32

    @classmethod
    def audit_catalog(cls, catalog_path=ROOT / "data" / "global_world_catalog.json"):
        data=json.loads(Path(catalog_path).read_text(encoding="utf-8"))
        errors=[]
        if len(data.get("associations",{})) != cls.EXPECTED_COUNTRIES:
            errors.append(f"catalog associations != {cls.EXPECTED_COUNTRIES}")
        if len(data.get("national_teams",{})) != cls.EXPECTED_COUNTRIES:
            errors.append(f"catalog national teams != {cls.EXPECTED_COUNTRIES}")
        if len(data.get("clubs",{})) != cls.EXPECTED_CLUBS:
            errors.append(f"catalog clubs != {cls.EXPECTED_CLUBS}")
        if len(data.get("leagues",{})) != cls.EXPECTED_LEAGUES:
            errors.append(f"catalog leagues != {cls.EXPECTED_LEAGUES}")
        if set(data.get("confederations",{})) != set(cls.EXPECTED_CONFEDS):
            errors.append("catalog confederations mismatch")
        approved=V112ContinentalCompetitionFramework.__dict__["PLANS"]
        approved_count=sum(len(rows) for rows in approved.values())
        if approved_count != cls.EXPECTED_CONTINENTAL_COMPETITIONS:
            errors.append("V112 approved continental registry is not 24")
        return {"status":"PASS" if not errors else "FAIL","errors":errors,
                "catalog_counts":{"associations":len(data.get("associations",{})),"national_teams":len(data.get("national_teams",{})),"leagues":len(data.get("leagues",{})),"clubs":len(data.get("clubs",{})),"catalog_competitions":len(data.get("competitions",{}))},
                "approved_v112_competitions":approved_count}

    @classmethod
    def audit_rules(cls):
        errors=[]
        if len(V112ContinentalCompetitionFramework.PLANS) != 6: errors.append("V112 confederation count mismatch")
        if sum(len(x) for x in V112ContinentalCompetitionFramework.PLANS.values()) != 24: errors.append("V112 competition count mismatch")
        if V157ClubCalendar.DIRECT_ENTRIES != 56 or V157ClubCalendar.PRELIMINARY_ENTRIES != 32: errors.append("SMC access counts mismatch")
        if V157ClubCalendar.CONTINENTAL_CYCLE_PLACES != 48 or V157ClubCalendar.INTERCONTINENTAL_CYCLE_PLACES != 4 or V157ClubCalendar.COEFFICIENT_DIRECT_PLACES != 4: errors.append("SMC 56-place composition mismatch")
        if len(V158GlobalSelectionCalendar.WORLD_CUP_YEARS) != 4: errors.append("World Cup year set mismatch")
        if sum(V158GlobalSelectionCalendar.WC_SLOTS.values()) != 46: errors.append("Confederation World Cup direct slots must total 46")
        if V158GlobalSelectionCalendar.FRIENDLIES_PER_TEAM != 8: errors.append("friendly count mismatch")
        return {"status":"PASS" if not errors else "FAIL","errors":errors,
                "smc":{"direct":56,"preliminary":32,"continental_cycle_places":48,"intercontinental_cycle_places":4,"coefficient_places":4},
                "world_cup_confederation_slots":dict(V158GlobalSelectionCalendar.WC_SLOTS),
                "world_cup_total_with_intercontinental":sum(V158GlobalSelectionCalendar.WC_SLOTS.values())+2}

    @classmethod
    def audit_runtime_source(cls):
        p=(ROOT/"engine"/"v151_global_competition_integration.py").read_text(encoding="utf-8")
        errors=[]
        if "approved_present" in p: errors.append("V151 still gates V112 materialization on stale world competitions")
        if "for cid, base in approved.items()" not in p: errors.append("V151 does not materialize complete V112 registry")
        ws=(ROOT/"engine"/"world_simulator.py").read_text(encoding="utf-8")
        if "V127WorldCup64" in ws: errors.append("WorldSimulator still routes directly to V127")
        save=load_global_simulation(ROOT/"data"/"global_world_catalog.json")
        configs=V151GlobalCompetitionIntegration(save)._configs()
        if len(configs) != cls.EXPECTED_CONTINENTAL_COMPETITIONS:
            errors.append(f"clean global runtime materialized {len(configs)} continental competitions, expected {cls.EXPECTED_CONTINENTAL_COMPETITIONS}")
        if len(save.get("world",{}).get("competitions",{})) != cls.EXPECTED_CONTINENTAL_COMPETITIONS:
            errors.append("clean global world competition registry did not close at 24")
        bad=[cid for cid,cfg in save.get("continental",{}).get("competitions",{}).items() if cfg.get("size") is None]
        if bad: errors.append(f"invalid runtime competition records with null size: {bad}")
        return {"status":"PASS" if not errors else "FAIL","errors":errors,
                "selection_runtime_owner":"V158GlobalSelectionCalendar","club_calendar_owner":"V157ClubCalendar","season_orchestrator":"V152GlobalWorldSeasonEngine",
                "clean_global_runtime_continental_competitions":len(configs),
                "clean_global_runtime_world_competitions":len(save.get("world",{}).get("competitions",{}))}

    @classmethod
    def run(cls):
        parts={"catalog":cls.audit_catalog(),"rules":cls.audit_rules(),"runtime":cls.audit_runtime_source()}
        errors=[]
        for part in parts.values(): errors.extend(part.get("errors",[]))
        return {"version":cls.VERSION,"status":"PASS" if not errors else "FAIL","errors":errors,"parts":parts,
                "preserved":{"no_player_system":True,"v157_club_rules":True,"v158_selection_rules":True}}
