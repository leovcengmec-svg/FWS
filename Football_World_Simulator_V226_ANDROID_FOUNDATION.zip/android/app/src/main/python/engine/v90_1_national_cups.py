from __future__ import annotations
import json
from pathlib import Path
from .national_cup_engine import NationalCupEngine
from .season_pipeline import SeasonPipeline

class V90_1NationalCups:
    VERSION='V90.1'
    def __init__(self, registry):
        self.registry=registry
    @classmethod
    def from_file(cls,path):
        return cls(json.loads(Path(path).read_text(encoding='utf-8')))
    def attach(self, save):
        save.setdefault('world',{})['national_cup_registry']=self.registry
        return save
    def run_domestic_phase(self, save, simulator):
        self.attach(save)
        return SeasonPipeline(save,simulator,self.registry).domestic_phase()
    def validate(self, association_ids):
        from .national_cup_engine import NationalCupEngine
        # Lightweight schema validation without requiring a simulator.
        errors=[]
        countries=self.registry.get('countries',{})
        for cid in association_ids:
            row=countries.get(cid)
            if not row: errors.append(f'missing cup package {cid}'); continue
            ids=[c.get('id') for c in row.get('cups',[])]
            if not ids: errors.append(f'no cups {cid}')
            if len(ids)!=len(set(ids)): errors.append(f'duplicate cup ids {cid}')
        return errors
