"""Domestic promotion/relegation engine with the V142 size-aware standardized pyramid."""
from __future__ import annotations

from .v142_domestic_pyramid_rules import (
    DIRECT_PROMOTION_PLACES, EXTRA_POOL_SIZE, RELEGATION_PLACES,
    PLAYOFF_MIN_CLUBS, is_brazil_league, run_promotion_playoff,
)


class PromotionRelegation:
    """Apply four-up/four-down to non-Brazil pyramids.

    The V140 rule is intentionally evaluated from end-of-season snapshots so a
    club promoted from level N+1 cannot be promoted again from level N+2 in the
    same seasonal transition. Brazil remains outside this generic rule.
    """

    def __init__(self, places=RELEGATION_PLACES):
        self.places = max(1, int(places))

    @staticmethod
    def _tables(save, league):
        ids = set(league.get("club_ids", []))
        return [r for r in save.get("history", {}).get("latest_tables", {}).get(league["id"], [])
                if r.get("club_id") in ids]

    def _apply_brazil_legacy(self, save, country_id):
        # Do not reinterpret the Brazilian special pyramid here. Existing
        # Brazil-specific engines/data remain authoritative for that country.
        return []

    def _apply_final_division_access(self, save, league, snapshot, country_id):
        """Replace the final division's four relegated clubs with four external clubs.

        The four external IDs must already exist in the save, must be real/verified,
        and must not belong to any active domestic league. If the pool is not ready,
        the transition remains pending instead of inventing clubs.
        """
        if len(snapshot) < RELEGATION_PLACES:
            return {"status": "pending_insufficient_final_field", "relegated": [], "promoted": []}
        queues = save.get("world", {}).get("final_division_waiting_queues", {})
        q = queues.get(country_id, {}) if isinstance(queues, dict) else {}
        queue_pool = list(q.get("club_ids", [])) if isinstance(q, dict) else []
        # V149 makes the persistent world queue authoritative. For legacy saves
        # that predate the world-level queue, retain the V141/V142 league field.
        pool = (queue_pool or list(league.get("extra_club_ids", [])))[:EXTRA_POOL_SIZE]
        if len(pool) != EXTRA_POOL_SIZE or len(set(pool)) != EXTRA_POOL_SIZE:
            return {"status": "external_access_pending_verified_real_clubs", "relegated": [], "promoted": [], "queue_before": pool}
        clubs = save["world"].get("clubs", {})
        active_league_ids = {l["id"] for l in save["world"].get("leagues", {}).values()}
        for cid in pool:
            club = clubs.get(cid)
            if not club or club.get("league_id") in active_league_ids:
                return {"status": "external_access_invalid_active_club", "relegated": [], "promoted": []}
            if club.get("data_status") not in {"verified_import", "verified_real", "verified"}:
                return {"status": "external_access_unverified_club", "relegated": [], "promoted": []}
        relegated = [r["club_id"] for r in snapshot[-RELEGATION_PLACES:]]
        return {"status": "ready", "relegated": relegated, "promoted": pool, "queue_before": list(pool), "queue_after": list(q.get("club_ids", []))[EXTRA_POOL_SIZE:]}

    def apply_country(self, save, country_id, seed=140):
        leagues = sorted(
            [l for l in save["world"]["leagues"].values() if l.get("country_id") == country_id],
            key=lambda l: l.get("level", 999),
        )
        if not leagues:
            return []
        if any(is_brazil_league(l) for l in leagues):
            return self._apply_brazil_legacy(save, country_id)

        # Snapshot all standings first. This prevents cascading movement across
        # two levels in one season.
        snapshots = {l["id"]: self._tables(save, l) for l in leagues}
        changes = []
        planned_moves = set()
        playoff_reports = []

        for upper, lower in zip(leagues, leagues[1:]):
            up = snapshots[upper["id"]]
            lo = snapshots[lower["id"]]
            if len(up) < RELEGATION_PLACES:
                changes.append({"from": upper["id"], "to": lower["id"], "status": "pending_insufficient_upper_field"})
                continue
            relegated = [r["club_id"] for r in up[-RELEGATION_PLACES:]]
            if len(lo) < PLAYOFF_MIN_CLUBS:
                # Small divisions use four direct promotion places and no playoff.
                direct = [r["club_id"] for r in lo[:4]]
                if len(direct) != 4:
                    changes.append({"from": upper["id"], "to": lower["id"],
                                    "status": "pending_insufficient_lower_field",
                                    "relegated": [], "promoted": []})
                    continue
                promoted = direct
                planned = set(relegated) | set(promoted)
                if planned_moves.intersection(planned):
                    changes.append({"from": upper["id"], "to": lower["id"], "status": "movement_conflict_deferred"})
                    continue
                planned_moves.update(planned)
                changes.append({"from": upper["id"], "to": lower["id"],
                                "status": "ready", "relegated": relegated,
                                "promoted": promoted, "direct_promotions": direct,
                                "playoff_promotion": None,
                                "promotion_rule": "4_direct_no_playoff"})
                continue

            direct = [r["club_id"] for r in lo[:DIRECT_PROMOTION_PLACES]]
            playoff = run_promotion_playoff(save, lower, lo, seed=seed)
            playoff_reports.append({"league_id": lower["id"], **{k:v for k,v in playoff.items() if k != "matches"}})
            playoff_matches = playoff.get("matches", [])
            if playoff_matches:
                save.setdefault("history", {}).setdefault("domestic_playoff_matches", []).extend(playoff_matches)
            winner = playoff.get("winner")
            if playoff.get("status") != "completed" or not winner:
                changes.append({"from": upper["id"], "to": lower["id"],
                                "status": "promotion_playoff_pending",
                                "relegated": [], "promoted": []})
                continue

            promoted = direct + [winner]
            if len(set(promoted)) != 4:
                changes.append({"from": upper["id"], "to": lower["id"], "status": "invalid_promotion_field"})
                continue

            # No club may move twice in this transition. If a lower-level
            # promoted club is already planned for the division above, defer
            # that pair rather than creating a two-level jump.
            selected = set(relegated) | set(promoted)
            if planned_moves.intersection(selected):
                changes.append({"from": upper["id"], "to": lower["id"], "status": "movement_conflict_deferred"})
                continue
            planned_moves.update(selected)
            changes.append({"from": upper["id"], "to": lower["id"],
                            "status": "ready", "relegated": relegated,
                            "promoted": promoted, "direct_promotions": direct,
                            "playoff_promotion": winner})

        # Apply only fully resolved adjacent swaps.
        for row in changes:
            if row.get("status") != "ready":
                continue
            upper = save["world"]["leagues"][row["from"]]
            lower = save["world"]["leagues"][row["to"]]
            for cid in row["relegated"]:
                if cid in upper.get("club_ids", []):
                    upper["club_ids"].remove(cid)
                if cid not in lower.setdefault("club_ids", []):
                    lower["club_ids"].append(cid)
                save["world"]["clubs"][cid]["league_id"] = lower["id"]
                save["world"]["clubs"][cid]["division"] = lower.get("level")
            for cid in row["promoted"]:
                if cid in lower.get("club_ids", []):
                    lower["club_ids"].remove(cid)
                if cid not in upper.setdefault("club_ids", []):
                    upper["club_ids"].append(cid)
                save["world"]["clubs"][cid]["league_id"] = upper["id"]
                save["world"]["clubs"][cid]["division"] = upper.get("level")

        # Final division: four clubs leave the modeled pyramid and four verified
        # external clubs replace them. This also handles countries with only one league.
        final_league = leagues[-1]
        final_snapshot = snapshots[final_league["id"]]
        final_report = self._apply_final_division_access(save, final_league, final_snapshot, country_id)
        if final_report.get("status") == "ready":
            for cid in final_report["relegated"]:
                if cid in final_league.get("club_ids", []):
                    final_league["club_ids"].remove(cid)
                save["world"]["clubs"][cid]["league_id"] = None
                save["world"]["clubs"][cid]["division"] = None
                save["world"]["clubs"][cid]["domestic_status"] = "relegated_from_final_division"
            for cid in final_report["promoted"]:
                final_league.setdefault("club_ids", []).append(cid)
                save["world"]["clubs"][cid]["league_id"] = final_league["id"]
                save["world"]["clubs"][cid]["division"] = final_league.get("level")
                save["world"]["clubs"][cid]["domestic_status"] = "external_access_promoted"
                save["world"]["clubs"][cid]["active"] = True
            # Consume the first four FIFO entries permanently. Remaining entries
            # stay in order; later verified clubs may be appended by the queue API.
            queues = save.setdefault("world", {}).setdefault("final_division_waiting_queues", {})
            q = queues.setdefault(country_id, {"club_ids": list(final_league.get("extra_club_ids", []))})
            # If the queue was initialized from the legacy league field, consume
            # the same four IDs exactly once; otherwise consume the persistent FIFO.
            remaining = list(q.get("club_ids", []))[EXTRA_POOL_SIZE:] if q.get("club_ids") else []
            q["club_ids"] = remaining
            q["external_slots_needed"] = max(0, EXTRA_POOL_SIZE-len(remaining))
            q["status"] = "ready" if remaining else "awaiting_new_verified_real_clubs"
            final_league["extra_club_ids"] = remaining
            final_league["extra_pool_size"] = len(remaining)
        changes.append({"from": None, "to": final_league["id"], "status": final_report["status"],
                        "relegated": final_report.get("relegated", []),
                        "promoted": final_report.get("promoted", []),
                        "external_access": True})

        save.setdefault("history", {}).setdefault("promotion_relegation_rules", []).append({
            "season": save["world"].get("current_year"),
            "country_id": country_id,
            "rule_version": "V142_SIZE_AWARE_DOMESTIC_PYRAMID",
            "relegation_places": RELEGATION_PLACES,
            "direct_promotion_places": DIRECT_PROMOTION_PLACES,
            "playoff_positions": [4,5,6,7],
            "promotion_playoff_minimum_clubs": PLAYOFF_MIN_CLUBS,
            "under_threshold_promotion_rule": "4_direct_no_playoff",
            "extra_pool_size": EXTRA_POOL_SIZE,
            "extra_pool_scope": "last_division_only",
            "final_division_external_access": final_report,
            "playoffs": playoff_reports,
            "changes": changes,
        })
        return [x for x in changes if x.get("status") == "ready"]
