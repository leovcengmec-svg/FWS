class OwnershipMarket:
    """Club ownership transfer market. Ownership changes do not create free money."""
    def __init__(self, save):
        self.save=save
        self.history=save.setdefault('history',{}).setdefault('ownership_market',[])

    def offer(self, club_id, buyer_type='external', premium=0.0):
        club=self.save['world']['clubs'][club_id]
        base=float(club.get('market_value',0.1) or 0.1)
        price=round(max(0.1,base*(1.0+max(-0.5,min(1.0,float(premium))))),2)
        return {'club_id':club_id,'buyer_type':buyer_type,'asking_price':price,'owner_type':club.get('owner_type','ai'),'season':self.save['world']['current_year']}

    def transfer_external(self, club_id, buyer_id, price):
        club=self.save['world']['clubs'][club_id]
        if price<=0: raise ValueError('preço inválido')
        old_owner=club.get('owner_id')
        club['owner_type']='external_investor'; club['owner_id']=buyer_id
        self.history.append({'season':self.save['world']['current_year'],'club_id':club_id,'type':'external_transfer','price':round(price,2),'old_owner':old_owner,'new_owner':buyer_id})
        return club
