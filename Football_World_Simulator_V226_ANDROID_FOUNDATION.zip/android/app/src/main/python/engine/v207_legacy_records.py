"""V207 — Aggregate club/selection/federation legacy and durable records."""
from __future__ import annotations
from copy import deepcopy

class V207LegacyRecords:
    VERSION='V207'
    def __init__(self, save):
        self.save=save; self.history=save.setdefault('history',{})
        self.records=self.history.setdefault('legacy_records',{})

    def rebuild(self):
        world=self.save.setdefault('world',{}); clubs=world.get('clubs',{}); teams=world.get('national_teams',{})
        out={'clubs':{},'selections':{},'associations':{}}
        # Prefer the consolidated V132 ledger when available.
        cl=self.history.get('world_legacy',{}).get('club_legacy',{})
        for cid,c in clubs.items():
            base=deepcopy(cl.get(cid,{})); seasons=base.get('seasons',[])
            league_titles=sum(1 for row in self.history.get('world_seasons',[]) if cid in (row.get('league_champions',{}) or {}).values())
            continental_titles=sum(1 for row in self.history.get('world_seasons',[]) if cid in (row.get('continental_champions',{}) or {}).values())
            base['titles']=max(int(base.get('titles',0)), league_titles)
            base['continental_titles']=max(int(base.get('continental_titles',0)), continental_titles)
            out['clubs'][cid]={
                'entity_id':cid,'name':c.get('name',cid),'seasons':len(seasons),
                'titles':int(base.get('titles',0)),'continental_titles':int(base.get('continental_titles',0)),
                'promotions':int(base.get('promotions',0)),'relegations':int(base.get('relegations',0)),
                'current_prestige':round(float(c.get('prestige',50)),3),
                'current_strength':round(float(c.get('sporting_strength',50)),3),
            }
        # Selection career is manager history, while selection legacy remains aggregate by team.
        for tid,t in teams.items():
            rows=[r for r in self.history.get('selection_performance',[]) if r.get('team_id')==tid]
            out['selections'][tid]={'entity_id':tid,'name':t.get('name',tid),'cycles':len(rows),'average_quality':round(sum(float(r.get('average_quality',0)) for r in rows)/len(rows),3) if rows else 0.0}
        assoc=self.history.get('world_legacy',{}).get('association_legacy',{})
        for aid,data in assoc.items():
            out['associations'][aid]=deepcopy(data)
        self.records=out; self.history['legacy_records']=deepcopy(out); self.history['legacy_records_version']=self.VERSION
        return deepcopy(out)

    def club(self,club_id): return deepcopy(self.records.get('clubs',{}).get(str(club_id),{}))
    def selection(self,team_id): return deepcopy(self.records.get('selections',{}).get(str(team_id),{}))
    def validate(self):
        errors=[]
        for group in ('clubs','selections','associations'):
            if not isinstance(self.records.get(group,{}),dict): errors.append(f'V207 invalid {group}')
        return errors
