"""Strategic review and corrective-action layer.

Turns governance signals into explicit, auditable executive actions. Actions are
advisory/administrative: they do not create cash and never alter match odds.
"""
class StrategicReviewEngine:
    ACTIONS = ("monitor", "reinforce", "correct", "rebaseline")

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_reviews", [])

    @staticmethod
    def _clamp(v, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(v))), 4)

    def review(self, club_id, governance=None, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        season = self.save.get("world", {}).get("current_year") if season is None else int(season)
        governance = governance or clubs[club_id].get("strategic_governance", {})
        if governance.get("status") == "no_plan" or not governance.get("milestone"):
            row = {"club_id": club_id, "season": season, "status": "no_plan", "action": "monitor", "priority": "none"}
        else:
            risk = float(governance.get("risk_score", 50.0))
            gap = float(governance.get("execution_gap", 0.0))
            if risk >= 70 or gap <= -20:
                action, priority = "correct", "high"
            elif risk >= 45 or gap < 0:
                action, priority = "reinforce", "medium"
            else:
                action, priority = "monitor", "low"
            row = {
                "club_id": club_id, "season": season,
                "milestone": governance.get("milestone"),
                "risk_score": self._clamp(risk), "execution_gap": round(gap, 4),
                "action": action, "priority": priority,
                "status": "open",
            }
        club = clubs[club_id]
        club.setdefault("strategic_review_actions", []).append(row)
        self.history.append(row)
        return row

    def rebaseline(self, club_id, new_target_quality, reason="executive_review", season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        plan = club.get("strategic_plan")
        if not plan or plan.get("status") != "active":
            raise ValueError("o clube precisa ter um plano estratégico ativo")
        season = self.save.get("world", {}).get("current_year") if season is None else int(season)
        old = float(plan.get("target_quality", 70.0))
        new = self._clamp(new_target_quality)
        if new == old:
            raise ValueError("nova meta deve ser diferente da meta atual")
        plan["target_quality"] = new
        plan.setdefault("rebaselines", []).append({"season": season, "old_target_quality": old, "new_target_quality": new, "reason": str(reason)})
        row = {"club_id": club_id, "season": season, "action": "rebaseline", "old_target_quality": old, "new_target_quality": new, "reason": str(reason), "status": "executed"}
        club.setdefault("strategic_review_actions", []).append(row)
        self.history.append(row)
        return row

    def execute_action(self, club_id, action_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        actions = clubs[club_id].get("strategic_review_actions", [])
        if not 0 <= int(action_id) < len(actions):
            raise ValueError("ação estratégica inexistente")
        action = actions[int(action_id)]
        if action.get("status") == "executed":
            raise ValueError("ação já executada")
        season = self.save.get("world", {}).get("current_year") if season is None else int(season)
        action["status"] = "executed"
        action["executed_season"] = season
        return action

    def snapshot(self, club_id):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        actions = clubs[club_id].get("strategic_review_actions", [])
        open_actions = [a for a in actions if a.get("status") == "open"]
        return {"club_id": club_id, "open_actions": len(open_actions), "total_actions": len(actions),
                "high_priority": sum(a.get("priority") == "high" for a in open_actions),
                "latest": actions[-1] if actions else None}
