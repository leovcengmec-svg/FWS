import json
from pathlib import Path
from .world_dynamics import WorldDynamics

class V89WorldDynamics:
    VERSION = "V89"
    def __init__(self, catalog):
        self.catalog = catalog
    @classmethod
    def from_file(cls, path):
        return cls(json.loads(Path(path).read_text(encoding="utf-8")))
    def initialize(self, season=2026, seed=89):
        return WorldDynamics(self.catalog, seed=seed).initialize_season(season)
    def validate(self, state):
        errors=[]
        if state.get("engine") != "V89_WorldDynamics": errors.append("wrong engine")
        if state.get("season") is None: errors.append("missing season")
        if state.get("leagues") != len(self.catalog.get("leagues",{})): errors.append("league count mismatch")
        if state.get("clubs") != len(self.catalog.get("clubs",{})): errors.append("club count mismatch")
        for lid,row in state.get("leagues_state",{}).items():
            if lid not in self.catalog.get("leagues",{}): errors.append(f"unknown league {lid}")
            if len(row.get("club_ids",[])) != len(set(row.get("club_ids",[]))): errors.append(f"duplicate clubs {lid}")
            for cid in row.get("club_ids",[]):
                if cid not in self.catalog.get("clubs",{}): errors.append(f"unknown club {cid}")
        return errors
    def summary(self, state):
        completed=sum(r.get("status")=="completed" for r in state.get("leagues_state",{}).values())
        scheduled=sum(r.get("status")=="scheduled" for r in state.get("leagues_state",{}).values())
        return {"version":self.VERSION,"season":state.get("season"),"countries":state.get("countries"),
                "leagues":state.get("leagues"),"clubs":state.get("clubs"),
                "scheduled_leagues":scheduled,"completed_leagues":completed,
                "promotion_relegation_pairs":len(state.get("promotions_relegations",[]))}
