"""V204 — World Alive: aggregate narrative/news ledger."""
from __future__ import annotations
from copy import deepcopy
class V204WorldNarrative:
    VERSION='V204'
    def __init__(self,save): self.save=save
    def build(self,season=None):
        w=self.save.setdefault('world',{}); h=self.save.setdefault('history',{}); year=int(w.get('current_year',2026) if season is None else season)
        events=[e for e in h.get('world_events',[]) if int(e.get('season',-1))==year]
        reactions=[r for r in h.get('world_reactions',[]) if int(r.get('season',-1))==year]
        news=[]
        for e in events:
            verb={'breakthrough':'registrou um avanço','financial_pressure':'entrou em pressão financeira','infrastructure':'avançou estruturalmente','reputation_shift':'teve mudança de reputação','competition_pressure':'sofreu pressão competitiva'}.get(e['type'],'teve um acontecimento')
            news.append({'season':year,'priority':'high' if e.get('severity')=='major' else 'normal','entity_id':e['entity_id'],'headline':f"{e['entity_id']} {verb}",'event_id':e['event_id']})
        row={'version':self.VERSION,'season':year,'news':news,'events':len(events),'reactions':len(reactions)}
        h.setdefault('world_narratives',[]).append(deepcopy(row)); w['world_narrative_version']=self.VERSION; return deepcopy(row)
    def validate(self): return []
