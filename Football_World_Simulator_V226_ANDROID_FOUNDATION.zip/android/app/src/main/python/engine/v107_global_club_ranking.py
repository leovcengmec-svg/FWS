"""V107 — Global Club Ranking & World Competition Seeding.

Builds a deterministic, simulation-only world club ranking from the club's
recent continental/global outcomes and uses it to seed the Super World groups.
It does not alter the verified real-world catalog or introduce players.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .v106_global_club_world_consequences import V106GlobalClubWorldConsequences


class V107GlobalClubRanking(V106GlobalClubWorldConsequences):
    VERSION = "V107"

    def build_global_club_ranking(self, season=None, limit=None):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        year = int(season if season is not None else world.get("current_year", 2026))
        clubs = catalog.get("clubs", {})
        scores = {}
        # Base sporting/reputation signal, bounded and simulation-only.
        for cid, club in clubs.items():
            base = float(club.get("reputation", club.get("prestige", 50.0)))
            strength = float(club.get("sporting_strength", club.get("strength", club.get("prestige", 50.0))))
            scores[cid] = 0.55 * base + 0.45 * strength

        # Recent continental champions and global-club outcomes add bounded points.
        hist = self.save.get("history", {})
        for conf, rows in hist.get("continental_champions", {}).items():
            for row in rows[-4:]:
                cid = row.get("club_id")
                if cid in scores:
                    age = max(0, year - int(row.get("season", year)))
                    scores[cid] += max(2.0, 12.0 - age * 2.0)
        for row in hist.get("super_world", [])[-2:]:
            champion = row.get("champion")
            if champion in scores:
                scores[champion] += 25.0
        for row in hist.get("global_club_world_consequences", [])[-4:]:
            for cid, impact in row.get("impacts", {}).items():
                if cid not in scores:
                    continue
                scores[cid] += float(impact.get("reputation_delta", 0.0)) * 1.25
                stage = impact.get("stage")
                scores[cid] += {"champion": 8.0, "runner_up": 5.0, "semi_final": 3.0,
                                 "quarter_final": 1.5, "round_of_32": .5, "group_stage": 0.0,
                                 "preliminary": -.5}.get(stage, 0.0)

        rows = []
        for cid, score in scores.items():
            digest = hashlib.sha256(f"V107:{year}:{cid}".encode()).hexdigest()
            rows.append({"club_id": cid, "score": round(max(0.0, score), 3), "tie_key": digest})
        rows.sort(key=lambda r: (-r["score"], r["tie_key"], r["club_id"]))
        for idx, row in enumerate(rows, 1):
            row["rank"] = idx
        if limit is not None:
            rows = rows[:int(limit)]
        ranking = {"version": self.VERSION, "season": year, "clubs": rows,
                   "club_count": len(rows), "status": "completed"}
        world["global_club_ranking"] = deepcopy(ranking)
        world.setdefault("global_club_ranking_history", []).append(deepcopy(ranking))
        return deepcopy(ranking)

    @staticmethod
    def _seed_four_pots(clubs, ranking):
        rank_map = {r["club_id"]: r["rank"] for r in ranking.get("clubs", [])}
        ordered = sorted(clubs, key=lambda c: (rank_map.get(c["id"], 10**9), c["id"]))
        if len(ordered) != 64:
            raise ValueError("Super World seeding requires exactly 64 clubs")
        pots = [ordered[i:i+16] for i in range(0, 64, 16)]
        return pots

    def run_super_world(self, season=None, cycle_years=4, seed=107):
        execution = super().run_super_world(season, cycle_years, seed)
        if not execution:
            return None
        ranking = self.build_global_club_ranking(season=execution["season"])
        group_field = [c for g in execution.get("groups", []) for c in g.get("clubs", [])]
        pots = self._seed_four_pots(group_field, ranking)
        # Rebuild groups from four ranking pots. Each group receives one club
        # from each pot; assignment is deterministic and keeps the same match engine.
        groups = [{"group": i + 1, "clubs": [], "qualified": []} for i in range(16)]
        for pot_no, pot in enumerate(pots):
            for i, club in enumerate(pot):
                groups[i]["clubs"].append(club)
        # Re-simulate group matches and qualification using the existing helper.
        group_matches = []
        for g in groups:
            rebuilt, matches = self._groups(g["clubs"], 1, 4, self.SUPER_WORLD_ID,
                                            execution["season"], seed + 300 + g["group"])
            g["qualified"] = rebuilt[0]["qualified"]
            g["table"] = rebuilt[0].get("table", [])
            g["matches"] = rebuilt[0].get("matches", [])
            group_matches.extend(matches)
        knockout_field = [c for g in groups for c in g["qualified"]]
        champion, knockout_matches = self._knockout(knockout_field, self.SUPER_WORLD_ID,
                                                     execution["season"], seed + 500)
        execution = deepcopy(execution)
        execution["version"] = self.VERSION
        execution["seeding"] = {"model": "4_ranking_pots", "pots": [[c["id"] for c in p] for p in pots]}
        execution["groups"] = groups
        execution["group_matches"] = group_matches
        execution["knockout_entries"] = len(knockout_field)
        execution["knockout_matches"] = knockout_matches
        execution["champion"] = champion["id"] if champion else None
        world = self.save.setdefault("world", {})
        world["super_world_execution"] = deepcopy(execution)
        world.setdefault("super_world_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("super_world", []).append(deepcopy(execution))
        return deepcopy(execution)

    def validate(self):
        errors = super().validate()
        ranking = self.save.get("world", {}).get("global_club_ranking")
        if ranking:
            if ranking.get("version") != self.VERSION:
                errors.append("wrong global club ranking version")
            rows = ranking.get("clubs", [])
            if len({r.get("club_id") for r in rows}) != len(rows):
                errors.append("global club ranking contains duplicate clubs")
            ranks = [r.get("rank") for r in rows]
            if ranks != list(range(1, len(rows) + 1)):
                errors.append("global club ranking ranks are not contiguous")
        execution = self.save.get("world", {}).get("super_world_execution")
        if execution and execution.get("version") == self.VERSION:
            pots = execution.get("seeding", {}).get("pots", [])
            if len(pots) != 4 or any(len(p) != 16 for p in pots):
                errors.append("Super World must have four seeding pots of 16")
            ids = [cid for p in pots for cid in p]
            if len(ids) != len(set(ids)):
                errors.append("Super World seeding contains duplicate clubs")
            groups = execution.get("groups", [])
            if len(groups) == 16 and any(len(g.get("clubs", [])) != 4 for g in groups):
                errors.append("seeded Super World groups must contain 4 clubs")
        return errors
