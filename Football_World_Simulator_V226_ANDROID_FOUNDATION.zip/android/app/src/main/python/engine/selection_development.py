class SelectionDevelopment:
    CATEGORIES={"training":"training_facility","technical":"technical_department","youth":"youth_development","scouting":"scouting_network","management":"federation_management"}
    def __init__(self,save,rng): self.save,self.rng=save,rng; self.history=save.setdefault('history',{}).setdefault('selection_development',[])
    def ensure_profile(self,team):
        infra=team.setdefault('infrastructure',{})
        for k in self.CATEGORIES.values(): infra.setdefault(k,40.0)
        team.setdefault('development_budget',8.0); team.setdefault('strength',50.0); team.setdefault('base_strength',team.get('strength',50.0)); return team
    def infrastructure_score(self,team):
        self.ensure_profile(team); v=list(team['infrastructure'].values()); return sum(v)/len(v)
    def effective_strength(self,team):
        self.ensure_profile(team); i=self.infrastructure_score(team); t=team['infrastructure']['technical_department']; y=team['infrastructure']['youth_development']; f=team.get('form',0.0)
        return max(1,min(99,team['base_strength']*.62+i*.22+t*.10+y*.06+f))
    def cycle(self,team_id,result_quality=None,opponent_strength=None):
        team=self.save['world']['national_teams'][team_id]; self.ensure_profile(team); before=self.infrastructure_score(team)
        perf=0 if result_quality is None or opponent_strength is None else (result_quality-opponent_strength)*.025
        drift=self.rng.uniform(-1.25,1.25)+perf+(team.get('development_budget',8)-8)*.04
        for k in team['infrastructure']: team['infrastructure'][k]=max(1,min(100,team['infrastructure'][k]+drift+self.rng.uniform(-.55,.55)))
        after=self.infrastructure_score(team); team['strength']=self.effective_strength(team); team['development_budget']=max(1,team.get('development_budget',8)+self.rng.uniform(-.8,1))
        e={'team_id':team_id,'before_infrastructure':round(before,2),'after_infrastructure':round(after,2),'strength':round(team['strength'],2),'delta':round(after-before,2),'performance_factor':round(perf,3)}; self.history.append(e); return e
    def invest(self,team_id,amount,category='training',investor_id=None):
        if amount<=0: raise ValueError('valor do investimento deve ser positivo')
        team=self.save['world']['national_teams'][team_id]; self.ensure_profile(team)
        if category not in self.CATEGORIES: raise ValueError(f'categoria inválida: {category}')
        k=self.CATEGORIES[category]; level=team['infrastructure'][k]; gain=(amount**.5)*2.2*max(.15,1-level/125)*self.rng.uniform(.8,1.2)
        team['infrastructure'][k]=max(1,min(100,level+gain)); team['development_budget']=min(100,team.get('development_budget',8)+amount*.10); team['strength']=self.effective_strength(team)
        r={'team_id':team_id,'category':category,'amount':round(amount,2),'gain':round(gain,2),'new_level':round(team['infrastructure'][k],2),'new_strength':round(team['strength'],2),'investor_id':investor_id}; self.history.append({'type':'external_investment',**r}); return r
