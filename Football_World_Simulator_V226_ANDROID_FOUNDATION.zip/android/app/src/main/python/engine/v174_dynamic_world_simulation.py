"""V174 — Dynamic World Simulation.

Consumes V173 intelligence intents and applies bounded, deterministic world-state
changes at club/association level. No player or transfer layer is introduced.
"""
from __future__ import annotations
import hashlib
import pickle
from copy import deepcopy

class V174DynamicWorldSimulation:
    VERSION = "V174"
    SCHEMA = 1
    DELTA_LIMIT = 2.5

    def __init__(self, save, seed=174):
        self.save = save
        self.seed = int(seed)

    def _world(self): return self.save.setdefault("world", {})
    def _history(self): return self.save.setdefault("history", {})

    def _noise(self, key):
        d = hashlib.sha256(f"{self.seed}:{key}".encode()).digest()
        return int.from_bytes(d[:8], "big") / float(2**64 - 1)

    @staticmethod
    def _clamp(v): return round(max(0.0, min(100.0, float(v))), 3)

    def _delta(self, intent, n):
        table = {
            "compete": (1.10, 0.20, -0.35, 0.20),
            "develop": (0.65, 0.55, -0.10, 0.10),
            "consolidate": (-0.20, 0.15, 0.55, 0.00),
            "rebuild": (0.20, 0.75, 0.35, -0.10),
            "expand": (0.85, 0.30, -0.20, 0.75),
        }
        sporting, development, stability, reach = table.get(intent, (0, 0, 0, 0))
        jitter = (n - .5) * .35
        return {"sporting_strength": sporting + jitter, "development": development,
                "management_stability": stability, "reach": reach}

    def run(self, season=None):
        world = self._world(); history = self._history()
        year = int(world.get("current_year", 2026) if season is None else season)
        cycles = history.get("world_intelligence_cycles", [])
        cycle = next((r for r in reversed(cycles) if int(r.get("season", -1)) == year), None)
        if cycle is None:
            from .v173_world_intelligence_core import V173WorldIntelligenceCore
            cycle = V173WorldIntelligenceCore(self.save, self.seed + 173).run(year)
        if "players" in world or "player_transfers" in history:
            raise ValueError("V174 refuses forbidden player systems")
        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            applied = {}
            for cid, decision in sorted(cycle.get("clubs", {}).items()):
                club = world.get("clubs", {}).get(cid)
                if not club: continue
                n = self._noise(f"club:{cid}:{year}")
                d = self._delta(decision.get("intent"), n)
                before = {k: float(club.get(k, 50.0)) for k in ("sporting_strength", "prestige", "management_stability")}
                club["sporting_strength"] = self._clamp(before["sporting_strength"] + d["sporting_strength"])
                club["prestige"] = self._clamp(before["prestige"] + d["reach"] * .55)
                club["management_stability"] = self._clamp(before["management_stability"] + d["management_stability"])
                club.setdefault("world_intelligence", {})["last_intent"] = decision.get("intent")
                club["world_intelligence"]["last_season"] = year
                applied[cid] = {"intent": decision.get("intent"), "delta": {k: round(v,3) for k,v in d.items()}}
            row = {"version": self.VERSION, "schema": self.SCHEMA, "season": year,
                   "status": "completed", "source_version": "V173", "clubs_applied": len(applied),
                   "club_effects": applied, "player_layer_forbidden": True,
                   "effects_for": ["V175", "V176"]}
            history.setdefault("dynamic_world_cycles", []).append(deepcopy(row))
            world["dynamic_world_version"] = self.VERSION
            world["dynamic_world_status"] = "ready_for_v175_v176"
            return deepcopy(row)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snapshot)); raise

    def validate(self):
        errors=[]; history=self._history(); world=self._world()
        if "players" in world or "player_transfers" in history: errors.append("player_system_forbidden")
        for row in history.get("dynamic_world_cycles", []):
            if row.get("version") != self.VERSION or row.get("status") != "completed": errors.append("invalid_cycle")
            for e in row.get("club_effects", {}).values():
                for v in e.get("delta", {}).values():
                    if abs(float(v)) > self.DELTA_LIMIT: errors.append("delta_limit_exceeded")
        return sorted(set(errors))
