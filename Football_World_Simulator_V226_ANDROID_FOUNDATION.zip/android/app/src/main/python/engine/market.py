class ClubMarket:
    """Dynamic club market, historical valuation and financial distress layer."""
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("club_market", [])

    def _recent_economy(self, club_id, window=5):
        rows=[]
        for season in self.save.setdefault("history", {}).get("club_economy", [])[-window:]:
            for row in season.get("clubs", []):
                if row.get("club_id")==club_id: rows.append(row)
        return rows

    def revalue_club(self, club_id):
        club=self.save["world"]["clubs"][club_id]
        prestige=max(1.0,float(club.get("prestige",20.0)))
        cash=max(0.0,float(club.get("cash",0.0)))
        debt=max(0.0,float(club.get("debt",0.0)))
        investment=sum(float(v) for v in club.get("investment",{}).values())
        recent=self._recent_economy(club_id)
        avg_profit=sum(float(r.get("profit",0.0)) for r in recent)/len(recent) if recent else 0.0
        avg_position=sum(max(0.15,1.0-(float(r.get("league_position",1))-1.0)/max(1.0,float(r.get("league_size",20))-1.0)) for r in recent)/len(recent) if recent else 0.5
        titles=int(club.get("titles",0)); continental_titles=int(club.get("continental_titles",0))
        infrastructure=float(club.get("infrastructure_score",0.0))
        historical_premium=1.0+min(0.35,titles*0.025+continental_titles*0.05)
        sport_factor=0.82+min(0.38,avg_position*0.38)
        finance_factor=1.0+min(0.35,max(-0.35,avg_profit/max(1.0,prestige*0.5)))
        structure_factor=1.0+min(0.30,infrastructure/100.0+investment/5000.0)
        base=prestige*0.12+cash*0.80
        value=max(0.1,base*sport_factor*finance_factor*structure_factor*historical_premium-debt*0.65)
        club["market_value"]=round(value,2)
        club["market_profile"]={"recent_profit_average":round(avg_profit,2),"sporting_factor":round(sport_factor,3),"finance_factor":round(finance_factor,3),"structure_factor":round(structure_factor,3),"historical_premium":round(historical_premium,3),"debt_penalty":round(debt*0.65,2)}
        return club["market_value"]

    def assess_club(self, club_id):
        club=self.save["world"]["clubs"][club_id]; self.revalue_club(club_id)
        cash=float(club.get("cash",0.0)); value=float(club.get("market_value",0.1) or 0.1)
        prestige=float(club.get("prestige",0.0)); profit=float(club.get("last_economy",{}).get("profit",0.0)); debt=float(club.get("debt",0.0))
        status="distressed" if debt>0 or cash<=0 else ("at_risk" if profit<0 else "healthy")
        return {"club_id":club_id,"cash":round(cash,2),"market_value":round(value,2),"prestige":round(prestige,2),"profit":round(profit,2),"debt":round(debt,2),"status":status,"market_profile":club.get("market_profile",{})}

    def refresh_market(self):
        season=self.save["world"]["current_year"]; reports=[self.assess_club(cid) for cid in self.save["world"].get("clubs",{})]
        self.history.append({"season":season,"clubs":reports}); return reports

    def distressed_clubs(self): return [r for r in self.refresh_market() if r["status"]=="distressed"]

    def recovery_score(self, club_id):
        club=self.save["world"]["clubs"][club_id]; recent=self._recent_economy(club_id)
        profits=[float(r.get("profit",0.0)) for r in recent]; positive=sum(1 for p in profits if p>0); trend=positive/len(profits) if profits else 0.5
        structure=min(1.0,float(club.get("infrastructure_score",0.0))/100.0)
        return round(max(0.0,min(100.0,trend*70+structure*30)),2)

    def forced_sale_value(self, club_id, discount=0.25):
        club=self.save["world"]["clubs"][club_id]
        if self._recent_economy(club_id):
            self.revalue_club(club_id)
        value=float(club.get("market_value",0.1) or 0.1)
        return round(max(0.1, value * (1.0 - max(0.0, min(0.9, discount)))), 2)

    def emergency_rescue(self, club_id, amount):
        if amount<=0: raise ValueError("valor deve ser positivo")
        club=self.save["world"]["clubs"][club_id]; club["cash"]=float(club.get("cash",0.0))+amount; club["rescue_capital"]=float(club.get("rescue_capital",0.0))+amount
        return club["cash"]
