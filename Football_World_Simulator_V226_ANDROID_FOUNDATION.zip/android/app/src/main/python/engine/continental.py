class ContinentalAccessEngine:
    def __init__(self, min_direct=1, max_direct=6):
        self.min_direct=min_direct
        self.max_direct=max_direct

    def allocate(self, competition_size, leagues):
        """Compatibility alias for qualification allocation."""
        return self.distribute(competition_size, leagues)

    def distribute(self, competition_size, leagues):
        """Allocate direct places by coefficient, with caps and small-league protection."""
        if not leagues or competition_size <= 0:
            return []
        total=sum(max(0.1,l.get("coefficient",1.0)) for l in leagues)
        allocations={l["id"]:self.min_direct for l in leagues}
        remaining=max(0,competition_size-sum(allocations.values()))
        while remaining:
            eligible=[l for l in leagues if allocations[l["id"]] < self.max_direct]
            if not eligible: break
            eligible.sort(key=lambda l:(l.get("coefficient",1.0)/(allocations[l["id"]]+1),-l.get("coefficient",1.0)),reverse=True)
            allocations[eligible[0]["id"]]+=1
            remaining-=1
        return [{"league_id":k,"direct_slots":v} for k,v in allocations.items()]
