"""V166 — Global Season Checkpoint Reconciliation.

V166 validates the chain created by V165. It does not execute sporting engines
itself: V165 remains the execution/checkpoint boundary and V164 remains the
atomic season motor. V166 adds temporal continuity, checkpoint fingerprints,
and a tamper-evident reconciliation ledger.
"""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
import pickle

from .v165_global_season_checkpoint import V165GlobalSeasonCheckpoint
from .v164_global_season_motor import V164GlobalSeasonMotor
from .world_integrity import assert_world_integrity


class V166GlobalSeasonReconciliation:
    VERSION = "V166"
    SCHEMA = 1

    def __init__(self, save, seed=166):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _checkpoints(self):
        return self._history().setdefault("global_season_checkpoints", [])

    def _ledger(self):
        return self._history().setdefault("global_season_reconciliation", [])

    @staticmethod
    def _digest(value):
        payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @classmethod
    def checkpoint_fingerprint(cls, checkpoint):
        return cls._digest(checkpoint)

    def _validate_checkpoint(self, row):
        errors = []
        season = int(row.get("season", -1))
        if row.get("version") != "V165":
            errors.append(f"checkpoint_version:{season}")
        if row.get("status") != "closed":
            errors.append(f"checkpoint_status:{season}")
        if row.get("engine_version") != "V164":
            errors.append(f"checkpoint_engine:{season}")
        if row.get("world_year_before") != season:
            errors.append(f"checkpoint_entry_year:{season}")
        if row.get("world_year_after") != season + 1:
            errors.append(f"checkpoint_exit_year:{season}")
        if row.get("dependency_chain") != list(V164GlobalSeasonMotor.PHASES):
            errors.append(f"checkpoint_dependency:{season}")
        if len(row.get("phases", [])) != len(V164GlobalSeasonMotor.PHASES):
            errors.append(f"checkpoint_phases:{season}")
        return errors

    def reconcile(self):
        """Reconcile all V165 checkpoints without changing the world season."""
        errors = []
        rows = self._checkpoints()
        ordered = sorted(rows, key=lambda r: int(r.get("season", -1)))
        seen = set()
        fingerprints = {}

        for row in ordered:
            season = int(row.get("season", -1))
            if season in seen:
                errors.append(f"duplicate_season:{season}")
            seen.add(season)
            errors.extend(self._validate_checkpoint(row))
            fingerprints[season] = self.checkpoint_fingerprint(row)

        for previous, current in zip(ordered, ordered[1:]):
            py = int(previous.get("world_year_after", -1))
            cy = int(current.get("world_year_before", -1))
            if py != cy:
                errors.append(f"chain_break:{previous.get('season')}->{current.get('season')}")
            if int(current.get("season", -1)) != int(previous.get("season", -1)) + 1:
                errors.append(f"season_gap:{previous.get('season')}->{current.get('season')}")

        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("player_system_forbidden")

        return {
            "version": self.VERSION,
            "status": "valid" if not errors else "invalid",
            "checkpoint_count": len(ordered),
            "seasons": [int(r.get("season", -1)) for r in ordered],
            "fingerprints": fingerprints,
            "errors": errors,
        }

    def run_season(self, *, season=None, advance_year=True, club_context=None,
                   association_context=None, career_results=None):
        """Execute V165 once, then atomically reconcile the resulting chain."""
        requested_year = int(self._world().get("current_year", 2026) if season is None else season)
        if any(int(r.get("season", -1)) == requested_year for r in self._checkpoints()):
            raise ValueError(f"V166 season {requested_year} already reconciled")

        # Keep V166 rollback cheap even after large historical ledgers exist.
        before = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            # A continuation must start exactly where the previous checkpoint ended.
            existing = sorted(self._checkpoints(), key=lambda r: int(r.get("season", -1)))
            if existing:
                previous = existing[-1]
                if requested_year != int(previous.get("world_year_after", -1)):
                    raise ValueError(
                        f"V166 continuity break: expected season {previous.get('world_year_after')}, "
                        f"received {requested_year}"
                    )

            result = V165GlobalSeasonCheckpoint(self.save, seed=self.seed + 165).run_season(
                season=requested_year,
                advance_year=advance_year,
                club_context=club_context,
                association_context=association_context,
                career_results=career_results,
            )
            assert_world_integrity(self.save)

            checkpoint = result.get("season_checkpoint")
            if not isinstance(checkpoint, dict):
                raise ValueError("V166 requires a V165 season checkpoint")
            checkpoint_errors = self._validate_checkpoint(checkpoint)
            if checkpoint_errors:
                raise ValueError("V166 checkpoint validation failed: " + "; ".join(checkpoint_errors))

            reconciliation = self.reconcile()
            if reconciliation["status"] != "valid":
                raise ValueError("V166 reconciliation failed: " + "; ".join(reconciliation["errors"]))

            current_fp = reconciliation["fingerprints"][requested_year]
            previous_fp = None
            ordered = reconciliation["seasons"]
            if len(ordered) > 1:
                previous_fp = reconciliation["fingerprints"][ordered[-2]]

            row = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "season": requested_year,
                "status": "reconciled",
                "checkpoint_fingerprint": current_fp,
                "previous_checkpoint_fingerprint": previous_fp,
                "checkpoint_count": reconciliation["checkpoint_count"],
                "chain": ordered,
                "reconciled_at_year": int(self._world().get("current_year", requested_year)),
                "player_layer_forbidden": True,
            }
            self._ledger().append(deepcopy(row))
            self._world()["global_season_reconciliation_version"] = self.VERSION
            self._world()["global_season_reconciliation_status"] = "valid"

            result = deepcopy(result)
            result["season_reconciliation"] = deepcopy(row)
            return result
        except Exception:
            restored = pickle.loads(before)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        reconciliation = self.reconcile()
        errors.extend(reconciliation["errors"])

        rows = self._ledger()
        checkpoints = self._checkpoints()
        checkpoint_by_season = {int(r.get("season", -1)): r for r in checkpoints}
        seen = set()
        for row in rows:
            season = int(row.get("season", -1))
            if season in seen:
                errors.append(f"reconciliation_duplicate:{season}")
            seen.add(season)
            checkpoint = checkpoint_by_season.get(season)
            if checkpoint is None:
                errors.append(f"reconciliation_missing_checkpoint:{season}")
                continue
            if row.get("status") != "reconciled":
                errors.append(f"reconciliation_not_closed:{season}")
            expected = self.checkpoint_fingerprint(checkpoint)
            if row.get("checkpoint_fingerprint") != expected:
                errors.append(f"fingerprint_mismatch:{season}")

        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("player_system_forbidden")
        return errors
