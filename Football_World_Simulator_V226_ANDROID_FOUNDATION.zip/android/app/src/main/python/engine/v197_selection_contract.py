"""V197 — National-team offer, contract and tenure management."""
from __future__ import annotations
from copy import deepcopy
class V197SelectionContract:
    VERSION='V197'
    def __init__(self,save):
        self.save=save; self.career=save.setdefault('careers',{}).setdefault('selection',{}); self.history=save.setdefault('history',{}).setdefault('selection_contracts',[])
        self.career.setdefault('contracts',{})
    def sign(self,team_id,seasons=1,role='national_manager'):
        if team_id != self.career.get('current_team_id'): raise ValueError('a seleção precisa estar sob gestão')
        seasons=max(1,int(seasons)); year=int(self.save['world'].get('current_year',2026)); end=year+seasons
        row={'version':self.VERSION,'team_id':team_id,'role':role,'start_season':year,'end_season':end,'status':'active'}
        self.career['contracts'][team_id]=row; self.history.append(deepcopy(row)); return deepcopy(row)
    def active(self,team_id=None):
        team_id=team_id or self.career.get('current_team_id'); c=self.career.get('contracts',{}).get(team_id)
        if not c:return None
        year=int(self.save['world'].get('current_year',2026))
        if year>=int(c['end_season']) and c.get('status')=='active': c['status']='expired'
        return deepcopy(c)
    def renew(self,team_id,seasons=1):
        current=self.active(team_id)
        if not current: raise ValueError('não há contrato ativo')
        year=int(self.save['world'].get('current_year',2026)); current['end_season']=max(current['end_season'],year)+max(1,int(seasons)); current['status']='active'
        self.career['contracts'][team_id]=current; self.history.append(deepcopy(current)); return deepcopy(current)
    def leave(self,team_id=None,reason='voluntary'):
        team_id=team_id or self.career.get('current_team_id'); c=self.career.get('contracts',{}).get(team_id)
        if not c:return None
        c['status']='ended'; c['end_reason']=reason; c['end_season']=int(self.save['world'].get('current_year',2026)); self.history.append(deepcopy(c)); return deepcopy(c)
    def validate(self): return []
