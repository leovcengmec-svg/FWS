from pathlib import Path
from .assets import AssetManager

LEVELS={"DISTRICT":30,"STATE":45,"NATIONAL":60,"INTERNATIONAL":75,"WORLD_CLASS":88}

class ClubCreator:
    def __init__(self, save, assets_root):
        self.save=save
        self.assets=AssetManager(assets_root)

    def create(self, club_id, name, country_id, city, colors, starting_level, image_file=None):
        if club_id in self.save["world"]["clubs"]:
            raise ValueError("club id already exists")
        if starting_level not in LEVELS:
            raise ValueError("invalid starting level")
        strength=LEVELS[starting_level]
        club={
          "id":club_id,"name":name,"country_id":country_id,"city":city,
          "league_id":None,"division":None,"attack":strength,"defense":strength,
          "prestige":strength,"cash":10,"created_by_user":True,
          "colors":colors,"asset":{"type":"user_club","id":club_id,"path":None}
        }
        if image_file:
            club["asset"]["path"]=self.assets.register("user_club",club_id,image_file)
        self.save["world"]["clubs"][club_id]=club
        self.save.setdefault("world",{}).setdefault("custom_clubs",[]).append(club_id)
        return club
