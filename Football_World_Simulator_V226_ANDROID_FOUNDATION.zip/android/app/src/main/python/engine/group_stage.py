class GroupStage:
    def __init__(self, group_id, clubs, engine, season):
        self.group_id=group_id; self.clubs=clubs; self.engine=engine; self.season=season
        self.table={c["id"]:{"club_id":c["id"],"played":0,"wins":0,"draws":0,"losses":0,
                             "gf":0,"ga":0,"gd":0,"points":0} for c in clubs}
        self.matches=[]

    def play(self):
        # double round robin within group
        n=len(self.clubs)
        for i in range(n):
            for j in range(i+1,n):
                for home,away in ((self.clubs[i],self.clubs[j]),(self.clubs[j],self.clubs[i])):
                    r=self.engine.play(self.group_id,self.season,len(self.matches)+1,home,away)
                    self.matches.append(r.__dict__)
                    h=self.table[r.home_id]; a=self.table[r.away_id]
                    h["played"]+=1; a["played"]+=1
                    h["gf"]+=r.home_goals; h["ga"]+=r.away_goals
                    a["gf"]+=r.away_goals; a["ga"]+=r.home_goals
                    if r.home_goals>r.away_goals:
                        h["wins"]+=1; h["points"]+=3; a["losses"]+=1
                    elif r.home_goals<r.away_goals:
                        a["wins"]+=1; a["points"]+=3; h["losses"]+=1
                    else:
                        h["draws"]+=1; a["draws"]+=1; h["points"]+=1; a["points"]+=1
        for x in self.table.values(): x["gd"]=x["gf"]-x["ga"]
        return sorted(self.table.values(),key=lambda x:(-x["points"],-x["gd"],-x["gf"],x["club_id"]))

class MultiGroupStage:
    def __init__(self, groups, engine, season):
        self.groups=groups; self.engine=engine; self.season=season
        self.results={}

    def play(self):
        for gid,clubs in self.groups.items():
            self.results[gid]=GroupStage(gid,clubs,self.engine,self.season).play()
        return self.results
