"""Parser for OpenFootball/football.db-style club text files.

The parser produces a *candidate* pack. It never marks data verified by itself.
"""
import re

class OpenFootballImporter:
    SOURCE = "openfootball/clubs"

    def parse_clubs(self, text, country_id, league_id=None):
        clubs = []
        current = None
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("="):
                continue
            if line.startswith("|"):
                continue
            m = re.match(r"^(.*?)(?:,\s*(\d{4}))?(?:,\s*@\s*(.*?))?(?:,\s*([^,]+))?$", line)
            if not m:
                continue
            name = m.group(1).strip()
            if not name:
                continue
            founded = int(m.group(2)) if m.group(2) else None
            stadium = (m.group(3) or "").strip() or None
            city = (m.group(4) or "").strip() or None
            clubs.append({
                "id": None,
                "name": name,
                "country_id": country_id,
                "league_id": league_id,
                "founded": founded,
                "stadium": stadium,
                "city": city,
                "source": self.SOURCE,
                "status": "candidate",
            })
        return clubs

    def normalize_ids(self, clubs, prefix):
        seen = set()
        out = []
        for index, club in enumerate(clubs, 1):
            slug = re.sub(r"[^a-z0-9]+", "_", club["name"].lower()).strip("_") or f"club_{index}"
            base = f"{prefix}_{slug}"
            cid = base
            n = 2
            while cid in seen:
                cid = f"{base}_{n}"
                n += 1
            seen.add(cid)
            row = dict(club)
            row["id"] = cid
            out.append(row)
        return out
