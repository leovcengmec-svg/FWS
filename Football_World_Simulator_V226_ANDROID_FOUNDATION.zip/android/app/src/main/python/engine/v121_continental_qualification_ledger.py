"""V121 — Continental Qualification Ledger.

Separates the total continental field from the direct-entry budget.
V112 defines the order: direct entry -> existing preliminary rounds -> league phase.
V121 makes that separation executable without inventing a direct-slot budget.
If a competition has no explicit direct_slot_budget, its qualification ledger is
reported as configuration_pending instead of silently treating the whole field
size as direct places.
"""
from __future__ import annotations
from copy import deepcopy
from .v120_continental_world_integration import V120ContinentalWorldIntegration


class V121ContinentalQualificationLedger(V120ContinentalWorldIntegration):
    VERSION = "V121"

    def build_ledger(self, competition, leagues):
        size = int(competition.get("size", competition.get("default_size", 0)))
        budget = competition.get("direct_slot_budget")
        if budget is None:
            return {
                "version": self.VERSION,
                "competition_id": competition.get("id"),
                "confederation": competition.get("confederation"),
                "field_size": size,
                "status": "qualification_configuration_pending",
                "missing_configuration": ["direct_slot_budget"],
                "direct_slots": 0,
                "preliminary_slots": 0,
                "direct_allocations": [],
            }
        budget = max(0, min(int(budget), size))
        eligible = [l for l in leagues if not competition.get("confederation") or l.get("confederation") == competition.get("confederation")]
        allocations = self.allocate_direct_places(budget, eligible, max_direct=6)
        direct_total = sum(x["direct_slots"] for x in allocations)
        return {
            "version": self.VERSION,
            "competition_id": competition.get("id"),
            "confederation": competition.get("confederation"),
            "field_size": size,
            "status": "ready",
            "direct_slots": direct_total,
            "preliminary_slots": max(0, size - direct_total),
            "direct_allocations": deepcopy(allocations),
            "qualification_order": ["direct_entry", "entry_preliminary", "league_phase"],
            "no_minimum_one_slot": True,
            "max_direct_slots_per_league": 6,
        }

    def build_all_ledgers(self, competitions, leagues):
        result = {}
        for comp in competitions:
            result[comp["id"]] = self.build_ledger(comp, leagues)
        self.save.setdefault("world", {})["continental_qualification_ledger"] = {
            "version": self.VERSION,
            "competitions": deepcopy(result),
        }
        return deepcopy(self.save["world"]["continental_qualification_ledger"])

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_qualification_ledger_framework"] = {
            "version": self.VERSION,
            "base_version": "V120",
            "separates_field_size_from_direct_slot_budget": True,
            "does_not_invent_direct_slot_budget": True,
            "qualification_order": ["direct_entry", "entry_preliminary", "league_phase"],
            "max_direct_slots_per_league": 6,
            "min_direct_slots_per_league": 0,
        }
        return deepcopy(world["continental_qualification_ledger_framework"])

    def validate(self):
        errors = super().validate()
        fw = self.save.get("world", {}).get("continental_qualification_ledger_framework", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V121 qualification ledger version")
        if fw and fw.get("max_direct_slots_per_league") != 6:
            errors.append("V121 maximum direct slots must remain six")
        if fw and fw.get("min_direct_slots_per_league") != 0:
            errors.append("V121 minimum direct slots must remain zero")
        return errors
