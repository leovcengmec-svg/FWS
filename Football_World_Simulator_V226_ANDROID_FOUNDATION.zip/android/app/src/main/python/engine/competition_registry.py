"""Competition definitions and configuration validation."""

CONTINENTAL_BY_CONF = {
    "UEFA": ("UEFA_CHAMPIONS", "UEFA_EUROPA", "UEFA_CONFERENCE"),
    "CONMEBOL": ("LIBERTADORES", "SUDAMERICANA"),
    "AFC": ("AFC_CHAMPIONS", "AFC_CHAMPIONS_TWO", "AFC_CHALLENGE"),
    "CAF": ("CAF_CHAMPIONS", "CAF_CONFEDERATION"),
    "CONCACAF": ("CONCACAF_CHAMPIONS", "CONCACAF_CENTRAL", "CONCACAF_CARIBBEAN"),
    "OFC": ("OFC_CHAMPIONS",),
}


class CompetitionRegistry:
    def __init__(self, save):
        self.save = save
        self.world = save.setdefault("world", {})
        self.config = save.get("continental", {})

    def initialize(self):
        competitions = self.world.setdefault("competitions", {})
        definitions = self.config.get("competitions", {})
        for cid, cfg in definitions.items():
            row = dict(cfg)
            row["id"] = cid
            row.setdefault("size", row.get("default_size"))
            row.setdefault("type", "continental_club")
            row.setdefault("confederation", next((conf for conf, ids in CONTINENTAL_BY_CONF.items() if cid in ids), None))
            row.setdefault("enabled", False)
            row.setdefault("official", False)
            competitions[cid] = row
        return competitions

    def enabled_continental(self):
        return [c for c in self.world.get("competitions", {}).values()
                if c.get("enabled") and c.get("type") == "continental_club"]

    def for_confederation(self, confederation):
        ids = set(CONTINENTAL_BY_CONF.get(confederation, ()))
        return [c for c in self.enabled_continental() if c.get("id") in ids]

    def validate(self):
        errors = []
        definitions = self.config.get("competitions", {})
        for cid, comp in self.world.get("competitions", {}).items():
            if comp.get("size", 0) < comp.get("min_size", 0):
                errors.append(f"{cid} size below minimum")
            if comp.get("size", 0) > comp.get("max_size", 10**9):
                errors.append(f"{cid} size above maximum")
            if cid not in definitions:
                errors.append(f"{cid} not present in continental configuration")
        return errors
