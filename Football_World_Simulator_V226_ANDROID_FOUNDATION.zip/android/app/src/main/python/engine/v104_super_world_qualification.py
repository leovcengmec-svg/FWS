"""V104 — Super World four-year qualification cycle.

Defines the FWS proprietary four-season qualification window for the V102
64-team Super World Club Championship. The cycle produces 56 direct
qualifiers and 32 preliminary entrants; the preliminary tournament produces
8 additional group-stage places. It is deterministic and catalog-backed.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from .v103_global_calendar import V103GlobalCalendar


class V104SuperWorldQualification(V103GlobalCalendar):
    VERSION = "V104"

    def build_super_world_qualification(self, season=None, cycle_years=4, seed=104):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        end_year = int(season if season is not None else world.get("current_year", 2026))
        years = int(cycle_years)
        if years <= 0:
            raise ValueError("cycle_years must be positive")
        start_year = end_year - years + 1

        clubs = catalog.get("clubs", {})
        scores = {cid: 0.0 for cid in clubs}
        appearances = {cid: 0 for cid in clubs}
        wins = {cid: 0 for cid in clubs}

        # Continental champions are the strongest explicit signal available in
        # the existing world history. Count only seasons inside this four-year window.
        hist = self.save.get("history", {})
        for cid, rows in hist.get("continental_champions", {}).items():
            for row in rows or []:
                y = int(row.get("season", 0))
                if start_year <= y <= end_year:
                    club = row.get("club_id")
                    if club in scores:
                        scores[club] += 100.0
                        wins[club] += 1
                        appearances[club] += 1

        # World-club results add a stronger second signal when available.
        for row in hist.get("global_club_world", []) or []:
            y = int(row.get("season", 0))
            if not (start_year <= y <= end_year):
                continue
            for comp_key in ("annual_intercontinental", "super_world"):
                comp = row.get(comp_key) or {}
                champ = comp.get("champion")
                if champ in scores:
                    scores[champ] += 150.0 if comp_key == "super_world" else 125.0
                    wins[champ] += 1
                    appearances[champ] += 1

        # Deterministic fallback signal ensures the four-year window can always
        # produce a complete field from the verified global catalog, even when
        # a fresh save has little historical data.
        for cid, club in clubs.items():
            digest = hashlib.sha256(f"{seed}:{start_year}:{end_year}:{cid}".encode()).digest()
            fallback = digest[0] / 255.0 * 25.0
            scores[cid] += fallback
            appearances[cid] += 0

        ranked = []
        for cid, club in clubs.items():
            ranked.append({
                "club_id": cid,
                "club_name": club.get("name", cid),
                "score": round(scores[cid], 6),
                "continental_titles": wins[cid],
                "appearances": appearances[cid],
            })
        ranked.sort(key=lambda r: (-r["score"], -r["continental_titles"], r["club_id"]))

        # The first 56 are direct. The next 32 are the preliminary field.
        direct = ranked[:56]
        preliminary = ranked[56:88]
        if len(direct) < 56 or len(preliminary) < 32:
            raise ValueError("verified club catalog does not contain enough clubs for the Super World field")

        direct_ids = {r["club_id"] for r in direct}
        preliminary = [r for r in preliminary if r["club_id"] not in direct_ids][:32]
        if len(preliminary) != 32:
            raise ValueError("preliminary field must contain 32 unique clubs")

        qualification = {
            "version": self.VERSION,
            "cycle_start": start_year,
            "cycle_end": end_year,
            "cycle_years": years,
            "direct_entries": 56,
            "preliminary_entries": 32,
            "preliminary_qualifying_places": 8,
            "direct": deepcopy(direct),
            "preliminary": deepcopy(preliminary),
            "group_field_size": 64,
            "group_count": 16,
            "group_size": 4,
            "status": "qualified",
        }
        world["super_world_qualification"] = deepcopy(qualification)
        world.setdefault("super_world_qualification_history", []).append(deepcopy(qualification))
        return deepcopy(qualification)

    def validate(self):
        errors = super().validate()
        q = self.save.get("world", {}).get("super_world_qualification")
        if not q:
            return errors
        if q.get("version") != self.VERSION:
            errors.append("wrong super world qualification version")
        if q.get("direct_entries") != 56:
            errors.append("super world qualification must have 56 direct entries")
        if q.get("preliminary_entries") != 32:
            errors.append("super world qualification must have 32 preliminary entries")
        if q.get("preliminary_qualifying_places") != 8:
            errors.append("super world qualification must have 8 preliminary qualifying places")
        direct_ids = [r.get("club_id") for r in q.get("direct", [])]
        prelim_ids = [r.get("club_id") for r in q.get("preliminary", [])]
        if len(direct_ids) != 56 or len(set(direct_ids)) != 56:
            errors.append("direct qualification field must contain 56 unique clubs")
        if len(prelim_ids) != 32 or len(set(prelim_ids)) != 32:
            errors.append("preliminary qualification field must contain 32 unique clubs")
        if set(direct_ids) & set(prelim_ids):
            errors.append("direct and preliminary qualification fields overlap")
        if q.get("group_field_size") != 64:
            errors.append("super world group field must be 64")
        return errors
