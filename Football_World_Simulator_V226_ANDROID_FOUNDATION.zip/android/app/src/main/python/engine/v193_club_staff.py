class V193ClubStaff:
    ROLES=('head_coach','sporting_director','commercial_director')
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}).setdefault('club_staff',[])
    def appoint(self,club_id,role,profile):
        if role not in self.ROLES: raise ValueError('função inválida')
        c=self.save['world']['clubs'][club_id]; c.setdefault('staff',{})[role]=dict(profile); r={'club_id':club_id,'season':self.save['world'].get('current_year'),'role':role,'profile':dict(profile)}; self.history.append(r); return r
    def dismiss(self,club_id,role):
        c=self.save['world']['clubs'][club_id]; old=c.setdefault('staff',{}).pop(role,None); r={'club_id':club_id,'season':self.save['world'].get('current_year'),'role':role,'dismissed':old is not None}; self.history.append(r); return r
    def validate(self): return []
