from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'data/global_world_catalog.json'
AUDIT=ROOT/'data/v147_verified_roster_restoration.json'

VERIFIED={
'SWE':{
 'sources':['https://www.svenskfotboll.se/4af842/globalassets/svff/dokumentdokumentblock/tavling/arsplaner--seriesammansattningar/2026/faststalld-seriesammansattning-allsvenskan-och-superettan-2026.pdf'],
 'leagues':{
 'SWE_D1':['Mjällby AIF','BK Häcken','GAIS','IFK Göteborg','Örgryte IS Fotboll','Halmstad','Malmö FF','Kalmar FF','AIK','Djurgården','Hammarby','IF Brommapojkarna','IK Sirius FK','IF Elfsborg','Västerås SK FK','Degerfors IF'],
 'SWE_D2':['IK Oddevold','Ljungskile SK Herrfotboll','IK Brage','Sandvikens IF','Falkenbergs FF','Varbergs BoIS FC','Östersund','GIF Sundsvall','Helsingborgs IF','Landskrona BoIS','IFK Värnamo','Östers IF','Nordic United FC','Norrby IF','Örebro','IFK Norrköping FK']
 }},
'SUI':{
 'sources':['https://matchcenter-sfl.football.ch/default.aspx?a=mgr&ln=11011&lng=1&ls=25694&oid=2&s=2027&sg=0','https://matchcenter-sfl.football.ch/default.aspx?a=mgr&ln=11016&lng=1&ls=25693&oid=2&s=2027&sg=0'],
 'leagues':{
 'SUI_D1':['FC Basel 1893','Grasshopper Club Zürich','FC Lausanne-Sport','FC Lugano','FC Luzern','Servette FC','FC Sion','FC St. Gallen 1879','FC Thun Berner Oberland','FC Vaduz','BSC Young Boys','FC Zürich'],
 'SUI_D2':['FC Aarau','Etoile Carouge FC','SC Kriens','Neuchâtel Xamax','FC Rapperswil-Jona','FC Stade-Lausanne-Ouchy','FC Stade Nyonnais','FC Wil 1900','FC Winterthur','Yverdon Sport FC']
 }},
'TUR':{
 'sources':['https://www.tff.org/?pageID=198'],
 'leagues':{
 'TUR_D1':['Galatasaray A.Ş.','Fenerbahçe A.Ş.','Beşiktaş A.Ş.','Trabzonspor A.Ş.','Kasımpaşa A.Ş.','TÜMOSAN Konyaspor','Çaykur Rizespor A.Ş.','Samsunspor A.Ş.','Göztepe A.Ş.','Gençlerbirliği','Gaziantep Futbol Kulübü A.Ş.','Corendon Alanyaspor','İstanbul Başakşehir FK','Kocaelispor','Eyüpspor','Arca Çorum FK','Erzurumspor FK','Amed Sportif Faaliyetler']
 }}}

def norm(s):
 return ''.join(ch.lower() for ch in s if ch.isalnum())

def restore():
 d=json.loads(CATALOG.read_text())
 clubs=d['clubs']; leagues=d['leagues']
 by_country={}
 for cid,c in clubs.items(): by_country.setdefault(c['country_id'],{})[norm(c['name'])]=cid
 changes=[]; created=[]
 for country, cfg in VERIFIED.items():
  for lid,names in cfg['leagues'].items():
   if lid not in leagues: continue
   old=set(leagues[lid]['club_ids'])
   new=[]
   for name in names:
    key=norm(name); cid=by_country.get(country,{}).get(key)
    if cid is None:
     cid=f'{lid}_C{len(clubs)+1}'
     clubs[cid]={'id':cid,'name':name,'country_id':country,'league_id':lid,'data_status':'verified_external_import','source_version':'V147'}
     by_country.setdefault(country,{})[key]=cid; created.append(cid)
    else:
     clubs[cid]['league_id']=lid; clubs[cid]['data_status']='verified_external_import'
    new.append(cid)
   if len(new)>=10:
    for cid in old-set(new):
     if cid in clubs and clubs[cid].get('league_id')==lid: clubs[cid]['league_id']=None
    leagues[lid]['club_ids']=new; leagues[lid]['club_count']=len(new)
    leagues[lid]['data_status']='verified_external_import'
    leagues[lid]['source_note']='V147 verified against federation/league source; 2026/27 or 2026 season reference.'
    changes.append({'league_id':lid,'before':len(old),'after':len(new),'added_or_reassigned':len(set(new)-old)})
 d['version']='V147'
 d['integrity']['v147_verified_roster_restoration']=True
 d['integrity']['v147_verified_leagues']=len(changes)
 d['integrity']['v147_new_or_reassigned_clubs']=len(created)
 d['source_policy']['v147']='Only federation/league-published roster sources accepted for verified imports.'
 # Keep queues intact; never auto-enroll a club unless explicitly verified as an external candidate.
 report={'version':'V147','season_reference':'2026/2027','verified_leagues':changes,'new_or_reassigned_clubs':len(created),'sources':{c:v['sources'] for c,v in VERIFIED.items()},'queue_policy':'Existing 4-club final-division queues preserved; no unverified club added.'}
 CATALOG.write_text(json.dumps(d,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 AUDIT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 return report

if __name__=='__main__':
 print(json.dumps(restore(),ensure_ascii=False,indent=2))
