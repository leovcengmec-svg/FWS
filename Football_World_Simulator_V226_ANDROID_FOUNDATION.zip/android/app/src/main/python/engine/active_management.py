"""Active management layer for investor-owned clubs and national teams.

Ownership and selection invitations remain unchanged. This layer only defines
which owned club and/or currently controlled national team receive the player's
close-management view and decisions. The rest of the football world continues
running normally.
"""


class ActiveManagement:
    def __init__(self, save):
        self.save = save
        careers = save.setdefault("careers", {})
        self.state = careers.setdefault("active_management", {
            "active_club_id": None,
            "active_selection_id": None,
            "club_history": [],
            "selection_history": [],
            "club_decisions": [],
            "selection_decisions": [],
        })
        self._sync_selection()

    @property
    def investor(self):
        return self.save.setdefault("careers", {}).setdefault("investor", {
            "cash": 0.0, "owned_clubs": [], "transactions": [], "created_clubs": []
        })

    @property
    def selection(self):
        return self.save.setdefault("careers", {}).setdefault("selection", {
            "manager_prestige": 0.0, "current_team_id": None,
            "history": [], "invitations": [], "declined": []
        })

    def _sync_selection(self):
        current = self.selection.get("current_team_id")
        if current:
            self.state["active_selection_id"] = current
        elif self.state.get("active_selection_id"):
            self.state["selection_history"].append({
                "team_id": self.state["active_selection_id"],
                "ended_season": self.save["world"].get("current_year"),
            })
            self.state["active_selection_id"] = None

    def assume_club(self, club_id):
        owned = self.investor.get("owned_clubs", [])
        if club_id not in owned:
            raise ValueError("o clube precisa pertencer ao investidor")
        clubs = self.save["world"].get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        previous = self.state.get("active_club_id")
        if previous == club_id:
            return club_id
        season = self.save["world"].get("current_year")
        if previous:
            self.state["club_history"].append({
                "club_id": previous, "ended_season": season
            })
        self.state["active_club_id"] = club_id
        self.state["club_history"].append({
            "club_id": club_id, "started_season": season
        })
        return club_id

    def leave_club(self):
        current = self.state.get("active_club_id")
        if current:
            self.state["club_history"].append({
                "club_id": current,
                "ended_season": self.save["world"].get("current_year"),
            })
        self.state["active_club_id"] = None
        return current

    def assume_selection(self, team_id=None):
        self._sync_selection()
        current = self.selection.get("current_team_id")
        target = team_id or current
        if not target or target not in self.save["world"].get("national_teams", {}):
            raise ValueError("a seleção precisa ser uma seleção nacional válida")
        if current and current != target:
            raise ValueError("a carreira de seleção controla outra seleção atualmente")
        if current != target:
            self.selection["current_team_id"] = target
        self.state["active_selection_id"] = target
        if not self.state["selection_history"] or self.state["selection_history"][-1].get("team_id") != target:
            self.state["selection_history"].append({
                "team_id": target,
                "started_season": self.save["world"].get("current_year")
            })
        return target

    def leave_selection(self):
        current = self.selection.get("current_team_id")
        if current:
            self.selection["current_team_id"] = None
            self.state["selection_history"].append({
                "team_id": current,
                "ended_season": self.save["world"].get("current_year"),
            })
        self.state["active_selection_id"] = None
        return current

    def _sync_club(self):
        current = self.state.get("active_club_id")
        if current and current not in self.investor.get("owned_clubs", []):
            self.state["club_history"].append({
                "club_id": current,
                "ended_season": self.save["world"].get("current_year"),
                "reason": "ownership_lost",
            })
            self.state["active_club_id"] = None

    def active_entities(self):
        self._sync_club()
        self._sync_selection()
        return {
            "club_id": self.state.get("active_club_id"),
            "selection_id": self.state.get("active_selection_id"),
            "simultaneous_management": bool(
                self.state.get("active_club_id") and self.state.get("active_selection_id")
            ),
        }


    def owned_clubs_overview(self):
        """Return every owned club without imposing an artificial portfolio cap."""
        clubs = self.save["world"].get("clubs", {})
        active = self.state.get("active_club_id")
        rows = []
        for club_id in self.investor.get("owned_clubs", []):
            club = clubs.get(club_id)
            if not club:
                continue
            rows.append({
                "club_id": club_id,
                "name": club.get("name"),
                "active": club_id == active,
                "cash": club.get("cash", 0),
                "prestige": club.get("prestige", 0),
                "sporting_strength": club.get("sporting_strength", 0),
            })
        return rows

    def selection_matches(self, team_id=None, season=None, competition=None):
        """Return tracked national-team matches for the controlled selection."""
        team_id = team_id or self.state.get("active_selection_id")
        history = self.save.setdefault("history", {})
        rows = list(history.get("national_team_matches", []))
        if season is not None:
            rows = [m for m in rows if m.get("season") == season]
        if competition is not None:
            rows = [m for m in rows if m.get("competition", m.get("competition_id")) == competition]
        rows = [m for m in rows if team_id in (m.get("home_id"), m.get("away_id"), m.get("team_id"))]
        return [self._match_view(m) for m in rows]

    def selection_trajectory(self, team_id=None, season=None):
        team_id = team_id or self.state.get("active_selection_id")
        team = self.save["world"].get("national_teams", {}).get(team_id)
        if not team:
            raise ValueError("seleção inexistente")
        matches = self.selection_matches(team_id, season)
        return {
            "selection_id": team_id,
            "season": season if season is not None else self.save["world"].get("current_year"),
            "selection": {"name": team.get("name"), "strength": team.get("strength", 0)},
            "matches": matches,
            "by_competition": self._group_by_competition(matches),
        }

    def active_schedule(self, season=None):
        """Unified agenda for the active club and controlled national team."""
        entities = self.active_entities()
        rows = []
        if entities["club_id"]:
            rows.extend(self.club_matches(entities["club_id"], season))
        if entities["selection_id"]:
            rows.extend(self.selection_matches(entities["selection_id"], season))
        rows.sort(key=lambda m: (m.get("date") or "", m.get("season") or 0, m.get("competition") or ""))
        return rows

    def spend_club_money(self, category, amount):
        """Spend the active club's own cash; investor cash is untouched."""
        club_id = self.state.get("active_club_id")
        if not club_id:
            raise ValueError("nenhum clube está sob gestão ativa")
        if club_id not in self.investor.get("owned_clubs", []):
            raise ValueError("o clube ativo deixou de pertencer ao investidor")
        if amount <= 0:
            raise ValueError("o valor deve ser positivo")
        club = self.save["world"]["clubs"][club_id]
        cash = float(club.get("cash", 0.0))
        if cash < amount:
            raise ValueError("caixa do clube insuficiente")
        club["cash"] = round(cash - amount, 2)
        club.setdefault("management_spending", {}).setdefault(category, 0.0)
        club["management_spending"][category] = round(
            club["management_spending"][category] + amount, 2
        )
        decision = {
            "club_id": club_id,
            "category": category,
            "amount": round(amount, 2),
            "season": self.save["world"].get("current_year"),
        }
        self.state["club_decisions"].append(decision)
        return decision

    def club_matches(self, club_id=None, season=None, competition=None):
        """Return tracked matches for a club, grouped by competition metadata."""
        club_id = club_id or self.state.get("active_club_id")
        history = self.save.setdefault("history", {})
        rows = list(history.get("season_matches", [])) + list(history.get("competition_matches", []))
        if season is not None:
            rows = [m for m in rows if m.get("season") == season]
        if competition is not None:
            rows = [m for m in rows if m.get("competition", m.get("competition_id")) == competition]
        rows = [m for m in rows if club_id in (m.get("home_id"), m.get("away_id"))]
        return [self._match_view(m) for m in rows]

    def club_trajectory(self, club_id=None, season=None):
        club_id = club_id or self.state.get("active_club_id")
        club = self.save["world"].get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        matches = self.club_matches(club_id, season)
        return {
            "club_id": club_id,
            "season": season if season is not None else self.save["world"].get("current_year"),
            "club": {
                "name": club.get("name"),
                "cash": club.get("cash", 0),
                "prestige": club.get("prestige", 0),
                "sporting_strength": club.get("sporting_strength", 0),
            },
            "matches": matches,
            "by_competition": self._group_by_competition(matches),
        }

    @staticmethod
    def _match_view(match):
        return {
            "competition": match.get("competition", match.get("competition_id")),
            "season": match.get("season"),
            "round": match.get("round", match.get("round_no")),
            "home_id": match.get("home_id"),
            "away_id": match.get("away_id"),
            "home_goals": match.get("home_goals"),
            "away_goals": match.get("away_goals"),
            "date": match.get("date"),
        }

    @staticmethod
    def _group_by_competition(matches):
        grouped = {}
        for match in matches:
            grouped.setdefault(match.get("competition"), []).append(match)
        return grouped
