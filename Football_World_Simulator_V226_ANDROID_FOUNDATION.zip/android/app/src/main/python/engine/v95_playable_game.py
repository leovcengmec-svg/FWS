"""V95 first playable build: career entry, club control and season play loop."""
from __future__ import annotations
import json
from pathlib import Path
from copy import deepcopy
from .v94_core_integration import V94Core

class V95PlayableGame:
    VERSION='V95'
    def __init__(self,catalog,cup_registry=None,seed=95):
        self.catalog=catalog; self.cup_registry=cup_registry or {}; self.seed=int(seed); self.state=None
    @classmethod
    def from_file(cls,path,cup_registry=None,seed=95):
        return cls(json.loads(Path(path).read_text(encoding='utf-8')),cup_registry,seed)
    def new_career(self,season=2026):
        core=V94Core(self.catalog,self.seed,self.cup_registry)
        state=core.start(season); state['player']={'career_status':'active','controlled_club_id':None,'controlled_selection_id':None,'capital':0.0,'prestige':0.0}
        state['playable']={'phase':'club_selection','turn':0,'available_clubs':self._available_clubs()}
        self.state=state; return self.state
    def _available_clubs(self):
        # V95 respects the established club-entry model: initial entry is restricted
        # to clubs, with no invented clubs. Selection offers remain invitation-based.
        return sorted(self.catalog.get('clubs',{}), key=lambda cid:(-float(self.catalog['clubs'][cid].get('prestige',0)),cid))
    def choose_club(self,club_id):
        if self.state is None: raise RuntimeError('start career first')
        if club_id not in self.catalog.get('clubs',{}): raise ValueError('unknown club')
        self.state['player']['controlled_club_id']=club_id; self.state['playable']['phase']='club_season'; self.state['playable']['turn']=0
        return {'club_id':club_id,'club_name':self.catalog['clubs'][club_id].get('name')}
    def play_league(self,league_id=None):
        if self.state is None or self.state['playable']['phase']!='club_season': raise RuntimeError('choose a club first')
        cid=self.state['player']['controlled_club_id']; league_id=league_id or self.catalog['clubs'][cid].get('league_id')
        core=V94Core(self.catalog,self.seed,self.cup_registry); row=core.execute_league(self.state,league_id)
        self.state['playable']['turn']+=1; self.state['playable']['phase']='season_review'; self.state['events']=deepcopy(core.bus.events)
        return row
    def finish_season(self):
        if self.state is None: raise RuntimeError('start career first')
        core=V94Core(self.catalog,self.seed,self.cup_registry)
        # Reuse the existing world state; V94 closure is append-only via V93.
        core.stateful=True; core.bus.events=deepcopy(self.state.get('events',[])); core.close_season(self.state)
        self.state['playable']['phase']='career_review'; return self.state
    def standings(self):
        cid=self.state['player']['controlled_club_id']; lid=self.catalog['clubs'][cid].get('league_id')
        return self.state['world']['leagues_state'][lid].get('standings',[])
    def validate(self):
        errors=[]
        if not self.state: return ['game not initialized']
        if self.state.get('playable',{}).get('phase') not in {'club_selection','club_season','season_review','career_review'}: errors.append('invalid playable phase')
        cid=self.state.get('player',{}).get('controlled_club_id')
        if cid is not None and cid not in self.catalog.get('clubs',{}): errors.append('unknown controlled club')
        return errors
