"""V172 — Grande Atualização 1: World Core & Persistence.

Consolidates V168-V171 into one audited block. It does not replace sporting,
economic, promotion or calendar engines; it closes their persistence and audit
boundaries and records explicit data-pending states instead of fabricating clubs.
"""
from __future__ import annotations
import pickle
from copy import deepcopy
from .v167_global_season_integrity_gate import V167GlobalSeasonIntegrityGate
from .v168_world_state_persistence import V168WorldStatePersistence
from .v169_world_simulation_stress import V169WorldSimulationStress
from .v170_competition_lifecycle_audit import V170CompetitionLifecycleAudit
from .v171_domestic_promotion_audit import V171DomesticPromotionAudit
from .v91_economy_market import V91EconomyMarket
from .world_integrity import assert_world_integrity

class V172WorldCoreUpdate:
    VERSION='V172'; SCHEMA=1
    BLOCK=('V168','V169','V170','V171','V172')
    def __init__(self,save,seed=172): self.save=save; self.seed=int(seed)
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def run(self, *, seasons=3, start_season=None, economy_audit=True):
        snapshot=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        try:
            assert_world_integrity(self.save)
            persistence=V168WorldStatePersistence(self.save).validate()
            if persistence: raise ValueError('V168 persistence failed: '+ '; '.join(persistence))
            stress=V169WorldSimulationStress(self.save,seed=self.seed+169).run(seasons=seasons,start_season=start_season)
            last=int(stress['final_current_year'])-1
            lifecycle=V170CompetitionLifecycleAudit(self.save).run(last)
            domestic=V171DomesticPromotionAudit(self.save).run(last)
            economy=None
            if economy_audit:
                # Audit the existing V91 economy without introducing player transfers.
                economy=V91EconomyMarket(self.save).validate()
                if economy: raise ValueError('V172 economy integrity failed: '+ '; '.join(economy))
            assert_world_integrity(self.save)
            row={'version':self.VERSION,'schema':self.SCHEMA,'status':'completed','block':'Grande Atualização 1 — World Core & Persistence','internal_layers':['V168','V169','V170','V171'],'stress':deepcopy(stress),'competition_lifecycle':deepcopy(lifecycle),'domestic_promotion':deepcopy(domestic),'economy_validation':'PASS' if economy_audit else 'SKIPPED','player_layer_forbidden':True}
            self._history().setdefault('major_update_blocks',[]).append(deepcopy(row))
            self._world()['major_update_block']='V168-V172'; self._world()['major_update_block_status']='completed'; self._world()['major_update_block_version']=self.VERSION
            return deepcopy(row)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snapshot)); raise
    def validate(self):
        e=[]
        for r in self._history().get('major_update_blocks',[]):
            if r.get('version')!=self.VERSION or r.get('status')!='completed': e.append('invalid V172 block')
            if r.get('economy_validation') not in ('PASS','SKIPPED'): e.append('invalid V172 economy status')
        e.extend(V168WorldStatePersistence(self.save).validate())
        e.extend(V169WorldSimulationStress(self.save).validate())
        e.extend(V170CompetitionLifecycleAudit(self.save).validate())
        e.extend(V171DomesticPromotionAudit(self.save).validate())
        if 'players' in self._world() or 'player_transfers' in self._history(): e.append('player_system_forbidden')
        return e
