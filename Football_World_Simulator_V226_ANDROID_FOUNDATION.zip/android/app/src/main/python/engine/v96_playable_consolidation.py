"""V96 — Playable World Consolidation.

Connects the V95 playable career loop to the already implemented V91 economy,
V92 media/reputation and V93 historical layers without replacing them.
The match engine and the aggregate sporting model remain unchanged.
"""
from __future__ import annotations
from copy import deepcopy
from .v94_core_integration import V94Core
from .v91_economy_market import V91EconomyMarket
from .v92_media_reputation import V92MediaReputation
from .v93_historical_world import V93HistoricalWorld
from .v95_playable_game import V95PlayableGame


class V96PlayableConsolidation(V95PlayableGame):
    VERSION = "V96"

    def new_career(self, season=2026):
        state = super().new_career(season)
        state["version"] = self.VERSION
        state["integration"] = {
            "status": "initialized",
            "economy": None,
            "media_reputation": None,
            "history": None,
        }
        return state

    def _economy_save(self):
        """Create the V91-compatible world view from the canonical catalog.

        V89/V95 keep verified source data separate from generated season state;
        therefore V96 uses a simulation save adapter instead of mutating the
        verified catalog.
        """
        adapter = V91EconomyMarket.from_catalog(
            self.catalog,
            self.cup_registry,
            season=self.state["world"]["season"],
            seed=self.seed,
        )
        return adapter

    def _apply_economy(self, adapter):
        reports = {}
        clubs = adapter.save["world"].get("clubs", {})
        for cid, club in clubs.items():
            source = self.catalog.get("clubs", {}).get(cid, {})
            reports[cid] = {
                "cash": float(club.get("cash", source.get("cash", 0.0))),
                "market_value": float(club.get("market_value", source.get("market_value", 0.0))),
                "transfer_budget": float(club.get("transfer_budget", 0.0)),
                "economic_profile": deepcopy(club.get("economic_profile", {})),
                "economic_status": club.get("economic_status"),
                "last_economy": deepcopy(club.get("last_economy", {})),
            }
        # V95's world state intentionally stores catalog cardinality rather
        # than duplicating source club objects. Keep the economy as a linked
        # integration snapshot, not a second world database.
        return reports

    def _media_world(self):
        world = self.state["world"]
        return {
            "clubs": self.catalog.get("clubs", {}),
            "leagues_state": world.get("leagues_state", {}),
            "cup_champions": world.get("cup_results", {}) if isinstance(world.get("cup_results", {}), dict) else {},
        }

    def play_league(self, league_id=None):
        row = super().play_league(league_id)
        self.state["version"] = self.VERSION
        self.state["integration"]["status"] = "season_in_progress"
        return row

    def finish_season(self):
        if self.state is None:
            raise RuntimeError("start career first")
        if self.state["playable"]["phase"] != "season_review":
            raise RuntimeError("play a league before finishing the season")

        season = int(self.state["world"]["season"])

        # 1) Economy/market: use the existing V91 engine through an adapter.
        adapter = self._economy_save()
        economy_row = adapter.settle_season(ai_state=self.state.get("ai"))
        economy_reports = self._apply_economy(adapter)

        # 2) Media/reputation: consume the same sporting state plus economy
        #    results; no new sporting formula is introduced here.
        media_engine = V92MediaReputation(self.catalog, self.seed)
        media_state = media_engine.generate(
            self._media_world(), self.state.get("ai"), season
        )

        # 3) Close history append-only, including the newly connected layers.
        core = V94Core(self.catalog, self.seed, self.cup_registry)
        completed = {
            lid: r.get("standings", [])
            for lid, r in self.state["world"].get("leagues_state", {}).items()
            if r.get("status") == "completed"
        }
        # Recalculate movements from the actual current season state.
        from .world_dynamics import WorldDynamics
        movements = WorldDynamics(self.catalog, self.seed).apply_promotion_relegation(self.state["world"])

        history = V93HistoricalWorld(self.state)
        history_row = history.close_season(
            season,
            completed,
            self.state["world"].get("cup_results", {}),
            self.state["world"].get("continental_results", {}),
            movements,
            events=deepcopy(self.state.get("events", [])),
        )

        self.state["integration"] = {
            "status": "consolidated",
            "economy": {
                "summary": economy_row,
                "clubs": economy_reports,
            },
            "media_reputation": media_state,
            "history": {
                "season": season,
                "closed": history_row.get("status") == "closed",
                "source": history_row.get("source"),
            },
        }
        self.state["history"] = history.history
        self.state["playable"]["phase"] = "career_review"
        self.state["version"] = self.VERSION
        return self.state

    def validate(self):
        errors = []
        if not self.state:
            return ["game not initialized"]
        if self.state.get("version") != self.VERSION:
            errors.append("wrong version")
        errors.extend(super().validate())
        if self.state.get("version") != self.VERSION:
            # super() intentionally validates the V95 identity; V96 replaces
            # that only at the outer state boundary.
            errors = [e for e in errors if e != "wrong version"]
        integration = self.state.get("integration", {})
        if self.state.get("playable", {}).get("phase") == "career_review":
            if integration.get("status") != "consolidated":
                errors.append("integration not consolidated")
            if not integration.get("economy", {}).get("summary"):
                errors.append("economy integration missing")
            if integration.get("media_reputation", {}).get("engine") != "V92":
                errors.append("media/reputation integration missing")
            if not integration.get("history", {}).get("closed"):
                errors.append("history integration missing")
            errors.extend(V93HistoricalWorld(self.state).validate())
        return errors
