"""Compatibility facade for the V142 size-aware domestic pyramid rules."""
from .v142_domestic_pyramid_rules import *
