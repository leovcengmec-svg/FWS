class V191ClubStrategy:
    FOCUSES=('sporting','commercial','development','consolidation')
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}).setdefault('club_strategy',[])
    def set_focus(self,club_id,focus):
        if focus not in self.FOCUSES: raise ValueError('foco estratégico inválido')
        c=self.save['world']['clubs'][club_id]; c['strategic_focus']=focus; c['strategic_quality']=min(100,round(float(c.get('strategic_quality',50))+2,4))
        r={'club_id':club_id,'season':self.save['world'].get('current_year'),'focus':focus}; self.history.append(r); return r
    def set_targets(self,club_id,**targets):
        c=self.save['world']['clubs'][club_id]; c['board_targets']=dict(targets); r={'club_id':club_id,'season':self.save['world'].get('current_year'),'targets':dict(targets)}; self.history.append(r); return r
    def snapshot(self,club_id):
        c=self.save['world']['clubs'][club_id]; return {'club_id':club_id,'focus':c.get('strategic_focus','balanced'),'targets':c.get('board_targets',{}),'quality':c.get('strategic_quality',50)}
    def validate(self): return []
