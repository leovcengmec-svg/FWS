"""V182 — Unified career dashboard and action routing."""
from __future__ import annotations
from copy import deepcopy
from .v97_career_power_hub import V97CareerPowerHub

class V182CareerHub:
    VERSION='V182'
    def __init__(self, save, assets_root=None): self.save=save; self.hub=V97CareerPowerHub(save,assets_root)
    def snapshot(self):
        s=self.hub.snapshot()
        return {'version':self.VERSION,'career':deepcopy(s['career']),'active':deepcopy(s['active']),
                'owned_clubs':deepcopy(s['owned_clubs']),'world_year':s['world_year']}
    def actions(self):
        s=self.snapshot(); a=[]
        if s['career']['capital']>0: a += ['buy_club','invest']
        if s['career']['owned_clubs']: a += ['manage_club','sell_club','switch_club']
        if s['career']['selection_invitations']: a += ['review_selection_offers']
        if s['active'].get('selection_id'): a += ['manage_selection']
        a += ['world','calendar','history']
        return sorted(set(a))
    def validate(self): return self.hub.validate()
