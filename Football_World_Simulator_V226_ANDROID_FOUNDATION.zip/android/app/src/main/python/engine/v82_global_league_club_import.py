"""V82: deterministic importer for verified country league/club packs.

Only packs explicitly marked verified in the import manifest are promoted into
Global Football Database. Unknown fields remain unknown; no synthetic facts are
created to improve coverage percentages.
"""
import copy
import json
from pathlib import Path

class V82LeagueClubImporter:
    REQUIRED_LEAGUE_KEYS = {"id", "country_id", "level", "name", "data_status"}
    REQUIRED_CLUB_KEYS = {"id", "country_id", "league_id", "name", "data_status"}

    def __init__(self, catalog, completeness, manifest):
        self.catalog = catalog
        self.completeness = completeness
        self.manifest = manifest

    @classmethod
    def from_files(cls, catalog_path, completeness_path, manifest_path):
        load = lambda p: json.loads(Path(p).read_text(encoding="utf-8"))
        return cls(load(catalog_path), load(completeness_path), load(manifest_path))


    def _validate_tier_policy(self, pack):
        policy_path = Path(__file__).resolve().parents[1] / "data" / "global_league_tier_policy.json"
        policy = json.loads(policy_path.read_text(encoding="utf-8"))
        cid = pack["country_id"]
        rule = policy.get("country_overrides", {}).get(cid)
        if not rule:
            return []
        group = rule["group"]
        if group == "brazil_exception":
            return []
        target = rule["target_divisions"]
        levels = sorted(x.get("level") for x in pack.get("leagues", []))
        real_levels = int(pack.get("real_levels_checked", len(levels)))
        if group == "small" and levels != [1]:
            return [f"{cid}: small league system must contain exactly division 1"]
        if group == "intermediate" and levels != [1, 2] and real_levels >= 2:
            return [f"{cid}: intermediate league system must contain divisions 1 and 2 when two real levels exist"]
        if group in ("top_confederation", "top_five"):
            if real_levels <= 2 and levels != list(range(1, real_levels + 1)):
                return [f"{cid}: top-tier group must preserve all {real_levels} real national levels"]
            if real_levels >= 3 and not (3 <= len(levels) <= 5):
                return [f"{cid}: top-tier group must contain 3-5 divisions when 3+ real national levels exist"]
        return []

    def validate(self):
        errors = []
        for pack in self.manifest.get("packs", []):
            if pack.get("status") != "verified":
                continue
            errors.extend(self._validate_tier_policy(pack))
            cid = pack["country_id"]
            league_ids = set()
            for league in pack.get("leagues", []):
                missing = self.REQUIRED_LEAGUE_KEYS - set(league)
                if missing:
                    errors.append(f"{cid}: league missing {sorted(missing)}")
                if league["id"] in self.catalog["leagues"]:
                    errors.append(f"{cid}: duplicate league id {league['id']}")
                league_ids.add(league["id"])
            for club in pack.get("clubs", []):
                missing = self.REQUIRED_CLUB_KEYS - set(club)
                if missing:
                    errors.append(f"{cid}: club missing {sorted(missing)}")
                if club["id"] in self.catalog["clubs"]:
                    errors.append(f"{cid}: duplicate club id {club['id']}")
                if club["league_id"] not in league_ids and club["league_id"] not in self.catalog["leagues"]:
                    errors.append(f"{cid}: club {club['id']} references unknown league {club['league_id']}")
        return errors

    def apply(self):
        errors = self.validate()
        if errors:
            raise ValueError("; ".join(errors))
        applied = []
        for pack in self.manifest.get("packs", []):
            if pack.get("status") != "verified":
                continue
            cid = pack["country_id"]
            for league in pack.get("leagues", []):
                row = copy.deepcopy(league)
                row.setdefault("asset", {"id": row["id"], "path": None, "type": "league"})
                self.catalog["leagues"][row["id"]] = row
            for club in pack.get("clubs", []):
                row = copy.deepcopy(club)
                row.setdefault("asset", {"id": row["id"], "path": None, "type": "club"})
                self.catalog["clubs"][row["id"]] = row
            assoc = self.catalog["associations"][cid]
            assoc["league_pack_status"] = "verified"
            assoc["club_pack_status"] = "verified"
            comp = self.completeness["countries"][cid]["checklist"]
            comp["leagues_divisions"] = {"status": "confirmed", "evidence": pack["source_note"]}
            comp["clubs"] = {"status": "confirmed", "evidence": pack["source_note"]}
            comp["competitions"] = {"status": "partial", "evidence": "Domestic league competition imported; full competition inventory remains pending."}
            comp["visual_assets"] = {"status": "partial", "evidence": "League/club records imported without asserting complete crest/logo coverage."}
            comp["city"] = {"status": "not_verified", "evidence": "Not asserted by this V82 pack."}
            comp["stadium"] = {"status": "not_verified", "evidence": "Not asserted by this V82 pack."}
            comp["capacity"] = {"status": "not_verified", "evidence": "Not asserted by this V82 pack."}
            comp["provenance"] = {"status": "confirmed", "evidence": pack["source_note"]}
            comp["validation"] = {"status": "confirmed", "evidence": "V82 schema, ID and relationship validation passed."}
            applied.append(cid)
        self.catalog["version"] = "V82"
        self.completeness["version"] = "V82"
        return applied
