"""V180.1 — Career Experience Completion.

Closes the remaining playable-career gaps found after V180:
* Brazil create-from-zero starts in the selected state's lowest loaded state
  division and can feed the annual 256-place national Access qualification.
* National-team management exposes aggregate strategic and development
  decisions without introducing individual players or player transfers.
* Investor + club presidency + national-team management remain simultaneous.
"""
from __future__ import annotations
from copy import deepcopy
import json
from pathlib import Path

VERSION = "V180.1"
ACCESS_SIZE = 256
BRAZIL = "BRA"

class V1801CareerExperienceCompletion:
    VERSION = VERSION

    @staticmethod
    def _catalog_path():
        return Path(__file__).resolve().parent.parent / "data" / "v172_4_brazil_state_database.json"

    @classmethod
    def brazil_state_options(cls):
        data=json.loads(cls._catalog_path().read_text(encoding="utf-8"))
        return {
            uf: {
                "name": row.get("state", uf),
                "championship": row.get("championship"),
                "lowest_division": max((d.get("level", 1) for d in row.get("divisions", [])), default=1),
                "competition_id": max(row.get("divisions", []), key=lambda d:d.get("level",1)).get("competition_id") if row.get("divisions") else None,
            }
            for uf,row in data.get("states", {}).items()
        }

    @classmethod
    def brazil_creation_target(cls, state_code):
        state_code=str(state_code).upper()
        opts=cls.brazil_state_options()
        if state_code not in opts:
            raise ValueError("estado brasileiro inválido ou sem estadual cadastrado")
        return deepcopy(opts[state_code])

    @classmethod
    def create_brazil_club(cls, creator, club_id, name, city, colors, state_code, image_file=None, starting_cash=2.0):
        target=cls.brazil_creation_target(state_code)
        if not getattr(creator, "assets", None):
            raise ValueError("assets_root necessário para criar clube")
        if club_id in creator.save["world"]["clubs"]:
            raise ValueError("id já existe")
        leagues=creator.save["world"].setdefault("leagues", {})
        league_id=target["competition_id"]
        league=leagues.setdefault(league_id, {
            "id": league_id,
            "name": f"{target['name']} - divisão {target['lowest_division']}",
            "country_id": BRAZIL,
            "level": target["lowest_division"],
            "type": "state_league",
            "state_code": str(state_code).upper(),
            "club_ids": [],
            "active": True,
        })
        club={
            "id":club_id,"name":name,"country_id":BRAZIL,"city":city,
            "league_id":league_id,"division":target["lowest_division"],
            "state_code":str(state_code).upper(),
            "state_competition_id":league_id,
            "state_division_level":target["lowest_division"],
            "state_roster_status":"created_user_club",
            "attack":22,"defense":22,"prestige":10,"cash":starting_cash,
            "market_value":max(0.5,starting_cash*1.5),
            "created_by_user":True,"career_origin":"created_from_zero_brazil_state",
            "owner_type":"user_investor","owner_id":"player","colors":colors,
            "brazil_access_status":"awaiting_state_championship_result",
            "asset":{"type":"user_club","id":club_id,"path":None}
        }
        if image_file:
            club["asset"]["path"]=creator.assets.register("user_club",club_id,image_file)
        creator.save["world"]["clubs"][club_id]=club
        league.setdefault("club_ids",[]).append(club_id)
        creator.save.setdefault("world",{}).setdefault("custom_clubs",[]).append(club_id)
        investor = creator.save.setdefault("careers", {}).setdefault("investor", {})
        # Older/fresh integrated careers may not yet contain the custom-club
        # ledger. Add only missing fields and preserve the current career state.
        investor.setdefault("cash", 0.0)
        investor.setdefault("owned_clubs", [])
        investor.setdefault("transactions", [])
        investor.setdefault("created_clubs", [])
        if club_id not in investor["owned_clubs"]:
            investor["owned_clubs"].append(club_id)
        if club_id not in investor["created_clubs"]:
            investor["created_clubs"].append(club_id)
        creator.save.setdefault("history",{}).setdefault("brazil_created_clubs",[]).append({
            "club_id":club_id,"state_code":str(state_code).upper(),
            "state_competition_id":league_id,"state_division_level":target["lowest_division"],
            "season":creator.save["world"].get("current_year")
        })
        return deepcopy(club)

    @staticmethod
    def register_state_result(save, club_id, performance_score, points=0, goal_difference=0, goals_for=0, final_position=None, division_level=None):
        club=save.get("world",{}).get("clubs",{}).get(club_id)
        if not club or club.get("country_id") != BRAZIL:
            raise ValueError("clube brasileiro inexistente")
        row={"state_result_valid":True,"performance_score":float(performance_score),"points":float(points),
             "goal_difference":float(goal_difference),"goals_for":float(goals_for)}
        if final_position is not None: row["final_position"]=int(final_position)
        if division_level is not None: row["division_level"]=int(division_level)
        season=str(save.get("world",{}).get("current_year",2026))
        save.setdefault("history",{}).setdefault("brazil_state_results",{}).setdefault(season,{})[club_id]=row
        club["brazil_access_status"]="state_result_recorded"
        return deepcopy(row)

    @classmethod
    def qualify_brazil_access(cls, save, state_results=None, season=None):
        from .v172_4_brazil_state_database import V1724BrazilStateDatabase
        catalog=json.loads(cls._catalog_path().read_text(encoding="utf-8"))
        if state_results is None:
            year=str(season or save.get("world",{}).get("current_year",2026))
            state_results=save.get("history",{}).get("brazil_state_results",{}).get(year,{})
        # User-created Brazilian clubs are persistent members of the state registry
        # even though they did not exist in the original static catalog file.
        catalog["all_club_ids"]=list(dict.fromkeys(list(catalog.get("all_club_ids",[]))+[
            cid for cid,club in save.get("world",{}).get("clubs",{}).items()
            if club.get("country_id")==BRAZIL and club.get("career_origin")=="created_from_zero_brazil_state"
        ]))
        national={cid for cid,club in save.get("world",{}).get("clubs",{}).items() if club.get("league_id") in {f"BRA-BR-{i}" for i in range(1,7)}}
        result=V1724BrazilStateDatabase(save).run(catalog,state_results,national,season or save.get("world",{}).get("current_year",2026))
        access=set(result.get("access",{}).get("club_ids",[]))
        for cid in access:
            club=save.get("world",{}).get("clubs",{}).get(cid)
            if club and club.get("career_origin")=="created_from_zero_brazil_state":
                club["brazil_access_status"]="qualified_for_access"
                club["league_id"]="BRA-ACCESS"
                club["division"]=7
        return result

    @staticmethod
    def set_selection_strategy(save, team_id, strategy, intensity=50, rotation_policy="balanced"):
        teams=save.get("world",{}).get("national_teams",{})
        if team_id not in teams: raise ValueError("seleção inexistente")
        allowed={"balanced","development","competitive","defensive","offensive","tournament"}
        if strategy not in allowed: raise ValueError("estratégia de seleção inválida")
        intensity=max(0,min(100,float(intensity)))
        team=teams[team_id]
        team["management_strategy"]={"strategy":strategy,"intensity":round(intensity,2),"rotation_policy":rotation_policy}
        decision={"type":"selection_strategy","team_id":team_id,"strategy":strategy,"intensity":round(intensity,2),"rotation_policy":rotation_policy,"season":save.get("world",{}).get("current_year")}
        save.setdefault("careers",{}).setdefault("active_management",{}).setdefault("selection_decisions",[]).append(decision)
        return deepcopy(decision)

    @staticmethod
    def invest_selection(save, team_id, amount, category="training", investor_id="player"):
        from .selection_development import SelectionDevelopment
        if amount <= 0: raise ValueError("valor do investimento deve ser positivo")
        dev=SelectionDevelopment(save, __import__("random").Random(1801))
        result=dev.invest(team_id,float(amount),category,investor_id)
        result["decision_type"]="selection_investment"
        save.setdefault("careers",{}).setdefault("active_management",{}).setdefault("selection_decisions",[]).append(deepcopy(result))
        return result

    @classmethod
    def validate(cls, save):
        errors=[]
        teams=save.get("world",{}).get("national_teams",{})
        active=save.get("careers",{}).get("active_management",{})
        sel=active.get("active_selection_id")
        if sel and sel not in teams: errors.append("active_selection_missing")
        for cid,club in save.get("world",{}).get("clubs",{}).items():
            if club.get("career_origin")=="created_from_zero_brazil_state":
                if club.get("country_id")!=BRAZIL: errors.append(f"brazil_created_wrong_country:{cid}")
                if not club.get("state_code") or not club.get("state_competition_id"): errors.append(f"brazil_created_missing_state:{cid}")
                if club.get("brazil_access_status") not in {"awaiting_state_championship_result","state_result_recorded","qualified_for_access"}: errors.append(f"brazil_created_invalid_access_status:{cid}")
        return sorted(set(errors))
