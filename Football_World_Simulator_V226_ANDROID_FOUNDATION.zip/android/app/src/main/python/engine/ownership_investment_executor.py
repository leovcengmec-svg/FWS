class OwnershipInvestmentExecutor:
    """Executes planned ownership investments with delayed, bounded effects.

    Spending is represented as applied investment, not as an automatic sporting
    boost. Each priority accumulates a management score and a small, bounded
    readiness effect that future systems can consume probabilistically.
    """
    EFFECT_RATES = {
        'infrastructure': 0.010,
        'commercial': 0.012,
        'youth': 0.011,
        'scouting': 0.010,
        'sporting': 0.009,
    }

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('ownership_investment_executions', [])

    def execute(self, plan, season=None):
        if plan.get('status') != 'planned':
            raise ValueError('plano não está pendente')
        club_id = plan['club_id']
        club = self.save['world']['clubs'][club_id]
        season = self.save['world'].get('current_year') if season is None else season
        state = club.setdefault('investment_effects', {})
        applied = {}
        total_effect = 0.0
        for priority, amount in plan.get('allocations', {}).items():
            amount = max(0.0, float(amount))
            state[priority] = round(float(state.get(priority, 0.0)) + amount, 2)
            effect = round(amount * self.EFFECT_RATES[priority], 4)
            applied[priority] = {'amount': round(amount, 2), 'effect': effect}
            total_effect += effect
        state['management_readiness'] = round(min(100.0, float(state.get('management_readiness', 0.0)) + total_effect), 4)
        record = {
            'club_id': club_id,
            'season': season,
            'requested_budget': plan.get('requested_budget', 0.0),
            'applied_budget': round(sum(x['amount'] for x in applied.values()), 2),
            'applied': applied,
            'management_readiness': state['management_readiness'],
            'status': 'executed',
        }
        plan['status'] = 'executed'
        plan['executed_season'] = season
        self.history.append(record)
        return record
