"""V187 — Club acquisition, sale, valuation and ownership consequences."""
from __future__ import annotations
from copy import deepcopy
from .v186_investor_finance import V186InvestorFinance
class V187ClubOwnershipValue:
    VERSION='V187'
    def __init__(self, save): self.save=save; self.fin=V186InvestorFinance(save)
    def buy(self, club_id, price=None):
        club=self.save.get('world',{}).get('clubs',{}).get(club_id)
        if not club: raise ValueError('club not found')
        price=float(price if price is not None else club.get('market_value',0))
        if price<=0 or price>float(self.fin.investor.get('cash',0)): raise ValueError('insufficient cash')
        if club_id in self.fin.investor.setdefault('owned_clubs',[]): return deepcopy(club)
        self.fin.investor['cash']=round(float(self.fin.investor['cash'])-price,2)
        self.fin.investor['owned_clubs'].append(club_id); club['owner_type']='user_investor'; club['owner_id']='player'; club['ownership_history']=club.setdefault('ownership_history',[])+[{'action':'buy','price':price,'season':self.save['world'].get('current_year')}]
        self.fin._tx('purchase',price,club_id,'club_acquisition')
        return deepcopy(club)
    def sell(self, club_id, price=None):
        if club_id not in self.fin.investor.get('owned_clubs',[]): raise ValueError('club not owned')
        club=self.save['world']['clubs'][club_id]; price=float(price if price is not None else club.get('market_value',0))
        if price<=0: raise ValueError('invalid sale price')
        self.fin.investor['owned_clubs'].remove(club_id); self.fin.investor['cash']=round(float(self.fin.investor['cash'])+price,2)
        club['owner_type']='market'; club['owner_id']=None; club.setdefault('ownership_history',[]).append({'action':'sell','price':price,'season':self.save['world'].get('current_year')})
        self.fin._tx('sale',price,club_id,'club_sale')
        return {'club_id':club_id,'price':price,'cash':self.fin.investor['cash']}
    def valuation(self, club_id):
        c=self.save['world']['clubs'][club_id]; base=max(0.1,float(c.get('market_value',0))); prestige=max(0,float(c.get('prestige',0))); cash=max(0,float(c.get('cash',0)))
        value=base*(1+min(0.50,prestige/2000))+cash*0.10
        c['market_value']=round(value,3); return c['market_value']
    def validate(self):
        clubs=self.save.get('world',{}).get('clubs',{}); ids=self.fin.investor.get('owned_clubs',[])
        return [f'owned_missing:{x}' for x in ids if x not in clubs]
