class FinancialForecast:
    """V32: non-mutating financial projections based on the existing investor ledger."""
    def __init__(self, save):
        from .investor_finance import InvestorFinance
        self.save = save
        self.finance = InvestorFinance(save)

    def _averages(self, weeks=8):
        rows = [r for r in self.finance.history[-weeks:] if 'income' in r and 'expenses' in r]
        if not rows:
            return 0.0, 0.0
        income = sum(float(r.get('income', 0.0)) for r in rows) / len(rows)
        expenses = sum(float(r.get('expenses', 0.0)) for r in rows) / len(rows)
        return income, expenses

    def project(self, weeks=12, scenario='base', history_weeks=8):
        weeks = int(weeks)
        if weeks < 1 or weeks > 520:
            raise ValueError('horizonte inválido')
        if scenario not in {'base', 'pressure', 'recovery'}:
            raise ValueError('cenário inválido')
        income, expenses = self._averages(history_weeks)
        if not self.finance.history:
            income = float(self.finance.rules.get('weekly_base_income', 0.0))
            expenses = float(self.finance.rules.get('weekly_admin_expense', 0.0)) + float(self.finance.rules.get('weekly_financial_obligation', 0.0))
        if scenario == 'pressure':
            income *= 0.80
            expenses *= 1.15
        elif scenario == 'recovery':
            income *= 1.10
            expenses *= 0.95
        flow = income - expenses
        available = self.finance.available_cash()
        points = []
        cash = available
        for week in range(1, weeks + 1):
            cash = round(max(0.0, cash + flow), 2)
            points.append({'week': week, 'available_cash': cash, 'weekly_flow': round(flow, 2)})
        depletion = None
        if flow < 0 and available > 0:
            depletion = round(available / abs(flow), 2)
        return {
            'scenario': scenario,
            'weeks': weeks,
            'starting_available_cash': round(available, 2),
            'average_weekly_income': round(income, 2),
            'average_weekly_expenses': round(expenses, 2),
            'projected_weekly_flow': round(flow, 2),
            'projected_available_cash': points[-1]['available_cash'],
            'cash_depletion_weeks': depletion,
            'points': points,
        }

    def horizons(self, scenario='base'):
        return {str(w): self.project(w, scenario=scenario) for w in (4, 12, 52)}
