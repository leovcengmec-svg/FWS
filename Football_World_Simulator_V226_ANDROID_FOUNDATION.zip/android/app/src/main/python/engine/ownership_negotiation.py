class OwnershipNegotiation:
    """Competitive negotiation layer above V36 marketplace.

    It manages competing offers, counteroffers and withdrawals without moving
    cash or changing ownership. Settlement remains exclusively V35 atomic.
    """
    def __init__(self, save, marketplace):
        self.save = save
        self.marketplace = marketplace

    def _offer(self, offer_id):
        for offer in self.marketplace.offers:
            if offer['id'] == offer_id:
                return offer
        raise ValueError('oferta inexistente')

    def _listing(self, listing_id):
        return self.marketplace._listing(listing_id)

    def competing_offers(self, listing_id):
        listing = self._listing(listing_id)
        offers = [o.copy() for o in self.marketplace.offers
                  if o['listing_id'] == listing_id and o['status'] == 'pending']
        offers.sort(key=lambda x: (-float(x['price']), x['id']))
        return offers

    def counter_offer(self, offer_id, price):
        offer = self._offer(offer_id)
        if offer['status'] != 'pending':
            raise ValueError('oferta já encerrada')
        price = float(price)
        if price <= 0:
            raise ValueError('preço da contraproposta inválido')
        offer['status'] = 'countered'
        counter = {
            'id': self.marketplace._next_id('offer'),
            'listing_id': offer['listing_id'],
            'club_id': offer['club_id'],
            'buyer': offer['buyer'],
            'price': round(price, 2),
            'status': 'pending',
            'counter_to': offer['id'],
            'season': self.save.get('world', {}).get('current_year')
        }
        self.marketplace.offers.append(counter)
        return counter.copy()

    def withdraw_offer(self, offer_id):
        offer = self._offer(offer_id)
        if offer['status'] != 'pending':
            raise ValueError('oferta não está pendente')
        offer['status'] = 'withdrawn'
        return offer.copy()

    def accept_selected_offer(self, listing_id, offer_id):
        listing = self._listing(listing_id)
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        offer = self._offer(offer_id)
        if offer['listing_id'] != listing_id:
            raise ValueError('oferta não pertence ao anúncio')
        if offer['status'] != 'pending':
            raise ValueError('oferta não está pendente')
        # Close the selected offer and invalidate other pending offers.
        offer['status'] = 'accepted'
        for other in self.marketplace.offers:
            if other['listing_id'] == listing_id and other['id'] != offer_id and other['status'] == 'pending':
                other['status'] = 'superseded'
        return self.marketplace.accepted_offer(offer_id)
