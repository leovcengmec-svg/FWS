"""V210 — Integrated History & Legacy gate."""
from __future__ import annotations
from copy import deepcopy
from .v206_history_eras import V206HistoryEras
from .v207_legacy_records import V207LegacyRecords
from .v208_hall_of_fame import V208HallOfFame
from .v209_career_legacy import V209CareerLegacy

class V210HistoryLegacyIntegration:
    VERSION='V210'; CHAIN=['V206','V207','V208','V209','V210']
    def __init__(self,save):
        self.save=save; self.eras=V206HistoryEras(save); self.records=V207LegacyRecords(save); self.hof=V208HallOfFame(save); self.career=V209CareerLegacy(save)
    def close(self,season=None):
        year=int(self.save.setdefault('world',{}).get('current_year',2026) if season is None else season)
        h=self.save.setdefault('history',{}); cycles=h.setdefault('history_legacy_cycles',[])
        prior=next((x for x in reversed(cycles) if int(x.get('season',-1))==year),None)
        if prior is not None: return dict(prior,idempotent_replay=True)
        eras=self.eras.build(year); records=self.records.rebuild(); hof=self.hof.rebuild(); career=self.career.close_season(year)
        row={'version':self.VERSION,'season':year,'eras':len(eras),'clubs':len(records['clubs']),'selections':len(records['selections']),'hof_clubs':len(hof['clubs']),'career_season':career['season'],'player_layer_forbidden':True,'chain':list(self.CHAIN)}
        cycles.append(row); cycles.sort(key=lambda x:x['season']); self.save.setdefault('world',{})['history_legacy_status']='ready'; self.save['world']['history_legacy_version']=self.VERSION
        return deepcopy(row)
    def snapshot(self):
        return {'version':self.VERSION,'eras':self.eras.current(),'hall_of_fame':deepcopy(self.hof.hof),'career_legacy':self.career.snapshot()}
    def validate(self): return self.eras.validate()+self.records.validate()+self.hof.validate()+self.career.validate()
