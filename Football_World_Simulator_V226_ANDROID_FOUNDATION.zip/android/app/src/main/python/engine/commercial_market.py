class CommercialMarket:
    """Broadcast and sponsorship rights driven by brand, competition and performance."""
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('commercial_market', [])

    def ensure_club(self, club):
        club.setdefault('broadcast_power', max(5.0, float(club.get('brand_strength', 20.0)) * .65))
        club.setdefault('sponsorship_power', max(5.0, float(club.get('commercial_strength', 20.0))))
        return club

    def season_club(self, club_id, league_position=None, league_size=None, continental=False):
        club = self.save['world']['clubs'][club_id]
        self.ensure_club(club)
        brand = float(club.get('brand_strength', 20.0))
        commercial = float(club.get('commercial_strength', 20.0))
        prestige = float(club.get('prestige', 20.0))
        commercial_capacity = max(0.0, min(100.0, float(club.get('marketing_level', 40.0))))
        infrastructure_capacity = max(0.0, min(100.0, float(club.get('infrastructure_score', 40.0))))
        size = max(1, int(league_size or 1))
        pos = int(league_position or size)
        performance = max(0.0, 1.0 - (pos - 1) / max(1, size - 1)) if size > 1 else 1.0
        continental_factor = 1.25 if continental else 1.0
        capacity_factor = 1.0 + (commercial_capacity - 40.0) * 0.0015
        infrastructure_factor = 1.0 + (infrastructure_capacity - 40.0) * 0.0010
        broadcast = max(1.0, (brand*.045 + prestige*.025 + performance*1.5) * continental_factor * infrastructure_factor)
        sponsorship = max(1.0, (commercial*.055 + prestige*.035 + performance*1.25) * capacity_factor)
        club['broadcast_power'] = max(1.0, min(100.0, club['broadcast_power']*.85 + brand*.15 + (infrastructure_capacity-40.0)*.015))
        club['sponsorship_power'] = max(1.0, min(100.0, club['sponsorship_power']*.85 + commercial*.15 + (commercial_capacity-40.0)*.015))
        row = {'season':self.save['world']['current_year'], 'club_id':club_id,
               'broadcast_revenue':round(broadcast,2), 'sponsorship_revenue':round(sponsorship,2), 'commercial_capacity':round(commercial_capacity,2),
               'infrastructure_capacity':round(infrastructure_capacity,2),
               'continental':bool(continental)}
        self.history.append(row)
        return row

    def season_selection(self, team_id):
        team = self.save['world']['national_teams'][team_id]
        reputation = float(team.get('global_reputation', team.get('prestige', 20.0)))
        commercial = float(team.get('commercial_reputation', reputation*.9))
        federation_media = max(0.5, reputation*.018 + commercial*.012)
        federation_sponsors = max(0.5, commercial*.022)
        row = {'season':self.save['world']['current_year'], 'team_id':team_id,
               'media_value':round(federation_media,2), 'sponsorship_value':round(federation_sponsors,2),
               'investor_return':0.0}
        self.history.append(row)
        return row
