from dataclasses import dataclass, asdict
from datetime import date, timedelta

@dataclass
class Fixture:
    id:str
    season:int
    date:str
    competition_id:str
    round_no:int
    home_id:str
    away_id:str
    status:str="scheduled"

class CalendarEngine:
    """Central fixture calendar. One club cannot be scheduled twice on the same day."""
    def __init__(self, season, start_date=None):
        self.season=season
        self.start_date=date.fromisoformat(start_date) if start_date else date(season,8,1)
        self.fixtures=[]
        self.reserved=set()

    def reserve_window(self, start, end, reason, scope=None):
        d=date.fromisoformat(start); e=date.fromisoformat(end)
        scope=scope or "global"
        while d<=e:
            self.reserved.add((d.isoformat(),scope,reason))
            d+=timedelta(days=1)

    def _is_free(self, day, home, away):
        for f in self.fixtures:
            if f.date==day and (f.home_id in (home,away) or f.away_id in (home,away)):
                return False
        return True

    def schedule(self, competition_id, round_no, matches, preferred_day=None):
        day=self.start_date if preferred_day is None else date.fromisoformat(preferred_day)
        created=[]
        for home,away in matches:
            # Avoid same-day conflicts and globally reserved windows.
            while (day.isoformat(),"global","blocked") in self.reserved or not self._is_free(day.isoformat(),home["id"],away["id"]):
                day+=timedelta(days=1)
            fixture=Fixture(
                id=f"{competition_id}-{self.season}-{round_no}-{len(self.fixtures)+1}",
                season=self.season,date=day.isoformat(),competition_id=competition_id,
                round_no=round_no,home_id=home["id"],away_id=away["id"])
            self.fixtures.append(fixture); created.append(fixture)
            day+=timedelta(days=1)
        return created

    def detect_conflicts(self):
        seen={}
        conflicts=[]
        for f in self.fixtures:
            for cid in (f.home_id,f.away_id):
                key=(f.date,cid)
                if key in seen:
                    conflicts.append((seen[key],f.id,cid,f.date))
                else: seen[key]=f.id
        return conflicts

    def export(self):
        return [asdict(f) for f in self.fixtures]
