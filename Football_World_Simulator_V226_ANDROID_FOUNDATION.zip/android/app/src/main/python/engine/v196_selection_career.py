"""V196 — Selection career ladder and invitation lifecycle."""
from __future__ import annotations
from copy import deepcopy

class V196SelectionCareer:
    VERSION = 'V196'
    TIERS = ((20,'EMERGING'),(40,'REGIONAL'),(60,'INTERNATIONAL'),(80,'ELITE'),(101,'WORLD'))
    def __init__(self, save, legacy=None):
        self.save = save
        self.career = save.setdefault('careers', {}).setdefault('selection', {})
        self.career.setdefault('manager_prestige', 0.0)
        self.career.setdefault('current_team_id', None)
        self.career.setdefault('history', [])
        self.career.setdefault('invitations', [])
        self.career.setdefault('declined', [])
        self.career.setdefault('offers', {})
        self.history = save.setdefault('history', {}).setdefault('selection_career_v196', [])
        self.legacy = legacy
    @staticmethod
    def clamp(v): return max(0.0, min(100.0, round(float(v),4)))
    def tier(self, prestige=None):
        p=self.career.get('manager_prestige',0) if prestige is None else prestige
        for limit,name in self.TIERS:
            if p < limit: return name
        return 'WORLD'
    def eligible(self):
        p=float(self.career.get('manager_prestige',0)); teams=self.save['world'].get('national_teams',{})
        return sorted([tid for tid,t in teams.items() if float(t.get('manager_prestige_required',10))<=p])
    def generate_offers(self):
        cur=self.career.get('current_team_id'); eligible=[x for x in self.eligible() if x!=cur]
        offers={}
        for tid in eligible:
            t=self.save['world']['national_teams'][tid]
            offers[tid]={'team_id':tid,'season':self.save['world'].get('current_year'),'required_prestige':float(t.get('manager_prestige_required',10)),'status':'pending'}
        self.career['offers']=offers
        self.career['invitations']=sorted(offers)
        row={'version':self.VERSION,'season':self.save['world'].get('current_year'),'type':'offers_generated','offers':deepcopy(offers)}
        self.history.append(row); return deepcopy(offers)
    def accept(self, team_id):
        offers=self.career.get('offers',{})
        if team_id not in offers: raise ValueError('seleção não enviou convite')
        old=self.career.get('current_team_id'); year=self.save['world'].get('current_year')
        if old:
            self.career['history'].append({'team_id':old,'ended_season':year,'type':'selection_exit'})
        offers[team_id]['status']='accepted'; offers[team_id]['accepted_season']=year
        self.career['current_team_id']=team_id
        self.career['invitations']=[x for x in self.career.get('invitations',[]) if x!=team_id]
        self.career['history'].append({'team_id':team_id,'started_season':year,'type':'selection_appointment'})
        row={'version':self.VERSION,'season':year,'type':'accepted','team_id':team_id,'previous_team_id':old}
        self.history.append(row); return row
    def decline(self, team_id):
        if team_id not in self.career.get('offers',{}): raise ValueError('oferta inexistente')
        self.career['offers'][team_id]['status']='declined'; self.career['declined'].append({'team_id':team_id,'season':self.save['world'].get('current_year')})
        self.career['invitations']=[x for x in self.career.get('invitations',[]) if x!=team_id]
        row={'version':self.VERSION,'season':self.save['world'].get('current_year'),'type':'declined','team_id':team_id}; self.history.append(row); return row
    def snapshot(self):
        return {'version':self.VERSION,'prestige':self.clamp(self.career.get('manager_prestige',0)),'tier':self.tier(),'current_team_id':self.career.get('current_team_id'),'offers':deepcopy(self.career.get('offers',{})),'history_count':len(self.history)}
    def validate(self): return []
