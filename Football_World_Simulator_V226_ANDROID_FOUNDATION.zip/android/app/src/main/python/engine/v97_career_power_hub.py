"""V97 — Career & Power Hub.

Unifies the already implemented user-power systems without replacing them:
- investor capital and club ownership
- invitation-based national-team career
- active club + active selection management
- executive/strategic management
- club creation from zero

This layer is an orchestration/view layer. It does not create a player registry
and does not replace the aggregate match engine or the autonomous world.
"""
from __future__ import annotations

from copy import deepcopy

from .investor_career import InvestorCareer
from .selection_career import SelectionCareer
from .active_executive import ActiveExecutive
from .create_club_career import CreateClubCareer
from .ownership_market import OwnershipMarket


class V97CareerPowerHub:
    VERSION = "V97"

    def __init__(self, save, assets_root=None):
        self.save = save
        self.investor = InvestorCareer(save)
        self.selection = SelectionCareer(save)
        self.active = ActiveExecutive(save)
        self.ownership = OwnershipMarket(save)
        self.assets_root = assets_root

    def initialize(self, starting_cash=None, manager_prestige=None):
        """Initialize only missing career values; never overwrite progress."""
        career = self.save.setdefault("careers", {})
        inv = career.setdefault("investor", {
            "cash": 0.0, "owned_clubs": [], "transactions": [], "created_clubs": []
        })
        sel = career.setdefault("selection", {
            "manager_prestige": 0.0, "current_team_id": None,
            "history": [], "invitations": [], "declined": []
        })
        if starting_cash is not None and "cash" not in inv:
            inv["cash"] = float(starting_cash)
        if manager_prestige is not None and "manager_prestige" not in sel:
            sel["manager_prestige"] = float(manager_prestige)
        self.selection.generate_invitations()
        return self.snapshot()

    def snapshot(self):
        """Return one read-only-style view of the user's current power."""
        entities = self.active.active.active_entities()
        return {
            "version": self.VERSION,
            "career": {
                "capital": round(float(self.investor.career.get("cash", 0.0)), 2),
                "owned_clubs": list(self.investor.career.get("owned_clubs", [])),
                "created_clubs": list(self.investor.career.get("created_clubs", [])),
                "manager_prestige": float(self.selection.career.get("manager_prestige", 0.0)),
                "selection_tier": self.selection.tier(),
                "selection_invitations": list(self.selection.career.get("invitations", [])),
            },
            "active": deepcopy(entities),
            "owned_clubs": self.active.active.owned_clubs_overview(),
            "world_year": self.save.get("world", {}).get("current_year"),
        }

    def buy_club(self, club_id):
        return self.investor.buy_club(club_id)

    def sell_club(self, club_id):
        return self.investor.sell_club(club_id)

    def make_selection_invitations(self):
        return self.selection.generate_invitations()

    def accept_selection_invitation(self, team_id):
        return self.selection.accept_invitation(team_id)

    def activate_owned_club(self, club_id):
        return self.active.active.assume_club(club_id)

    def activate_selection(self):
        return self.active.active.assume_selection()

    def executive_dashboard(self):
        return self.active.executive_dashboard()

    def ownership_offer(self, club_id, buyer_type="external", premium=0.0):
        return self.ownership.offer(club_id, buyer_type, premium)

    def create_club_from_zero(self, club_id, name, country_id, city, colors,
                              image_file=None, starting_cash=2.0, state_code=None):
        if not self.assets_root:
            raise ValueError("assets_root necessário para criar clube")
        creator = CreateClubCareer(self.save, self.assets_root)
        return creator.create_from_zero(
            club_id, name, country_id, city, colors,
            image_file=image_file, starting_cash=starting_cash, state_code=state_code
        )

    def qualify_brazil_access(self, state_results=None, season=None):
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.qualify_brazil_access(self.save, state_results, season)

    def set_selection_strategy(self, team_id, strategy, intensity=50, rotation_policy="balanced"):
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.set_selection_strategy(self.save, team_id, strategy, intensity, rotation_policy)

    def invest_in_selection(self, team_id, amount, category="training", investor_id="player"):
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.invest_selection(self.save, team_id, amount, category, investor_id)

    def record_brazil_state_result(self, club_id, performance_score, points=0, goal_difference=0, goals_for=0, final_position=None, division_level=None):
        from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
        return V1801CareerExperienceCompletion.register_state_result(self.save, club_id, performance_score, points, goal_difference, goals_for, final_position, division_level)

    def validate(self):
        errors = []
        careers = self.save.get("careers", {})
        investor = careers.get("investor", {})
        selection = careers.get("selection", {})
        clubs = self.save.get("world", {}).get("clubs", {})
        teams = self.save.get("world", {}).get("national_teams", {})

        for club_id in investor.get("owned_clubs", []):
            if club_id not in clubs:
                errors.append(f"owned club missing: {club_id}")
        current_team = selection.get("current_team_id")
        if current_team is not None and current_team not in teams:
            errors.append("current selection missing")
        active = self.active.active.active_entities()
        if active["club_id"] and active["club_id"] not in investor.get("owned_clubs", []):
            errors.append("active club is not owned")
        if active["selection_id"] and active["selection_id"] != current_team:
            errors.append("active selection differs from selection career")
        return errors
