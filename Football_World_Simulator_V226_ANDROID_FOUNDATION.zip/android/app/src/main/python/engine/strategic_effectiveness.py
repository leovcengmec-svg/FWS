"""Measures whether strategic actions produced observable club-state progress.

This is an audit/evaluation layer only. It never creates cash, changes match
odds, or directly changes sporting results.
"""
class StrategicEffectiveness:
    METRICS = ("strategic_quality", "cash", "prestige", "sporting_strength", "identity_score")

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_effectiveness", [])

    @staticmethod
    def _clamp(v, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(v))), 4)

    def _club(self, club_id):
        club = self.save.get("world", {}).get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        return club

    def evaluate(self, club_id, season=None):
        club = self._club(club_id)
        season = self.save["world"].get("current_year") if season is None else int(season)
        actions = club.get("strategic_review_actions", [])
        evaluated = []
        for idx, action in enumerate(actions):
            lc = action.get("lifecycle")
            if not lc or lc.get("status") in ("pending", "cancelled"):
                continue
            baseline = lc.get("baseline_state")
            if not baseline:
                baseline = self._state(club)
                lc["baseline_state"] = dict(baseline)
            current = self._state(club)
            deltas = {k: round(current[k] - float(baseline.get(k, current[k])), 4) for k in self.METRICS}
            quality_delta = deltas["strategic_quality"]
            progress = float(lc.get("progress", 0.0))
            score = self._clamp(50.0 + quality_delta * 1.5 + progress * 0.35)
            if score >= 70:
                outcome = "effective"
            elif score >= 45:
                outcome = "partial"
            else:
                outcome = "ineffective"
            row = {"club_id": club_id, "action_id": idx, "season": season,
                   "status": lc.get("status"), "progress": round(progress, 4),
                   "effectiveness_score": score, "outcome": outcome, "deltas": deltas}
            action["effectiveness"] = row
            evaluated.append(row)
            self.history.append(row)
        summary = self.snapshot(club_id)
        club["strategic_effectiveness"] = summary
        club.setdefault("strategic_effectiveness_history", []).append({"season": season, **summary})
        return summary

    def _state(self, club):
        return {"strategic_quality": self._clamp(club.get("strategic_quality", 50.0)),
                "cash": round(float(club.get("cash", 0.0)), 2),
                "prestige": self._clamp(club.get("prestige", 0.0)),
                "sporting_strength": self._clamp(club.get("sporting_strength", 0.0)),
                "identity_score": self._clamp(club.get("identity_score", 0.0))}

    def snapshot(self, club_id):
        club = self._club(club_id)
        rows = [a["effectiveness"] for a in club.get("strategic_review_actions", []) if a.get("effectiveness")]
        return {"club_id": club_id, "evaluated_actions": len(rows),
                "effective": sum(r.get("outcome") == "effective" for r in rows),
                "partial": sum(r.get("outcome") == "partial" for r in rows),
                "ineffective": sum(r.get("outcome") == "ineffective" for r in rows),
                "average_score": round(sum(float(r.get("effectiveness_score", 0)) for r in rows) / len(rows), 4) if rows else 0.0,
                "latest": rows[-1] if rows else None}
