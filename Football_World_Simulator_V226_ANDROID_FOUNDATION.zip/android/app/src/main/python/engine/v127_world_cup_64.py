"""V127 — FWS 64-team World Cup reconfiguration.

Block 2 correction/finalization: 64 national teams, eight groups of eight,
seven single round-robin group rounds, top four from each group to a 32-team
knockout, then 16 -> 8 -> 4 -> 2 -> champion.

Qualification: 48 direct places plus a single global 32-team intercontinental
playoff for 16 additional places. The playoff allocation intentionally gives
more entry places to weaker confederations and fewer to stronger ones.
No individual players or player transfer systems are introduced.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from .v126_national_team_cycle import V126NationalTeamCycle
from .match_engine import MatchEngine


class V127WorldCup64(V126NationalTeamCycle):
    VERSION = "V127"
    WORLD_CUP = "FWS_WORLD_CUP"
    WORLD_CUP_SIZE = 64
    WORLD_CUP_GROUPS = 8
    WORLD_CUP_GROUP_SIZE = 8
    WORLD_CUP_GROUP_ROUNDS = 7
    WORLD_CUP_GROUP_QUALIFIERS = 4
    WORLD_CUP_KNOCKOUT = 32

    # 48 direct places. The remaining 16 places are decided by one global
    # 32-team playoff. This is an FWS rule, not a copy of FIFA allocation.
    WC_DIRECT_ALLOCATION = {
        "UEFA": 14,
        "CAF": 10,
        "AFC": 9,
        "CONCACAF": 7,
        "CONMEBOL": 6,
        "OFC": 2,
    }
    # Global playoff entry places: stronger confederations receive fewer,
    # weaker confederations receive more opportunities.
    WC_PLAYOFF_ALLOCATION = {
        "UEFA": 3,
        "CONMEBOL": 3,
        "CONCACAF": 5,
        "AFC": 7,
        "CAF": 9,
        "OFC": 5,
    }

    def qualify_world_cup(self, season=None, seed=127):
        self._ensure_state()
        year = season or self.save["world"].get("current_year", 2026)
        ranking = self.build_ranking(year)
        direct, playoff_entries, details = [], [], {}
        for conf in ("UEFA", "CAF", "AFC", "CONCACAF", "CONMEBOL", "OFC"):
            ids = [r["team_id"] for r in ranking["teams"] if r.get("confederation") == conf]
            d = self.WC_DIRECT_ALLOCATION[conf]
            p = self.WC_PLAYOFF_ALLOCATION[conf]
            if len(ids) < d + p:
                raise ValueError(f"World Cup access incomplete for {conf}: need {d+p}, have {len(ids)}")
            d_ids = ids[:d]
            p_ids = ids[d:d+p]
            direct.extend(d_ids)
            playoff_entries.extend(p_ids)
            details[conf] = {
                "direct_slots": d,
                "direct_qualified": d_ids,
                "playoff_entries": p,
                "playoff_teams": p_ids,
                "method": "continental_ranking_access",
            }
        if len(direct) != 48 or len(set(direct)) != 48:
            raise ValueError("World Cup direct access did not close at 48")
        if len(playoff_entries) != 32 or len(set(playoff_entries)) != 32:
            raise ValueError("World Cup global playoff field did not close at 32")

        # One global playoff. Pairing is deterministic after a seeded shuffle;
        # all confederations share the same bracket and no quota is reserved for
        # the winners. Exactly 16 winners enter the World Cup.
        ordered = list(playoff_entries)
        ordered.sort(key=lambda tid: hashlib.sha256(f"V127:{seed}:{year}:{tid}".encode()).hexdigest())
        teams = self.save["world"]["national_teams"]
        winners, playoff_matches = [], []
        for i in range(0, 32, 2):
            a, b = ordered[i], ordered[i+1]
            ta, tb = self._team(dict(teams[a])), self._team(dict(teams[b]))
            ta["id"], tb["id"] = a, b
            result = MatchEngine(int(seed) + 70000 + i).play("FWS_WORLD_CUP_PLAYOFF", year, 1, ta, tb)
            if result.home_goals > result.away_goals:
                winner = a
            elif result.away_goals > result.home_goals:
                winner = b
            else:
                digest = hashlib.sha256(f"V127-PO:{seed}:{year}:{a}:{b}".encode()).digest()
                winner = a if digest[0] % 2 == 0 else b
            winners.append(winner)
            playoff_matches.append({
                "competition_id": "FWS_WORLD_CUP_PLAYOFF",
                "season": year,
                "round_no": 1,
                "home_id": a,
                "away_id": b,
                "home_goals": result.home_goals,
                "away_goals": result.away_goals,
                "winner": winner,
            })
        qualified = direct + winners
        if len(qualified) != 64 or len(set(qualified)) != 64:
            raise ValueError("World Cup final field did not close at 64")
        result = {
            "version": self.VERSION,
            "season": year,
            "qualified": qualified,
            "direct_qualified": direct,
            "global_playoff_entries": playoff_entries,
            "global_playoff_winners": winners,
            "global_playoff_matches": playoff_matches,
            "details": details,
            "direct_total": 48,
            "playoff_entry_total": 32,
            "playoff_qualification_total": 16,
            "final_field_total": 64,
        }
        self.save["world"]["world_cup_qualification"] = deepcopy(result)
        self.save.setdefault("history", {}).setdefault("world_cup_qualification", []).append(deepcopy(result))
        return result

    @staticmethod
    def _round_robin_pairs(group):
        """Return all 28 unordered pairings for eight teams in seven rounds."""
        if len(group) != 8 or len(set(group)) != 8:
            raise ValueError("World Cup group must contain exactly 8 unique teams")
        arr = list(group)
        rounds = []
        # Circle method, seven rounds, four matches per round.
        for _ in range(7):
            rounds.append([(arr[i], arr[-1-i]) for i in range(4)])
            arr = [arr[0], arr[-1], *arr[1:-1]]
        return rounds

    def simulate_world_cup(self, season=None, seed=127):
        self._ensure_state()
        year = season or self.save["world"].get("current_year", 2026)
        q = self.qualify_world_cup(year, seed)
        teams = {k: self._team(v) for k, v in self.save["world"]["national_teams"].items()}
        for k, t in teams.items():
            t["id"] = k
        ids = list(q["qualified"])
        groups = self._groups(ids, self.WORLD_CUP_GROUPS)
        if any(len(g) != 8 for g in groups):
            raise ValueError("World Cup must have 8 groups of 8")
        tables, group_matches = [], []
        for gi, group in enumerate(groups, 1):
            points = {x: 0 for x in group}
            wins = {x: 0 for x in group}
            draws = {x: 0 for x in group}
            goals_for = {x: 0 for x in group}
            goals_against = {x: 0 for x in group}
            rounds = self._round_robin_pairs(group)
            for round_no, pairings in enumerate(rounds, 1):
                for pi, (a, b) in enumerate(pairings):
                    _, match, pa, pb = self._play_match(
                        self.WORLD_CUP, year, round_no, teams[a], teams[b],
                        int(seed) + gi * 1000 + round_no * 31 + pi
                    )
                    group_matches.append(match)
                    points[a] += pa; points[b] += pb
                    goals_for[a] += match["home_goals"]; goals_for[b] += match["away_goals"]
                    goals_against[a] += match["away_goals"]; goals_against[b] += match["home_goals"]
                    if pa == 3: wins[a] += 1
                    elif pb == 3: wins[b] += 1
                    else: draws[a] += 1; draws[b] += 1
            ordered = sorted(
                group,
                key=lambda x: (-points[x], -(goals_for[x] - goals_against[x]), -goals_for[x], x)
            )
            table = []
            for pos, tid in enumerate(ordered, 1):
                table.append({
                    "team_id": tid, "points": points[tid], "wins": wins[tid],
                    "draws": draws[tid], "goals_for": goals_for[tid],
                    "goals_against": goals_against[tid],
                    "goal_difference": goals_for[tid] - goals_against[tid],
                    "position": pos,
                })
            tables.append({"group": gi, "table": table, "qualified": [r["team_id"] for r in table[:4]]})

        qualified32 = [tid for table in tables for tid in table["qualified"]]
        if len(qualified32) != 32 or len(set(qualified32)) != 32:
            raise ValueError("World Cup knockout field must contain exactly 32 unique teams")

        # Cross-group bracket: group winners face fourth-placed teams from
        # another group, runners-up face third-placed teams. Pairing is rotated
        # so no group meets itself in the round of 32.
        slots = []
        for i in range(8):
            g = tables[i]["table"]
            other = tables[(i + 1) % 8]["table"]
            slots.extend([
                (g[0]["team_id"], other[3]["team_id"]),
                (g[1]["team_id"], other[2]["team_id"]),
            ])
        knockout_matches = []
        round_ids = []
        for i, (a, b) in enumerate(slots):
            winner, match, _, _ = self._play_match(self.WORLD_CUP, year, 100, teams[a], teams[b], int(seed) + 90000 + i)
            if winner is None:
                digest = hashlib.sha256(f"V127-KO:{seed}:{year}:100:{a}:{b}".encode()).digest()
                winner = teams[a] if digest[0] % 2 == 0 else teams[b]
            match["winner"] = winner["id"]
            knockout_matches.append(match)
            round_ids.append(winner["id"])

        round_no = 2
        while len(round_ids) > 1:
            if len(round_ids) not in (16, 8, 4, 2):
                raise ValueError("World Cup knockout closure invalid")
            nxt = []
            for i in range(0, len(round_ids), 2):
                a, b = round_ids[i], round_ids[i + 1]
                winner, match, _, _ = self._play_match(self.WORLD_CUP, year, 100 + round_no, teams[a], teams[b], int(seed) + 100000 + round_no * 100 + i)
                if winner is None:
                    digest = hashlib.sha256(f"V127-KO:{seed}:{year}:{round_no}:{a}:{b}".encode()).digest()
                    winner = teams[a] if digest[0] % 2 == 0 else teams[b]
                match["winner"] = winner["id"]
                knockout_matches.append(match)
                nxt.append(winner["id"])
            round_ids = nxt
            round_no += 1
        champion = round_ids[0]
        if len(knockout_matches) != 31:
            raise ValueError("World Cup knockout must contain exactly 31 matches")
        result = {
            "version": self.VERSION,
            "competition_id": self.WORLD_CUP,
            "season": year,
            "qualified": ids,
            "groups": tables,
            "group_count": 8,
            "group_size": 8,
            "group_rounds": 7,
            "group_matches_count": len(group_matches),
            "qualified_to_knockout": qualified32,
            "knockout_matches": knockout_matches,
            "knockout_match_count": len(knockout_matches),
            "champion": champion,
            "format": "64 -> 8x8 -> 32 -> 16 -> 8 -> 4 -> 2 -> champion",
        }
        self.save.setdefault("history", {}).setdefault("world_champions", []).append({"season": year, "national_team_id": champion})
        self.save["world"]["world_cup"] = deepcopy(result)
        return result

    def validate(self):
        errors = [e for e in super().validate() if not e.startswith("V126 ") and e != "wrong V126 ranking version"]
        ranking = self.save.get("world", {}).get("national_team_ranking")
        wc = self.save.get("world", {}).get("world_cup")
        q = self.save.get("world", {}).get("world_cup_qualification")
        if q:
            if q.get("direct_total") != 48 or len(q.get("direct_qualified", [])) != 48:
                errors.append("V127 direct World Cup access must contain 48 teams")
            if q.get("playoff_entry_total") != 32 or len(q.get("global_playoff_entries", [])) != 32:
                errors.append("V127 global playoff must contain 32 entries")
            if q.get("playoff_qualification_total") != 16 or len(q.get("global_playoff_winners", [])) != 16:
                errors.append("V127 global playoff must produce 16 winners")
            if len(q.get("qualified", [])) != 64 or len(set(q.get("qualified", []))) != 64:
                errors.append("V127 World Cup qualification field must contain 64 unique teams")
        if wc:
            if len(wc.get("qualified", [])) != 64 or len(set(wc.get("qualified", []))) != 64:
                errors.append("V127 World Cup field invalid")
            if len(wc.get("groups", [])) != 8 or any(len(g.get("table", [])) != 8 for g in wc.get("groups", [])):
                errors.append("V127 World Cup must contain 8 groups of 8")
            if wc.get("group_rounds") != 7 or wc.get("group_matches_count") != 224:
                errors.append("V127 World Cup group stage must contain 112 matches over 7 rounds")
            if len(wc.get("qualified_to_knockout", [])) != 32:
                errors.append("V127 World Cup knockout field must contain 32 teams")
            if wc.get("knockout_match_count") != 31:
                errors.append("V127 World Cup knockout must contain 31 matches")
            if wc.get("champion") not in wc.get("qualified", []):
                errors.append("V127 World Cup champion invalid")
        return errors
