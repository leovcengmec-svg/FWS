"""Integrated global club-football season cycle.

Keeps domestic and continental competitions connected without duplicating the
existing match/tournament engines. The cycle is deterministic when the
underlying simulator is seeded.
"""
from .world_bootstrap import WorldBootstrap
from .world_registry import WorldRegistry
from .world_integrity import assert_world_integrity
from .promotion import PromotionRelegation
from .season_pipeline import SeasonPipeline
from .coefficient import CoefficientEngine
from .world_history import WorldHistoryLedger


class GlobalSeasonCycle:
    def __init__(self, save, simulator):
        self.save = save
        self.simulator = simulator
        self.coefficients = CoefficientEngine(
            save.get("coefficients", {}).get("window_seasons", 5),
            save.get("coefficients", {}).get("decay", .75),
        )

    def run(self, advance_year=True):
        WorldBootstrap(self.save).prepare()
        assert_world_integrity(self.save)
        year = self.save["world"]["current_year"]

        pipeline = SeasonPipeline(self.save, self.simulator)
        league_results, cup_winners = pipeline.domestic_phase()

        # Coefficients are updated from domestic performance before access for
        # the next season. Current-season continental points are also accepted
        # by the ledger when available.
        for league_id, table in league_results.items():
            points = self._league_points(table)
            self.coefficients.update_league(self.save, league_id, points)

        continental = {}
        for competition_id, cfg in self.save["world"].get("competitions", {}).items():
            if not cfg.get("enabled") or cfg.get("type") != "continental_club":
                continue
            champion = pipeline.continental_phase(competition_id)
            continental[competition_id] = champion["id"] if champion else None

        movements = {}
        places = self.save.get("simulation", {}).get("promotion_relegation_places", 4)
        for country_id in self.save["world"].get("countries", {}):
            changes = PromotionRelegation(places).apply_country(self.save, country_id)
            if changes:
                movements[country_id] = changes

        WorldHistoryLedger(self.save).record_world_season(
            year, league_results, cup_winners, continental, movements
        )
        assert_world_integrity(self.save)

        report = {
            "season": year,
            "leagues": len(league_results),
            "cups": len([x for x in cup_winners.values() if x]),
            "continental_competitions": len(continental),
            "continental_champions": continental,
            "promotions_relegations": movements,
            "world_summary": WorldRegistry(self.save).summary(),
        }
        if advance_year:
            self.save["world"]["current_year"] = year + 1
            self.save["world"]["current_round"] = 0
        return report

    @staticmethod
    def _league_points(table):
        # Compact coefficient proxy: rewards wins/draws while avoiding club
        # strength or financial data entering the coefficient directly.
        if not table:
            return 0.0
        return round(sum(row.get("points", 0) for row in table) / len(table), 3)
