"""V211 — World Depth: regional power and balance map."""
from __future__ import annotations
from copy import deepcopy

class V211WorldRegions:
    VERSION='V211'
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}); self.map=self.history.setdefault('world_depth_regions',{})
    def build(self,season=None):
        w=self.save.setdefault('world',{}); year=int(w.get('current_year',2026) if season is None else season)
        clubs=w.get('clubs',{}); groups={}
        for cid,c in clubs.items():
            key=str(c.get('confederation') or c.get('region') or c.get('country_code') or c.get('country_id') or 'WORLD').upper()
            groups.setdefault(key,[]).append(c)
        out={}
        for key,items in sorted(groups.items()):
            strengths=[float(c.get('sporting_strength',50)) for c in items]; prestige=[float(c.get('prestige',50)) for c in items]
            out[key]={'region':key,'season':year,'clubs':len(items),'average_strength':round(sum(strengths)/len(strengths),3),'average_prestige':round(sum(prestige)/len(prestige),3),'top_strength':round(max(strengths),3),'depth_score':round(min(100,(sum(strengths)/len(strengths))*0.65+min(len(items),100)*0.35),3)}
        self.map['season']=year; self.map['regions']=out; self.map['version']=self.VERSION; self.history.setdefault('world_depth_region_cycles',[]).append({'version':self.VERSION,'season':year,'regions':len(out)})
        return deepcopy(out)
    def snapshot(self): return deepcopy(self.map)
    def validate(self):
        return [] if isinstance(self.map.get('regions',{}),dict) else ['V211 invalid regions']
