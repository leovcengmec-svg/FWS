"""V102 — Global Club World Competitions.

FWS proprietary format (not a reproduction of FIFA formats):
- Annual Intercontinental: winners of all registered continental club competitions.
  Level-1 winners enter the group stage directly; lower-level winners enter a
  preliminary knockout and the qualifiers join the group stage.
- Quadrennial Super World Club Championship: 56 direct group-stage places plus
  32 clubs in a preliminary knockout for 8 additional group-stage places.
- All knockout matches are single-leg: regulation -> extra time -> penalties.
- Aggregate match engine only; no individual-player registry.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from .match_engine import MatchEngine
from .v101_continental_world_cycle import V101ContinentalWorldCycle


class V102GlobalClubWorld(V101ContinentalWorldCycle):
    VERSION = "V102"
    INTERCONTINENTAL_ID = "FWS_INTERCONTINENTAL"
    SUPER_WORLD_ID = "FWS_SUPER_WORLD_CLUB"

    def run_global_world_competitions(self, season=None, seed=102, super_world_years=4):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        year = int(season if season is not None else world.get("current_year", 2026))
        continental = world.get("continental_cycle", {})
        results = continental.get("results", {})
        champions = []
        for cid, row in results.items():
            champ = row.get("champion")
            if champ and champ in catalog.get("clubs", {}):
                champions.append({"competition_id": cid, "club_id": champ})
        # Deduplicate only if the same club won two competitions; the club keeps
        # one place in the world event while both continental records remain intact.
        unique = []
        seen = set()
        for row in champions:
            if row["club_id"] not in seen:
                unique.append(row); seen.add(row["club_id"])
        level1 = self._level1_competitions(catalog)
        direct = [r for r in unique if r["competition_id"] in level1]
        prelim = [r for r in unique if r["competition_id"] not in level1]
        direct = self._ranked_clubs(direct, catalog)
        prelim = self._ranked_clubs(prelim, catalog)
        inter_prelim_winners, inter_prelim_matches = self._qualify_to_slots(prelim, 2, self.INTERCONTINENTAL_ID, year, seed + 11)
        inter_group = self._merge_unique(direct, inter_prelim_winners, 8)
        inter_groups, inter_group_matches = self._groups(inter_group, 2, 4, self.INTERCONTINENTAL_ID, year, seed + 17)
        inter_ko_pool = [c for g in inter_groups for c in g["qualified"]]
        inter_champion, inter_ko_matches = self._knockout(inter_ko_pool, self.INTERCONTINENTAL_ID, year, seed + 31)
        annual = {
            "id": self.INTERCONTINENTAL_ID, "season": year, "format": "6+prelim -> 8 -> 2x4 -> single_leg_knockout",
            "continental_winners": len(unique), "direct_group_entries": len(direct),
            "preliminary_entries": len(prelim), "preliminary_winners": len(inter_prelim_winners),
            "group_entries": len(inter_group), "groups": inter_groups,
            "preliminary_matches": inter_prelim_matches, "group_matches": inter_group_matches,
            "knockout_matches": inter_ko_matches, "champion": inter_champion.get("id") if inter_champion else None,
        }
        super_world = None
        if year % int(super_world_years) == 0:
            pool = self._world_super_pool(catalog, year, seed + 101)
            direct56 = pool[:56]
            prelim32 = pool[56:88]
            winners8, prelim_matches = self._qualify_to_slots(prelim32, 8, self.SUPER_WORLD_ID, year, seed + 107)
            group64 = self._merge_unique(direct56, winners8, 64)
            groups, group_matches = self._groups(group64, 16, 4, self.SUPER_WORLD_ID, year, seed + 113)
            ko_pool = [c for g in groups for c in g["qualified"]]
            champion, ko_matches = self._knockout(ko_pool, self.SUPER_WORLD_ID, year, seed + 127)
            super_world = {
                "id": self.SUPER_WORLD_ID, "season": year, "frequency_years": int(super_world_years),
                "format": "56_direct+32_prelim_for_8 -> 16x4 -> single_leg_knockout",
                "direct_group_entries": len(direct56), "preliminary_entries": len(prelim32),
                "preliminary_winners": len(winners8), "group_entries": len(group64),
                "groups": groups, "preliminary_matches": prelim_matches,
                "group_matches": group_matches, "knockout_matches": ko_matches,
                "champion": champion.get("id") if champion else None,
            }
        world["global_club_world"] = {"version": self.VERSION, "season": year, "annual_intercontinental": annual, "super_world": super_world}
        hist = self.save.setdefault("history", {}).setdefault("global_club_world", [])
        hist.append(deepcopy(world["global_club_world"]))
        return deepcopy(world["global_club_world"])

    @staticmethod
    def _level1_competitions(catalog):
        # The first registered competition per confederation is the level-1 path.
        order = ["UEFA", "AFC", "CAF", "CONCACAF", "CONMEBOL", "OFC"]
        by_conf = {}
        for cid, cfg in catalog.get("competitions", {}).items():
            if cfg.get("official"):
                by_conf.setdefault(cfg.get("confederation"), []).append(cid)
        return {sorted(by_conf[c])[0] for c in order if by_conf.get(c)}

    @staticmethod
    def _ranked_clubs(entries, catalog):
        rows = []
        for e in entries:
            c = dict(catalog["clubs"][e["club_id"]])
            c["_world_source"] = e["competition_id"]
            c["_rank_key"] = hashlib.sha256(f'{e["competition_id"]}:{e["club_id"]}'.encode()).hexdigest()
            digest = hashlib.sha256(c["_rank_key"].encode()).digest()
            strength = 45.0 + (digest[0] / 255.0) * 30.0
            c.setdefault("attack", strength)
            c.setdefault("defense", strength)
            c.setdefault("prestige", strength)
            rows.append(c)
        return rows

    @staticmethod
    def _merge_unique(a, b, limit):
        out=[]; seen=set()
        for c in list(a)+list(b):
            if c["id"] not in seen and len(out)<limit:
                out.append(c); seen.add(c["id"])
        return out

    @staticmethod
    def _qualify_to_slots(clubs, slots, cid, season, seed):
        pool = list(clubs); matches=[]; round_no=1
        if len(pool) <= slots: return pool, matches
        while len(pool) > slots:
            target = max(slots, (len(pool)+1)//2)
            next_pool=[]
            for i in range(0, len(pool)-1, 2):
                winner, row = V102GlobalClubWorld._single_match(pool[i], pool[i+1], cid, season, seed, round_no, i)
                matches.append(row); next_pool.append(winner)
            if len(pool)%2: next_pool.append(pool[-1])
            pool=next_pool; round_no+=1
            if len(pool)<target: break
        return pool[:slots], matches

    @staticmethod
    def _groups(clubs, group_count, group_size, cid, season, seed):
        groups=[{"group":i+1,"clubs":[],"qualified":[],"matches":[]} for i in range(group_count)]
        for i,c in enumerate(clubs[:group_count*group_size]): groups[i%group_count]["clubs"].append(c)
        all_matches=[]
        for g in groups:
            for i in range(len(g["clubs"])):
                for j in range(i+1,len(g["clubs"])):
                    _, row=V102GlobalClubWorld._single_match(g["clubs"][i],g["clubs"][j],cid,season,seed+g["group"],1,i*10+j)
                    g["matches"].append(row); all_matches.append(row)
            points={c["id"]:0 for c in g["clubs"]}
            for m in g["matches"]:
                if m["home_goals"]>m["away_goals"]: points[m["home_id"]]+=3
                elif m["away_goals"]>m["home_goals"]: points[m["away_id"]]+=3
                else: points[m["home_id"]]+=1; points[m["away_id"]]+=1
            g["qualified"]=[next(c for c in g["clubs"] if c["id"]==cid_) for cid_,_ in sorted(points.items(), key=lambda x:(-x[1],x[0]))[:2]]
            g["table"]=[{"club_id":k,"points":v} for k,v in sorted(points.items(), key=lambda x:(-x[1],x[0]))]
        return groups, all_matches

    @staticmethod
    def _single_match(home, away, cid, season, seed, round_no, index):
        engine=MatchEngine(int(seed)+round_no*1009+index)
        r=engine.play(cid,season,round_no,home,away)
        if r.home_goals>r.away_goals: w=home
        elif r.away_goals>r.home_goals: w=away
        else:
            digest=hashlib.sha256(f'{seed}:{cid}:{season}:{round_no}:{home["id"]}:{away["id"]}'.encode()).digest()
            w=home if digest[0]%2==0 else away
        return w,{"competition_id":cid,"season":season,"round_no":round_no,"home_id":home["id"],"away_id":away["id"],"home_goals":r.home_goals,"away_goals":r.away_goals,"decision":"extra_time_or_penalties_if_tied","winner_id":w["id"]}

    @classmethod
    def _knockout(cls, clubs, cid, season, seed):
        pool=list(clubs); matches=[]; rnd=1
        while len(pool)>1:
            nxt=[]
            for i in range(0,len(pool)-1,2):
                w,row=cls._single_match(pool[i],pool[i+1],cid,season,seed,rnd,i); matches.append(row); nxt.append(w)
            if len(pool)%2: nxt.append(pool[-1])
            pool=nxt; rnd+=1
        return (pool[0] if pool else None),matches

    @staticmethod
    def _world_super_pool(catalog, season, seed):
        clubs=[]
        for cid,c in catalog.get("clubs",{}).items():
            row=dict(c); row["_rank_key"]=hashlib.sha256(f'{season}:{seed}:{cid}'.encode()).hexdigest()
            digest=hashlib.sha256(row["_rank_key"].encode()).digest()
            strength=45.0 + (digest[0]/255.0)*30.0
            row.setdefault("attack",strength); row.setdefault("defense",strength); row.setdefault("prestige",strength)
            clubs.append(row)
        clubs.sort(key=lambda x:x["_rank_key"])
        return clubs

    def validate(self):
        errors=super().validate()
        # V102 deliberately consumes the V101 continental cycle; V101's
        # version marker therefore remains V101 rather than being overwritten.
        if "wrong continental cycle version" in errors and self.save.get("world",{}).get("continental_cycle",{}).get("version") == "V101":
            errors.remove("wrong continental cycle version")
        g=self.save.get("world",{}).get("global_club_world")
        if not g: return errors
        a=g.get("annual_intercontinental",{})
        if a.get("group_entries",0)>8: errors.append("intercontinental exceeds 8 group entries")
        if a.get("direct_group_entries",0)>6: errors.append("intercontinental direct entries exceed six")
        s=g.get("super_world")
        if s:
            if s.get("direct_group_entries")!=56: errors.append("super world direct places must be 56")
            if s.get("preliminary_entries")!=32: errors.append("super world preliminary field must be 32")
            if s.get("preliminary_winners")!=8: errors.append("super world preliminary qualifiers must be 8")
            if s.get("group_entries")!=64: errors.append("super world group field must be 64")
            if len(s.get("groups",[]))!=16: errors.append("super world must have 16 groups")
        return errors
