"""V137 - Global catalog quality audit and canonical club identity normalization."""
from __future__ import annotations
from copy import deepcopy


class V137CatalogQuality:
    VERSION = "V137"

    # Evidence-backed duplicate identities found in the active catalog.
    # The legacy IDs are retained as aliases so historical references remain resolvable.
    DUPLICATE_ALIASES = {
        "BRA-1-atletico-mg": "BRA_D1_C3",
        "BRA-1-botafogo": "BRA_D1_C4",
        "BRA-1-corinthians": "BRA_D1_C7",
        "BRA-1-flamengo": "BRA_D1_C1",
        "BRA-1-fluminense": "BRA_D1_C5",
        "BRA-1-internacional": "BRA_D1_C8",
        "BRA-1-palmeiras": "BRA_D1_C2",
        "BRA-1-sao-paulo": "BRA_D1_C6",
        "BDI_D2_C1": "BDI_D1_C8",
        "MAS_D1_C7": "MAS_D2_C5",
        "PAN_D2_C24": "PAN_D1_C10",
        "SDN_D2_C10": "SDN_D1_C1",
        "SDN_D2_C3": "SDN_D1_C6",
    }

    def normalize(self, catalog: dict) -> dict:
        out = deepcopy(catalog)
        clubs = out.setdefault("clubs", {})
        leagues = out.setdefault("leagues", {})
        aliases = out.setdefault("club_identity_aliases", {})
        removed = []
        for legacy_id, canonical_id in self.DUPLICATE_ALIASES.items():
            if legacy_id in clubs and canonical_id in clubs:
                aliases[legacy_id] = {
                    "canonical_id": canonical_id,
                    "reason": "duplicate_real_world_identity",
                    "status": "legacy_alias",
                }
                old = clubs.pop(legacy_id)
                old_league = old.get("league_id")
                if old_league in leagues:
                    leagues[old_league]["club_ids"] = [x for x in leagues[old_league].get("club_ids", []) if x != legacy_id]
                    leagues[old_league]["club_count"] = len(leagues[old_league]["club_ids"])
                removed.append(legacy_id)

        # Rebuild every reverse index from the canonical club records.
        by_league = {lid: [] for lid in leagues}
        for cid, club in clubs.items():
            lid = club.get("league_id")
            if lid in by_league:
                by_league[lid].append(cid)
        for lid, league in leagues.items():
            league["club_ids"] = sorted(by_league[lid])
            league["club_count"] = len(league["club_ids"])

        # Refresh derived coverage counters from actual active records.
        cov = out.setdefault("coverage", {})
        cov["total_clubs"] = len(clubs)
        cov["total_leagues"] = len(leagues)
        cov["clubs_empty_leagues"] = sum(1 for v in leagues.values() if not v.get("club_ids"))
        cov["verified_clubs"] = sum(1 for v in clubs.values() if v.get("data_status") in {"verified_import", "verified_seed", "verified_real_world_pack"})
        cov["partial_clubs"] = sum(1 for v in clubs.values() if v.get("data_status") == "partial_import")
        cov["clubs_with_identity_aliases"] = len(aliases)
        cov["active_clubs"] = len(clubs)
        cov["catalog_quality_version"] = self.VERSION
        out.setdefault("integrity", {})["catalog_quality_version"] = self.VERSION
        return out

    def validate(self, catalog: dict) -> dict:
        clubs = catalog.get("clubs", {})
        leagues = catalog.get("leagues", {})
        errors = []
        duplicate_keys = {}
        for cid, club in clubs.items():
            if club.get('status') == 'waiting_final_division':
                continue
            key = (club.get("country_id"), club.get("name", "").strip().casefold())
            duplicate_keys.setdefault(key, []).append(cid)
            lid = club.get("league_id")
            if lid not in leagues:
                errors.append({"type": "missing_league", "club_id": cid, "league_id": lid})
            elif cid not in leagues[lid].get("club_ids", []):
                errors.append({"type": "orphan_club_index", "club_id": cid, "league_id": lid})
        duplicates = {k: v for k, v in duplicate_keys.items() if k[1] and len(v) > 1}
        if duplicates:
            errors.append({"type": "active_duplicate_identity", "duplicates": duplicates})
        for lid, league in leagues.items():
            if league.get("club_count") != len(league.get("club_ids", [])):
                errors.append({"type": "club_count_mismatch", "league_id": lid})
        return {"valid": not errors, "error_count": len(errors), "errors": errors,
                "active_clubs": len(clubs), "leagues": len(leagues),
                "aliases": len(catalog.get("club_identity_aliases", {}))}
