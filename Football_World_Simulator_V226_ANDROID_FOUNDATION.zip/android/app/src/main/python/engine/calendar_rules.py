class CalendarRules:
    def __init__(self):
        self.rules={
            "max_matches_same_day_per_club":1,
            "minimum_days_between_matches":2,
            "international_windows":[],
            "season_start":"08-01",
            "season_end":"06-30"
        }

    def set_rule(self,key,value):
        self.rules[key]=value

    def validate_fixture_list(self,fixtures):
        errors=[]
        by_club={}
        for f in fixtures:
            for cid in (f["home_id"],f["away_id"]):
                by_club.setdefault(cid,[]).append(f)
        for cid,rows in by_club.items():
            rows=sorted(rows,key=lambda x:x["date"])
            for a,b in zip(rows,rows[1:]):
                if a["date"]==b["date"]:
                    errors.append({"type":"same_day","club_id":cid,"a":a["id"],"b":b["id"]})
        return errors
