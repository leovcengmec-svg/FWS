"""V117 — Continental Season Integration.

Connects V113→V116 to the annual FWS season calendar. This layer is orchestration
only: it does not replace the verified world catalog or invent unresolved format
parameters. Competitions missing required league/playoff/knockout settings are
reported as configuration_pending instead of being executed with guessed values.
"""
from __future__ import annotations
from copy import deepcopy
from .v116_continental_knockout import V116ContinentalKnockout


class V117ContinentalSeasonIntegration(V116ContinentalKnockout):
    VERSION = "V117"

    def build_season_calendar(self, season=None, super_world_years=4):
        year = int(season if season is not None else self.save.setdefault("world", {}).get("current_year", 2026))
        years = int(super_world_years)
        if years <= 0:
            raise ValueError("super_world_years must be positive")
        super_year = year % years == 0
        events = [
            {"id": "DOMESTIC_SEASON", "phase": "domestic", "order": 1, "frequency": "annual"},
            {"id": "CONTINENTAL_ENTRY", "phase": "continental", "order": 2, "frequency": "annual"},
            {"id": "CONTINENTAL_LEAGUE", "phase": "continental", "order": 3, "frequency": "annual"},
            {"id": "CONTINENTAL_POST_LEAGUE", "phase": "continental", "order": 4, "frequency": "annual"},
            {"id": "CONTINENTAL_KNOCKOUT", "phase": "continental", "order": 5, "frequency": "annual"},
            {"id": "FWS_INTERCONTINENTAL", "phase": "world_club", "order": 6, "frequency": "annual"},
        ]
        if super_year:
            events.append({"id": "FWS_SUPER_WORLD_CLUB", "phase": "world_club", "order": 7, "frequency": f"every_{years}_years"})
        calendar = {
            "version": self.VERSION, "season": year, "super_world_years": years,
            "is_super_world_year": super_year, "events": events,
            "dependency_chain": [e["id"] for e in events],
            "engine_chain": ["V100", "V113", "V114", "V115", "V116", "V110", "V102"],
        }
        self.save.setdefault("world", {})["global_calendar"] = deepcopy(calendar)
        self.save.setdefault("world", {}).setdefault("calendar_history", []).append(deepcopy(calendar))
        return deepcopy(calendar)

    @staticmethod
    def _configs(save):
        world = save.get("world", {})
        continental = save.get("continental", {}).get("competitions", {})
        registry = world.get("competitions", {})
        out = []
        for cid, raw in registry.items():
            if raw.get("type") != "continental_club" or not raw.get("enabled", False):
                continue
            merged = dict(continental.get(cid, {})); merged.update(dict(raw)); merged["id"] = cid
            if not merged.get("confederation"):
                continue
            out.append(merged)
        return out

    def _catalog_from_save(self):
        catalog = self.save.get("catalog")
        if isinstance(catalog, dict):
            return catalog
        catalog = self.save.get("world", {}).get("catalog")
        if isinstance(catalog, dict):
            return catalog
        raise ValueError("catálogo mundial não encontrado no save")

    def _tables_from_domestic(self):
        cycle = self.save.get("world", {}).get("autonomous_cycle", {})
        return {
            lid: row.get("standings", [])
            for lid, row in cycle.get("state", {}).get("leagues_state", {}).items()
            if row.get("status") == "completed"
        }

    def run_continental_season(self, season=None, seed=117, *, require_configuration=True):
        world = self.save.setdefault("world", {})
        year = int(season if season is not None else world.get("current_year", 2026))
        catalog = self._catalog_from_save()
        if not world.get("autonomous_cycle") or int(world["autonomous_cycle"].get("season", year)) != year:
            raise ValueError("domestic V100 season must be completed before V117 continental execution")
        tables = self._tables_from_domestic()
        leagues = [dict(x) for x in catalog.get("leagues", {}).values()]
        configs = self._configs(self.save)
        results = {}
        assigned_by_conf = {}

        for index, comp in enumerate(configs):
            cid = comp["id"]
            size = int(comp.get("size", comp.get("default_size", 0)))
            missing = []
            if size not in (16, 36, 72):
                missing.append("supported_size_16_36_72")
            if comp.get("league_phase_matches_per_club") is None:
                missing.append("league_phase_matches_per_club")
            if comp.get("post_league_playoff_legs") is None:
                missing.append("post_league_playoff_legs")
            if comp.get("knockout_legs") is None:
                missing.append("knockout_legs")
            if require_configuration and missing:
                results[cid] = {"version": self.VERSION, "competition_id": cid, "season": year,
                                "status": "configuration_pending", "missing_configuration": missing}
                continue

            # Use explicit values only. If execution is requested without strict
            # configuration, the competition remains pending rather than guessing.
            if missing:
                results[cid] = {"version": self.VERSION, "competition_id": cid, "season": year,
                                "status": "configuration_pending", "missing_configuration": missing}
                continue

            conf = comp.get("confederation")
            assigned = assigned_by_conf.setdefault(conf, set())
            entry = self.build_entry_field(comp, leagues, tables, season=year,
                                           seed=int(seed) + index * 7919,
                                           already_assigned=assigned)
            if not entry["field_complete"]:
                results[cid] = {"version": self.VERSION, "competition_id": cid, "season": year,
                                "status": "entry_field_incomplete", "entry": entry}
                assigned.update(x["club_id"] for x in entry.get("entries", []))
                continue
            assigned.update(x["club_id"] for x in entry["entries"])

            if size == 72:
                # The V112 rule is two independent groups of 36.
                group_a = entry["entries"][:36]
                group_b = entry["entries"][36:]
                league_a = self.run_league_phase(dict(comp, size=36), group_a, season=year, seed=int(seed) + 1001 + index)
                league_b = self.run_league_phase(dict(comp, size=36), group_b, season=year, seed=int(seed) + 2001 + index)
                post = self.run_72_post_league(comp, league_a["standings"], league_b["standings"], season=year, seed=int(seed) + 3001 + index)
            else:
                league = self.run_league_phase(comp, entry["entries"], season=year, seed=int(seed) + 1001 + index)
                post = self.run_post_league(comp, league["standings"], season=year, seed=int(seed) + 2001 + index)

            knockout = self.run_from_post_league(comp, post, season=year, seed=int(seed) + 3001 + index)
            results[cid] = {
                "version": self.VERSION, "competition_id": cid, "season": year,
                "status": "completed", "entry": entry,
                "league_phase": ([league_a, league_b] if size == 72 else league),
                "post_league": post, "knockout": knockout,
                "champion": knockout["champion_id"],
            }

        completed = {cid: r for cid, r in results.items() if r.get("status") == "completed"}
        cycle_results = {cid: {"status": r["status"], "champion": r.get("champion"),
                               "entries": r.get("entry", {}).get("entry_count", 0),
                               "matches": self._collect_matches(r)} for cid, r in results.items()}
        world["continental_cycle"] = {
            "version": self.VERSION, "season": year, "seed": int(seed),
            "competitions_processed": len(results), "competitions_completed": len(completed),
            "qualified_clubs": sum(v["entries"] for v in cycle_results.values()),
            "matches_simulated": sum(len(v["matches"]) for v in cycle_results.values()),
            "results": deepcopy(cycle_results),
        }
        world["continental_season_execution"] = {
            "version": self.VERSION, "season": year, "status": "completed" if all(r.get("status") == "completed" for r in results.values()) else "partial",
            "competitions": deepcopy(results),
        }
        self.save.setdefault("history", {}).setdefault("continental_season", []).append(deepcopy(world["continental_season_execution"]))
        return deepcopy(world["continental_season_execution"])

    @staticmethod
    def _collect_matches(result):
        out = []
        entry = result.get("entry", {})
        out.extend(entry.get("preliminary_matches", []))
        lp = result.get("league_phase", {})
        phases = lp if isinstance(lp, list) else [lp]
        for phase in phases:
            out.extend(phase.get("matches", []))
        post = result.get("post_league", {})
        out.extend(post.get("matches", []))
        for group in post.get("group_results", []):
            out.extend(group.get("matches", []))
        ko = result.get("knockout", {})
        for rnd in ko.get("rounds", []):
            out.extend(rnd.get("matches", []))
        return out

    def validate(self):
        errors = super().validate()
        cal = self.save.get("world", {}).get("global_calendar")
        if cal and cal.get("version") != self.VERSION:
            errors.append("wrong V117 calendar version")
        execution = self.save.get("world", {}).get("continental_season_execution")
        if execution:
            if execution.get("version") != self.VERSION:
                errors.append("wrong V117 continental execution version")
            for cid, row in execution.get("competitions", {}).items():
                if row.get("status") == "completed" and not row.get("champion"):
                    errors.append(f"completed continental competition without champion: {cid}")
        cycle = self.save.get("world", {}).get("continental_cycle")
        if cycle and cycle.get("version") != self.VERSION:
            errors.append("V117 continental cycle version mismatch")
        return errors
