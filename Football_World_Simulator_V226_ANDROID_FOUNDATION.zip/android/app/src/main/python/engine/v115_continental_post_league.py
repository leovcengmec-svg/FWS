from __future__ import annotations
from copy import deepcopy
import hashlib
from .match_engine import MatchEngine
from .v114_continental_league_phase import V114ContinentalLeaguePhase


class V115ContinentalPostLeague(V114ContinentalLeaguePhase):
    """V115: executes the post-league structures frozen by V112."""
    VERSION = "V115"

    @staticmethod
    def _club(entry):
        s = max(1.0, min(99.0, float(entry.get("league_coefficient", entry.get("strength", 50.0)))))
        return {"id": entry["club_id"], "attack": s, "defense": s,
                "prestige": s, "sporting_strength": s}

    @staticmethod
    def _winner(high_id, low_id, high_goals, low_goals, seed, comp, season, tie_id):
        if high_goals > low_goals:
            return high_id
        if low_goals > high_goals:
            return low_id
        digest = hashlib.sha256(
            f"{seed}:{comp}:{season}:{tie_id}:{high_id}:{low_id}".encode()
        ).digest()
        return high_id if digest[0] % 2 == 0 else low_id

    def _playoff(self, entries, slots, competition_id, season, seed, legs):
        if len(entries) != slots * 2:
            raise ValueError("post-league playoff requires exactly twice the target number of entries")
        legs = int(legs)
        if legs <= 0:
            raise ValueError("post_league_playoff_legs must be positive")
        winners, matches = [], []
        for i in range(slots):
            high, low = entries[i], entries[-1 - i]
            totals = {high["club_id"]: 0, low["club_id"]: 0}
            for leg in range(1, legs + 1):
                home, away = (high, low) if leg % 2 else (low, high)
                result = MatchEngine(int(seed) + i * 10007 + leg * 1009).play(
                    competition_id, int(season), i + 1, self._club(home), self._club(away)
                )
                hg, ag = int(result.home_goals), int(result.away_goals)
                totals[home["club_id"]] += hg
                totals[away["club_id"]] += ag
                matches.append({"competition_id": competition_id, "season": int(season),
                                "tie_id": i + 1, "leg": leg,
                                "home_id": home["club_id"], "away_id": away["club_id"],
                                "home_goals": hg, "away_goals": ag})
            winner = self._winner(high["club_id"], low["club_id"], totals[high["club_id"]],
                                  totals[low["club_id"]], seed, competition_id, season, i + 1)
            matches[-1]["tie_winner_id"] = winner
            winners.append(high if winner == high["club_id"] else low)
        return winners, matches

    def run_post_league(self, competition, standings, *, season=2026, seed=115):
        comp = dict(competition)
        size = int(comp.get("size", comp.get("default_size", 0)))
        rows = sorted((dict(x) for x in standings), key=lambda r: int(r.get("position", 10**9)))
        if len(rows) != size or any("position" not in r for r in rows):
            raise ValueError("post-league phase requires a complete positioned standings table")
        if size == 36:
            direct_n, playoff_n = 8, 16
        elif size == 16:
            direct_n, playoff_n = 4, 8
        else:
            raise ValueError("run_post_league accepts 16 or 36; use run_72_post_league for 72")
        legs = comp.get("post_league_playoff_legs")
        if legs is None:
            raise ValueError("post_league_playoff_legs must be configured")
        direct = rows[:direct_n]
        playoff_entries = rows[direct_n:direct_n + playoff_n]
        winners, matches = self._playoff(
            playoff_entries, playoff_n // 2, comp.get("id", "CONTINENTAL"), season, seed, legs
        )
        field = direct + winners
        return {
            "version": self.VERSION, "competition_id": comp.get("id"), "season": int(season),
            "field_size": size, "direct_count": direct_n,
            "playoff_entries": playoff_n, "playoff_qualifiers": len(winners),
            "post_league_playoff_legs": int(legs),
            "direct": [x["club_id"] for x in direct],
            "playoff_entries_ids": [x["club_id"] for x in playoff_entries],
            "playoff_winners": [x["club_id"] for x in winners],
            "knockout_field": [x["club_id"] for x in field],
            "knockout_size": len(field), "matches": matches,
        }

    def run_72_post_league(self, competition, group_a, group_b, *, season=2026, seed=115):
        comp = dict(competition)
        if int(comp.get("size", comp.get("default_size", 0))) != 72:
            raise ValueError("72-club post-league execution requires a 72-club competition")
        if len(group_a) != 36 or len(group_b) != 36:
            raise ValueError("72-club format requires two complete groups of 36")
        base = dict(comp)
        base["size"] = 36
        a = self.run_post_league(base, group_a, season=season, seed=seed * 2 + 1)
        b = self.run_post_league(base, group_b, season=season, seed=seed * 2 + 2)
        field = a["knockout_field"] + b["knockout_field"]
        return {"version": self.VERSION, "competition_id": comp.get("id"), "season": int(season),
                "groups": 2, "group_size": 36, "group_results": [a, b],
                "knockout_field": field, "knockout_size": len(field),
                "matches": a["matches"] + b["matches"]}

    def apply(self):
        super().apply()
        world = self.save.setdefault("world", {})
        world["continental_post_league_framework"] = {
            "version": self.VERSION, "base_version": "V114",
            "execution_order": ["entry_qualification", "league_phase", "post_league_direct",
                                "post_league_preliminary", "knockout"],
            "format_36": {"direct": 8, "playoff_entries": 16, "playoff_qualifiers": 8, "knockout_size": 16},
            "format_16": {"direct": 4, "playoff_entries": 8, "playoff_qualifiers": 4, "knockout_size": 8},
            "format_72": {"groups": 2, "group_size": 36, "direct_per_group": 8,
                           "playoff_entries_per_group": 16, "knockout_size": 32},
            "playoff_legs_is_configurable": True,
        }
        self.save.setdefault("continental", {})["post_league_version"] = self.VERSION
        return deepcopy(world["continental_post_league_framework"])

    def validate(self):
        errors = super().validate()
        fw = self.save.get("world", {}).get("continental_post_league_framework", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V115 post-league framework version")
        return errors
