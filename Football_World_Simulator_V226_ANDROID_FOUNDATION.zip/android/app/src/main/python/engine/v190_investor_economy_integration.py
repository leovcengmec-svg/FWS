"""V190 — Integrated investor economy gate for the V186–V190 block."""
from __future__ import annotations
from .v186_investor_finance import V186InvestorFinance
from .v187_club_ownership_value import V187ClubOwnershipValue
from .v188_club_financial_operations import V188ClubFinancialOperations
from .v189_investor_consequences import V189InvestorConsequences
class V190InvestorEconomyIntegration:
    VERSION='V190'; CHAIN=['V186','V187','V188','V189','V190']
    def __init__(self,save): self.save=save; self.fin=V186InvestorFinance(save); self.own=V187ClubOwnershipValue(save); self.ops=V188ClubFinancialOperations(save); self.cons=V189InvestorConsequences(save)
    def settle_season(self):
        ops=self.ops.settle(); cons=self.cons.close_season()
        return {'version':self.VERSION,'clubs_settled':len(ops),'investor':cons}
    def snapshot(self): return {'version':self.VERSION,'portfolio':self.fin.portfolio()}
    def validate(self): return self.fin.validate()+self.own.validate()+self.ops.validate()+self.cons.validate()
