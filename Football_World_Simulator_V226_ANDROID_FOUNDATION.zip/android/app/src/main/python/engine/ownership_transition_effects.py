class OwnershipTransitionEffects:
    """Records gradual management effects after a club ownership change.

    Ownership itself remains authoritative in V40/V41. This layer only updates
    non-result management context: transition status, integration counter and
    an investment capacity modifier. It never changes match results directly.
    """
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('ownership_transition_effects', [])

    def apply(self, club_id, new_owner, season=None):
        club = self.save['world']['clubs'][club_id]
        season = self.save['world'].get('current_year') if season is None else season
        state = club.setdefault('ownership_transition', {})
        state['owner_id'] = new_owner
        state['started_season'] = season
        state['seasons_since_change'] = 0
        state['integration_status'] = 'transition'
        state['investment_capacity_modifier'] = 0.90
        record = {'club_id': club_id, 'owner_id': new_owner, 'season': season,
                  'integration_status': 'transition', 'investment_capacity_modifier': 0.90}
        self.history.append(record)
        return record

    def advance_season(self, club_id):
        club = self.save['world']['clubs'][club_id]
        state = club.get('ownership_transition')
        if not state:
            return None
        seasons = int(state.get('seasons_since_change', 0)) + 1
        state['seasons_since_change'] = seasons
        if seasons >= 2:
            state['integration_status'] = 'integrated'
            state['investment_capacity_modifier'] = 1.0
        else:
            state['integration_status'] = 'transition'
            state['investment_capacity_modifier'] = 0.95
        return {'club_id': club_id, **state}

    def capacity(self, club_id, base_amount):
        club = self.save['world']['clubs'][club_id]
        state = club.get('ownership_transition', {})
        modifier = float(state.get('investment_capacity_modifier', 1.0))
        return round(float(base_amount) * modifier, 2)
