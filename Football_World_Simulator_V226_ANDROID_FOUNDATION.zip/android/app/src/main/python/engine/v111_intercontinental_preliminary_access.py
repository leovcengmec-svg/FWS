"""V111 — Intercontinental Preliminary Access.

Freezes the annual Intercontinental access rule: six Level-1 continental
champions enter directly and exactly eight lower-level continental champions
contest the two remaining group-stage places.
"""
from __future__ import annotations
from copy import deepcopy
from .v110_intercontinental_annual_cycle import V110IntercontinentalAnnualCycle


class V111IntercontinentalPreliminaryAccess(V110IntercontinentalAnnualCycle):
    VERSION = "V111"
    PRELIMINARY_ENTRANTS = 8
    PRELIMINARY_SLOTS = 2

    def run_intercontinental(self, season=None, seed=111):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        year = int(season if season is not None else world.get("current_year", 2026))
        continental = world.get("continental_cycle", {})
        results = continental.get("results", {})

        champions = []
        for cid, row in results.items():
            champ = row.get("champion")
            if champ and champ in catalog.get("clubs", {}):
                champions.append({"competition_id": cid, "club_id": champ})

        unique, seen = [], set()
        for row in champions:
            if row["club_id"] not in seen:
                unique.append(row)
                seen.add(row["club_id"])

        level1 = self._level1_competitions(catalog)
        direct = self._ranked_clubs([r for r in unique if r["competition_id"] in level1], catalog)
        lower_level = self._ranked_clubs([r for r in unique if r["competition_id"] not in level1], catalog)
        # Exactly eight lower-level champions enter the access phase. The
        # deterministic ranking is simulation-only and does not invent clubs
        # or competition identities.
        prelim = lower_level[: self.PRELIMINARY_ENTRANTS]
        winners, prelim_matches = self._qualify_to_slots(
            prelim, self.PRELIMINARY_SLOTS, self.INTERCONTINENTAL_ID, year, seed + 11
        )
        group_entries = self._merge_unique(direct, winners, 8)
        groups, group_matches = self._groups(
            group_entries, 2, 4, self.INTERCONTINENTAL_ID, year, seed + 17
        )
        ko_pool = [c for g in groups for c in g["qualified"]]
        champion, knockout_matches = self._knockout(
            ko_pool, self.INTERCONTINENTAL_ID, year, seed + 31
        )

        execution = {
            "version": self.VERSION,
            "competition_id": self.INTERCONTINENTAL_ID,
            "season": year,
            "status": "completed",
            "format": "6_level1_direct+8_lower_level_prelim_for_2 -> 8 -> 2x4 -> single_leg_knockout",
            "level1_direct_places": 6,
            "preliminary_entrants_rule": self.PRELIMINARY_ENTRANTS,
            "preliminary_group_stage_places": self.PRELIMINARY_SLOTS,
            "continental_winners": len(unique),
            "direct_group_entries": len(direct),
            "lower_level_winners_available": len(lower_level),
            "preliminary_entries": len(prelim),
            "preliminary_winners": len(winners),
            "group_entries": len(group_entries),
            "groups": groups,
            "preliminary_matches": prelim_matches,
            "group_matches": group_matches,
            "knockout_matches": knockout_matches,
            "champion": champion.get("id") if champion else None,
        }
        world["intercontinental_execution"] = deepcopy(execution)
        world.setdefault("intercontinental_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("intercontinental", []).append(deepcopy(execution))
        self._record_intercontinental_legacy(execution)
        self._apply_intercontinental_consequences(execution)
        return deepcopy(execution)

    def validate(self):
        errors = super().validate()
        execution = self.save.get("world", {}).get("intercontinental_execution")
        if execution:
            if execution.get("version") != self.VERSION:
                errors.append("wrong V111 intercontinental execution version")
            if execution.get("level1_direct_places") != 6:
                errors.append("V111 must reserve 6 direct Level-1 places")
            if execution.get("preliminary_entries") != self.PRELIMINARY_ENTRANTS:
                errors.append("V111 preliminary phase must contain exactly 8 entrants")
            if execution.get("preliminary_group_stage_places") != self.PRELIMINARY_SLOTS:
                errors.append("V111 preliminary phase must qualify exactly 2 clubs")
            if len(execution.get("preliminary_matches", [])) != 6 and execution.get("preliminary_entries") == 8:
                errors.append("V111 8-to-2 preliminary phase must have 6 matches")
            if execution.get("group_entries") != 8:
                errors.append("V111 Intercontinental must have 8 group entries")
        return errors
