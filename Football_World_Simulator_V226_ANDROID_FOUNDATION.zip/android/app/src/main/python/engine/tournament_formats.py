from .two_legged import TwoLeggedTie
from .group_stage import MultiGroupStage
from .league_phase import LeaguePhase
from .draw import CompetitionDraw

class TournamentFormatEngine:
    def __init__(self, engine, seed=0):
        self.engine=engine; self.seed=seed

    def run(self, competition, clubs):
        fmt=competition.get("format","knockout")
        season=competition["season"]
        if fmt=="league":
            return {"format":fmt,"table":LeaguePhase(competition["id"],clubs,self.engine,season,
                competition.get("matches_per_club",8)).play()}
        if fmt=="groups":
            groups=CompetitionDraw(self.seed).groups(clubs,competition.get("group_count",4))
            results=MultiGroupStage(groups,self.engine,season).play()
            return {"format":fmt,"groups":results}
        if fmt=="two_legged":
            ties=[]
            pool=clubs[:]
            for i in range(0,len(pool)-1,2):
                ties.append(TwoLeggedTie(self.engine,competition["id"],season,i+1).play(pool[i],pool[i+1]))
            return {"format":fmt,"ties":ties}
        return {"format":"knockout","clubs":clubs}
