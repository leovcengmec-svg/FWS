import random

class DomesticCup:
    def __init__(self, competition_id, season, clubs, engine):
        self.id=competition_id; self.season=season; self.clubs=clubs[:]; self.engine=engine
        self.results=[]

    def play(self):
        pool=self.clubs[:]
        random.Random(self.season+len(pool)).shuffle(pool)
        round_no=1
        while len(pool)>1:
            nxt=[]
            for i in range(0,len(pool)-1,2):
                a,b=pool[i],pool[i+1]
                r=self.engine.play(self.id,self.season,round_no,a,b)
                self.results.append(r)
                nxt.append(a if r.home_goals>r.away_goals else b)
            if len(pool)%2: nxt.append(pool[-1])
            pool=nxt; round_no+=1
        return pool[0] if pool else None
