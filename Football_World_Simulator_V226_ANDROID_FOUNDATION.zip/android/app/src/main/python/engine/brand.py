class BrandEngine:
    """Fan, reputation and commercial momentum layer for clubs and selections."""
    def __init__(self, save, rng=None):
        import random
        self.save = save
        self.rng = rng or random.Random()
        self.history = save.setdefault('history', {}).setdefault('brand_evolution', [])

    def ensure_club(self, club):
        prestige = float(club.get('prestige', 20.0))
        club.setdefault('supporter_base', max(1000.0, prestige * 12000.0))
        club.setdefault('fan_engagement', min(100.0, max(10.0, prestige)))
        club.setdefault('brand_strength', min(100.0, max(5.0, prestige)))
        club.setdefault('commercial_strength', min(100.0, max(5.0, prestige * .9)))
        return club

    def season_club(self, club_id, league_position=None, league_size=None, continental=False):
        club = self.save['world']['clubs'][club_id]
        self.ensure_club(club)
        prestige = float(club.get('prestige', 20.0))
        if league_position and league_size:
            performance = max(-1.0, min(1.0, 1.0 - 2.0*(league_position-1)/max(1, league_size-1)))
        else:
            performance = 0.0
        continental_bonus = .45 if continental else 0.0
        marketing = float(club.get('marketing_level', 40.0))
        stadium = float(club.get('stadium_capacity', 5000.0))
        stadium_factor = min(1.0, stadium/100000.0)
        noise = self.rng.uniform(-1.5, 1.5)
        delta = performance*2.0 + continental_bonus + (marketing-40.0)*.025 + noise
        club['fan_engagement'] = max(1.0, min(100.0, club['fan_engagement'] + delta))
        club['brand_strength'] = max(1.0, min(100.0, club['brand_strength'] + delta*.75 + (prestige-club['brand_strength'])*.035))
        club['commercial_strength'] = max(1.0, min(100.0, club['commercial_strength'] + delta*.55 + (marketing-40)*.02 + stadium_factor*.35))
        club['supporter_base'] = max(1000.0, club['supporter_base'] * (1.0 + delta/1000.0))
        # Brand momentum modestly feeds future sponsorship potential, never guaranteed income.
        club['brand_momentum'] = round(delta, 3)
        row = {'entity_type':'club','entity_id':club_id,'season':self.save['world']['current_year'],
               'brand_strength':round(club['brand_strength'],2),'fan_engagement':round(club['fan_engagement'],2),
               'commercial_strength':round(club['commercial_strength'],2),'supporter_base':round(club['supporter_base'],0),'delta':round(delta,3)}
        self.history.append(row)
        return row

    def selection_profile(self, team):
        team.setdefault('national_prestige', float(team.get('prestige', 20.0)))
        team.setdefault('global_reputation', team['national_prestige'])
        team.setdefault('commercial_reputation', min(100.0, team['national_prestige']*.9))
        return team

    def season_selection(self, team_id, result_quality=None, opponent_strength=None):
        team = self.save['world']['national_teams'][team_id]
        self.selection_profile(team)
        gap = 0.0 if result_quality is None or opponent_strength is None else max(-1.0, min(1.0, (result_quality-opponent_strength)/30.0))
        infra = float(team.get('infrastructure_score', 40.0))
        noise = self.rng.uniform(-1.0, 1.0)
        delta = gap*2.5 + (infra-40)*.015 + noise
        team['global_reputation'] = max(1.0, min(100.0, team['global_reputation'] + delta))
        team['commercial_reputation'] = max(1.0, min(100.0, team['commercial_reputation'] + delta*.65))
        return {'entity_type':'selection','entity_id':team_id,'season':self.save['world']['current_year'], 'global_reputation':round(team['global_reputation'],2), 'commercial_reputation':round(team['commercial_reputation'],2), 'delta':round(delta,3)}
