from .calendar import CalendarEngine
from .calendar_rules import CalendarRules

class WorldCalendar:
    def __init__(self, save):
        self.save=save
        year=save["world"]["current_year"]
        self.engine=CalendarEngine(year)
        self.rules=CalendarRules()
        self.load()

    def load(self):
        cal=self.save.setdefault("calendar",{"season":self.save["world"]["current_year"],
                                             "fixtures":[],"reserved_windows":[]})
        for w in cal.get("reserved_windows",[]):
            self.engine.reserve_window(w["start_date"],w["end_date"],w["name"],"global")

    def reserve_national_window(self,start,end,name):
        self.engine.reserve_window(start,end,name,"global")
        self.save.setdefault("calendar",{}).setdefault("reserved_windows",[]).append(
            {"start_date":start,"end_date":end,"name":name})

    def add_round(self,competition_id,round_no,matches,preferred_day=None):
        rows=self.engine.schedule(competition_id,round_no,matches,preferred_day)
        self.save.setdefault("calendar",{})["fixtures"]=self.engine.export()
        return rows

    def conflicts(self):
        return self.engine.detect_conflicts()
