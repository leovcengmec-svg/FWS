"""V151 — Global Competition Integration."""
from __future__ import annotations

import pickle
from copy import deepcopy
from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity
from .world_simulator import WorldSimulator
from .season_pipeline import SeasonPipeline
from .coefficient import CoefficientEngine
from .promotion import PromotionRelegation
from .world_history import WorldHistoryLedger
from .v118_continental_rules_configuration import V118ContinentalRulesConfiguration
from .v133_world_integration import V133WorldIntegration
from .v112_continental_competition_framework import V112ContinentalCompetitionFramework

class V151GlobalCompetitionIntegration:
    VERSION="V151"; SCHEMA=1; SUPPORTED_SIZES=(10,16,20,27,32,36,72)
    OPERATIONAL_DEFAULTS={16:{"league_phase_matches_per_club":6,"post_league_playoff_legs":2,"knockout_legs":2},36:{"league_phase_matches_per_club":8,"post_league_playoff_legs":2,"knockout_legs":2},72:{"league_phase_matches_per_club":8,"post_league_playoff_legs":2,"knockout_legs":2}}
    def __init__(self,save,seed=151): self.save=save; self.seed=int(seed); self.rules=V118ContinentalRulesConfiguration(save)
    def _world(self): return self.save.setdefault("world",{})
    def _history(self): return self.save.setdefault("history",{})
    def _assert_no_players(self):
        if "players" in self._world() or "player_transfers" in self._history(): raise ValueError("V151 must not introduce individual players or player transfers")
    def _configs(self):
        out=[]; configured=self.save.get("continental",{}).get("competitions",{})
        world_comps=self._world().get("competitions",{})
        approved = V112ContinentalCompetitionFramework(self.save).build_registry()
        # V112 is the frozen source of truth for the continental pyramid.
        # A canonical global save has all 211 associations; only that full
        # runtime must materialize the complete 24-competition registry. Small
        # unit fixtures may intentionally carry their own reduced competition
        # set and must remain isolated from the global catalog expansion.
        country_count=len(self._world().get("associations", self._world().get("countries", {})))
        is_global_world=country_count >= 211
        if is_global_world:
            for cid, base in approved.items():
                merged=dict(world_comps.get(cid, {}))
                merged.update(base)
                merged["type"]="continental_club"
                world_comps[cid]=merged
                configured[cid]=dict(merged)
        for cid,raw in world_comps.items():
            if raw.get("type")!="continental_club" or not raw.get("enabled",False) or not raw.get("confederation"): continue
            cfg=dict(configured.get(cid,{})); cfg.update(dict(raw)); cfg["id"]=cid; size=int(cfg.get("size",cfg.get("default_size",0)))
            if cid in approved:
                # Approved size/name/confederation/tier always win over legacy config.
                cfg.update({k:v for k,v in approved[cid].items() if k in ("name","size","default_size","confederation","official","identity_type","tier","intercontinental_eligible","qualification")})
                size=int(approved[cid]["size"])
            if size in self.SUPPORTED_SIZES:
                if size in self.OPERATIONAL_DEFAULTS:
                    for k,v in self.OPERATIONAL_DEFAULTS[size].items(): cfg.setdefault(k,v)
                    cfg["knockout_size"]=self.rules.rules_contract(size)["knockout_size"]
                else:
                    cfg.setdefault("league_phase_matches_per_club",4 if size<=10 else (6 if size<=20 else 8))
                    cfg.setdefault("post_league_playoff_legs",2); cfg.setdefault("knockout_legs",2); cfg.setdefault("knockout_pairing","seeded")
                cfg.setdefault("knockout_pairing","seeded")
            out.append(cfg)
        return out
    def _leagues_for_conf(self,conf):
        countries=self._world().get("countries",{})
        return [dict(l) for l in self._world().get("leagues",{}).values() if countries.get(l.get("country_id"),{}).get("confederation")==conf]
    def _run_comp(self,cfg,leagues,tables,season,index,assigned):
        cid=cfg["id"]; size=int(cfg.get("size",cfg.get("default_size",0)))
        if size not in self.SUPPORTED_SIZES:
            return {"version":self.VERSION,"competition_id":cid,"season":season,"status":"configuration_pending","reason":"unsupported_global_competition_size","configured_size":size}
        # V112/V118 remain authoritative for 16/36/72. Existing regional
        # competitions with 10/20/27/32 receive an explicit generic regional
        # contract here rather than being silently skipped or renamed.
        generic = size not in (16,36,72)
        if not generic:
            errors=V118ContinentalRulesConfiguration.validate_competition_rules(cfg)
            if errors: return {"version":self.VERSION,"competition_id":cid,"season":season,"status":"configuration_pending","missing_configuration":errors}
        entry=self.rules.build_entry_field(cfg,leagues,tables,season=season,seed=self.seed+index*7919,already_assigned=assigned)
        if not entry["field_complete"]: return {"version":self.VERSION,"competition_id":cid,"season":season,"status":"entry_field_incomplete","entry":entry}
        assigned.update(x["club_id"] for x in entry["entries"])
        if size==72:
            a,b=entry["entries"][:36],entry["entries"][36:]
            la=self.rules.run_league_phase(dict(cfg,size=36),a,season=season,seed=self.seed+1001+index)
            lb=self.rules.run_league_phase(dict(cfg,size=36),b,season=season,seed=self.seed+2001+index)
            post=self.rules.run_72_post_league(cfg,la["standings"],lb["standings"],season=season,seed=self.seed+3001+index); lp=[la,lb]
            ko=self.rules.run_from_post_league(cfg,post,season=season,seed=self.seed+4001+index)
        elif size in (16,36):
            league=self.rules.run_league_phase(cfg,entry["entries"],season=season,seed=self.seed+1001+index)
            post=self.rules.run_post_league(cfg,league["standings"],season=season,seed=self.seed+2001+index); lp=league
            ko=self.rules.run_from_post_league(cfg,post,season=season,seed=self.seed+3001+index)
        else:
            # Generic regional format: after the league phase, top quarter
            # advance directly, the next half enters a playoff, and the same
            # number of playoff winners join the direct field. This produces a
            # compact knockout field for real configured regional sizes.
            matches = 4 if size <= 10 else (6 if size <= 20 else 8)
            gcfg=dict(cfg, league_phase_matches_per_club=matches)
            league=self.rules.run_league_phase(gcfg,entry["entries"],season=season,seed=self.seed+1001+index); lp=league
            rows=sorted(league["standings"],key=lambda r:(-r["points"],-r["goal_difference"],-r["goals_for"],str(r["club_id"])))
            direct_n=max(2,size//4); playoff_n=direct_n*2
            playoff_entries=rows[direct_n:direct_n+playoff_n]
            winners,pmatches=self.rules._playoff(playoff_entries,direct_n,cid,season,self.seed+2001+index,2)
            field=[*rows[:direct_n],*winners]
            post={"version":"V115-GENERIC-REGIONAL","competition_id":cid,"season":season,"field_size":size,"direct_count":direct_n,"playoff_entries":playoff_n,"playoff_qualifiers":len(winners),"direct":[x["club_id"] for x in rows[:direct_n]],"playoff_entries_ids":[x["club_id"] for x in playoff_entries],"playoff_winners":[x["club_id"] for x in winners],"knockout_field":[x["club_id"] for x in field],"knockout_size":len(field),"matches":pmatches,"generic_regional":True}
            ko=self._generic_knockout(cfg,field,season,self.seed+3001+index)
        return {"version":self.VERSION,"competition_id":cid,"season":season,"status":"completed","entry":deepcopy(entry),"league_phase":deepcopy(lp),"post_league":deepcopy(post),"knockout":deepcopy(ko),"champion":ko["champion_id"],"operational_defaults_applied":True}
    def _generic_knockout(self, cfg, field, season, seed):
        pool=[self.rules._club(x) for x in field]
        rounds=[]; round_no=1
        while len(pool)>1:
            winners=[]; matches=[]
            for i in range(0,len(pool),2):
                if i+1>=len(pool):
                    winners.append(pool[i]); continue
                winner,rows=self.rules._tie(pool[i],pool[i+1],competition_id=cfg.get("id","CONTINENTAL"),season=season,seed=seed,round_no=round_no,tie_id=i//2+1,legs=2)
                winners.append(winner); matches.extend(rows)
            rounds.append({"round_no":round_no,"input_size":len(pool),"tie_count":len(matches)//2,"winners":[x["id"] for x in winners],"matches":matches})
            pool=winners; round_no+=1
        return {"version":"V116-GENERIC-REGIONAL","competition_id":cfg.get("id"),"season":season,"knockout_size":len(field),"knockout_legs":2,"knockout_pairing":"seeded","initial_field":[x["id"] for x in [self.rules._club(y) for y in field]],"round_count":len(rounds),"rounds":rounds,"champion_id":pool[0]["id"]}

    @staticmethod
    def _matches(row):
        out=list(row.get("entry",{}).get("preliminary_matches",[])); phases=row.get("league_phase",[]); phases=phases if isinstance(phases,list) else [phases]
        for p in phases: out.extend(p.get("matches",[]))
        post=row.get("post_league",{}); out.extend(post.get("matches",[]))
        for g in post.get("group_results",[]): out.extend(g.get("matches",[]))
        for r in row.get("knockout",{}).get("rounds",[]): out.extend(r.get("matches",[]))
        return out
    def run_season(self,*,season=None,club_context=None,association_context=None,career_results=None,advance_year=True):
        world=self._world(); year=int(world.get("current_year",2026) if season is None else season); snapshot=pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            self._assert_no_players(); WorldBootstrap(self.save).prepare(); assert_world_integrity(self.save)
            sim=WorldSimulator(self.save,seed=self.seed); pipeline=SeasonPipeline(self.save,sim); league_results,cup_winners=pipeline.domestic_phase()
            coeff=CoefficientEngine(self.save.get("coefficients",{}).get("window_seasons",5),self.save.get("coefficients",{}).get("decay",.75))
            for lid,table in league_results.items(): coeff.update_league(self.save,lid,round(sum(r.get("points",0) for r in table)/len(table),3) if table else 0.0)
            tables=self._history().get("latest_tables",{}); results={}; assigned_by_conf={}
            for i,cfg in enumerate(self._configs()):
                assigned=assigned_by_conf.setdefault(cfg.get("confederation"),set()); results[cfg["id"]]=self._run_comp(cfg,self._leagues_for_conf(cfg.get("confederation")),tables,year,i,assigned)
            completed={cid:r for cid,r in results.items() if r.get("status")=="completed"}; participants=set()
            for r in completed.values(): participants.update(x["club_id"] for x in r.get("entry",{}).get("entries",[]))
            movements={}; places=self.save.get("simulation",{}).get("promotion_relegation_places",4)
            for country_id in world.get("countries",{}):
                changes=PromotionRelegation(places).apply_country(self.save,country_id)
                if changes: movements[country_id]=changes
            execution={"version":self.VERSION,"season":year,"status":"completed" if all(r.get("status")=="completed" for r in results.values()) else "partial","competitions":deepcopy(results),"competitions_processed":len(results),"competitions_completed":len(completed),"participants":len(participants),"matches_simulated":sum(len(self._matches(r)) for r in results.values())}
            world["continental_season_execution"]=deepcopy(execution); world["continental_cycle"]={"version":self.VERSION,"season":year,"competitions_processed":len(results),"competitions_completed":len(completed),"qualified_clubs":len(participants),"matches_simulated":execution["matches_simulated"],"results":{cid:{"status":r.get("status"),"champion":r.get("champion"),"entries":r.get("entry",{}).get("entry_count",0)} for cid,r in results.items()}}
            self._history().setdefault("continental_season",[]).append(deepcopy(execution))
            WorldHistoryLedger(self.save).record_world_season(year,league_results,cup_winners,{cid:r.get("champion") for cid,r in completed.items()},movements)
            integration=V133WorldIntegration(self.save,seed=self.seed+133).run_season(year,club_context=club_context or {},association_context=association_context or {},competitions=deepcopy(results),career_results=career_results or {},continental_participants=participants,advance_year=False)
            self._assert_no_players(); assert_world_integrity(self.save); next_year=year+1 if advance_year else year; world["current_year"]=next_year; world["current_round"]=0; world["master_cycle_status"]="closed"; world["master_cycle_version"]=self.VERSION
            row={"version":self.VERSION,"schema":self.SCHEMA,"season":year,"status":"closed","next_year":next_year,"domestic":{"leagues":len(league_results),"cups":len(cup_winners)},"continental":deepcopy(execution),"promotion_relegation":deepcopy(movements),"integration":deepcopy(integration)}
            self._history().setdefault("global_competition_cycles",[]).append(deepcopy(row)); return deepcopy(row)
        except Exception:
            restored = pickle.loads(snapshot); self.save.clear(); self.save.update(restored); raise
    def validate(self):
        errors=[]
        for row in self._history().get("global_competition_cycles",[]):
            if row.get("version")!=self.VERSION or row.get("status")!="closed": errors.append(f"invalid V151 cycle: {row.get('season')}")
            for cid,c in row.get("continental",{}).get("competitions",{}).items():
                if c.get("status")=="completed" and (int(c.get("entry",{}).get("competition_size",0)) not in self.SUPPORTED_SIZES or not c.get("champion")): errors.append(f"invalid completed competition: {cid}")
        if "players" in self._world() or "player_transfers" in self._history(): errors.append("V151 player systems are forbidden")
        return errors
