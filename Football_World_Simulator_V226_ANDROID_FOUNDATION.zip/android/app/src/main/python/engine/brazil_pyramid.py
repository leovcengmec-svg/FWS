"""Brazil-specific pyramid rules for the Football World Simulator."""
from __future__ import annotations

ACCESS_SIZE = 256
ACCESS_PROMOTIONS = 4
LOWER_TIER_SIZE = 96
GROUP_COUNT = 16
TEAMS_PER_GROUP = 6
RELEGATION_PLACES = 4


def series_definitions():
    """Return the canonical Brazilian A-F pyramid plus Access."""
    defs = []
    for level, letter in [(1, "A"), (2, "B"), (3, "C"), (4, "D"), (5, "E"), (6, "F")]:
        row = {
            "id": f"BRA-BR-{level}",
            "name": f"Campeonato Brasileiro Série {letter}",
            "country_id": "BRA",
            "level": level,
            "tier": "national",
            "format": "double_round_robin" if level <= 2 else "mixed_groups_knockout",
            "group_count": GROUP_COUNT if level >= 4 else None,
            "teams_per_group": TEAMS_PER_GROUP if level >= 4 else None,
            "club_count": LOWER_TIER_SIZE if level >= 4 else None,
            "promotion_places": 4 if level >= 3 else 0,
            "relegation_places": RELEGATION_PLACES,
            "relegation_target": f"BRA-BR-{level + 1}" if level < 6 else "BRA-ACCESS",
            "season_rule": "brazil_lower_tier_template_v1" if level >= 4 else "existing_brazil_rule_v1",
        }
        defs.append(row)
    defs.append({
        "id": "BRA-ACCESS",
        "name": "Divisão de Acesso Nacional",
        "country_id": "BRA",
        "level": 7,
        "tier": "access",
        "format": "two_legged_single_elimination",
        "club_count": ACCESS_SIZE,
        "promotion_places": ACCESS_PROMOTIONS,
        "relegation_places": 0,
        "promotion_target": "BRA-BR-6",
        "rounds": 6,
        "ties_per_path": 6,
        "matches_per_path": 12,
        "aggregate_tie_break": "penalties",
        "season_rule": "brazil_access_256_to_4_v2",
    })
    return defs


def lower_tier_template():
    return {
        "club_count": LOWER_TIER_SIZE,
        "group_count": GROUP_COUNT,
        "teams_per_group": TEAMS_PER_GROUP,
        "format": "mixed_groups_knockout",
        "promotion_places": 4,
        "relegation_places": RELEGATION_PLACES,
    }


def validate_lower_tiers(definitions):
    rows = {x["id"]: x for x in definitions}
    errors = []
    template = lower_tier_template()
    for sid in ("BRA-BR-4", "BRA-BR-5", "BRA-BR-6"):
        row = rows.get(sid)
        if not row:
            errors.append(f"missing {sid}")
            continue
        for key, expected in template.items():
            if row.get(key) != expected:
                errors.append(f"{sid}.{key} != {expected}")
    return errors


def build_access_field(relegated_from_f, candidates):
    """Build exactly 256 access participants, prioritising F relegation entrants."""
    ordered = []
    seen = set()
    for club_id in list(relegated_from_f) + list(candidates):
        if club_id not in seen:
            seen.add(club_id)
            ordered.append(club_id)
        if len(ordered) == ACCESS_SIZE:
            break
    if len(ordered) != ACCESS_SIZE:
        raise ValueError(f"Divisão de Acesso requires {ACCESS_SIZE} unique clubs")
    return ordered


def access_bracket(participants):
    """Return six two-legged rounds from 256 clubs to 4 promoted clubs."""
    if len(participants) != ACCESS_SIZE or len(set(participants)) != ACCESS_SIZE:
        raise ValueError("Access bracket requires exactly 256 unique clubs")
    sizes = []
    n = len(participants)
    while n > ACCESS_PROMOTIONS:
        n //= 2
        sizes.append(n)
    return {"participants": list(participants), "round_winners": sizes, "rounds": len(sizes),
            "legs_per_tie": 2, "matches_per_path": len(sizes) * 2,
            "aggregate_tie_break": "penalties", "promotions": ACCESS_PROMOTIONS}
