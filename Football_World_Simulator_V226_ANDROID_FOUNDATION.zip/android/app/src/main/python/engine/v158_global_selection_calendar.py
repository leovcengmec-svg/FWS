"""V158 — Global Selection Calendar & Qualification Engine.

Selection calendar fixed by FWS rules:
2026: World Cup (initial ranking), 8 friendlies, start WC2030 cycle
2027: WC qualifiers + continental qualifiers + 8 friendlies
2028: continental championships + WC qualifiers + 8 friendlies
2029: Nations League + conclusion WC2030 qualifiers + 8 friendlies
2030: World Cup + start WC2034 cycle + 8 friendlies
2031: qualifiers + continental qualifiers + 8 friendlies
2032: continental championships + WC qualifiers + 8 friendlies
2033: Nations League + conclusion WC2034 qualifiers + 8 friendlies
2034: World Cup + start WC2038 cycle + 8 friendlies
2035: qualifiers + continental qualifiers + 8 friendlies
2036: continental championships + WC qualifiers + 8 friendlies
2037: Nations League + conclusion WC2038 qualifiers + 8 friendlies
2038: World Cup.

Ranking is only an initialization mechanism for the first game year (2026).
From 2027 onward, official qualification is decided by simulated matches and
qualification ledgers, never by direct ranking selection.
No player layer is introduced.
"""
from __future__ import annotations
from copy import deepcopy
from collections import defaultdict
import hashlib

from .v126_national_team_cycle import V126NationalTeamCycle


class V158GlobalSelectionCalendar(V126NationalTeamCycle):
    VERSION = "V158"
    WORLD_CUP_YEARS = {2026, 2030, 2034, 2038}
    CONTINENTAL_CUP_YEARS = {2028, 2032, 2036}
    NATIONS_LEAGUE_YEARS = {2029, 2033, 2037}
    WC_CYCLE_STARTS = {2026: 2030, 2030: 2034, 2034: 2038}
    CONFEDS = ("UEFA", "AFC", "CAF", "CONMEBOL", "CONCACAF", "OFC")
    # Finals sizes retained from V126. Qualification is now match based.
    CONTINENTAL_FINAL_SIZE = {"UEFA":24,"CONMEBOL":16,"AFC":24,"CAF":24,"CONCACAF":16,"OFC":8}
    # Minimum qualification group counts adapt to association population.
    QUAL_GROUPS = {"UEFA":12,"AFC":8,"CAF":8,"CONCACAF":6,"CONMEBOL":3,"OFC":2}
    WC_SLOTS = {"UEFA":16,"AFC":8,"CAF":9,"CONMEBOL":6,"CONCACAF":6,"OFC":1}
    FRIENDLIES_PER_TEAM = 8
    NL_DIVISIONS = ("A","B","C","D")

    def _ensure_state(self):
        super()._ensure_state()
        w = self.save.setdefault("world", {})
        c = w.setdefault("selection_calendar", {})
        c.setdefault("version", self.VERSION)
        c.setdefault("world_cup_qualification_cycles", {})
        c.setdefault("continental_qualification", {})
        c.setdefault("nations_league", {})
        c.setdefault("friendlies", {})
        h = self.save.setdefault("history", {})
        h.setdefault("selection_calendar", [])
        h.setdefault("national_qualifiers", [])
        h.setdefault("continental_qualifiers", [])
        h.setdefault("nations_league", [])
        h.setdefault("national_friendlies", [])

    @staticmethod
    def calendar_for_year(year: int):
        y=int(year)
        rows=[]
        if y in (2026,2030,2034,2038): rows.append("WORLD_CUP")
        if y in (2028,2032,2036): rows.append("CONTINENTAL_CHAMPIONSHIPS")
        if y in (2029,2033,2037): rows.append("NATIONS_LEAGUE")
        if y in (2026,2030,2034): rows.append("WORLD_CUP_QUALIFICATION_START")
        elif y in (2027,2028,2029,2031,2032,2033,2035,2036,2037): rows.append("WORLD_CUP_QUALIFICATION")
        if y in (2027,2031,2035): rows.append("CONTINENTAL_QUALIFICATION")
        if y in (2026,2027,2028,2029,2030,2031,2032,2033,2034,2035,2036,2037,2038): rows.append("8_FRIENDLIES")
        return rows

    def _teams_by_conf(self):
        teams=self.save["world"].get("national_teams",{})
        out=defaultdict(list)
        for tid,t in teams.items():
            if t.get("confederation") in self.CONFEDS:
                out[t.get("confederation")].append(tid)
        for c in out: out[c].sort()
        return out

    def _ordered_initial(self, conf, ids):
        ranking=self.build_ranking(self.save["world"].get("current_year",2026))
        pos={r["team_id"]:i for i,r in enumerate(ranking["teams"])}
        return sorted(ids,key=lambda x:(pos.get(x,10**9),x))

    def _play_round_robin(self, competition, season, ids, seed, rounds=1):
        teams={k:self._team(v) for k,v in self.save["world"].get("national_teams",{}).items()}
        for k,t in teams.items(): t["id"]=k
        matches=[]; points=defaultdict(int)
        ids=list(ids)
        if len(ids)<2:return matches,points
        for r in range(rounds):
            offset=(r+1)%len(ids)
            rot=ids[offset:]+ids[:offset]
            if len(rot)%2: rot.append(None)
            for i in range(0,len(rot),2):
                a,b=rot[i],rot[i+1]
                if not a or not b or a==b: continue
                _,m,pa,pb=self._play_match(competition,season,r+1,teams[a],teams[b],seed+r*10000+i)
                matches.append(m); points[a]+=pa; points[b]+=pb
        return matches,points

    def _allocate_from_qualifiers(self, ids, points, slots):
        return sorted(ids,key=lambda x:(-points.get(x,0),x))[:slots]

    def _wc_cycle(self, target_year):
        return self.save["world"]["selection_calendar"]["world_cup_qualification_cycles"].setdefault(str(target_year),{"target_year":target_year,"started":target_year-4,"matches":[],"points":{},"qualified":None,"status":"open"})

    def _wc_qualification_year(self, year):
        target=year+4 if year in self.WC_CYCLE_STARTS else None
        if target is None:return None
        return target

    def simulate_world_cup_qualification(self, season):
        self._ensure_state(); y=int(season)
        target=2026 if y==2026 else self._wc_qualification_year(y)
        # 2026 is a special bootstrap: the game starts with the World Cup field from ranking.
        if y==2026:
            q=super().qualify_world_cup(y)
            q["method"]="initial_ranking_bootstrap"
            self.save["world"]["selection_calendar"]["world_cup_qualification_cycles"]["2030"]={"target_year":2030,"started":2026,"matches":[],"points":{},"qualified":None,"status":"open"}
        # All years belong to the active four-year WC cycle; 2026 is both
        # the initial bootstrap World Cup and the first qualifying year for 2030.
        target = 2030 if 2026 <= y <= 2029 else 2034 if 2030 <= y <= 2033 else 2038 if 2034 <= y <= 2037 else None
        if target is None:return None
        cycle=self._wc_cycle(target); teams=self._teams_by_conf(); all_matches=[]
        for ci,conf in enumerate(self.CONFEDS):
            ids=teams.get(conf,[])
            if not ids: continue
            # Two qualification matches per team per year; points accumulate over four years.
            matches,pts=self._play_round_robin(f"FWS_{conf}_WORLD_CUP_QUALIFIERS_{target}",y,ids,15800+ci*1000+y,rounds=2)
            all_matches.extend(matches)
            p=cycle["points"]
            for tid,val in pts.items(): p[tid]=int(p.get(tid,0))+int(val)
        cycle["matches"].extend(all_matches)
        cycle["last_season"]=y
        if y==target-1:
            qualified=[]; details={}
            for conf,slots in self.WC_SLOTS.items():
                ids=teams.get(conf,[]); chosen=self._allocate_from_qualifiers(ids,cycle["points"],slots)
                qualified.extend(chosen); details[conf]={"slots":slots,"qualified":chosen,"method":"four_year_match_qualification"}
            # Intercontinental places are the best non-qualified teams by accumulated qualifier points.
            pool=[tid for tid,val in sorted(cycle["points"].items(),key=lambda kv:(-kv[1],kv[0])) if tid not in qualified]
            chosen=pool[:2]; qualified.extend(chosen); details["INTERCONTINENTAL"]={"slots":2,"qualified":chosen,"method":"qualification_playoff_pool"}
            if len(qualified)!=48 or len(set(qualified))!=48: raise ValueError(f"WC{target} qualification did not close at 48")
            cycle["qualified"]=qualified; cycle["details"]=details; cycle["status"]="qualified"
            self.save["world"]["world_cup_qualification"]=deepcopy({"version":self.VERSION,"season":target,"qualified":qualified,"details":details,"method":"four_year_match_qualification"})
            self.save["history"]["world_cup_qualification" if "world_cup_qualification" in self.save["history"] else "national_qualifiers"] .append(deepcopy({"version":self.VERSION,"target_year":target,"qualified":qualified,"details":details}))
        return {"version":self.VERSION,"season":y,"target_world_cup":target,"status":cycle["status"],"match_count":len(all_matches),"qualified":cycle.get("qualified")}

    def simulate_continental_qualification(self, season):
        self._ensure_state(); y=int(season); out=[]
        # Qualifiers in 2027/2031/2035 feed finals in the following year.
        target=y+1
        if y not in (2027,2031,2035): return out
        teams=self._teams_by_conf()
        for ci,conf in enumerate(self.CONFEDS):
            ids=teams.get(conf,[])
            if not ids: continue
            final_size=self.CONTINENTAL_FINAL_SIZE[conf]
            groups=min(self.QUAL_GROUPS[conf],max(1,len(ids)//2))
            buckets=[[] for _ in range(groups)]
            for i,tid in enumerate(ids): buckets[i%groups].append(tid)
            matches=[]; pts=defaultdict(int)
            for gi,g in enumerate(buckets):
                m,p=self._play_round_robin(f"FWS_{conf}_CONTINENTAL_QUALIFIERS_{target}",y,g,15900+ci*1000+gi,rounds=2)
                matches.extend(m); pts.update({k:pts[k]+v for k,v in p.items()})
            ranked=sorted(ids,key=lambda x:(-pts.get(x,0),x)); qualified=ranked[:min(final_size,len(ranked))]
            row={"version":self.VERSION,"season":y,"target_year":target,"confederation":conf,"competition_id":f"FWS_{conf}_CONTINENTAL_QUALIFIERS_{target}","qualified":qualified,"matches":matches,"method":"qualifying_competition"}
            out.append(row); self.save["history"]["continental_qualifiers"].append(deepcopy(row))
            self.save["world"]["selection_calendar"]["continental_qualification"][f"{conf}:{target}"]=deepcopy(row)
        return out

    def _continental_final_field(self, conf, year):
        # 2026 uses ranking bootstrap. From 2028 onward use the previous year's qualification ledger.
        if year==2026:
            ranking=self.build_ranking(year)
            return [r["team_id"] for r in ranking["teams"] if r["confederation"]==conf][:self.CONTINENTAL_FINAL_SIZE[conf]]
        row=self.save["world"]["selection_calendar"]["continental_qualification"].get(f"{conf}:{year}")
        if row: return list(row.get("qualified",[]))
        # Never silently fall back to ranking after initialization.
        return []

    def simulate_continental_championships(self, season=None, seed=126):
        self._ensure_state(); year=int(season or self.save["world"].get("current_year",2026)); out=[]
        if year not in self.CONTINENTAL_CUP_YEARS and year!=2026: return out
        for conf,cfg in self.CONTINENTAL_FORMATS.items():
            ids=self._continental_final_field(conf,year)
            if len(ids)!=cfg["size"]: continue
            comp=self._tournament(f"FWS_{conf}_NATIONS",year,conf,ids,cfg["size"],cfg["groups"],cfg["knockout"],seed+len(out)*1000)
            comp["qualification_method"]="ranking_bootstrap" if year==2026 else "continental_qualification"
            self.save["history"]["national_team_competitions"].append(deepcopy(comp)); self.save["world"]["national_team_cycle"]["competitions"].append(deepcopy(comp)); out.append(comp)
        return out

    def simulate_nations_league(self, season):
        self._ensure_state(); y=int(season)
        if y not in self.NATIONS_LEAGUE_YEARS:return None
        teams=self._teams_by_conf(); all_rows=[]
        memberships=self.save["world"]["selection_calendar"].setdefault("nations_league_membership",{})
        for ci,conf in enumerate(self.CONFEDS):
            ids=teams.get(conf,[])
            if not ids: continue
            ranking=self.build_ranking(y); rankpos={r["team_id"]:r["rank"] for r in ranking["teams"]}
            stored=memberships.get(conf)
            if stored:
                div_map={name:[tid for tid in stored.get(name,[]) if tid in ids] for name in self.NL_DIVISIONS}
            else:
                ordered=sorted(ids,key=lambda x:(rankpos.get(x,9999),x))
                active_divs=4 if len(ordered)>=16 else 3 if len(ordered)>=8 else 2
                div_map={name:[] for name in self.NL_DIVISIONS[:active_divs]}
                for i,tid in enumerate(ordered): div_map[self.NL_DIVISIONS[i%active_divs]].append(tid)
            divs=[(name,members) for name,members in div_map.items() if members]
            conf_rows=[]
            for di,(division,member_ids) in enumerate(divs):
                matches,pts=self._play_round_robin(f"FWS_{conf}_NATIONS_LEAGUE_{division}_{y}",y,member_ids,16000+ci*1000+di*100,rounds=2)
                table=sorted(member_ids,key=lambda x:(-pts.get(x,0),x))
                promotions=table[:2] if di>0 else []
                relegations=table[-2:] if di<len(divs)-1 else []
                row={"version":self.VERSION,"season":y,"confederation":conf,"division":division,"teams":member_ids,"matches":matches,"table":table,"promotions":promotions,"relegations":relegations,"format":"groups_home_away_adapted"}
                conf_rows.append(row); self.save["history"]["nations_league"].append(deepcopy(row))
            # Apply promotion/relegation to the next Nations League edition.
            names=[r["division"] for r in conf_rows]
            next_map={r["division"]:list(r["teams"]) for r in conf_rows}
            for idx,name in enumerate(names):
                table=next(r["table"] for r in conf_rows if r["division"]==name)
                if idx>0:
                    lower=next_map[name]
                    top=table[:2]; next_map[name]=[x for x in lower if x not in top]
                    prev=names[idx-1]; next_map[prev].extend(top)
                if idx<len(names)-1:
                    bottom=table[-2:] if len(table)>=4 else table[-1:]
                    next_map[name]=[x for x in next_map[name] if x not in bottom]
                    next_map[names[idx+1]].extend(bottom)
            memberships[conf]={k:sorted(set(v)) for k,v in next_map.items()}
            all_rows.append({"confederation":conf,"season":y,"divisions":conf_rows,"next_membership":deepcopy(memberships[conf])})
        self.save["world"]["selection_calendar"]["nations_league"][str(y)]=deepcopy(all_rows)
        return {"version":self.VERSION,"season":y,"confederations":all_rows,"status":"completed"}

    def simulate_friendlies(self, season=None, seed=158):
        self._ensure_state(); y=int(season or self.save["world"].get("current_year",2026)); teams=self._teams_by_conf()
        all_ids=sorted([tid for ids in teams.values() for tid in ids])
        # Eight official friendly rounds. With an odd number of associations, four rounds
        # contain one bye and four contain one controlled double appearance so the
        # total annual appearances close exactly at 211 * 8.
        rounds=[]; counts=defaultdict(int)
        for r in range(self.FRIENDLIES_PER_TEAM):
            order=all_ids[r:]+all_ids[:r]
            # With an odd number of associations, four of the eight rounds
            # carry one bye (210 appearances) and four carry one extra
            # appearance (212). The four bye teams and four double-appearance
            # teams are distinct; this balances the year at exactly 8 matches
            # per team (211 * 8 appearances).
            if r < 4:
                order=order[:-1]  # one bye
            else:
                order.append([all_ids[210], all_ids[0], all_ids[1], all_ids[2]][r-4])  # compensate one of the first four bye teams
            used=[]; matches=[]
            for i in range(0,len(order),2):
                a,b=order[i],order[i+1]
                if a==b: raise ValueError("V158 friendly pairing produced self-match")
                teams_map={k:self._team(v) for k,v in self.save["world"]["national_teams"].items()}
                teams_map[a]["id"]=a; teams_map[b]["id"]=b
                _,m,_,_=self._play_match("FWS_INTERNATIONAL_FRIENDLY",y,r+1,teams_map[a],teams_map[b],seed+y*100+r*10000+i)
                matches.append(m); counts[a]+=1; counts[b]+=1; used.extend((a,b))
            rounds.append({"round":r+1,"match_count":len(matches),"matches":matches})
        if set(counts)!=set(all_ids) or any(counts[t]!=self.FRIENDLIES_PER_TEAM for t in all_ids):
            raise ValueError("V158 friendly calendar did not produce exactly 8 matches per national team")
        result={"version":self.VERSION,"season":y,"friendlies_per_team":self.FRIENDLIES_PER_TEAM,"team_match_counts":dict(counts),"rounds":rounds,"status":"completed"}
        self.save["history"]["national_friendlies"].append(deepcopy(result)); self.save["world"]["selection_calendar"]["friendlies"][str(y)]=deepcopy(result)
        return result

    def qualify_world_cup(self, season=None, seed=158):
        """Return the approved qualification ledger; 2026 alone uses ranking bootstrap."""
        self._ensure_state(); year=int(season or self.save["world"].get("current_year",2026))
        if year == 2026:
            q=super().qualify_world_cup(year,seed)
            q["version"]=self.VERSION; q["method"]="initial_ranking_bootstrap"
            return q
        q=self.save["world"].get("world_cup_qualification")
        if isinstance(q,dict) and int(q.get("season",0))==year and len(q.get("qualified",[]))==48:
            return deepcopy(q)
        raise ValueError(f"World Cup {year} has no completed four-year qualification ledger")

    def advance_cycle(self, season=None, seed=158):
        self._ensure_state(); year=int(season or self.save["world"].get("current_year",2026))
        self.build_ranking(year)
        wcq=self.simulate_world_cup_qualification(year)
        contq=self.simulate_continental_qualification(year)
        continental=self.simulate_continental_championships(year,seed=seed)
        nl=self.simulate_nations_league(year)
        friendlies=self.simulate_friendlies(year,seed=seed)
        wc=None
        if year in self.WORLD_CUP_YEARS:
            if year==2026:
                wc=super().simulate_world_cup(year,seed=seed)
                wc["qualification_method"]="initial_ranking_bootstrap"
            elif year in (2030,2034,2038):
                # Final qualification ledger already produced in the prior year.
                q=self.save["world"].get("world_cup_qualification")
                if not q or int(q.get("season",0))!=year:
                    raise ValueError(f"World Cup {year} missing completed qualification ledger")
                wc=super().simulate_world_cup(year,seed=seed)
                wc["qualification_method"]="four_year_match_qualification"
        result={"version":self.VERSION,"season":year,"calendar":self.calendar_for_year(year),"world_cup_qualification":wcq,"continental_qualification":contq,"continental":continental,"nations_league":nl,"friendlies":friendlies,"world_cup":wc,"status":"COMPLETE"}
        self.save["world"]["national_team_cycle"]["last_completed"]=deepcopy(result)
        self.save["history"]["selection_calendar"].append(deepcopy(result))
        return result

    def validate(self):
        self._ensure_state(); errors=[]
        w=self.save["world"]; c=w.get("selection_calendar",{})
        if c.get("version")!=self.VERSION: errors.append("V158 selection calendar version mismatch")
        for year in range(2026,2039):
            cal=self.calendar_for_year(year)
            if "8_FRIENDLIES" not in cal and year<=2038: errors.append(f"V158 missing friendlies {year}")
            if year in (2028,2032,2036) and "CONTINENTAL_CHAMPIONSHIPS" not in cal: errors.append(f"missing continental cup {year}")
            if year in (2029,2033,2037) and "NATIONS_LEAGUE" not in cal: errors.append(f"missing nations league {year}")
        if "players" in w or "player_transfers" in self.save.get("history",{}): errors.append("V158 player systems are forbidden")
        return errors
