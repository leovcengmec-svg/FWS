"""V189 — Investor risk, return, prestige and portfolio consequences."""
from __future__ import annotations
from copy import deepcopy
class V189InvestorConsequences:
    VERSION='V189'
    def __init__(self, save): self.save=save
    def close_season(self):
        inv=self.save.setdefault('careers',{}).setdefault('investor',{'cash':0,'owned_clubs':[],'transactions':[]})
        clubs=self.save.get('world',{}).get('clubs',{}); total=0.0; risk=0
        for cid in list(inv.get('owned_clubs',[])):
            c=clubs.get(cid)
            if not c: continue
            cash=float(c.get('cash',0)); value=float(c.get('market_value',0)); total+=value
            c['investor_return_index']=round((cash/max(value,0.1))*100,3)
            if cash<0: risk+=1
        inv['portfolio_value']=round(total,3); inv['risk_level']='high' if risk>=3 else ('medium' if risk else 'low')
        inv['prestige']=round(min(100, float(inv.get('prestige',0))+min(3,len(inv.get('owned_clubs',[]))*0.25)),2)
        row={'season':self.save['world'].get('current_year'),'portfolio_value':inv['portfolio_value'],'risk_level':inv['risk_level'],'prestige':inv['prestige']}
        self.save.setdefault('history',{}).setdefault('investor_consequences',[]).append(row)
        return deepcopy(row)
    def validate(self):
        inv=self.save.get('careers',{}).get('investor',{}); return [] if float(inv.get('portfolio_value',0))>=0 else ['negative_portfolio_value']
