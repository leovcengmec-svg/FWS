"""V105 — Super World Club Championship execution.

Executes the proprietary FWS 64-club Super World in its four-year season:
32-club preliminary knockout -> 8 qualifiers; 56 direct + 8 = 64;
16 groups of 4; then a single-leg 32-club knockout. Knockout matches use
regulation, extra time and penalties through the existing aggregate engine.
"""
from __future__ import annotations
from copy import deepcopy
from .v104_super_world_qualification import V104SuperWorldQualification


class V105SuperWorldExecution(V104SuperWorldQualification):
    VERSION = "V105"

    def run_super_world(self, season=None, cycle_years=4, seed=105):
        world = self.save.setdefault("world", {})
        year = int(season if season is not None else world.get("current_year", 2026))
        if year % int(cycle_years) != 0:
            world["super_world_execution"] = None
            return None

        qualification = self.build_super_world_qualification(year, cycle_years, seed - 1)
        catalog = self._catalog_from_save()
        clubs = catalog.get("clubs", {})
        def playable(rows):
            out = []
            for r in rows:
                c = dict(clubs[r["club_id"]])
                if "attack" not in c or "defense" not in c:
                    digest = __import__("hashlib").sha256(f"{seed}:{year}:{c['id']}".encode()).digest()
                    strength = 45.0 + (digest[0] / 255.0) * 30.0
                    c.setdefault("attack", strength)
                    c.setdefault("defense", strength)
                    c.setdefault("prestige", strength)
                out.append(c)
            return out

        direct = playable(qualification["direct"])
        preliminary = playable(qualification["preliminary"])

        winners8, preliminary_matches = self._qualify_to_slots(
            preliminary, 8, self.SUPER_WORLD_ID, year, seed + 1
        )
        group_field = self._merge_unique(direct, winners8, 64)
        if len(group_field) != 64:
            raise ValueError("Super World group field must contain exactly 64 unique clubs")

        groups, group_matches = self._groups(
            group_field, 16, 4, self.SUPER_WORLD_ID, year, seed + 7
        )
        knockout_field = [c for g in groups for c in g["qualified"]]
        if len(knockout_field) != 32 or len({c["id"] for c in knockout_field}) != 32:
            raise ValueError("Super World knockout field must contain 32 unique clubs")

        champion, knockout_matches = self._knockout(
            knockout_field, self.SUPER_WORLD_ID, year, seed + 17
        )
        execution = {
            "version": self.VERSION,
            "competition_id": self.SUPER_WORLD_ID,
            "season": year,
            "format": "32_prelim->8 + 56_direct -> 16x4 -> 32_club_single_leg_knockout",
            "qualification": {
                "direct_entries": 56,
                "preliminary_entries": 32,
                "preliminary_qualifying_places": 8,
                "group_entries": 64,
            },
            "preliminary_matches": preliminary_matches,
            "preliminary_winners": [c["id"] for c in winners8],
            "groups": groups,
            "group_matches": group_matches,
            "knockout_entries": len(knockout_field),
            "knockout_matches": knockout_matches,
            "champion": champion["id"] if champion else None,
            "status": "completed" if champion else "incomplete",
        }
        world["super_world_execution"] = deepcopy(execution)
        world.setdefault("super_world_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("super_world", []).append(deepcopy(execution))
        return deepcopy(execution)

    def validate(self):
        errors = super().validate()
        execution = self.save.get("world", {}).get("super_world_execution")
        if not execution:
            return errors
        if execution.get("version") != self.VERSION:
            errors.append("wrong super world execution version")
        q = execution.get("qualification", {})
        if q.get("direct_entries") != 56 or q.get("preliminary_entries") != 32 or q.get("preliminary_qualifying_places") != 8:
            errors.append("super world qualification counts invalid")
        if q.get("group_entries") != 64:
            errors.append("super world group field must be 64")
        if len(execution.get("groups", [])) != 16:
            errors.append("super world must contain 16 groups")
        if any(len(g.get("clubs", [])) != 4 for g in execution.get("groups", [])):
            errors.append("every super world group must contain 4 clubs")
        if execution.get("knockout_entries") != 32:
            errors.append("super world knockout must start with 32 clubs")
        if not execution.get("champion"):
            errors.append("super world must have a champion when completed")
        return errors
