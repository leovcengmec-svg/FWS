"""V164 — Global World Season Motor.

V164 is the single orchestration facade for one FWS world season.  It does not
replace the approved competition engines: V151 remains authoritative for the
club season, V119 for the annual Intercontinental, V157 for the Super World,
and V158/V162 for national selections and qualification integrity.

The motor adds a deterministic dependency chain, phase ledger, invariant
checks, and one atomic entry point so callers do not accidentally execute only
part of a world season.
"""
from __future__ import annotations
from copy import deepcopy
import pickle

from .v152_global_world_season_engine import V152GlobalWorldSeasonEngine
from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity


class V164GlobalSeasonMotor:
    VERSION = "V164"
    SCHEMA = 1
    PHASES = (
        "CLUB_DOMESTIC_CONTINENTAL",
        "INTERCONTINENTAL_CLUB",
        "SUPER_WORLD_CLUB",
        "NATIONAL_SELECTION",
        "GLOBAL_CALENDAR_CLOSE",
    )

    def __init__(self, save, seed=164):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("global_season_motor", [])

    @staticmethod
    def _phase_status(row, phase):
        if phase == "CLUB_DOMESTIC_CONTINENTAL":
            return row.get("sporting", {}).get("status", "unknown")
        if phase == "INTERCONTINENTAL_CLUB":
            return row.get("intercontinental", {}).get("status", "unknown")
        if phase == "SUPER_WORLD_CLUB":
            value = row.get("super_world")
            return "not_due" if value is None else value.get("status", "unknown")
        if phase == "NATIONAL_SELECTION":
            return row.get("national_team", {}).get("status", "unknown")
        if phase == "GLOBAL_CALENDAR_CLOSE":
            return row.get("calendar", {}).get("status", "unknown")
        return "unknown"

    def _build_motor_report(self, row):
        phases = []
        for index, phase in enumerate(self.PHASES, start=1):
            phases.append({"order": index, "phase": phase, "status": self._phase_status(row, phase)})
        return {
            "version": self.VERSION,
            "schema": self.SCHEMA,
            "season": int(row["season"]),
            "status": "completed" if all(p["status"] in ("completed", "COMPLETE", "closed", "valid", "not_due") for p in phases) else "configuration_pending",
            "dependency_chain": list(self.PHASES),
            "phases": phases,
            "source_engine": "V152GlobalWorldSeasonEngine",
            "source_versions": ["V151", "V119", "V157", "V162", "V152"],
            "player_layer_forbidden": True,
        }

    def _validate_row(self, row, season):
        errors = []
        if int(row.get("season", -1)) != int(season):
            errors.append("season_mismatch")
        if int(row.get("next_year", -1)) != int(season) + 1:
            errors.append("next_year_mismatch")
        if row.get("calendar", {}).get("status") != "valid":
            errors.append("calendar_not_valid")
        if row.get("intercontinental", {}).get("status") != "completed":
            errors.append("intercontinental_not_completed")
        national = row.get("national_team", {})
        if national.get("status") not in ("COMPLETE", "completed"):
            errors.append("national_cycle_not_complete")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("player_layer_forbidden")
        return errors

    def run_season(self, *, season=None, advance_year=True, club_context=None,
                   association_context=None, career_results=None):
        year = int(self._world().get("current_year", 2026) if season is None else season)
        if any(int(r.get("season", -1)) == year for r in self._ledger()):
            raise ValueError(f"V164 season {year} already integrated")

        # The world save contains large historical ledgers. Pickle provides a
        # much faster atomic snapshot than recursive deepcopy while preserving
        # the exact rollback semantics of the V164 boundary.
        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            WorldBootstrap(self.save).prepare()
            assert_world_integrity(self.save)
            row = V152GlobalWorldSeasonEngine(self.save, seed=self.seed).run_season(
                season=year,
                advance_year=advance_year,
                club_context=club_context,
                association_context=association_context,
                career_results=career_results,
            )
            errors = self._validate_row(row, year)
            if errors:
                raise ValueError("V164 season motor validation failed: " + "; ".join(errors))

            motor = self._build_motor_report(row)
            if motor["status"] != "completed":
                raise ValueError("V164 season motor did not close all phases")
            self._ledger().append(deepcopy(motor))
            self._world()["global_season_motor_version"] = self.VERSION
            self._world()["global_season_motor_status"] = "validated"
            row = deepcopy(row)
            row["season_motor"] = deepcopy(motor)
            return row
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        for row in self._ledger():
            if row.get("version") != self.VERSION:
                errors.append(f"wrong_version:{row.get('season')}")
            if row.get("status") != "completed":
                errors.append(f"motor_not_completed:{row.get('season')}")
            if row.get("dependency_chain") != list(self.PHASES):
                errors.append(f"dependency_chain_invalid:{row.get('season')}")
            if len(row.get("phases", [])) != len(self.PHASES):
                errors.append(f"phase_count_invalid:{row.get('season')}")
            if any(p.get("status") not in ("completed", "COMPLETE", "closed", "valid", "not_due") for p in row.get("phases", [])):
                errors.append(f"phase_status_invalid:{row.get('season')}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("player_system_forbidden")
        return errors
