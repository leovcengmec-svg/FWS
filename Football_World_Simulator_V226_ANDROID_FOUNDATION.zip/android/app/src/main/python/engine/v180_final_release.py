"""V180 — Finalization and Playable Build release gate."""
from __future__ import annotations
from copy import deepcopy
from .v177_release_hardening import V177ReleaseHardening
from .v178_runtime_packaging import V178RuntimePackaging
from .v179_playable_world import V179PlayableWorld
from .v176_world_intelligence_integration import V176WorldIntelligenceIntegration

class V180FinalRelease:
    VERSION='V180'; SCHEMA=1
    CHAIN=('V177','V178','V179','V180')
    def __init__(self,save,seed=180): self.save=save; self.seed=int(seed)
    def build(self,run_smoke=True):
        hard=V177ReleaseHardening(self.save).run()
        runtime=V178RuntimePackaging(self.save).start()
        playable=V179PlayableWorld(self.save,self.seed+179).start()
        smoke=None
        if run_smoke:
            clubs=self.save.get('world',{}).get('clubs',{})
            if not clubs: raise ValueError('V180 no clubs available')
            smoke={'status':'passed','club_count':len(clubs),'selected_sample':sorted(clubs)[0]}
        row={'version':self.VERSION,'schema':self.SCHEMA,'status':'released','chain':list(self.CHAIN),
             'base_version':'V176','hardening':hard,'runtime':runtime,'playable':playable,'smoke':smoke,
             'player_layer_forbidden':True}
        self.save.setdefault('history',{}).setdefault('final_release',[]).append(deepcopy(row))
        self.save.setdefault('world',{})['final_release_version']=self.VERSION
        self.save['world']['final_release_status']='released'
        return deepcopy(row)
    def validate(self):
        errors=V177ReleaseHardening(self.save).validate()
        errors += V178RuntimePackaging(self.save).validate()
        errors += V179PlayableWorld(self.save,self.seed+179).validate()
        for row in self.save.get('history',{}).get('final_release',[]):
            if row.get('version')!=self.VERSION or row.get('status')!='released': errors.append('invalid_final_release')
            if row.get('chain')!=list(self.CHAIN): errors.append('final_release_chain_invalid')
        if self.save.get('world',{}).get('final_release_version')!=self.VERSION: errors.append('final_release_version_missing')
        return sorted(set(errors))
