from .tournament import KnockoutTournament

class ContinentalSeason:
    def __init__(self, save, competition, entries, engine):
        self.save=save
        self.competition=competition
        self.entries=entries
        self.engine=engine
        self.matches=[]
        self.champion=None

    def run(self):
        clubs=[self.save["world"]["clubs"][e["club_id"]] for e in self.entries]
        # The competition's configured size is respected; if too few entries exist,
        # the season runs with the available field rather than fabricating clubs.
        clubs=clubs[:self.competition["size"]]
        ko=KnockoutTournament(self.competition["id"],self.save["world"]["current_year"],clubs,self.engine)
        self.champion=ko.run()
        self.matches=[m.__dict__ for m in ko.matches]
        return self.champion
