"""V170 — Competition Lifecycle Audit."""
from __future__ import annotations
from copy import deepcopy
class V170CompetitionLifecycleAudit:
    VERSION='V170'; SCHEMA=1
    def __init__(self,save): self.save=save
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def audit_season(self, season):
        h=self._history(); w=self._world(); errors=[]; completed=0; champions=0
        comps=h.get('continental_season',[]); row=next((r for r in reversed(comps) if int(r.get('season',-1))==int(season)),None)
        if row is None: errors.append(f'missing_continental_season:{season}')
        else:
            for cid,c in row.get('competitions',{}).items():
                if c.get('status')=='completed':
                    completed+=1
                    if not c.get('champion'): errors.append(f'completed_without_champion:{cid}')
                    else: champions+=1
                    size=int(c.get('entry',{}).get('competition_size',0))
                    if size not in (10,16,20,27,32,36,72): errors.append(f'invalid_field_size:{cid}:{size}')
        for key in ('global_competition_cycles','global_world_seasons'):
            found=next((r for r in reversed(h.get(key,[])) if int(r.get('season',-1))==int(season)),None)
            if found is None: errors.append(f'missing_{key}:{season}')
        inter=next((r for r in reversed(h.get('global_world_seasons',[])) if int(r.get('season',-1))==int(season)),None)
        if inter:
            if inter.get('intercontinental',{}).get('status') not in ('completed','configuration_pending'): errors.append('intercontinental_invalid_status')
            sw=inter.get('super_world')
            if sw is not None and sw.get('status')!='completed': errors.append('super_world_invalid_status')
            if inter.get('calendar',{}).get('status')!='valid': errors.append('calendar_invalid')
        if 'players' in w or 'player_transfers' in h: errors.append('player_system_forbidden')
        return {'season':int(season),'status':'PASS' if not errors else 'FAIL','errors':errors,'completed_continental_competitions':completed,'champions_recorded':champions}
    def run(self, season=None):
        year=int(self._world().get('current_year',2026)-1 if season is None else season)
        report=self.audit_season(year); 
        if report['errors']: raise ValueError('V170 lifecycle audit failed: '+ '; '.join(report['errors']))
        self._history().setdefault('competition_lifecycle_audits',[]).append(deepcopy(report)); return deepcopy(report)
    def validate(self):
        return [f"V170 audit failed:{r.get('season')}" for r in self._history().get('competition_lifecycle_audits',[]) if r.get('status')!='PASS']
