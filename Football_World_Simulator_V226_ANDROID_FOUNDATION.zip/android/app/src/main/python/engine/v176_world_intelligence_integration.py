"""V176 — World Intelligence Integration.

Final integration facade for Grande Atualização 2. It can run the intelligence
layers after an existing V164 season, or run a standalone intelligence cycle.
Atomic rollback protects the already validated world-season pipeline.
"""
from __future__ import annotations
import pickle
from copy import deepcopy
from .v173_world_intelligence_core import V173WorldIntelligenceCore
from .v174_dynamic_world_simulation import V174DynamicWorldSimulation
from .v175_competition_market_dynamics import V175CompetitionMarketDynamics

class V176WorldIntelligenceIntegration:
    VERSION="V176"
    SCHEMA=1
    CHAIN=("V173","V174","V175","V176")
    def __init__(self,save,seed=176): self.save=save; self.seed=int(seed)
    def _world(self): return self.save.setdefault("world",{})
    def _history(self): return self.save.setdefault("history",{})

    def run_cycle(self,season=None):
        world=self._world(); history=self._history(); year=int(world.get("current_year",2026) if season is None else season)
        snapshot=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        try:
            a=V173WorldIntelligenceCore(self.save,self.seed+173).run(year)
            b=V174DynamicWorldSimulation(self.save,self.seed+174).run(year)
            c=V175CompetitionMarketDynamics(self.save,self.seed+175).run(year)
            validation_errors = (
                V173WorldIntelligenceCore(self.save).validate()
                + V174DynamicWorldSimulation(self.save).validate()
                + V175CompetitionMarketDynamics(self.save).validate()
            )
            if validation_errors:
                raise ValueError("Grande Bloco 2 validation failed: " + "; ".join(validation_errors))
            row={"version":self.VERSION,"schema":self.SCHEMA,"season":year,"status":"completed",
                 "chain":list(self.CHAIN),"counts":{"clubs":a["counts"]["clubs"],"associations":a["counts"]["associations"],"competitions":a["counts"]["competitions"]},
                 "stages":{"V173":"completed","V174":"completed","V175":"completed"},"player_layer_forbidden":True}
            history.setdefault("world_intelligence_integration",[]).append(deepcopy(row))
            world["world_intelligence_integration_version"]=self.VERSION
            world["world_intelligence_integration_status"]="validated"
            world["world_intelligence_pending_effects"]=False
            return deepcopy(row)
        except Exception:
            self.save.clear();self.save.update(pickle.loads(snapshot));raise

    def run_after_season(self, season_result):
        season=int(season_result["season"])
        return self.run_cycle(season)

    def validate(self):
        errors=[]; world=self._world(); history=self._history()
        if "players" in world or "player_transfers" in history: errors.append("player_system_forbidden")
        for row in history.get("world_intelligence_integration",[]):
            if row.get("version")!=self.VERSION or row.get("status")!="completed": errors.append("invalid_integration")
            if row.get("chain")!=list(self.CHAIN): errors.append("chain_invalid")
        return sorted(set(errors))
