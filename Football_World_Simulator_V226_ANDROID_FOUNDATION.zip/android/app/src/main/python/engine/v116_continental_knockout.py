from __future__ import annotations
from copy import deepcopy
import hashlib
from .match_engine import MatchEngine
from .v115_continental_post_league import V115ContinentalPostLeague


class V116ContinentalKnockout(V115ContinentalPostLeague):
    """V116: executes the continental knockout after V115 produces the field.

    The knockout size is inherited from the V112/V115 format (8, 16 or 32).
    The number of legs and pairing policy remain competition-configurable so
    no unapproved competition detail is frozen into the framework.
    """
    VERSION = "V116"

    @staticmethod
    def _club(entry):
        if isinstance(entry, dict):
            cid = entry["club_id"]
            strength = float(entry.get("league_coefficient", entry.get("strength", 50.0)))
        else:
            cid = entry
            strength = 50.0
        strength = max(1.0, min(99.0, strength))
        return {"id": cid, "attack": strength, "defense": strength,
                "prestige": strength, "sporting_strength": strength}

    @staticmethod
    def _tie_break(high_id, low_id, seed, competition_id, season, round_no, tie_id):
        digest = hashlib.sha256(
            f"{seed}:{competition_id}:{season}:{round_no}:{tie_id}:{high_id}:{low_id}".encode()
        ).digest()
        return high_id if digest[0] % 2 == 0 else low_id

    @staticmethod
    def _pair(pool, policy):
        if policy == "seeded":
            return [(pool[i], pool[-1 - i]) for i in range(len(pool) // 2)]
        if policy == "adjacent":
            return [(pool[i], pool[i + 1]) for i in range(0, len(pool), 2)]
        raise ValueError("unsupported knockout_pairing; use 'seeded' or 'adjacent'")

    def _tie(self, high, low, *, competition_id, season, seed, round_no, tie_id, legs):
        high_id, low_id = high["id"], low["id"]
        totals = {high_id: 0, low_id: 0}
        matches = []
        for leg in range(1, legs + 1):
            home, away = (high, low) if leg % 2 else (low, high)
            result = MatchEngine(int(seed) + round_no * 100003 + tie_id * 1009 + leg).play(
                competition_id, int(season), round_no, home, away
            )
            hg, ag = int(result.home_goals), int(result.away_goals)
            totals[home["id"]] += hg
            totals[away["id"]] += ag
            matches.append({
                "competition_id": competition_id, "season": int(season),
                "round_no": round_no, "tie_id": tie_id, "leg": leg,
                "home_id": home["id"], "away_id": away["id"],
                "home_goals": hg, "away_goals": ag,
            })
        if totals[high_id] > totals[low_id]:
            winner = high
        elif totals[low_id] > totals[high_id]:
            winner = low
        else:
            winner_id = self._tie_break(high_id, low_id, seed, competition_id, season, round_no, tie_id)
            winner = high if winner_id == high_id else low
        for match in matches:
            match["tie_winner_id"] = winner["id"]
        return winner, matches

    def run_knockout(self, competition, field, *, season=2026, seed=116):
        comp = dict(competition)
        expected = int(comp.get("knockout_size", comp.get("size", 0)))
        if expected not in (8, 16, 32):
            raise ValueError("continental knockout size must be 8, 16 or 32")
        if len(field) != expected:
            raise ValueError("knockout field does not match configured knockout size")
        if len({self._club(x)["id"] for x in field}) != expected:
            raise ValueError("knockout field contains duplicate clubs")
        legs = int(comp.get("knockout_legs", 1))
        if legs <= 0:
            raise ValueError("knockout_legs must be positive")
        policy = comp.get("knockout_pairing", "seeded")
        pool = [self._club(x) for x in field]
        rounds = []
        round_no = 1
        while len(pool) > 1:
            pairs = self._pair(pool, policy)
            winners = []
            round_matches = []
            for tie_id, (high, low) in enumerate(pairs, 1):
                winner, matches = self._tie(
                    high, low, competition_id=comp.get("id", "CONTINENTAL"),
                    season=season, seed=seed, round_no=round_no, tie_id=tie_id, legs=legs
                )
                winners.append(winner)
                round_matches.extend(matches)
            rounds.append({
                "round_no": round_no,
                "input_size": len(pool),
                "tie_count": len(pairs),
                "winners": [x["id"] for x in winners],
                "matches": round_matches,
            })
            pool = winners
            round_no += 1
        champion = pool[0]["id"]
        return {
            "version": self.VERSION,
            "competition_id": comp.get("id"),
            "season": int(season),
            "knockout_size": expected,
            "knockout_legs": legs,
            "knockout_pairing": policy,
            "initial_field": [self._club(x)["id"] for x in field],
            "round_count": len(rounds),
            "rounds": rounds,
            "champion_id": champion,
        }

    def run_from_post_league(self, competition, post_league_result, *, season=2026, seed=116):
        result = dict(post_league_result)
        field_ids = result.get("knockout_field", [])
        if not field_ids:
            raise ValueError("post-league result has no knockout field")
        field = [{"club_id": cid, "league_coefficient": 50.0} for cid in field_ids]
        comp = dict(competition)
        comp["knockout_size"] = len(field)
        return self.run_knockout(comp, field, season=season, seed=seed)

    def apply(self):
        super().apply()
        world = self.save.setdefault("world", {})
        world["continental_knockout_framework"] = {
            "version": self.VERSION,
            "base_version": "V115",
            "execution_order": ["entry_qualification", "league_phase", "post_league_qualification", "knockout", "champion"],
            "supported_knockout_sizes": [8, 16, 32],
            "knockout_legs_is_configurable": True,
            "knockout_pairing_is_configurable": True,
            "default_knockout_pairing": "seeded",
            "no_catalog_mutation": True,
        }
        self.save.setdefault("continental", {})["knockout_version"] = self.VERSION
        return deepcopy(world["continental_knockout_framework"])

    def validate(self):
        errors = super().validate()
        fw = self.save.get("world", {}).get("continental_knockout_framework", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V116 continental knockout framework version")
        return errors
