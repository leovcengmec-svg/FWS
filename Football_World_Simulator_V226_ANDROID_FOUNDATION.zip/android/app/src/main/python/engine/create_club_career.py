from .assets import AssetManager
from .investor_career import InvestorCareer

LEVELS={"START_FROM_LAST_DIVISION":22}

class CreateClubCareer:
    def __init__(self, save, assets_root):
        self.save=save
        self.assets=AssetManager(assets_root)

    def create_from_zero(self, club_id, name, country_id, city, colors, image_file=None, starting_cash=2.0, state_code=None):
        if country_id == "BRA":
            from .v180_1_career_experience_completion import V1801CareerExperienceCompletion
            if not state_code:
                raise ValueError("para criar um clube no Brasil é obrigatório escolher o estado")
            return V1801CareerExperienceCompletion.create_brazil_club(
                self, club_id, name, city, colors, state_code, image_file=image_file, starting_cash=starting_cash
            )

        leagues=sorted(
            [l for l in self.save["world"]["leagues"].values() if l["country_id"]==country_id],
            key=lambda x:x["level"], reverse=True)
        if not leagues: raise ValueError("país sem pirâmide cadastrada")
        bottom=leagues[0]
        if club_id in self.save["world"]["clubs"]: raise ValueError("id já existe")
        club={
          "id":club_id,"name":name,"country_id":country_id,"city":city,
          "league_id":bottom["id"],"division":bottom["level"],
          "attack":22,"defense":22,"prestige":10,"cash":starting_cash,
          "market_value":max(0.5,starting_cash*1.5),
          "created_by_user":True,"career_origin":"created_from_zero",
          "owner_type":"user_investor","owner_id":"player","colors":colors,
          "asset":{"type":"user_club","id":club_id,"path":None}
        }
        if image_file:
            club["asset"]["path"]=self.assets.register("user_club",club_id,image_file)
        self.save["world"]["clubs"][club_id]=club
        bottom["club_ids"].append(club_id)
        self.save.setdefault("world",{}).setdefault("custom_clubs",[]).append(club_id)
        investor = self.save.setdefault("careers", {}).setdefault("investor", {})
        # Existing career records may predate the created_clubs ledger. Repair
        # missing collections without replacing cash, ownership, or transactions.
        investor.setdefault("cash", 0.0)
        investor.setdefault("owned_clubs", [])
        investor.setdefault("transactions", [])
        investor.setdefault("created_clubs", [])
        if club_id not in investor["owned_clubs"]:
            investor["owned_clubs"].append(club_id)
        if club_id not in investor["created_clubs"]:
            investor["created_clubs"].append(club_id)
        return club
