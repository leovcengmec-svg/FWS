class OwnershipOwnerAccounts:
    """Explicit financial ledgers for non-player ownership-market sellers.

    Accounts are opt-in: the simulator never invents a seller balance. This
    lets V41 settle AI-to-AI deals safely while preserving the V40 defer rule
    when an owner has no financial ledger.
    """
    def __init__(self, save):
        self.save = save
        self.accounts = save.setdefault('runtime', {}).setdefault('ownership_owner_accounts', {})

    def register(self, owner_id, capital):
        owner_id = str(owner_id)
        capital = float(capital)
        if not owner_id:
            raise ValueError('proprietário inválido')
        if capital < 0:
            raise ValueError('capital inválido')
        if owner_id in self.accounts:
            raise ValueError('conta já cadastrada')
        self.accounts[owner_id] = {'capital': round(capital, 2)}
        return {'owner_id': owner_id, 'capital': self.accounts[owner_id]['capital']}

    def ensure(self, owner_id, capital=0.0):
        owner_id = str(owner_id)
        if owner_id not in self.accounts:
            self.register(owner_id, capital)
        return self.accounts[owner_id]

    def balance(self, owner_id):
        if owner_id not in self.accounts:
            raise ValueError('conta inexistente')
        return float(self.accounts[owner_id]['capital'])
