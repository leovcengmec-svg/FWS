"""V162 — Global Qualification Integrity Audit.

Audits the frozen access architecture without changing sporting rules:
- World Cup V127/V161: 48 direct + 32 global playoff -> 16 -> 64.
- Intercontinental V153/V119: 6 Level-1 direct + 17 lower-level,
  with 15 direct to the 16-club playoff and 2 in a preliminary -> 1.
- Super World V157: 48 continental-cycle + 4 Intercontinental + 4 coefficient
  direct = 56 direct, plus 32 preliminary -> 8 -> 64.

No player layer is introduced.
"""
from __future__ import annotations
from copy import deepcopy

from .v161_world_cup_64_correction import V161WorldCup64Correction
from .v119_intercontinental_club_format import V119IntercontinentalClubFormat
from .v157_club_calendar import V157ClubCalendar


class V162QualificationIntegrityAudit(V161WorldCup64Correction):
    VERSION = "V162"

    WC_DIRECT_TOTAL = 48
    WC_PLAYOFF_ENTRY_TOTAL = 32
    WC_PLAYOFF_WINNER_TOTAL = 16
    WC_FINAL_TOTAL = 64

    IC_LEVEL1_DIRECT = 6
    IC_LOWER_TOTAL = 17
    IC_LOWER_DIRECT = 15
    IC_LOWER_PRELIM = 2
    IC_PRELIM_WINNERS = 1
    IC_PLAYOFF_FIELD = 16
    IC_PLAYOFF_QUALIFIERS = 2
    IC_FINAL_FIELD = 8

    SW_DIRECT = 56
    SW_PRELIM = 32
    SW_PRELIM_WINNERS = 8
    SW_FINAL = 64

    def audit_qualification_architecture(self):
        errors = []

        if sum(self.WC_DIRECT_ALLOCATION.values()) != self.WC_DIRECT_TOTAL:
            errors.append("World Cup direct allocation does not close at 48")
        if sum(self.WC_PLAYOFF_ALLOCATION.values()) != self.WC_PLAYOFF_ENTRY_TOTAL:
            errors.append("World Cup playoff allocation does not close at 32")
        if self.WC_DIRECT_TOTAL + self.WC_PLAYOFF_WINNER_TOTAL != self.WC_FINAL_TOTAL:
            errors.append("World Cup 48+16 does not close at 64")

        if (self.IC_LOWER_DIRECT + self.IC_LOWER_PRELIM) != self.IC_LOWER_TOTAL:
            errors.append("Intercontinental lower-level access does not close at 17")
        if self.IC_LOWER_PRELIM != 2 or self.IC_PRELIM_WINNERS != 1:
            errors.append("Intercontinental preliminary must be 2 -> 1")
        if self.IC_LOWER_DIRECT + self.IC_PRELIM_WINNERS != self.IC_PLAYOFF_FIELD:
            errors.append("Intercontinental playoff field does not close at 16")
        if self.IC_PLAYOFF_QUALIFIERS != 2 or self.IC_LEVEL1_DIRECT + self.IC_PLAYOFF_QUALIFIERS != self.IC_FINAL_FIELD:
            errors.append("Intercontinental final field does not close at 8")

        if self.SW_DIRECT + self.SW_PRELIM != 88:
            errors.append("Super World access pool must be 56 direct + 32 preliminary")
        if self.SW_PRELIM_WINNERS != 8 or self.SW_DIRECT + self.SW_PRELIM_WINNERS != self.SW_FINAL:
            errors.append("Super World final field does not close at 64")

        # Cross-check the authoritative older engines so future edits cannot
        # silently diverge from the frozen architecture.
        if V119IntercontinentalClubFormat.LOWER_LEVEL_PLACES != self.IC_LOWER_TOTAL:
            errors.append("V119 lower-level count diverges from V153")
        if V119IntercontinentalClubFormat.LOWER_DIRECT_PLACES != self.IC_LOWER_DIRECT:
            errors.append("V119 lower direct count diverges from V153")
        if V119IntercontinentalClubFormat.LOWER_PRELIMINARY_ENTRANTS != self.IC_LOWER_PRELIM:
            errors.append("V119 preliminary entrant count diverges from V153")
        if V119IntercontinentalClubFormat.PLAYOFF_SIZE != self.IC_PLAYOFF_FIELD:
            errors.append("V119 playoff field diverges from V153")
        if V119IntercontinentalClubFormat.PLAYOFF_QUALIFIERS != self.IC_PLAYOFF_QUALIFIERS:
            errors.append("V119 playoff qualifier count diverges from V153")
        if V157ClubCalendar.DIRECT_ENTRIES != self.SW_DIRECT:
            errors.append("V157 direct Super World entries diverge from frozen architecture")
        if V157ClubCalendar.PRELIMINARY_ENTRIES != self.SW_PRELIM:
            errors.append("V157 preliminary Super World entries diverge from frozen architecture")
        if V157ClubCalendar.PRELIMINARY_QUALIFYING_PLACES != self.SW_PRELIM_WINNERS:
            errors.append("V157 preliminary Super World qualifiers diverge from frozen architecture")

        return errors

    def validate(self):
        errors = super().validate()
        errors.extend(self.audit_qualification_architecture())

        q = self.save.get("world", {}).get("world_cup_qualification")
        if isinstance(q, dict):
            direct = list(q.get("direct_qualified", []))
            playoff = list(q.get("global_playoff_entries", []))
            winners = list(q.get("global_playoff_winners", []))
            qualified = list(q.get("qualified", []))
            if set(direct) & set(playoff):
                errors.append("World Cup direct and playoff fields overlap")
            if set(direct) & set(winners):
                errors.append("World Cup direct field overlaps playoff winners")
            if len(qualified) != len(set(qualified)):
                errors.append("World Cup qualified field contains duplicates")

        ic = self.save.get("world", {}).get("intercontinental_execution")
        if isinstance(ic, dict) and ic.get("status") == "completed":
            if ic.get("level1_direct_places") != 6:
                errors.append("Intercontinental execution level-1 direct count is not 6")
            if ic.get("lower_level_places") != 17:
                errors.append("Intercontinental execution lower-level count is not 17")
            if ic.get("lower_direct_places") != 15:
                errors.append("Intercontinental execution lower direct count is not 15")
            if ic.get("lower_preliminary_entries") != 2:
                errors.append("Intercontinental execution preliminary count is not 2")
            if ic.get("preliminary_matches") and len(ic["preliminary_matches"]) != 1:
                errors.append("Intercontinental preliminary must contain exactly one match")
            if ic.get("playoff_entries") != 16:
                errors.append("Intercontinental playoff field is not 16")
            if ic.get("playoff_qualifiers") != 2:
                errors.append("Intercontinental playoff must produce 2 qualifiers")
            if ic.get("group_entries") != 8:
                errors.append("Intercontinental final group field is not 8")

        sw = self.save.get("world", {}).get("super_world_qualification")
        if isinstance(sw, dict) and sw.get("status") == "qualified":
            if sw.get("direct_entries") != 56:
                errors.append("Super World direct field is not 56")
            if sw.get("preliminary_entries") != 32:
                errors.append("Super World preliminary field is not 32")
            if sw.get("preliminary_qualifying_places") != 8:
                errors.append("Super World preliminary qualifiers are not 8")
            if sw.get("group_field_size") != 64:
                errors.append("Super World final field is not 64")
            direct = [x.get("club_id") for x in sw.get("direct", [])]
            prelim = [x.get("club_id") for x in sw.get("preliminary", [])]
            if len(direct) != len(set(direct)) or len(prelim) != len(set(prelim)) or set(direct) & set(prelim):
                errors.append("Super World direct/preliminary fields overlap or duplicate")

        return errors

    def run_audit(self):
        errors = self.validate()
        result = {
            "version": self.VERSION,
            "status": "PASS" if not errors else "FAIL",
            "errors": errors,
            "world_cup": {"direct": 48, "playoff_entries": 32, "playoff_winners": 16, "final": 64, "groups": 8, "group_size": 8},
            "intercontinental": {"level1_direct": 6, "lower_total": 17, "lower_direct": 15, "lower_prelim": 2, "prelim_winner": 1, "playoff": 16, "playoff_qualifiers": 2, "final": 8},
            "super_world": {"direct": 56, "preliminary": 32, "preliminary_winners": 8, "final": 64},
        }
        self.save.setdefault("world", {})["qualification_integrity_audit"] = deepcopy(result)
        self.save.setdefault("history", {}).setdefault("qualification_integrity_audit", []).append(deepcopy(result))
        return result
