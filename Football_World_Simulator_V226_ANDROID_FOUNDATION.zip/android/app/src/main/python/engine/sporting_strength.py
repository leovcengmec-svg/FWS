"""Club sporting-strength model.

Keeps sporting power explicit and bounded. Financial/ownership values are not
used directly to change match strength.
"""
import random


class SportingStrengthEngine:
    def __init__(self, rng=None, minimum=1.0, maximum=99.0):
        self.rng = rng or random.Random()
        self.minimum = float(minimum)
        self.maximum = float(maximum)

    @staticmethod
    def _clamp(value, lo, hi):
        return round(max(lo, min(hi, float(value))), 3)

    def initialize(self, club):
        if "sporting_strength" not in club:
            attack = float(club.get("attack", 50))
            defense = float(club.get("defense", 50))
            prestige = float(club.get("prestige", 50))
            club["sporting_strength"] = self._clamp(
                attack * .42 + defense * .42 + prestige * .16,
                self.minimum, self.maximum
            )
        club.setdefault("sporting_form", 50.0)
        club.setdefault("strength_tier", self.tier(club["sporting_strength"]))
        return club["sporting_strength"]

    def tier(self, strength):
        s = float(strength)
        if s >= 85: return "elite"
        if s >= 70: return "strong"
        if s >= 55: return "competitive"
        if s >= 40: return "developing"
        return "lower"

    def match_modifier(self, club):
        self.initialize(club)
        # Bounded effect: 70 strength is +0.10 xG, 40 is -0.10 xG.
        return (float(club["sporting_strength"]) - 55.0) * 0.0033

    def update_after_season(self, club, rank, field_size, appearances=1):
        self.initialize(club)
        n = max(1, int(field_size))
        performance = 1.0 if n == 1 else (n - rank) / (n - 1)
        form = self._clamp(35 + performance * 65, 0, 100)
        old = float(club["sporting_strength"])
        # Management capacity changes how efficiently a club converts a season
        # into structural sporting evolution; it is not a match-result bonus.
        sporting_capacity = self._clamp(club.get("sporting_management_capacity", 40.0), 0, 100)
        youth_capacity = self._clamp(club.get("youth_development_capacity", 40.0), 0, 100)
        scouting_capacity = self._clamp(club.get("scouting_capacity", 40.0), 0, 100)
        development_efficiency = self._clamp(0.70 + sporting_capacity/100*0.20 + youth_capacity/100*0.06 + scouting_capacity/100*0.04, 0.70, 1.00)
        momentum = self._clamp(club.get("management_momentum", 50.0), 0, 100)
        stability = self._clamp(club.get("management_stability", 50.0), 0, 100)
        cycle_modifier = self._clamp(1.0 + (momentum-50.0)*0.0004 + (stability-50.0)*0.0002, 0.96, 1.04)
        development_efficiency = self._clamp(development_efficiency * cycle_modifier, 0.70, 1.00)
        # Small random component prevents deterministic permanent hierarchies.
        noise = self.rng.uniform(-1.0, 1.0) if appearances else 0.0
        delta = ((form - 50.0) * 0.10 * development_efficiency) + noise * development_efficiency
        new = self._clamp(old + delta, self.minimum, self.maximum)
        club["sporting_strength"] = new
        club["sporting_form"] = form
        club["strength_tier"] = self.tier(new)
        # Keep legacy attack/defense fields synchronized without abrupt jumps.
        target_attack = self._clamp(new * 0.96 + float(club.get("prestige", 50)) * 0.04, 1, 99)
        target_defense = self._clamp(new * 0.96 + float(club.get("prestige", 50)) * 0.04, 1, 99)
        club["attack"] = self._clamp(float(club.get("attack", 50)) * .85 + target_attack * .15, 1, 99)
        club["defense"] = self._clamp(float(club.get("defense", 50)) * .85 + target_defense * .15, 1, 99)
        club["prestige"] = self._clamp(float(club.get("prestige", 50)) * .90 + new * .10, 1, 99)
        return {"old": round(old, 3), "new": new, "delta": round(new - old, 3), "form": form,
                "development_efficiency": round(development_efficiency, 4),
                "sporting_management_capacity": sporting_capacity,
                "youth_development_capacity": youth_capacity,
                "scouting_capacity": scouting_capacity,
                "cycle_modifier": round(cycle_modifier, 4),
                "management_momentum": momentum,
                "management_stability": stability,
                "tier": club["strength_tier"]}
