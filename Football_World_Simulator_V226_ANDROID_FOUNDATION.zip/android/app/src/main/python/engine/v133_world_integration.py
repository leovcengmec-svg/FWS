"""V133 — Final World Simulation Integration.

Closes the final roadmap block by providing one transactional annual orchestration
layer over the established FWS engines. It does not replace those engines and it
never invents competition access, clubs, players or transfers.

Annual order:
    preflight -> autonomous/user control split -> economic settlement
    -> club/association development -> career consequences -> historical close
    -> validation -> advance world year

A failed phase restores the complete pre-cycle save snapshot, preventing partial
world seasons. A successful season receives one immutable integration ledger row.
"""
from __future__ import annotations

import pickle

from copy import deepcopy

from .v91_economy_market import V91EconomyMarket
from .v129_club_association_development import V129ClubAssociationDevelopment
from .v130_ai_autonomous import V130AutonomousAI
from .v131_integrated_career import V131IntegratedCareer
from .v132_historical_legacy import V132HistoricalLegacy


class V133WorldIntegration:
    VERSION = "V133"
    SCHEMA = 1
    PHASES = (
        "preflight",
        "autonomous_ai",
        "economy",
        "development",
        "career",
        "history",
        "validation",
        "commit",
    )

    def __init__(self, save, seed=133):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _cycles(self):
        return self._history().setdefault("world_integration", [])

    def _current_year(self):
        return int(self._world().get("current_year", 2026))

    @staticmethod
    def _copy(value):
        return deepcopy(value)

    def _preflight(self, season):
        if any(int(row.get("season", -1)) == season for row in self._cycles()):
            raise ValueError(f"V133 season {season} already integrated")
        if "players" in self._world():
            raise ValueError("V133 must not contain an individual player layer")
        if "player_transfers" in self._history():
            raise ValueError("V133 must not contain a player transfer history")
        clubs = self._world().get("clubs", {})
        associations = self._world().get("associations", {})
        if len(clubs) != len(set(clubs)):
            raise ValueError("V133 duplicate club identifiers")
        if len(associations) != len(set(associations)):
            raise ValueError("V133 duplicate association identifiers")
        return {"season": season, "clubs": len(clubs), "associations": len(associations)}

    def _controlled_ids(self):
        integrated = self.save.get("careers", {}).get("integrated", {})
        active_club = integrated.get("active_club_id")
        active_selection = integrated.get("active_selection_id")
        team = self._world().get("national_teams", {}).get(active_selection, {}) if active_selection else {}
        controlled_association = team.get("association_id")
        return active_club, controlled_association

    def _run_ai(self, season, club_context, association_context):
        # If a V131 integrated career exists, use its protected autonomous pass;
        # otherwise use V130 directly for a world without an active user career.
        if "integrated" in self.save.get("careers", {}):
            career = V131IntegratedCareer(self.save)
            result = career.autonomous_world_cycle(
                season=season,
                club_context=club_context,
                association_context=association_context,
                seed=self.seed,
            )
            return result
        ai = V130AutonomousAI(self.save, seed=self.seed)
        return ai.run_cycle(season, club_context, association_context)

    def _bridge_ai_to_development(self, ai_cycle):
        # V130 produces plans; V129 consumes seasonal investment/performance.
        # This bridge is deliberately aggregate and does not create staff/player data.
        plans = {}
        for bucket in ("clubs", "associations"):
            for item in ai_cycle.get(bucket, []):
                decision = item.get("decision", {})
                plans[decision.get("entity_id")] = float(decision.get("planned_investment", 0.0))
        return plans

    def _run_economy(self, season, continental_participants=None):
        # V128 is the dynamic-economy roadmap layer; the executable economy
        # implementation in this package is the mature V91 composite. V133
        # integrates that engine rather than duplicating financial logic.
        self._world()["current_year"] = season
        economy = V91EconomyMarket(self.save, seed=self.seed + 91)
        return economy.settle_season(continental_participants=continental_participants or set())

    def _run_development(self, season, club_context, association_context, ai_plans):
        clubs = deepcopy(club_context)
        for cid, plan in ai_plans.items():
            if cid in self._world().get("clubs", {}):
                clubs.setdefault(cid, {})
                clubs[cid].setdefault("investment", plan)
                clubs[cid]["investment"] = max(float(clubs[cid].get("investment", 0.0)), plan)
                self._world()["clubs"][cid]["season_investment"] = plan
        development = V129ClubAssociationDevelopment(self.save)
        return development.run_season(season, clubs, association_context)

    def _run_career(self, season, career_results):
        if "integrated" not in self.save.get("careers", {}):
            return {"status": "not_initialized", "records": []}
        career = V131IntegratedCareer(self.save)
        records = []
        for row in career_results.get("clubs", []):
            records.append(career.record_club_season(
                row["club_id"], season=season,
                league_position=row.get("league_position"),
                league_size=row.get("league_size", 20),
                continental_success=row.get("continental_success", 0),
                title=row.get("title", False),
                objective_quality=row.get("objective_quality"),
            ))
        for row in career_results.get("selections", []):
            # Only record when the integrated career currently controls the team.
            if self.save.get("careers", {}).get("integrated", {}).get("active_selection_id"):
                records.append(career.record_selection_cycle(
                    row.get("result_quality", 50),
                    row.get("opponent_strength", 50),
                    season=season,
                ))
        return {"status": "completed", "records": records, "snapshot": career.career_snapshot()}

    def _validate(self):
        errors = []
        errors.extend(V130AutonomousAI(self.save, seed=self.seed).validate())
        errors.extend(V129ClubAssociationDevelopment(self.save).validate())
        if "integrated" in self.save.get("careers", {}):
            errors.extend(V131IntegratedCareer(self.save).validate())
        errors.extend(V132HistoricalLegacy(self.save).validate())
        # Global financial invariants.
        for cid, club in self._world().get("clubs", {}).items():
            if float(club.get("cash", 0.0)) < 0:
                errors.append(f"V133 negative cash {cid}")
            if float(club.get("debt", 0.0)) < 0:
                errors.append(f"V133 negative debt {cid}")
        return errors

    def run_season(self, season=None, *, club_context=None, association_context=None,
                   continental_participants=None, competitions=None,
                   career_results=None, advance_year=True):
        season = int(self._current_year() if season is None else season)
        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        phase_log = []
        try:
            preflight = self._preflight(season)
            phase_log.append("preflight")
            club_context = club_context or {}
            association_context = association_context or {}
            competitions = self._copy(competitions or {})
            career_results = career_results or {}

            ai = self._run_ai(season, club_context, association_context)
            phase_log.append("autonomous_ai")
            plans = self._bridge_ai_to_development(ai)

            economy = self._run_economy(season, continental_participants)
            phase_log.append("economy")

            development = self._run_development(season, club_context, association_context, plans)
            phase_log.append("development")

            career = self._run_career(season, career_results)
            phase_log.append("career")

            historical = V132HistoricalLegacy(self.save)
            club_history = {
                cid: self._copy(data) for cid, data in club_context.items()
            }
            association_history = {
                aid: self._copy(data) for aid, data in association_context.items()
            }
            historical_row = historical.record_season(
                season,
                competitions=competitions,
                clubs=club_history,
                associations=association_history,
                career=career.get("snapshot", {}),
                summary={
                    "economy": self._copy(economy),
                    "development": self._copy(development),
                    "ai": {"clubs": len(ai.get("clubs", [])), "associations": len(ai.get("associations", []))},
                },
            )
            phase_log.append("history")

            errors = self._validate()
            phase_log.append("validation")
            if errors:
                raise ValueError("V133 validation failed: " + "; ".join(errors))

            next_year = season + 1 if advance_year else season
            self._world()["current_year"] = next_year
            cycle = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "season": season,
                "status": "closed",
                "next_year": next_year,
                "phases": list(phase_log) + ["commit"],
                "preflight": preflight,
                "ai": self._copy(ai),
                "economy": self._copy(economy),
                "development": self._copy(development),
                "career": self._copy(career),
                "historical_season": self._copy(historical_row),
            }
            self._cycles().append(self._copy(cycle))
            self._world()["last_integrated_season"] = season
            self._world()["integration_status"] = "closed"
            return self._copy(cycle)
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        cycles = self._cycles()
        seasons = [int(row.get("season")) for row in cycles]
        if len(seasons) != len(set(seasons)):
            errors.append("V133 integration seasons must be unique")
        for row in cycles:
            if row.get("version") != self.VERSION or row.get("status") != "closed":
                errors.append(f"V133 invalid integration cycle: {row.get('season')}")
            if row.get("phases") != list(self.PHASES):
                errors.append(f"V133 incomplete phase order: {row.get('season')}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("V133 player systems are forbidden")
        return errors
