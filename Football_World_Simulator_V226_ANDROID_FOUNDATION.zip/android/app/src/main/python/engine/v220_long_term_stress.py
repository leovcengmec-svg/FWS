"""V220 — 1/5/10/25/50/100-season stress gate for Block 11."""
from __future__ import annotations
from copy import deepcopy
from .v216_long_horizon import V216LongHorizon
from .v217_economic_stability import V217EconomicStability
from .v218_sporting_continuity import V218SportingContinuity
from .v219_history_save_integrity import V219HistorySaveIntegrity
class V220LongTermStress:
    VERSION="V220"; HORIZONS=(1,5,10,25,50,100)
    def __init__(self,save,seed=220): self.save=save; self.seed=seed
    def run(self):
        baseline=self.save.get("world",{}).get("current_year",2026)
        results=[]
        last=0
        for horizon in self.HORIZONS:
            delta=horizon-last
            V216LongHorizon(self.save,self.seed+horizon).run(delta)
            V217EconomicStability(self.save).run()
            V218SportingContinuity(self.save).run()
            V219HistorySaveIntegrity(self.save).close()
            errors=(V216LongHorizon(self.save).validate()+V217EconomicStability(self.save).validate()+
                    V218SportingContinuity(self.save).validate()+V219HistorySaveIntegrity(self.save).validate())
            results.append({"seasons":horizon,"year":self.save["world"]["current_year"],"errors":errors,
                            "clubs":len(self.save["world"].get("clubs",{})),
                            "history_entries":sum(len(v) for v in self.save.get("history",{}).values() if isinstance(v,list))})
            last=horizon
        out={"version":self.VERSION,"baseline_year":baseline,"horizons":results,"status":"ready" if not any(r["errors"] for r in results) else "failed","player_layer_forbidden":True}
        self.save.setdefault("history",{}).setdefault("long_term_stress_runs",[]).append(deepcopy(out))
        self.save["world"]["long_term_stress_status"]=out["status"]
        return out
    def validate(self):
        return [] if self.save.get("world",{}).get("long_term_stress_status")=="ready" else ["stress gate not ready"]
