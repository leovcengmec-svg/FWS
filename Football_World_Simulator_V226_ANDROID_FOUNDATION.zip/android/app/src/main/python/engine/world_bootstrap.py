"""Build a playable world from the existing seed without replacing user data."""
import copy
from .world_registry import WorldRegistry
from .competition_registry import CompetitionRegistry
from .world_integrity import assert_world_integrity
from .sporting_strength import SportingStrengthEngine


class WorldBootstrap:
    def __init__(self, save):
        self.save = save
        self.registry = WorldRegistry(save)
        self.competitions = CompetitionRegistry(save)

    def prepare(self):
        self._normalize_world_maps()
        self._normalize_leagues()
        self._normalize_clubs()
        self._normalize_countries()
        self._normalize_national_teams()
        self.competitions.initialize()
        self._normalize_sporting_strength()
        self.registry.rebuild_indexes()
        assert_world_integrity(self.save)
        self.save.setdefault("world", {})["bootstrap"] = {
            "schema": 1,
            "prepared_year": self.save["world"].get("current_year", 2026),
            "country_count": len(self.registry.countries),
            "league_count": len(self.registry.leagues),
            "club_count": len(self.registry.clubs),
            "competition_count": len(self.registry.competitions),
        }
        return self.save

    def _normalize_world_maps(self):
        world = self.save.setdefault("world", {})
        for key in ("countries", "leagues", "clubs", "national_teams", "competitions"):
            value = world.setdefault(key, {})
            if isinstance(value, list):
                world[key] = {row["id"]: row for row in value}

    def _normalize_countries(self):
        for country in self.registry.countries.values():
            country.setdefault("division_levels", len(self.registry.leagues_for_country(country["id"])))
            country.setdefault("active", True)

    def _normalize_leagues(self):
        for league in self.registry.leagues.values():
            league.setdefault("active", True)
            league.setdefault("type", "league")
            league.setdefault("confederation", self.registry.countries.get(league.get("country_id"), {}).get("confederation"))
            league.setdefault("coefficient", 1.0)
            league.setdefault("club_ids", [])
            league["club_ids"] = list(dict.fromkeys(league["club_ids"]))

    def _normalize_clubs(self):
        for club in self.registry.clubs.values():
            club.setdefault("active", True)
            club.setdefault("prestige", 50)
            club.setdefault("cash", 10.0)
            club.setdefault("country_id", self.registry.leagues.get(club.get("league_id"), {}).get("country_id"))
            club.setdefault("division", self.registry.leagues.get(club.get("league_id"), {}).get("level", 1))
            club.setdefault("ownership", {"type": "ai", "owner_id": "ai"})
            club.setdefault("attack", 50.0)
            club.setdefault("defense", 50.0)

    def _normalize_sporting_strength(self):
        engine = SportingStrengthEngine()
        for club in self.registry.clubs.values():
            engine.initialize(club)

    def _normalize_national_teams(self):
        for team in self.registry.national_teams.values():
            team.setdefault("active", True)
            team.setdefault("strength", 50)
            team.setdefault("country_id", team.get("id"))
