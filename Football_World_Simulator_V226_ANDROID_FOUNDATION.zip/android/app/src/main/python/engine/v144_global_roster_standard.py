"""V144 — Global roster standard and final-division waiting queue.

Policy:
- Every simulated domestic league targets at least 10 active real clubs.
- Existing real clubs from lower/access divisions may be used to complete a
  league when the country's verified club pool permits it.
- No synthetic/fictitious club may be created to satisfy the target.
- Each association has a separate four-club external waiting pool for the
  final division. The queue is FIFO: four waiting clubs enter after the four
  relegated clubs leave; the next waiting clubs remain queued for the next
  season, and new verified clubs may be appended.
- Brazil D2/D3/D4 canonical aliases remain under Brazilian exception rules.
"""
from dataclasses import dataclass
from typing import Dict, Any, List

BRAZIL_ALIASES = {"BRA_D2", "BRA_D3", "BRA_D4"}
MIN_LEAGUE_CLUBS = 10
EXTRA_POOL_SIZE = 4

@dataclass(frozen=True)
class LeagueTarget:
    league_id: str
    country_id: str
    level: int
    current_clubs: int
    target_clubs: int
    gap: int
    status: str


def active_clubs_by_country(catalog: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    out: Dict[str, List[Dict[str, Any]]] = {}
    for club in catalog.get("clubs", {}).values():
        if not club.get("active", True):
            continue
        country = club.get("country_id")
        out.setdefault(country, []).append(club)
    return out


def league_counts(catalog: Dict[str, Any]) -> Dict[str, int]:
    clubs = catalog.get("clubs", {})
    counts = {}
    for lid in catalog.get("leagues", {}):
        counts[lid] = sum(1 for c in clubs.values() if c.get("active", True) and c.get("league_id") == lid)
    return counts


def audit_catalog(catalog: Dict[str, Any]) -> Dict[str, Any]:
    counts = league_counts(catalog)
    rows: List[Dict[str, Any]] = []
    for lid, league in catalog.get("leagues", {}).items():
        country = league.get("country_id")
        n = counts.get(lid, 0)
        if lid in BRAZIL_ALIASES:
            rows.append({"league_id": lid, "country_id": country, "level": league.get("level", 0),
                         "current_clubs": n, "target_clubs": None, "gap": 0,
                         "status": "brazil_canonical_alias"})
            continue
        gap = max(0, MIN_LEAGUE_CLUBS - n)
        rows.append({"league_id": lid, "country_id": country, "level": league.get("level", 0),
                     "current_clubs": n, "target_clubs": MIN_LEAGUE_CLUBS, "gap": gap,
                     "status": "meets_target" if gap == 0 else "below_target"})

    by_country = {}
    for country in catalog.get("associations", {}):
        league_rows = [r for r in rows if r["country_id"] == country and r["status"] != "brazil_canonical_alias"]
        total_real = len(active_clubs_by_country(catalog).get(country, []))
        required_for_leagues = MIN_LEAGUE_CLUBS * len(league_rows)
        required_with_extras = required_for_leagues + EXTRA_POOL_SIZE
        surplus_after_standard = max(0, total_real - required_with_extras)
        external_needed = max(0, required_with_extras - total_real)
        by_country[country] = {
            "league_count": len(league_rows),
            "active_real_clubs": total_real,
            "minimum_for_leagues": required_for_leagues,
            "minimum_plus_four_extras": required_with_extras,
            "external_real_clubs_needed": external_needed,
            "capacity_status": "sufficient_internal_real_pool" if external_needed == 0 else "requires_external_real_club_collection",
            "four_extra_pool": {"size": EXTRA_POOL_SIZE, "status": "verified_pool_pending" if external_needed else "can_be_formed_from_verified_real_pool"},
        }

    return {
        "version": "V144",
        "policy": {
            "minimum_clubs_per_league": MIN_LEAGUE_CLUBS,
            "extra_waiting_clubs_per_country": EXTRA_POOL_SIZE,
            "no_synthetic_clubs": True,
            "source_priority": ["existing_verified_real_club", "verified_access_division_club", "verified_amateur_club"],
            "last_division_queue": "FIFO",
            "season_transition": "4 relegated leave; first 4 waiting enter; remaining waiting stay queued; new verified entrants append",
        },
        "total_leagues": len(rows),
        "leagues_below_10": sum(r["status"] == "below_target" for r in rows),
        "leagues_meeting_10": sum(r["status"] == "meets_target" for r in rows),
        "brazil_aliases": sum(r["status"] == "brazil_canonical_alias" for r in rows),
        "countries_requiring_external_collection": sum(v["external_real_clubs_needed"] > 0 for v in by_country.values()),
        "rows": rows,
        "countries": by_country,
    }


def apply_waiting_queue_transition(queue: List[str], relegated: List[str], incoming_count: int = 4):
    """Return (next_active_external, next_waiting_queue).

    This is intentionally independent from match/relegation calculation. The
    caller supplies the four relegated club IDs and the waiting FIFO.
    """
    if incoming_count != 4:
        raise ValueError("FINAL_DIVISION_INCOMING_MUST_BE_FOUR")
    if len(relegated) != 4:
        raise ValueError("FINAL_DIVISION_RELEGATED_MUST_BE_FOUR")
    if len(queue) < 4:
        raise ValueError("FINAL_DIVISION_WAITING_POOL_REQUIRES_FOUR")
    incoming = queue[:4]
    remaining = queue[4:]
    return incoming, remaining
