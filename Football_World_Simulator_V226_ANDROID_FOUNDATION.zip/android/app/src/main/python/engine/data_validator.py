def validate_registry(registry):
    errors=[]
    if len(registry.get("associations",{}))!=211:
        errors.append(f"Expected 211 unique associations, found {len(registry.get('associations',{}))}")
    missing=[c for c in ["AFC","CAF","CONCACAF","CONMEBOL","OFC","UEFA"] if c not in registry.get("confederations",[])]
    if missing: errors.append("Missing confederations: "+",".join(missing))
    return errors
