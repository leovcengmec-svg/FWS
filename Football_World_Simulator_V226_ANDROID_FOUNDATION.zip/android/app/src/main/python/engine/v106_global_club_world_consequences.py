"""V106 — Global Club World consequences.

Converts the completed proprietary world-club tournaments into persistent,
bounded consequences for reputation, club economy, and permanent history.
It does not replace the match engine or create individual players.
"""
from __future__ import annotations
from copy import deepcopy
from .v105_super_world_execution import V105SuperWorldExecution


class V106GlobalClubWorldConsequences(V105SuperWorldExecution):
    VERSION = "V106"
    PRIZE = {"champion": 100.0, "runner_up": 60.0, "semi_final": 35.0,
             "quarter_final": 20.0, "round_of_32": 10.0, "group_stage": 4.0,
             "preliminary": 1.0}
    REP = {"champion": 12.0, "runner_up": 8.0, "semi_final": 6.0,
           "quarter_final": 4.0, "round_of_32": 2.0, "group_stage": 0.5,
           "preliminary": -1.0}

    @staticmethod
    def _clamp(value, low=0.0, high=100.0):
        return round(max(low, min(high, float(value))), 3)

    def _club_store(self):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        return world.setdefault("clubs", catalog.get("clubs", {}))

    def apply_super_world_consequences(self, execution=None):
        execution = execution or self.save.get("world", {}).get("super_world_execution")
        if not execution or execution.get("status") != "completed":
            raise ValueError("Super World concluído necessário para aplicar consequências")
        year = int(execution["season"])
        groups = execution.get("groups", [])
        knockout = execution.get("knockout_matches", [])
        champion = execution.get("champion")
        participants = {c["id"] for g in groups for c in g.get("clubs", [])}
        direct_stage = {cid: "group_stage" for cid in participants}

        # Any club appearing in knockout round 1 reached the round of 32.
        for match in knockout:
            if int(match.get("round_no", 0)) == 1:
                direct_stage.setdefault(match["home_id"], "round_of_32")
                direct_stage.setdefault(match["away_id"], "round_of_32")
        # Later rounds upgrade surviving clubs. Round numbers are 1..5.
        round_stage = {2: "round_of_16", 3: "quarter_final", 4: "semi_final", 5: "runner_up"}
        for match in knockout:
            r = int(match.get("round_no", 0))
            stage = round_stage.get(r)
            if not stage:
                continue
            winner = match.get("winner_id")
            loser = match.get("away_id") if winner == match.get("home_id") else match.get("home_id")
            if r == 2:
                direct_stage[winner] = "quarter_final"  # upgraded below by r3
            elif r == 3:
                direct_stage[winner] = "semi_final"
                direct_stage[loser] = "quarter_final"
            elif r == 4:
                direct_stage[winner] = "runner_up"
                direct_stage[loser] = "semi_final"
            elif r == 5:
                direct_stage[winner] = "champion"
                direct_stage[loser] = "runner_up"

        # A 32-team knockout has rounds 1..5. Round-2 losers are R16 exits,
        # therefore they receive the R32 economic/reputation tier here; the
        # public stage name remains explicit for traceability.
        for match in knockout:
            if int(match.get("round_no", 0)) == 1:
                loser = match.get("away_id") if match.get("winner_id") == match.get("home_id") else match.get("home_id")
                direct_stage.setdefault(loser, "round_of_32")

        store = self._club_store()
        impacts = {}
        for cid in sorted(participants):
            club = store.get(cid, {"id": cid, "name": cid})
            stage = direct_stage.get(cid, "group_stage")
            # Normalize internal R16 stage to the nearest defined reward tier.
            reward_stage = "round_of_32" if stage == "round_of_16" else stage
            cash_before = float(club.get("cash", 0.0))
            rep_before = float(club.get("reputation", club.get("prestige", 50.0)))
            prize = self.PRIZE[reward_stage]
            rep_delta = self.REP[reward_stage]
            club["cash"] = round(cash_before + prize, 3)
            club["reputation"] = self._clamp(rep_before + rep_delta)
            club["last_global_club_world"] = {
                "season": year, "stage": stage, "prize": prize,
                "reputation_delta": rep_delta,
            }
            impacts[cid] = {
                "club_id": cid, "season": year, "competition_id": execution["competition_id"],
                "stage": stage, "prize": prize, "reputation_before": round(rep_before, 3),
                "reputation_after": club["reputation"], "reputation_delta": rep_delta,
                "cash_before": round(cash_before, 3), "cash_after": club["cash"],
                "champion": cid == champion,
            }

        result = {
            "version": self.VERSION, "season": year,
            "competition_id": execution["competition_id"],
            "champion": champion, "participants": len(participants), "impacts": impacts,
            "status": "applied",
        }
        world = self.save.setdefault("world", {})
        world["global_club_world_consequences"] = deepcopy(result)
        world.setdefault("global_club_world_consequence_history", []).append(deepcopy(result))
        self.save.setdefault("history", {}).setdefault("global_club_world_consequences", []).append(deepcopy(result))
        return deepcopy(result)

    def validate(self):
        errors = super().validate()
        state = self.save.get("world", {}).get("global_club_world_consequences")
        if not state:
            return errors
        if state.get("version") != self.VERSION:
            errors.append("wrong global club world consequence version")
        if state.get("status") != "applied":
            errors.append("global club world consequences not applied")
        if not state.get("champion"):
            errors.append("global club world consequence champion missing")
        if state.get("participants", 0) != 64:
            errors.append("global club world consequence participant count must be 64")
        if len(state.get("impacts", {})) != 64:
            errors.append("global club world consequence impact count must be 64")
        return errors
