"""V184 — World/career navigation and history views."""
from __future__ import annotations
from copy import deepcopy
from .world_browser import WorldBrowser

class V184WorldNavigation:
    VERSION='V184'
    def __init__(self,save): self.save=save; self.browser=WorldBrowser(save)
    def club(self,club_id):
        c=self.browser.club_profile(club_id)
        if c is None: raise ValueError('unknown club')
        return deepcopy(c)
    def country(self,country_id):
        c=self.save.get('world',{}).get('countries',{}).get(country_id)
        if c is None: raise ValueError('unknown country')
        return deepcopy(c)
    def club_history(self,club_id):
        h=self.save.get('history',{})
        return {'club_id':club_id,'championships':deepcopy(h.get('club_champions',{}).get(club_id,[])),
                'transactions':deepcopy([x for x in h.get('ownership_transactions',[]) if x.get('club_id')==club_id]),
                'management':deepcopy([x for x in h.get('management_decisions',[]) if x.get('club_id')==club_id])}
    def world_summary(self):
        w=self.save.get('world',{})
        return {'year':w.get('current_year'),'clubs':len(w.get('clubs',{})),'leagues':len(w.get('leagues',{})),
                'competitions':len(w.get('competitions',{})),'countries':len(w.get('countries',{})),
                'national_teams':len(w.get('national_teams',{}))}
