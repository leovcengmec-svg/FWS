"""V168 — World State Persistence & Recovery.

Portable, checksummed snapshots using deterministic application-owned pickle data
inside a gzip container. The format is optimized for the very large historical
world state and is never treated as trusted external executable input.
"""
from __future__ import annotations
import gzip, hashlib, pickle, struct
from copy import deepcopy
from pathlib import Path

class V168WorldStatePersistence:
    VERSION='V168'; SCHEMA=2; MAGIC=b'FWS_WORLD_SAVE_V168'
    def __init__(self,save): self.save=save
    @classmethod
    def _payload_bytes(cls,save):
        if 'players' in save.get('world',{}) or 'player_transfers' in save.get('history',{}): raise ValueError('V168 refuses forbidden player systems')
        return pickle.dumps(deepcopy(save),protocol=pickle.HIGHEST_PROTOCOL)
    @classmethod
    def encode(cls,save):
        body=cls._payload_bytes(save); digest=hashlib.sha256(body).digest()
        header=cls.MAGIC+struct.pack('>HHI',2,cls.SCHEMA,len(digest))+digest+body
        return gzip.compress(header,compresslevel=6,mtime=0)
    @classmethod
    def decode(cls,data):
        try: raw=gzip.decompress(data); magic=raw[:len(cls.MAGIC)]
        except Exception as exc: raise ValueError(f'invalid FWS save container: {exc}') from exc
        if magic!=cls.MAGIC: raise ValueError('unsupported FWS save container')
        pos=len(cls.MAGIC); version,schema,dlen=struct.unpack('>HHI',raw[pos:pos+8]); pos+=8
        if version!=2 or schema!=cls.SCHEMA: raise ValueError('unsupported V168 save schema')
        digest=raw[pos:pos+dlen]; pos+=dlen; body=raw[pos:]
        if hashlib.sha256(body).digest()!=digest: raise ValueError('FWS save checksum mismatch')
        try: payload=pickle.loads(body)
        except Exception as exc: raise ValueError(f'corrupt FWS payload: {exc}') from exc
        if not isinstance(payload,dict): raise ValueError('FWS save payload is not an object')
        if 'players' in payload.get('world',{}) or 'player_transfers' in payload.get('history',{}): raise ValueError('forbidden player systems detected in save')
        return payload
    def export_bytes(self): return self.encode(self.save)
    def save_file(self,path):
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); data=self.export_bytes(); path.write_bytes(data)
        return {'version':self.VERSION,'schema':self.SCHEMA,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'path':str(path)}
    @classmethod
    def load_file(cls,path): return cls.decode(Path(path).read_bytes())
    def restore_bytes(self,data):
        restored=self.decode(data); self.save.clear(); self.save.update(restored); return self.save
    def validate(self):
        errors=[]
        try: data=self.export_bytes(); restored=self.decode(data)
        except Exception as exc: return [f'persistence_roundtrip:{exc}']
        if restored!=self.save: errors.append('persistence_roundtrip_mismatch')
        if self._forbidden(): errors.append('player_system_forbidden')
        return errors
    def _forbidden(self): return 'players' in self.save.get('world',{}) or 'player_transfers' in self.save.get('history',{})
