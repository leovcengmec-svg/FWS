class InvestorFinance:
    """Weekly investor cash-flow, liquidity, recurring obligations and V30 taxes/fees."""
    def __init__(self, save):
        self.save = save
        self.career = save.setdefault('careers', {}).setdefault('investor', {})
        self.history = save.setdefault('history', {}).setdefault('investor_finance', [])
        self.rules = save.setdefault('config_runtime', {}).setdefault('investor_finance', {})
        self._defaults()

    def _defaults(self):
        defaults = {
            'governance_profile': 'balanced',
            'weekly_base_income': 0.0,
            'weekly_admin_expense': 0.20,
            'weekly_asset_expense_rate': 0.0005,
            'weekly_financial_obligation': 0.0,
            'weekly_tax_rate': 0.15,
            'transaction_fee_rate': 0.01,
            'asset_fee_rate': 0.0005,
            'reserve_target': 10.0,
            'minimum_liquidity': 0.0,
            'weekly_distribution_rate': 0.35,
        }
        for k, v in defaults.items(): self.rules.setdefault(k, v)
        self.career.setdefault('cash', 0.0)
        self.career.setdefault('reserve', 0.0)
        self.career.setdefault('net_worth', self.career.get('cash', 0.0))
        self.career.setdefault('weekly_income', 0.0)
        self.career.setdefault('weekly_expenses', 0.0)
        self.career.setdefault('weekly_flow', 0.0)
        self.career.setdefault('taxes_paid', 0.0)
        self.career.setdefault('fees_paid', 0.0)

    def set_governance(self, profile):
        profiles = {'conservative': (0.80, 0.85), 'balanced': (1.00, 1.00), 'aggressive': (1.20, 1.15)}
        if profile not in profiles: raise ValueError('perfil de governança inválido')
        self.rules['governance_profile'] = profile
        return profile

    def _profile(self):
        return {'conservative': (0.80, 0.85), 'balanced': (1.00, 1.00), 'aggressive': (1.20, 1.15)}[self.rules['governance_profile']]

    def _owned_club_value(self):
        clubs = self.save.get('world', {}).get('clubs', {})
        return sum(float(clubs.get(cid, {}).get('market_value', 0.0) or 0.0) for cid in self.career.get('owned_clubs', []))

    def calculate_net_worth(self):
        self.career['net_worth'] = round(float(self.career.get('cash', 0.0)) + float(self.career.get('reserve', 0.0)) + self._owned_club_value(), 2)
        return self.career['net_worth']

    def available_cash(self):
        return round(max(0.0, float(self.career.get('cash', 0.0)) - float(self.career.get('reserve', 0.0))), 2)

    def set_reserve(self, amount):
        amount = float(amount)
        if amount < 0 or amount > float(self.career.get('cash', 0.0)): raise ValueError('reserva inválida')
        self.career['reserve'] = round(amount, 2)
        self.calculate_net_worth()
        return self.career['reserve']

    def _weekly_club_distribution(self):
        clubs = self.save.get('world', {}).get('clubs', {})
        rate = float(self.rules.get('weekly_distribution_rate', .35))
        total = 0.0
        for cid in self.career.get('owned_clubs', []):
            club = clubs.get(cid, {})
            profit = float(club.get('last_economy', {}).get('profit', 0.0))
            if profit > 0:
                total += (profit / 52.0) * rate
        return max(0.0, total)

    def settle_week(self, week, year=None):
        income = float(self.rules.get('weekly_base_income', 0.0)) + self._weekly_club_distribution()
        governance_multiplier, expense_multiplier = self._profile()
        income *= governance_multiplier
        admin = float(self.rules.get('weekly_admin_expense', 0.20)) * expense_multiplier
        assets = self._owned_club_value() * float(self.rules.get('weekly_asset_expense_rate', .0005))
        debt = float(self.rules.get('weekly_financial_obligation', 0.0))
        recurring = admin + assets + debt
        taxable = max(0.0, income - recurring)
        taxes = taxable * float(self.rules.get('weekly_tax_rate', .15))
        transaction_fees = 0.0
        expenses = recurring + taxes + transaction_fees
        flow = income - expenses
        self.career['cash'] = round(max(0.0, float(self.career.get('cash', 0.0)) + flow), 2)
        self.career['weekly_income'] = round(income, 2)
        self.career['weekly_expenses'] = round(expenses, 2)
        self.career['weekly_flow'] = round(flow, 2)
        self.career['taxes_paid'] = round(float(self.career.get('taxes_paid', 0.0)) + taxes, 2)
        self.career['fees_paid'] = round(float(self.career.get('fees_paid', 0.0)) + admin + assets, 2)
        self.calculate_net_worth()
        row = {'year': year if year is not None else self.save.get('world', {}).get('current_year'), 'week': int(week), 'income': round(income,2), 'recurring_expenses': round(recurring,2), 'taxes': round(taxes,2), 'fees': round(admin+assets,2), 'expenses': round(expenses,2), 'flow': round(flow,2), 'cash': round(self.career['cash'],2), 'reserve': round(self.career['reserve'],2), 'available_cash': self.available_cash(), 'net_worth': self.career['net_worth'], 'governance': self.rules['governance_profile']}
        self.history.append(row)
        return row

    def apply_transaction_fee(self, amount, transaction_type='generic'):
        amount = float(amount)
        fee = max(0.0, amount) * float(self.rules.get('transaction_fee_rate', .01))
        if fee > float(self.career.get('cash', 0.0)): raise ValueError('caixa insuficiente para taxa da transação')
        self.career['cash'] = round(float(self.career.get('cash',0.0)) - fee, 2)
        self.career['fees_paid'] = round(float(self.career.get('fees_paid',0.0)) + fee, 2)
        self.history.append({'type':'transaction_fee','transaction_type':transaction_type,'amount':round(amount,2),'fee':round(fee,2),'cash':self.career['cash']})
        self.calculate_net_worth()
        return round(fee,2)
