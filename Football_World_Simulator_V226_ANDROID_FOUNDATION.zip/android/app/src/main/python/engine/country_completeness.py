"""Country-by-country completeness registry for the global football database.

The registry is an audit layer only: it never promotes unverified real-world data
into playable data. Each FIFA association receives the same 13-item checklist.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

CHECKLIST = (
    "association",
    "national_team",
    "competitions",
    "leagues_divisions",
    "clubs",
    "visual_assets",
    "official_colors",
    "city",
    "stadium",
    "capacity",
    "stable_ids",
    "provenance",
    "validation",
)
VALID_STATUSES = {"confirmed", "partial", "pending", "not_verified"}


class CountryCompletenessRegistry:
    """Read-only audit service over the 211-country completeness manifest."""

    SCHEMA_VERSION = 1

    def __init__(self, manifest: dict):
        self.manifest = manifest
        self._validate_manifest()

    @classmethod
    def from_file(cls, path):
        return cls(json.loads(Path(path).read_text(encoding="utf-8")))

    def _validate_manifest(self):
        countries = self.manifest.get("countries", {})
        if len(countries) != 211:
            raise ValueError(f"Expected 211 countries, got {len(countries)}")
        if set(countries) != {r["association_id"] for r in countries.values()}:
            raise ValueError("Country keys and association IDs diverge")
        for association_id, row in countries.items():
            if row.get("association_id") != association_id:
                raise ValueError(f"Association key mismatch: {association_id}")
            items = row.get("checklist", {})
            if tuple(items) != CHECKLIST:
                raise ValueError(f"{association_id}: checklist is incomplete or reordered")
            for item in CHECKLIST:
                entry = items[item]
                if entry.get("status") not in VALID_STATUSES:
                    raise ValueError(f"{association_id}/{item}: invalid status")
                if not entry.get("evidence"):
                    raise ValueError(f"{association_id}/{item}: missing evidence note")

    def country(self, association_id):
        return copy.deepcopy(self.manifest["countries"][association_id])

    def pending(self, item=None):
        rows = self.manifest["countries"].values()
        if item is None:
            return [copy.deepcopy(r) for r in rows if self.country_status(r["association_id"]) != "confirmed"]
        if item not in CHECKLIST:
            raise KeyError(item)
        return [copy.deepcopy(r) for r in rows if r["checklist"][item]["status"] != "confirmed"]

    def country_status(self, association_id):
        statuses = {v["status"] for v in self.manifest["countries"][association_id]["checklist"].values()}
        if statuses == {"confirmed"}:
            return "confirmed"
        if "pending" in statuses:
            return "pending"
        if "not_verified" in statuses:
            return "not_verified"
        return "partial"

    def summary(self):
        countries = self.manifest["countries"]
        by_item = {}
        for item in CHECKLIST:
            counts = {status: 0 for status in VALID_STATUSES}
            for row in countries.values():
                counts[row["checklist"][item]["status"]] += 1
            by_item[item] = counts
        country_states = {state: 0 for state in VALID_STATUSES}
        for association_id in countries:
            country_states[self.country_status(association_id)] += 1
        return {
            "country_count": len(countries),
            "country_status": country_states,
            "by_item": by_item,
        }
