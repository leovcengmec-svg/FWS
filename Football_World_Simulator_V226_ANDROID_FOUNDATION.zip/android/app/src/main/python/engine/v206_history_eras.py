"""V206 — Historical eras derived from the append-only world history."""
from __future__ import annotations
from copy import deepcopy

class V206HistoryEras:
    VERSION='V206'
    def __init__(self, save):
        self.save=save; self.history=save.setdefault('history',{})
        self.eras=self.history.setdefault('history_eras',[])

    def build(self, season=None):
        year=int(self.save.setdefault('world',{}).get('current_year',2026) if season is None else season)
        seasons=self.history.get('world_seasons',[])
        legacy=self.history.get('world_legacy',{}).get('seasons',[])
        years=sorted({int(x.get('season')) for x in seasons+legacy if x.get('season') is not None and int(x.get('season'))<=year})
        if not years:
            years=[year]
        eras=[]; start=years[0]; prev=years[0]
        for y in years[1:]:
            if y-prev>1:
                eras.append(self._make(start,prev,years)); start=y
            prev=y
        eras.append(self._make(start,prev,years))
        self.eras[:] = eras
        self.history['history_eras_version']=self.VERSION
        return deepcopy(eras)

    def _make(self,start,end,years):
        return {'version':self.VERSION,'era_id':f'{start}-{end}','start_season':start,'end_season':end,'seasons':end-start+1,'continuous':all(y in years for y in range(start,end+1))}

    def current(self): return deepcopy(self.eras[-1]) if self.eras else None
    def validate(self):
        errors=[]
        ids=[e.get('era_id') for e in self.eras]
        if len(ids)!=len(set(ids)): errors.append('V206 duplicate era IDs')
        for e in self.eras:
            if e.get('version')!=self.VERSION or int(e.get('end_season',0))<int(e.get('start_season',0)): errors.append('V206 invalid era')
        return errors
