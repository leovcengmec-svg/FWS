"""V101 — Continental World Cycle.

Connects the completed domestic world pulse to the existing continental
qualification, coefficient and knockout layers. It never mutates the verified
catalog and never introduces individual-player simulation.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .v100_autonomous_world_cycle import V100AutonomousWorldCycle
from .coefficient import CoefficientEngine
from .continental import ContinentalAccessEngine
from .match_engine import MatchEngine
from .competition_registry import CONTINENTAL_BY_CONF


class V101ContinentalWorldCycle(V100AutonomousWorldCycle):
    VERSION = "V101"

    def advance_continental_cycle(self, season=None, seed=101, max_competitions=None):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        cycle = world.get("autonomous_cycle")
        if not cycle or not isinstance(cycle.get("state"), dict):
            raise ValueError("ciclo doméstico V100 não encontrado")

        year = int(season if season is not None else cycle.get("season", world.get("current_year", 2026)))
        state = cycle["state"]
        tables = {lid: row.get("standings", []) for lid, row in state.get("leagues_state", {}).items() if row.get("status") == "completed"}

        # Build a simulation-only world view from the verified catalog.
        sim_world = {
            "countries": {k: dict(v) for k, v in catalog.get("associations", {}).items()},
            "leagues": {k: dict(v) for k, v in catalog.get("leagues", {}).items()},
            "clubs": {k: dict(v) for k, v in catalog.get("clubs", {}).items()},
        }
        for lid, league in sim_world["leagues"].items():
            country = sim_world["countries"].get(league.get("country_id"), {})
            league.setdefault("confederation", country.get("confederation"))
            league.setdefault("coefficient", float(league.get("coefficient", 1.0)))

        # Update simulation-only league coefficients from the completed V100 tables.
        coeff_save = {"world": {**sim_world, "current_year": year}, "history": {}, "coefficients": {"window_seasons": 5, "decay": .75}}
        coefficient_engine = CoefficientEngine(5, .75)
        for lid, table in tables.items():
            if lid in sim_world["leagues"] and table:
                points = round(sum(float(r.get("points", 0)) for r in table) / max(1, len(table)), 3)
                coefficient_engine.update_league(coeff_save, lid, points)
        sim_world = coeff_save["world"]

        # Official continental competition definitions come from the existing
        # world defaults. No new competition identity is invented here.
        defaults = self.save.get("continental", {})
        definitions = defaults.get("competitions", {})
        enabled = []
        for conf, ids in CONTINENTAL_BY_CONF.items():
            for cid in ids:
                cfg = definitions.get(cid)
                catalog_cfg = catalog.get("competitions", {}).get(cid)
                if cfg and cfg.get("enabled") and catalog_cfg and catalog_cfg.get("official"):
                    enabled.append((cid, dict(cfg, id=cid, confederation=conf)))
        if max_competitions is not None:
            enabled = enabled[:max(0, int(max_competitions))]

        access = ContinentalAccessEngine(
            int(defaults.get("min_direct_slots", 1)),
            int(defaults.get("max_direct_slots", 6)),
        )
        results = {}
        matches_total = 0
        qualified_total = 0
        assigned_by_conf = {conf: set() for conf in CONTINENTAL_BY_CONF}

        for cid, cfg in enabled:
            size = int(cfg.get("default_size", 0))
            conf = cfg.get("confederation")
            leagues = [l for l in sim_world["leagues"].values()
                       if l.get("confederation") == conf and l.get("level", 999) == 1 and l.get("id") in tables]
            allocations = access.distribute(size, leagues)
            entries = []
            seen = set()
            for alloc in allocations:
                lid = alloc["league_id"]
                table = tables.get(lid, [])
                added_from_league = 0
                for row in table:
                    if added_from_league >= int(alloc["direct_slots"]):
                        break
                    club_id = row["club_id"]
                    if club_id in sim_world["clubs"] and club_id not in seen and club_id not in assigned_by_conf.get(conf, set()):
                        entries.append({"club_id": club_id, "league_id": lid, "position": len(entries) + 1})
                        seen.add(club_id)
                        assigned_by_conf.setdefault(conf, set()).add(club_id)
                        added_from_league += 1
                    if len(entries) >= size:
                        break
                if len(entries) >= size:
                    break

            qualified_total += len(entries)
            if len(entries) < 2:
                results[cid] = {"status": "insufficient_entries", "entries": len(entries), "champion": None, "matches": []}
                continue

            clubs = []
            for entry in entries:
                base = dict(sim_world["clubs"][entry["club_id"]])
                league = sim_world["leagues"].get(entry["league_id"], {})
                strength = float(league.get("coefficient", 50.0)) * .75
                base["attack"] = max(1.0, min(99.0, strength))
                base["defense"] = max(1.0, min(99.0, strength))
                base["prestige"] = max(1.0, min(99.0, strength))
                clubs.append(base)

            champion, matches = self._knockout(cid, year, clubs, int(seed))
            matches_total += len(matches)
            results[cid] = {
                "status": "completed",
                "entries": len(entries),
                "champion": champion.get("id") if champion else None,
                "matches": matches,
            }

        world["continental_cycle"] = {
            "version": self.VERSION,
            "season": year,
            "seed": int(seed),
            "competitions_processed": len(enabled),
            "competitions_completed": sum(1 for r in results.values() if r["status"] == "completed"),
            "qualified_clubs": qualified_total,
            "matches_simulated": matches_total,
            "results": deepcopy(results),
        }
        world.setdefault("history", {})
        history = self.save.setdefault("history", {})
        history.setdefault("continental_champions", {})
        for cid, row in results.items():
            if row.get("champion"):
                history["continental_champions"].setdefault(cid, []).append({
                    "season": year,
                    "club_id": row["champion"],
                    "entry_count": row["entries"],
                    "matches": deepcopy(row["matches"]),
                })

        return deepcopy(world["continental_cycle"])

    @staticmethod
    def _knockout(competition_id, season, clubs, seed):
        rng_seed = int(seed)
        pool = clubs[:]
        matches = []
        round_no = 1
        while len(pool) > 1:
            next_pool = []
            for i in range(0, len(pool) - 1, 2):
                home, away = pool[i], pool[i + 1]
                engine = MatchEngine(rng_seed + round_no * 1009 + i)
                result = engine.play(competition_id, season, round_no, home, away)
                if result.home_goals > result.away_goals:
                    winner = home
                elif result.away_goals > result.home_goals:
                    winner = away
                else:
                    digest = hashlib.sha256(f"{rng_seed}:{competition_id}:{season}:{round_no}:{home['id']}:{away['id']}".encode()).digest()
                    winner = home if digest[0] % 2 == 0 else away
                matches.append({
                    "competition_id": competition_id, "season": season, "round_no": round_no,
                    "home_id": home["id"], "away_id": away["id"],
                    "home_goals": result.home_goals, "away_goals": result.away_goals,
                    "winner_id": winner["id"],
                })
                next_pool.append(winner)
            if len(pool) % 2:
                next_pool.append(pool[-1])
            pool = next_pool
            round_no += 1
        return (pool[0] if pool else None), matches

    def validate(self):
        errors = super().validate()
        cycle = self.save.get("world", {}).get("continental_cycle")
        if cycle:
            if cycle.get("version") != self.VERSION:
                errors.append("wrong continental cycle version")
            if int(cycle.get("competitions_completed", 0)) > int(cycle.get("competitions_processed", 0)):
                errors.append("completed continental competitions exceed processed")
            if int(cycle.get("matches_simulated", 0)) < 0:
                errors.append("negative continental match count")
            seen_by_conf = {}
            for cid, row in cycle.get("results", {}).items():
                if row.get("champion") and row["champion"] not in self._catalog_from_save().get("clubs", {}):
                    errors.append(f"unknown continental champion {cid}")
                for match in row.get("matches", []):
                    seen_by_conf.setdefault(cid, set()).update((match.get("home_id"), match.get("away_id")))
            # The cycle itself stores unique entries per confederation before matches;
            # the explicit allocation rule prevents one club from entering two
            # continental competitions in the same confederation.
        return errors
