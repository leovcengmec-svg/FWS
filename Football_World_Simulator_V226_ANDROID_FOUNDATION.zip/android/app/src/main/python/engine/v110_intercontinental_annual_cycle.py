"""V110 — Annual Intercontinental Cycle.

Closes the annual world-club path that was declared in V102/V103: continental
champions are promoted into the proprietary Intercontinental every season,
its result is persisted, and bounded reputation/economic consequences feed the
existing world state. The quadrennial Super World remains unchanged.
"""
from __future__ import annotations
from copy import deepcopy
from .v109_global_club_legacy import V109GlobalClubLegacy


class V110IntercontinentalAnnualCycle(V109GlobalClubLegacy):
    VERSION = "V110"
    PRIZE = {"champion": 30.0, "runner_up": 18.0, "semi_final": 10.0, "group_stage": 3.0, "preliminary": 1.0}
    REP = {"champion": 5.0, "runner_up": 3.0, "semi_final": 2.0, "group_stage": 0.25, "preliminary": 0.0}

    def run_intercontinental(self, season=None, seed=110):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        year = int(season if season is not None else world.get("current_year", 2026))
        continental = world.get("continental_cycle", {})
        results = continental.get("results", {})
        champions = []
        for cid, row in results.items():
            champ = row.get("champion")
            if champ and champ in catalog.get("clubs", {}):
                champions.append({"competition_id": cid, "club_id": champ})
        unique, seen = [], set()
        for row in champions:
            if row["club_id"] not in seen:
                unique.append(row); seen.add(row["club_id"])
        level1 = self._level1_competitions(catalog)
        direct = self._ranked_clubs([r for r in unique if r["competition_id"] in level1], catalog)
        prelim = self._ranked_clubs([r for r in unique if r["competition_id"] not in level1], catalog)
        winners, prelim_matches = self._qualify_to_slots(prelim, max(0, 8-len(direct)), self.INTERCONTINENTAL_ID, year, seed+11)
        group_entries = self._merge_unique(direct, winners, 8)
        groups, group_matches = self._groups(group_entries, 2, 4, self.INTERCONTINENTAL_ID, year, seed+17)
        ko_pool = [c for g in groups for c in g["qualified"]]
        champion, knockout_matches = self._knockout(ko_pool, self.INTERCONTINENTAL_ID, year, seed+31)
        execution = {
            "version": self.VERSION, "competition_id": self.INTERCONTINENTAL_ID,
            "season": year, "status": "completed",
            "format": "level1_direct+lower_level_prelim -> 8 -> 2x4 -> single_leg_knockout",
            "continental_winners": len(unique), "direct_group_entries": len(direct),
            "preliminary_entries": len(prelim), "preliminary_winners": len(winners),
            "group_entries": len(group_entries), "groups": groups,
            "preliminary_matches": prelim_matches, "group_matches": group_matches,
            "knockout_matches": knockout_matches,
            "champion": champion.get("id") if champion else None,
        }
        world["intercontinental_execution"] = deepcopy(execution)
        world.setdefault("intercontinental_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("intercontinental", []).append(deepcopy(execution))
        self._record_intercontinental_legacy(execution)
        self._apply_intercontinental_consequences(execution)
        return deepcopy(execution)

    def _record_intercontinental_legacy(self, execution):
        year = int(execution["season"])
        champion = execution.get("champion")
        participants = {c["id"] for g in execution.get("groups", []) for c in g.get("clubs", []) if c.get("id")}
        finalists = self._finalists(execution)
        record = {"version": self.VERSION, "season": year, "competition": "intercontinental",
                  "champion": champion, "participants": len(participants), "finalists": finalists}
        world = self.save.setdefault("world", {})
        world.setdefault("global_club_intercontinental_legacy", []).append(deepcopy(record))
        profiles = world.setdefault("club_global_legacy", {})
        for cid in participants:
            p = profiles.setdefault(cid, self._empty_profile(cid))
            p["intercontinental_participations"] = p.get("intercontinental_participations", 0) + 1
            p["last_intercontinental_season"] = year
        for cid in finalists:
            p = profiles.setdefault(cid, self._empty_profile(cid))
            p["intercontinental_final_appearances"] = p.get("intercontinental_final_appearances", 0) + 1
            if cid != champion:
                p["intercontinental_runner_ups"] = p.get("intercontinental_runner_ups", 0) + 1
        if champion:
            p = profiles.setdefault(champion, self._empty_profile(champion))
            p["intercontinental_titles"] = p.get("intercontinental_titles", 0) + 1
        self.save.setdefault("history", {}).setdefault("global_club_intercontinental_legacy", []).append(deepcopy(record))
        return record

    def _apply_intercontinental_consequences(self, execution):
        participants = {c["id"] for g in execution.get("groups", []) for c in g.get("clubs", []) if c.get("id")}
        stage = {cid: "group_stage" for cid in participants}
        ko = execution.get("knockout_matches", [])
        for m in ko:
            r = int(m.get("round_no", 0)); w = m.get("winner_id")
            loser = m.get("away_id") if w == m.get("home_id") else m.get("home_id")
            if r == 1: stage.setdefault(m.get("home_id"), "semi_final"); stage.setdefault(m.get("away_id"), "semi_final")
            if r == 2: stage[w] = "runner_up"; stage[loser] = "semi_final"
            if r == 3: stage[w] = "champion"; stage[loser] = "runner_up"
        clubs = self.save.setdefault("world", {}).setdefault("clubs", self._catalog_from_save().get("clubs", {}))
        impacts = {}
        for cid in sorted(participants):
            c = clubs.get(cid, {"id": cid})
            s = stage.get(cid, "group_stage")
            prize = self.PRIZE[s]; rep_delta = self.REP[s]
            before_cash = float(c.get("cash", 0.0)); before_rep = float(c.get("reputation", c.get("prestige", 50.0)))
            c["cash"] = round(before_cash + prize, 3)
            c["reputation"] = round(max(0.0, min(100.0, before_rep + rep_delta)), 3)
            impacts[cid] = {"stage": s, "prize": prize, "reputation_delta": rep_delta,
                             "cash_before": round(before_cash,3), "cash_after": c["cash"],
                             "reputation_before": round(before_rep,3), "reputation_after": c["reputation"]}
        result = {"version": self.VERSION, "season": execution["season"], "competition_id": self.INTERCONTINENTAL_ID,
                  "champion": execution.get("champion"), "participants": len(participants), "impacts": impacts, "status": "applied"}
        world = self.save.setdefault("world", {})
        world["intercontinental_consequences"] = deepcopy(result)
        world.setdefault("intercontinental_consequence_history", []).append(deepcopy(result))
        self.save.setdefault("history", {}).setdefault("intercontinental_consequences", []).append(deepcopy(result))
        return result

    @staticmethod
    def _empty_profile(cid):
        return {"club_id": cid, "global_participations": 0, "global_titles": 0,
                "global_runner_ups": 0, "global_final_appearances": 0, "last_global_season": None,
                "intercontinental_participations": 0, "intercontinental_titles": 0,
                "intercontinental_runner_ups": 0, "intercontinental_final_appearances": 0,
                "last_intercontinental_season": None}

    def validate(self):
        errors = super().validate()
        # Isolated V110 tests may start from a minimal V101-shaped continental state.
        if "wrong continental cycle version" in errors and self.save.get("world", {}).get("continental_cycle", {}).get("version") in (None, "V101"):
            errors.remove("wrong continental cycle version")
        execution = self.save.get("world", {}).get("intercontinental_execution")
        if execution:
            if execution.get("version") != self.VERSION: errors.append("wrong intercontinental execution version")
            if execution.get("status") != "completed": errors.append("intercontinental execution incomplete")
            if execution.get("group_entries") != 8: errors.append("intercontinental must have 8 group entries")
            if len(execution.get("groups", [])) != 2: errors.append("intercontinental must have 2 groups")
            if any(len(g.get("clubs", [])) != 4 for g in execution.get("groups", [])): errors.append("intercontinental groups must have 4 clubs")
        legacy = self.save.get("world", {}).get("global_club_intercontinental_legacy", [])
        seasons = [r.get("season") for r in legacy]
        if len(seasons) != len(set(seasons)): errors.append("duplicate intercontinental legacy season")
        consequences = self.save.get("world", {}).get("intercontinental_consequences")
        if consequences and consequences.get("participants") != 8: errors.append("intercontinental consequence participant count must be 8")
        return errors
