"""V119 — Intercontinental Club Competition Format.

Current approved Intercontinental Club rule:
- 8 final places.
- 6 Level-1 continental champions qualify directly.
- 17 Level-2-or-below continental champion places are available.
- Of those 17, the 15 highest-coefficient entries qualify directly to the
  Intercontinental playoff field and the 2 lowest coefficients play a
  preliminary match; its winner joins the 15 for a 16-club knockout.
- The 16-club playoff is 16 -> 8 -> 4 -> 2, producing exactly 2 qualifiers.
- 6 direct Level-1 champions + 2 playoff qualifiers = 8 group-stage clubs.
- The group stage is 2 groups of 4; each group has 3 rounds (single round
  robin, each club plays three matches). The top two of each group advance.
- The knockout is then 4 -> 2 -> 1 champion.

This remains an aggregate club/selection simulation. No player registry or
player-transfer system is introduced.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .match_engine import MatchEngine
from .v118_continental_rules_configuration import V118ContinentalRulesConfiguration


class V119IntercontinentalClubFormat(V118ContinentalRulesConfiguration):
    VERSION = "V119"
    INTERCONTINENTAL_ID = "FWS_INTERCONTINENTAL"
    LEVEL1_DIRECT_PLACES = 6
    LOWER_LEVEL_PLACES = 17
    LOWER_DIRECT_PLACES = 15
    LOWER_PRELIMINARY_ENTRANTS = 2
    FINAL_GROUP_ENTRIES = 8
    GROUP_COUNT = 2
    GROUP_SIZE = 4
    GROUP_ROUNDS = 3
    PLAYOFF_SIZE = 16
    PLAYOFF_QUALIFIERS = 2

    @staticmethod
    def _level1_competitions(catalog):
        order = ["UEFA", "AFC", "CAF", "CONCACAF", "CONMEBOL", "OFC"]
        by_conf = {}
        for cid, cfg in catalog.get("competitions", {}).items():
            if not cfg.get("intercontinental_eligible", True):
                continue
            # V112 tier metadata is authoritative. Legacy snapshots without
            # tier metadata retain the historical one-off top-competition
            # fallback so older unit fixtures remain compatible.
            if cfg.get("tier") == "level_1":
                by_conf.setdefault(cfg.get("confederation"), []).append(cid)
        if len(by_conf) < len([c for c in order if any(x.get("confederation") == c for x in catalog.get("competitions", {}).values())]):
            legacy = {}
            for cid, cfg in catalog.get("competitions", {}).items():
                if not cfg.get("intercontinental_eligible", True) or cfg.get("tier"):
                    continue
                if cfg.get("official"):
                    legacy.setdefault(cfg.get("confederation"), []).append(cid)
            for conf, ids in legacy.items():
                by_conf.setdefault(conf, []).extend(ids)
        return {sorted(by_conf[c])[0] for c in order if by_conf.get(c)}

    @staticmethod
    def _ranked_clubs(entries, catalog):
        rows = []
        for entry in entries:
            club = dict(catalog["clubs"][entry["club_id"]])
            club["_world_source"] = entry["competition_id"]
            club["_continental_coefficient"] = V119IntercontinentalClubFormat._competition_coefficient(entry["competition_id"], catalog)
            club["_rank_key"] = hashlib.sha256(f'{entry["competition_id"]}:{entry["club_id"]}'.encode()).hexdigest()
            rows.append(club)
        rows.sort(key=lambda c: (-c["_continental_coefficient"], c["_world_source"], c["id"]))
        return rows

    @staticmethod
    def _competition_coefficient(competition_id, catalog):
        cfg = catalog.get("competitions", {}).get(competition_id, {})
        return float(cfg.get("coefficient", cfg.get("continental_coefficient", 1.0)))

    def _lower_entries(self, unique, catalog, level1):
        rows = []
        for row in unique:
            cfg = catalog.get("competitions", {}).get(row["competition_id"], {})
            if row["competition_id"] in level1 or not cfg.get("intercontinental_eligible", True):
                continue
            coeff = self._competition_coefficient(row["competition_id"], catalog)
            club = dict(catalog["clubs"][row["club_id"]])
            club["_world_source"] = row["competition_id"]
            club["_continental_coefficient"] = coeff
            club["_rank_key"] = hashlib.sha256(
                f'{row["competition_id"]}:{row["club_id"]}'.encode()
            ).hexdigest()
            rows.append(club)
        # Higher coefficient is selected first. Stable ID breaks ties.
        rows.sort(key=lambda c: (-c["_continental_coefficient"], c["_world_source"], c["id"]))
        return rows

    @staticmethod
    def _merge_unique(a, b, limit):
        out = []; seen = set()
        for club in list(a) + list(b):
            if club["id"] not in seen and len(out) < limit:
                out.append(club); seen.add(club["id"])
        return out

    @staticmethod
    def _single_aggregate_match(home, away, cid, season, seed, round_no, index):
        engine = MatchEngine(int(seed) + round_no * 1009 + index)
        # Aggregate club model: coefficient is a context input, never a direct
        # winner guarantee. Existing club sporting attributes are preserved.
        h = dict(home); a = dict(away)
        coeff_h = float(h.get("_continental_coefficient", h.get("league_coefficient", 50.0)))
        coeff_a = float(a.get("_continental_coefficient", a.get("league_coefficient", 50.0)))
        h.setdefault("attack", max(1.0, min(99.0, coeff_h)))
        h.setdefault("defense", max(1.0, min(99.0, coeff_h)))
        h.setdefault("prestige", max(1.0, min(99.0, coeff_h)))
        a.setdefault("attack", max(1.0, min(99.0, coeff_a)))
        a.setdefault("defense", max(1.0, min(99.0, coeff_a)))
        a.setdefault("prestige", max(1.0, min(99.0, coeff_a)))
        r = engine.play(cid, season, round_no, h, a)
        if r.home_goals > r.away_goals:
            winner = home
        elif r.away_goals > r.home_goals:
            winner = away
        else:
            digest = hashlib.sha256(
                f'{seed}:{cid}:{season}:{round_no}:{home["id"]}:{away["id"]}'.encode()
            ).digest()
            winner = home if digest[0] % 2 == 0 else away
        return winner, {
            "competition_id": cid, "season": season, "round_no": round_no,
            "home_id": home["id"], "away_id": away["id"],
            "home_goals": r.home_goals, "away_goals": r.away_goals,
            "winner_id": winner["id"],
        }

    def _preliminary_two_to_one(self, entrants, season, seed):
        if len(entrants) < 2:
            return list(entrants), []
        winner, match = self._single_aggregate_match(
            entrants[0], entrants[1], self.INTERCONTINENTAL_ID, season, seed, 1, 0
        )
        return [winner], [match]

    def _playoff_16_to_2(self, clubs, season, seed):
        current = list(clubs)
        matches = []
        round_no = 1
        while len(current) > self.PLAYOFF_QUALIFIERS:
            if len(current) % 2:
                # The approved 16-club field is always even. This guard keeps
                # the motor deterministic if a malformed caller reaches here.
                current = current[:-1]
            nxt = []
            for i in range(0, len(current), 2):
                winner, row = self._single_aggregate_match(
                    current[i], current[i + 1], self.INTERCONTINENTAL_ID,
                    season, seed, round_no, i
                )
                nxt.append(winner); matches.append(row)
            current = nxt
            round_no += 1
        return current, matches

    def _four_team_knockout(self, clubs, season, seed):
        current = list(clubs); matches = []
        round_no = 1
        while len(current) > 1:
            nxt = []
            for i in range(0, len(current), 2):
                winner, row = self._single_aggregate_match(current[i], current[i + 1], self.INTERCONTINENTAL_ID, season, seed, round_no, i)
                nxt.append(winner); matches.append(row)
            current = nxt; round_no += 1
        return (current[0] if current else None), matches

    def _group_stage_three_rounds(self, clubs, season, seed):
        groups = [{"group": i + 1, "clubs": [], "qualified": [], "matches": [], "table": []}
                  for i in range(self.GROUP_COUNT)]
        for i, club in enumerate(clubs[:self.FINAL_GROUP_ENTRIES]):
            groups[i % self.GROUP_COUNT]["clubs"].append(club)

        all_matches = []
        # For four clubs: three rounds, each club plays once per round.
        schedule = ((0, 1, 2, 3), (0, 2, 1, 3), (0, 3, 1, 2))
        for group in groups:
            points = {c["id"]: 0 for c in group["clubs"]}
            for round_no, pairings in enumerate(schedule, start=1):
                for pair_index, (a_idx, b_idx) in enumerate(((pairings[0], pairings[1]), (pairings[2], pairings[3]))):
                    home = group["clubs"][a_idx]; away = group["clubs"][b_idx]
                    _, row = self._single_aggregate_match(
                        home, away, self.INTERCONTINENTAL_ID, season, seed + group["group"],
                        round_no, pair_index
                    )
                    group["matches"].append(row); all_matches.append(row)
                    if row["home_goals"] > row["away_goals"]:
                        points[home["id"]] += 3
                    elif row["away_goals"] > row["home_goals"]:
                        points[away["id"]] += 3
                    else:
                        points[home["id"]] += 1; points[away["id"]] += 1
            ranking = sorted(points.items(), key=lambda x: (-x[1], x[0]))
            group["qualified"] = [next(c for c in group["clubs"] if c["id"] == cid) for cid, _ in ranking[:2]]
            group["table"] = [{"club_id": cid, "points": pts} for cid, pts in ranking]
        return groups, all_matches

    def run_intercontinental(self, season=None, seed=119):
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        year = int(season if season is not None else world.get("current_year", 2026))
        results = world.get("continental_cycle", {}).get("results", {})

        champions = []
        for cid, row in results.items():
            champ = row.get("champion")
            if champ and champ in catalog.get("clubs", {}):
                champions.append({"competition_id": cid, "club_id": champ})
        unique, seen = [], set()
        for row in champions:
            if row["club_id"] not in seen:
                unique.append(row); seen.add(row["club_id"])

        level1 = self._level1_competitions(catalog)
        direct_rows = [r for r in unique if r["competition_id"] in level1]
        direct = self._ranked_clubs(direct_rows, catalog)[:self.LEVEL1_DIRECT_PLACES]

        lower = self._lower_entries(unique, catalog, level1)
        lower = lower[:self.LOWER_LEVEL_PLACES]
        # Lowest two coefficients play the preliminary match; the other 15 go
        # directly into the 16-club playoff.
        lower_sorted_ascending = sorted(lower, key=lambda c: (c["_continental_coefficient"], c["_world_source"], c["id"]))
        prelim_entries = lower_sorted_ascending[:self.LOWER_PRELIMINARY_ENTRANTS]
        prelim_direct = [c for c in lower if c["id"] not in {x["id"] for x in prelim_entries}]
        prelim_winner, preliminary_matches = self._preliminary_two_to_one(prelim_entries, year, seed + 11)
        playoff_entries = prelim_direct + prelim_winner
        playoff_entries.sort(key=lambda c: (-float(c.get("_continental_coefficient", 1.0)), c["_world_source"], c["id"]))
        playoff_entries = playoff_entries[:self.PLAYOFF_SIZE]
        playoff_qualifiers, playoff_matches = self._playoff_16_to_2(playoff_entries, year, seed + 23) if len(playoff_entries) == 16 else ([], [])

        group_entries = self._merge_unique(direct, playoff_qualifiers, self.FINAL_GROUP_ENTRIES)
        groups, group_matches = self._group_stage_three_rounds(group_entries, year, seed + 41) if len(group_entries) == self.FINAL_GROUP_ENTRIES else ([], [])
        ko_pool = [c for g in groups for c in g["qualified"]]
        champion, knockout_matches = self._four_team_knockout(ko_pool, year, seed + 59)

        execution = {
            "version": self.VERSION,
            "competition_id": self.INTERCONTINENTAL_ID,
            "season": year,
            "status": "completed" if len(group_entries) == 8 else "incomplete",
            "format": "6_level1_direct+17_lower_level(15_direct+2_lowest_prelim)->16->8->4->2; 8_group_stage=2x4_3_rounds; knockout_4->2->1",
            "level1_direct_places": 6,
            "lower_level_places": 17,
            "lower_direct_places": 15,
            "lower_preliminary_entries": len(prelim_entries),
            "lower_preliminary_winners": len(prelim_winner),
            "playoff_entries": len(playoff_entries),
            "playoff_qualifiers": len(playoff_qualifiers),
            "playoff_rounds": [16, 8, 4, 2] if len(playoff_entries) == 16 else [],
            "group_entries": len(group_entries),
            "group_count": 2,
            "group_size": 4,
            "group_rounds": 3,
            "groups": groups,
            "preliminary_matches": preliminary_matches,
            "playoff_matches": playoff_matches,
            "group_matches": group_matches,
            "knockout_matches": knockout_matches,
            "champion": champion.get("id") if champion else None,
        }
        world["intercontinental_execution"] = deepcopy(execution)
        world.setdefault("intercontinental_execution_history", []).append(deepcopy(execution))
        self.save.setdefault("history", {}).setdefault("intercontinental", []).append(deepcopy(execution))
        self._record_intercontinental_legacy(execution)
        self._apply_intercontinental_consequences(execution)
        return deepcopy(execution)

    @staticmethod
    def _empty_profile(cid):
        return {"club_id": cid, "global_participations": 0, "global_titles": 0,
                "global_runner_ups": 0, "global_final_appearances": 0, "last_global_season": None,
                "intercontinental_participations": 0, "intercontinental_titles": 0,
                "intercontinental_runner_ups": 0, "intercontinental_final_appearances": 0,
                "last_intercontinental_season": None}

    def _record_intercontinental_legacy(self, execution):
        year = int(execution["season"])
        champion = execution.get("champion")
        participants = {c["id"] for g in execution.get("groups", []) for c in g.get("clubs", []) if c.get("id")}
        ko = execution.get("knockout_matches", [])
        finalists = []
        if ko:
            final = max(ko, key=lambda m: int(m.get("round_no", 0)))
            finalists = [final.get("home_id"), final.get("away_id")]
        record = {"version": self.VERSION, "season": year, "competition": "intercontinental",
                  "champion": champion, "participants": len(participants), "finalists": finalists}
        world = self.save.setdefault("world", {})
        world.setdefault("global_club_intercontinental_legacy", []).append(deepcopy(record))
        profiles = world.setdefault("club_global_legacy", {})
        for cid in participants:
            prof = profiles.setdefault(cid, self._empty_profile(cid))
            prof["intercontinental_participations"] = prof.get("intercontinental_participations", 0) + 1
            prof["last_intercontinental_season"] = year
        for cid in finalists:
            if not cid:
                continue
            prof = profiles.setdefault(cid, self._empty_profile(cid))
            prof["intercontinental_final_appearances"] = prof.get("intercontinental_final_appearances", 0) + 1
            if cid != champion:
                prof["intercontinental_runner_ups"] = prof.get("intercontinental_runner_ups", 0) + 1
        if champion:
            prof = profiles.setdefault(champion, self._empty_profile(champion))
            prof["intercontinental_titles"] = prof.get("intercontinental_titles", 0) + 1
        self.save.setdefault("history", {}).setdefault("global_club_intercontinental_legacy", []).append(deepcopy(record))
        return record

    def _apply_intercontinental_consequences(self, execution):
        participants = {c["id"] for g in execution.get("groups", []) for c in g.get("clubs", []) if c.get("id")}
        stage = {cid: "group_stage" for cid in participants}
        for match in execution.get("knockout_matches", []):
            round_no = int(match.get("round_no", 0)); winner = match.get("winner_id")
            home = match.get("home_id"); away = match.get("away_id")
            loser = away if winner == home else home
            if round_no == 1:
                stage[home] = stage[away] = "semi_final"
            elif round_no == 2:
                stage[winner] = "champion"
                stage[loser] = "runner_up"
        clubs = self.save.setdefault("world", {}).setdefault("clubs", self._catalog_from_save().get("clubs", {}))
        prize = {"champion": 30.0, "runner_up": 18.0, "semi_final": 10.0, "group_stage": 3.0}
        rep = {"champion": 5.0, "runner_up": 3.0, "semi_final": 2.0, "group_stage": 0.25}
        impacts = {}
        for cid in sorted(participants):
            club = clubs.get(cid, {"id": cid})
            st = stage.get(cid, "group_stage")
            before_cash = float(club.get("cash", 0.0)); before_rep = float(club.get("reputation", club.get("prestige", 50.0)))
            club["cash"] = round(before_cash + prize[st], 3)
            club["reputation"] = round(max(0.0, min(100.0, before_rep + rep[st])), 3)
            impacts[cid] = {"stage": st, "prize": prize[st], "reputation_delta": rep[st],
                             "cash_before": round(before_cash, 3), "cash_after": club["cash"],
                             "reputation_before": round(before_rep, 3), "reputation_after": club["reputation"]}
        result = {"version": self.VERSION, "season": execution["season"],
                  "competition_id": self.INTERCONTINENTAL_ID, "champion": execution.get("champion"),
                  "participants": len(participants), "impacts": impacts, "status": "applied"}
        world = self.save.setdefault("world", {})
        world["intercontinental_consequences"] = deepcopy(result)
        world.setdefault("intercontinental_consequence_history", []).append(deepcopy(result))
        self.save.setdefault("history", {}).setdefault("intercontinental_consequences", []).append(deepcopy(result))
        return result

    def validate(self):
        errors = super().validate()
        execution = self.save.get("world", {}).get("intercontinental_execution")
        if execution:
            if execution.get("version") != self.VERSION:
                errors.append("wrong V119 intercontinental execution version")
            if execution.get("level1_direct_places") != 6:
                errors.append("V119 must reserve 6 direct Level-1 places")
            if execution.get("lower_level_places") != 17:
                errors.append("V119 must define 17 lower-level places")
            if execution.get("lower_direct_places") != 15:
                errors.append("V119 must define 15 lower-level direct places")
            if execution.get("lower_preliminary_entries") == 2 and execution.get("lower_preliminary_winners") != 1:
                errors.append("V119 two lowest-coefficient entrants must produce one preliminary qualifier")
            if execution.get("playoff_entries") == 16 and execution.get("playoff_qualifiers") != 2:
                errors.append("V119 16-club playoff must produce exactly 2 qualifiers")
            if execution.get("group_entries") == 8:
                if execution.get("group_count") != 2 or execution.get("group_size") != 4 or execution.get("group_rounds") != 3:
                    errors.append("V119 group stage must be 2x4 with 3 rounds")
                if len(execution.get("groups", [])) != 2 or any(len(g.get("clubs", [])) != 4 for g in execution.get("groups", [])):
                    errors.append("V119 group stage must contain two groups of four")
                if any(len(g.get("matches", [])) != 6 for g in execution.get("groups", [])):
                    errors.append("V119 each group must contain 6 matches across 3 rounds")
        return errors
