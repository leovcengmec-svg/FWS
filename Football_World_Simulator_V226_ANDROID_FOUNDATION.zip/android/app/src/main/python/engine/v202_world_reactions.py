"""V202 — World Alive: deterministic reactions to aggregate events."""
from __future__ import annotations
import pickle
from copy import deepcopy
class V202WorldReactions:
    VERSION='V202'
    def __init__(self,save): self.save=save
    def apply(self,season=None):
        w=self.save.setdefault('world',{}); h=self.save.setdefault('history',{}); year=int(w.get('current_year',2026) if season is None else season)
        events=[x for x in h.get('world_events',[]) if int(x.get('season',-1))==year]
        snap=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        try:
            reactions=[]
            for ev in events:
                c=w.get('clubs',{}).get(ev.get('entity_id'))
                if not c: continue
                m=float(ev.get('magnitude',0)); typ=ev.get('type'); before={k:float(c.get(k,50)) for k in ('prestige','management_stability','sporting_strength','cash')}
                if typ=='breakthrough': c['sporting_strength']=min(100,before['sporting_strength']+m); c['prestige']=min(100,before['prestige']+m*.45)
                elif typ=='financial_pressure': c['cash']=max(0,before['cash']+m); c['management_stability']=max(0,before['management_stability']+m*.35)
                elif typ=='infrastructure': c['management_stability']=min(100,before['management_stability']+m*.4); c['sporting_strength']=min(100,before['sporting_strength']+m*.15)
                elif typ=='reputation_shift': c['prestige']=max(0,min(100,before['prestige']+m))
                elif typ=='competition_pressure': c['management_stability']=max(0,min(100,before['management_stability']+m))
                reactions.append({'version':self.VERSION,'season':year,'event_id':ev['event_id'],'entity_id':ev['entity_id'],'type':typ,'changes':{k:round(float(c.get(k,0))-v,3) for k,v in before.items()}})
            h.setdefault('world_reactions',[]).extend(deepcopy(reactions)); w['world_alive_status']='reactions_applied'; return deepcopy(reactions)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snap)); raise
    def validate(self):
        h=self.save.setdefault('history',{}); return [] if all(r.get('version')==self.VERSION for r in h.get('world_reactions',[])) else ['invalid_reaction']
