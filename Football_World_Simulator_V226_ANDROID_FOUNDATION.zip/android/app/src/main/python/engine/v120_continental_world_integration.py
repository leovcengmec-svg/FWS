"""V120 compatibility layer for the continental/world integration milestone."""
from .v119_intercontinental_club_format import V119IntercontinentalClubFormat

class V120ContinentalWorldIntegration(V119IntercontinentalClubFormat):
    VERSION = "V120"

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_world_integration"] = {
            "version": self.VERSION,
            "base_version": "V119",
            "continental_competitions_are_world_registered": True,
        }
        return world["continental_world_integration"]

    def validate(self):
        errors = super().validate()
        cfg = self.save.get("world", {}).get("continental_world_integration", {})
        if cfg and cfg.get("version") != self.VERSION:
            errors.append("wrong V120 integration version")
        return errors
