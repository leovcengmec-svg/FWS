"""V124 — Continental Access Annual Cycle.

Turns the V123 global access engine into an annual, auditable pre-season gate.
It does not invent access values: callers must provide the already-resolved
competition access lists. A season may advance to continental draw/competition
execution only after the complete access package is valid and locked.
"""
from __future__ import annotations
from copy import deepcopy
from .v123_global_continental_access import V123GlobalContinentalAccess


class V124ContinentalAccessCycle(V123GlobalContinentalAccess):
    VERSION = "V124"

    def prepare_annual_access(self, season, competitions, access_lists):
        """Build, validate and lock one complete continental access package.

        The method is deliberately a gate: pending or invalid competitions do
        not get silently converted into executable access. No club, quota,
        path, or replacement is inferred here.
        """
        year = int(season)
        state = self.build_global_access_state(competitions, access_lists)
        package = {
            "version": self.VERSION,
            "season": year,
            "status": state["status"],
            "competitions": deepcopy(state["competitions"]),
            "errors": list(state.get("errors", [])),
        }
        world = self.save.setdefault("world", {})
        world.setdefault("continental_access_cycle_history", []).append(deepcopy(package))

        if state["status"] != self.STATUS_VALID:
            return deepcopy(package)

        locked = self.lock_access(state)
        locked["version"] = self.VERSION
        locked["season"] = year
        world["continental_access_cycle"] = deepcopy(locked)
        world["continental_access_cycle"]["status"] = "ACCESS_LOCKED"
        self.record_event(world, {
            "type": "CONTINENTAL_ACCESS_CYCLE_LOCKED",
            "version": self.VERSION,
            "season": year,
            "competitions": sorted(locked.get("competitions", {}).keys()),
        })
        return deepcopy(world["continental_access_cycle"])

    def can_start_continental_draw(self, season=None):
        cycle = self.save.get("world", {}).get("continental_access_cycle")
        if not cycle or cycle.get("status") != "ACCESS_LOCKED":
            return False
        if season is not None and int(cycle.get("season")) != int(season):
            return False
        return True

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_access_cycle_engine"] = {
            "version": self.VERSION,
            "base_version": "V123",
            "annual_gate": True,
            "draw_requires_access_lock": True,
            "execution_requires_access_lock": True,
            "no_invented_clubs": True,
            "no_invented_association_quotas": True,
            "history_append_only": True,
        }
        return deepcopy(world["continental_access_cycle_engine"])

    def validate(self):
        errors = super().validate()
        cfg = self.save.get("world", {}).get("continental_access_cycle_engine", {})
        if cfg and cfg.get("version") != self.VERSION:
            errors.append("wrong V124 continental access cycle version")
        if cfg and not cfg.get("annual_gate"):
            errors.append("V124 annual access gate is mandatory")
        cycle = self.save.get("world", {}).get("continental_access_cycle")
        if cycle and cycle.get("status") == "ACCESS_LOCKED":
            if cycle.get("version") != self.VERSION:
                errors.append("locked continental access cycle version mismatch")
            if not cycle.get("season"):
                errors.append("locked continental access cycle missing season")
        return errors
