"""Release continuity audit for the Football World Simulator.

This layer verifies that every declared version layer points to artifacts that
actually exist in the current package and that the version manifest is
internally consistent. It does not change gameplay behavior.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "config" / "version_manifest.json"


def load_manifest(path=MANIFEST):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def declared_layer_files(manifest):
    files = {}
    for version, entries in manifest.get("explicit_layers", {}).items():
        if isinstance(entries, str):
            files[version] = [part.strip() for part in entries.split("+")]
        else:
            files[version] = list(entries)
    for version, entry in manifest.get("layers", {}).items():
        values = entry.get("files", []) if isinstance(entry, dict) else []
        if isinstance(values, str):
            values = [part.strip() for part in values.split("+")]
        files.setdefault(version, []).extend(values)
    # The continuity_audit block is the canonical historical map and must be
    # included in the artifact audit; otherwise a layer can be documented there
    # yet be invisible to the checker.
    for version, entry in manifest.get("continuity_audit", {}).get("layers", {}).items():
        values = entry.get("files", []) if isinstance(entry, dict) else entry
        if isinstance(values, str):
            values = [part.strip() for part in values.split("+")]
        files.setdefault(version, []).extend(values or [])
    return {v: list(dict.fromkeys(paths)) for v, paths in files.items()}


def audit_manifest(manifest=None, root=ROOT):
    manifest = manifest or load_manifest()
    layers = declared_layer_files(manifest)
    missing = {
        version: [p for p in paths if not (root / p).is_file()]
        for version, paths in layers.items()
    }
    missing = {v: paths for v, paths in missing.items() if paths}
    return {
        "declared_versions": sorted(layers, key=lambda v: tuple(int(x) if x.isdigit() else x for x in v[1:].split("."))),
        "missing_artifacts": missing,
        "missing_count": sum(len(v) for v in missing.values()),
        "manifest_current_version": manifest.get("current_version"),
        "package_version": manifest.get("package_version"),
    }
