"""V122 — Continental Slot Matrix Framework.

Adds a first-class, auditable container for an eventual official direct-slot
matrix without inventing any association quotas. The matrix is optional:
missing values remain configuration_pending. Explicit values are validated
against the permanent rules (0 minimum, 6 maximum per association) and the
competition field size. No redistribution policy is assumed.
"""
from __future__ import annotations
from copy import deepcopy
from .v121_continental_qualification_ledger import V121ContinentalQualificationLedger


class V122ContinentalSlotMatrix(V121ContinentalQualificationLedger):
    VERSION = "V122"

    def build_slot_matrix(self, competitions, matrix=None):
        matrix = matrix or {}
        out = {}
        for comp in competitions:
            cid = comp["id"]
            field_size = int(comp.get("size", comp.get("default_size", 0)))
            raw = matrix.get(cid)
            if raw is None:
                out[cid] = {
                    "competition_id": cid,
                    "field_size": field_size,
                    "status": "qualification_configuration_pending",
                    "missing_configuration": ["direct_slot_matrix"],
                    "allocations": [],
                    "direct_slots_total": 0,
                    "preliminary_slots": 0,
                }
                continue
            allocations = []
            seen = set()
            errors = []
            for league_id, value in raw.items():
                if league_id in seen:
                    errors.append(f"duplicate league: {league_id}")
                    continue
                seen.add(league_id)
                try:
                    slots = int(value)
                except (TypeError, ValueError):
                    errors.append(f"invalid slots for {league_id}")
                    continue
                if slots < 0:
                    errors.append(f"negative slots for {league_id}")
                if slots > 6:
                    errors.append(f"more than six direct slots for {league_id}")
                if slots:
                    allocations.append({"league_id": league_id, "direct_slots": slots})
            total = sum(x["direct_slots"] for x in allocations)
            if total > field_size:
                errors.append("direct slots exceed competition field size")
            out[cid] = {
                "competition_id": cid,
                "field_size": field_size,
                "status": "ready" if not errors else "invalid",
                "missing_configuration": [],
                "errors": errors,
                "allocations": allocations,
                "direct_slots_total": total,
                "preliminary_slots": max(0, field_size - total),
                "redistribution_policy": "not_defined",
            }
        return out

    def apply(self):
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_slot_matrix_framework"] = {
            "version": self.VERSION,
            "base_version": "V121",
            "source_of_truth": "explicit_competition_direct_slot_matrix",
            "min_direct_slots_per_league": 0,
            "max_direct_slots_per_league": 6,
            "missing_matrix_behavior": "qualification_configuration_pending",
            "redistribution_policy": "not_defined",
            "does_not_invent_association_quotas": True,
        }
        return deepcopy(world["continental_slot_matrix_framework"])

    def validate(self):
        errors = super().validate()
        cfg = self.save.get("world", {}).get("continental_slot_matrix_framework", {})
        if cfg and cfg.get("version") != self.VERSION:
            errors.append("wrong V122 slot matrix framework version")
        if cfg and cfg.get("max_direct_slots_per_league") != 6:
            errors.append("V122 maximum direct slots must remain six")
        if cfg and cfg.get("min_direct_slots_per_league") != 0:
            errors.append("V122 minimum direct slots must remain zero")
        return errors
