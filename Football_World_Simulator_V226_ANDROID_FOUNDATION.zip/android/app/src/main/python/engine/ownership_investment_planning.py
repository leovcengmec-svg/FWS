class OwnershipInvestmentPlanning:
    """Plans post-acquisition investment without directly changing sporting results.

    The plan is informational/execution-ready: it uses the transition-adjusted
    investment capacity, records priorities and leaves actual spending to the
    existing finance/budget layers.
    """
    VALID_PRIORITIES = ('infrastructure', 'commercial', 'youth', 'scouting', 'sporting')

    def __init__(self, save, transition_effects):
        self.save = save
        self.transition_effects = transition_effects
        self.history = save.setdefault('history', {}).setdefault('ownership_investment_plans', [])

    def create_plan(self, club_id, budget, priorities=None, season=None):
        if club_id not in self.save['world']['clubs']:
            raise ValueError('clube inexistente')
        budget = float(budget)
        if budget < 0:
            raise ValueError('orçamento inválido')
        priorities = priorities or list(self.VALID_PRIORITIES)
        unknown = [p for p in priorities if p not in self.VALID_PRIORITIES]
        if unknown:
            raise ValueError('prioridade inválida')
        capacity = self.transition_effects.capacity(club_id, budget)
        weights = {p: 1.0 for p in priorities}
        total = sum(weights.values()) or 1.0
        allocations = {p: round(capacity * weights[p] / total, 2) for p in priorities}
        # Keep rounding deterministic by assigning the residual to the first priority.
        residual = round(capacity - sum(allocations.values()), 2)
        if priorities:
            allocations[priorities[0]] = round(allocations[priorities[0]] + residual, 2)
        season = self.save['world'].get('current_year') if season is None else season
        plan = {
            'club_id': club_id,
            'season': season,
            'requested_budget': round(budget, 2),
            'capacity': capacity,
            'allocations': allocations,
            'status': 'planned',
            'integration_status': self.save['world']['clubs'][club_id].get('ownership_transition', {}).get('integration_status', 'integrated'),
        }
        self.history.append(plan.copy())
        return plan

    def capacity(self, club_id, budget):
        return self.transition_effects.capacity(club_id, budget)
