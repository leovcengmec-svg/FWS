"""V215 — Integrated World Depth seasonal gate."""
from __future__ import annotations
from copy import deepcopy
from .v211_world_regions import V211WorldRegions
from .v212_country_development import V212CountryDevelopment
from .v213_competition_ecosystems import V213CompetitionEcosystems
from .v214_club_ecosystems import V214ClubEcosystems

class V215WorldDepthIntegration:
    VERSION='V215'; CHAIN=['V211','V212','V213','V214','V215']
    def __init__(self,save): self.save=save; self.regions=V211WorldRegions(save); self.countries=V212CountryDevelopment(save); self.competitions=V213CompetitionEcosystems(save); self.clubs=V214ClubEcosystems(save)
    def run(self,season=None):
        year=int(self.save.setdefault('world',{}).get('current_year',2026) if season is None else season); h=self.save.setdefault('history',{}); cycles=h.setdefault('world_depth_cycles',[])
        prior=next((x for x in reversed(cycles) if int(x.get('season',-1))==year),None)
        if prior is not None: return dict(prior,idempotent_replay=True)
        regions=self.regions.build(year); countries=self.countries.build(year); competitions=self.competitions.build(year); clubs=self.clubs.build(year)
        row={'version':self.VERSION,'season':year,'regions':len(regions),'countries':len(countries),'competitions':len(competitions),'clubs':len(clubs),'chain':list(self.CHAIN),'player_layer_forbidden':True}
        cycles.append(row); self.save['world']['world_depth_version']=self.VERSION; self.save['world']['world_depth_status']='ready'; return deepcopy(row)
    def snapshot(self): return {'version':self.VERSION,'status':self.save.setdefault('world',{}).get('world_depth_status'),'regions':self.regions.snapshot(),'countries':self.countries.data,'competitions':self.competitions.data,'clubs':self.clubs.data}
    def validate(self): return self.regions.validate()+self.countries.validate()+self.competitions.validate()+self.clubs.validate()
