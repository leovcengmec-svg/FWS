"""V129 — Club & Association Development Engine.

Completes Block 4 with autonomous, aggregate development of clubs and
associations. No individual players or player transfers are modeled.
"""
from __future__ import annotations
from copy import deepcopy


class V129ClubAssociationDevelopment:
    VERSION = "V129"
    DEFAULTS = {
        "max_score": 100.0,
        "min_score": 1.0,
        "decay_floor": 0.25,
        "development_ceiling": 2.5,
        "relegation_penalty": 0.75,
        "continental_bonus": 0.9,
        "title_bonus": 0.6,
        "investment_weight": 0.04,
        "infrastructure_weight": 0.03,
        "association_growth_weight": 0.02,
    }

    def __init__(self, save, config=None):
        self.save = save
        self.config = {**self.DEFAULTS, **(config or {})}

    def _world(self):
        return self.save.setdefault("world", {})

    def _clubs(self):
        return self._world().setdefault("clubs", {})

    def _associations(self):
        return self._world().setdefault("associations", {})

    @staticmethod
    def _clamp(value, lo, hi):
        return max(lo, min(hi, float(value)))

    def develop_club(self, club_id, season=None, context=None):
        clubs = self._clubs()
        if club_id not in clubs:
            raise KeyError(f"unknown club: {club_id}")
        club = clubs[club_id]
        context = context or {}
        year = season or self._world().get("current_year", 2026)
        strength = float(club.get("sporting_strength", club.get("strength", 50.0)))
        infrastructure = float(club.get("infrastructure", club.get("infrastructure_score", 50.0)))
        reputation = float(club.get("reputation", 50.0))
        investment = float(context.get("investment", club.get("season_investment", 0.0)))
        position = context.get("league_position")
        league_size = max(1, int(context.get("league_size", 20)))
        continental = float(context.get("continental_success", 0.0))
        titles = float(context.get("titles", 0.0))
        relegated = bool(context.get("relegated", False))
        promoted = bool(context.get("promoted", False))

        investment_effect = max(-2.0, min(2.0, investment / 100.0)) * self.config["investment_weight"] * 100
        infrastructure_effect = (infrastructure - 50.0) * self.config["infrastructure_weight"] / 2
        performance_effect = 0.0
        if position is not None:
            performance_effect = ((league_size + 1 - int(position)) / league_size) * 2.0
        if relegated:
            performance_effect -= self.config["relegation_penalty"]
        if promoted:
            performance_effect += 0.5
        continental_effect = continental * self.config["continental_bonus"]
        title_effect = titles * self.config["title_bonus"]

        delta = investment_effect + infrastructure_effect + performance_effect + continental_effect + title_effect
        new_strength = self._clamp(strength + delta, self.config["min_score"], self.config["max_score"])
        new_infra = self._clamp(infrastructure + investment_effect * 0.35, self.config["min_score"], self.config["max_score"])
        new_rep = self._clamp(reputation + performance_effect * 0.7 + continental_effect * 0.4 + title_effect * 0.3, self.config["min_score"], self.config["max_score"])

        club["sporting_strength"] = round(new_strength, 4)
        club["infrastructure"] = round(new_infra, 4)
        club["reputation"] = round(new_rep, 4)
        club["development"] = {
            "season": year, "delta": round(delta, 4), "performance_effect": round(performance_effect, 4),
            "investment_effect": round(investment_effect, 4), "infrastructure_effect": round(infrastructure_effect, 4),
            "continental_effect": round(continental_effect, 4), "title_effect": round(title_effect, 4),
        }
        return deepcopy(club["development"])

    def develop_association(self, association_id, season=None, context=None):
        associations = self._associations()
        if association_id not in associations:
            raise KeyError(f"unknown association: {association_id}")
        assoc = associations[association_id]
        context = context or {}
        year = season or self._world().get("current_year", 2026)
        strength = float(assoc.get("sporting_strength", assoc.get("strength", 50.0)))
        infrastructure = float(assoc.get("infrastructure", 50.0))
        reputation = float(assoc.get("reputation", 50.0))
        coefficient = float(assoc.get("coefficient", assoc.get("continental_coefficient", 0.0)))
        investment = float(context.get("investment", assoc.get("season_investment", 0.0)))
        results = float(context.get("performance", 0.0))
        development = investment * self.config["association_growth_weight"] + results * 0.4 + (coefficient / 100.0)
        assoc["sporting_strength"] = round(self._clamp(strength + development, 1, 100), 4)
        assoc["infrastructure"] = round(self._clamp(infrastructure + investment * 0.15, 1, 100), 4)
        assoc["reputation"] = round(self._clamp(reputation + results * 0.5, 1, 100), 4)
        assoc["development"] = {"season": year, "delta": round(development, 4)}
        return deepcopy(assoc["development"])

    def run_season(self, season=None, club_context=None, association_context=None):
        year = season or self._world().get("current_year", 2026)
        club_context = club_context or {}
        association_context = association_context or {}
        reports = {"version": self.VERSION, "season": year, "clubs": [], "associations": []}
        for cid in sorted(self._clubs()):
            reports["clubs"].append({"club_id": cid, **self.develop_club(cid, year, club_context.get(cid, {}))})
        for aid in sorted(self._associations()):
            reports["associations"].append({"association_id": aid, **self.develop_association(aid, year, association_context.get(aid, {}))})
        history = self.save.setdefault("history", {}).setdefault("club_association_development", [])
        history.append(deepcopy(reports))
        self._world()["club_association_development"] = deepcopy(reports)
        return reports

    def validate(self):
        errors = []
        for cid, club in self._clubs().items():
            for key in ("sporting_strength", "infrastructure", "reputation"):
                if key in club and not 1 <= float(club[key]) <= 100:
                    errors.append(f"V129 {cid} {key} out of range")
        for aid, assoc in self._associations().items():
            for key in ("sporting_strength", "infrastructure", "reputation"):
                if key in assoc and not 1 <= float(assoc[key]) <= 100:
                    errors.append(f"V129 {aid} {key} out of range")
        return errors
