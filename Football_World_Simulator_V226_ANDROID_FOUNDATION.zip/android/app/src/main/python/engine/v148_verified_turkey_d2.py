from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CATALOG=ROOT/'data/global_world_catalog.json'; ASSETS=ROOT/'data/global_asset_registry.json'; AUDIT=ROOT/'data/v148_verified_turkey_restoration.json'
SOURCE='https://www.tff.org/Default.aspx?pageID=142'
TEAMS=['Boluspor','Manisa Futbol Kulübü','Bandırma Spor','İstanbulspor A.Ş.','Antalyaspor A.Ş.','Ankara Keçiörengücü','Sivasspor','Esenler Erokspor','Ümraniyespor','Mardin 1969 Spor','SMS Grup Sarıyer','Muğlaspor Kulübü','Van Spor Futbol Kulübü','Kayserispor Futbol A.Ş.','Bodrum FK','Bursaspor','Iğdır Futbol Kulübü A.Ş.','Fatih Karagümrük A.Ş.','Pendikspor Futbol A.Ş.','Batman Petrol Spor A.Ş.']
ALIASES={'Bursaspor':'TUR_D3_C2','Batman Petrol Spor A.Ş.':'TUR_D3_C1'}
def norm(s): return ''.join(ch.lower() for ch in s if ch.isalnum())
def run():
 d=json.loads(CATALOG.read_text()); a=json.loads(ASSETS.read_text()); clubs=d['clubs']; leagues=d['leagues']; lid='TUR_D2'; old=set(leagues[lid].get('club_ids',[])); new=[]
 by={norm(c['name']):cid for cid,c in clubs.items() if c.get('country_id')=='TUR'}
 for name in TEAMS:
  cid=ALIASES.get(name) or by.get(norm(name))
  if cid is None:
   cid=f'TUR_D2_C{len(clubs)+1}'; clubs[cid]={'id':cid,'name':name,'country_id':'TUR','league_id':lid,'data_status':'verified_external_import','source_version':'V148'}
  else:
   clubs[cid]['name']=name; clubs[cid]['league_id']=lid; clubs[cid]['data_status']='verified_external_import'; clubs[cid]['source_version']='V148'
  new.append(cid)
 # remove migrated clubs from any other Turkish league
 for other_id,lg in leagues.items():
  if other_id==lid: continue
  if lg.get('country_id')!='TUR': continue
  lg['club_ids']=[cid for cid in lg.get('club_ids',[]) if cid not in new]; lg['club_count']=len(lg['club_ids'])
 leagues[lid]['club_ids']=new; leagues[lid]['club_count']=len(new); leagues[lid]['data_status']='verified_external_import'; leagues[lid]['source_note']='V148 verified against TFF 2026/27 Trendyol 1. Lig official fixture/table.'
 for cid in new:
  key=f'club:{cid}:crest'; a['assets'].setdefault(key,{'id':key,'owner_id':cid,'owner_type':'club','kind':'crest','schema_version':2,'source':'Official federation/league source candidate','status':'pending_verification','uri':None,'checksum':None,'license':'verify source/license before redistribution'})
 d['version']='V148'; d['integrity']['v148_verified_turkey_d2']=True; d['integrity']['v148_verified_clubs']=len(new); d['source_policy']['v148']='Only official federation/league source accepted for V148 Turkey D2.'
 remaining=[]
 for x,l in leagues.items():
  if x in {'BRA_D2','BRA_D3','BRA_D4'}: continue
  n=len(l.get('club_ids',[]))
  if n<10: remaining.append({'league_id':x,'country_id':l.get('country_id'),'club_count':n,'level':l.get('level'),'name':l.get('name')})
 report={'version':'V148','season_reference':'2026/2027','restored_league':'TUR_D2','before':len(old),'after':len(new),'verified_clubs':len(new),'source':SOURCE,'remaining_under_10_count':len(remaining),'remaining_under_10':remaining}
 AUDIT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n'); CATALOG.write_text(json.dumps(d,ensure_ascii=False,indent=2,sort_keys=True)+'\n'); ASSETS.write_text(json.dumps(a,ensure_ascii=False,indent=2,sort_keys=True)+'\n'); print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__': run()
