import copy, random
from .match_engine import MatchEngine
from .domestic import LeagueSeason
from .continental import ContinentalAccessEngine
from .career_history import WorldHistory, NationalTeamCareer
from .promotion import PromotionRelegation
from .season_pipeline import SeasonPipeline
from .selection_development import SelectionDevelopment
from .selection_career import SelectionCareer
from .economy import ClubEconomy, SelectionEconomy
from .investor_career import InvestorCareer
from .strategic_budget import StrategicBudget
from .commercial_market import CommercialMarket
from .sporting_strength import SportingStrengthEngine
from .club_identity import ClubIdentityEngine
from .active_management import ActiveManagement
from .active_management_effects import ActiveManagementEffects
from .management_integration import ManagementIntegration
from .management_maturity import ManagementMaturity
from .management_cycle import ManagementCycle
from .strategic_decisions import StrategicDecisionEngine
from .strategic_planning import StrategicPlanningEngine
from .strategic_governance import StrategicGovernance
from .strategic_review import StrategicReviewEngine
from .strategic_action_lifecycle import StrategicActionLifecycle
from .strategic_effectiveness import StrategicEffectiveness
from .club_objectives import ClubObjectivesEngine
from .v162_qualification_integrity_audit import V162QualificationIntegrityAudit

class WorldSimulator:
    def __init__(self, save, seed=None):
        self.save=save
        self.rng=random.Random(seed)
        sim=save.get("simulation",{})
        self.engine=MatchEngine(seed,sim.get("home_advantage",.22),sim.get("max_goal_lambda",3.8))
        self.history=WorldHistory(save)
        self.national_career=NationalTeamCareer(save)
        self.selection_development=SelectionDevelopment(save, self.rng)
        self.selection_career=SelectionCareer(save, self.rng)
        self.club_economy=ClubEconomy(save)
        self.selection_economy=SelectionEconomy(save, self.rng)
        self.investor=InvestorCareer(save)
        self.strategic_budget=StrategicBudget(save, self.rng)
        self.commercial_market=CommercialMarket(save)
        self.sporting_strength=SportingStrengthEngine(self.rng, sim.get("club_strength_min",1.0), sim.get("club_strength_max",99.0))
        self.club_identity=ClubIdentityEngine()
        self.active_management=ActiveManagement(save)
        self.active_management_effects=ActiveManagementEffects(save)
        self.management_integration=ManagementIntegration(save, self.active_management_effects)
        self.management_maturity=ManagementMaturity(save)
        self.management_cycle=ManagementCycle(save)
        self.strategic_planning=StrategicPlanningEngine(save)
        self.strategic_governance=StrategicGovernance(save)
        self.strategic_review=StrategicReviewEngine(save)
        self.strategic_action_lifecycle=StrategicActionLifecycle(save)
        self.strategic_effectiveness=StrategicEffectiveness(save)
        self.club_objectives=ClubObjectivesEngine(save)
        self.national_cycle=V162QualificationIntegrityAudit(save)

    def simulate_league(self, league_id):
        league=self.save["world"]["leagues"][league_id]
        clubs=[self.save["world"]["clubs"][cid] for cid in league["club_ids"]]
        season=self.save["world"]["current_year"]
        ls=LeagueSeason(league_id,clubs,season,engine=self.engine)
        result=ls.play()
        self.save.setdefault("history",{}).setdefault("season_matches",[]).extend([m.__dict__ for m in ls.matches])
        self.save["history"].setdefault("latest_tables",{})[league_id]=result
        champion=result[0]["club_id"]
        self.history.record_league_champion(league_id,season,champion)
        self._evolve_clubs(clubs,result)
        return result

    def simulate_all_leagues(self):
        # A catalog can legitimately contain a configured league whose club
        # pack is not populated. Never invent clubs to make it playable and
        # never call the match engine with an empty field. Such a league stays
        # configured for future access/data completion and is skipped this cycle.
        results = {}
        skipped = []
        inactive = []
        for lid, league in self.save["world"]["leagues"].items():
            # Brazil keeps legacy D1-D4 aliases for backward compatibility, but
            # the active sporting structures are BRA-BR-1..6.  Deprecated aliases
            # must never appear as "empty leagues" in runtime diagnostics.
            canonical_id = league.get("canonical_competition_id")
            if canonical_id and canonical_id != lid:
                inactive.append({"league_id": lid, "reason": "canonical_alias",
                                 "canonical_league_id": canonical_id})
                continue

            # The national Brazilian Access competition is dynamically selected
            # from current state-championship results.  Before those results exist
            # it is a configured future competition, not an empty league that needs
            # invented clubs.
            if lid == "BRA-ACCESS" and not league.get("club_ids"):
                inactive.append({"league_id": lid, "reason": "dynamic_access_awaiting_state_results"})
                continue

            club_ids = [cid for cid in league.get("club_ids", []) if cid in self.save["world"]["clubs"]]
            if len(club_ids) < 2:
                skipped.append(lid)
                continue
            results[lid] = self.simulate_league(lid)
        self.save.setdefault("history", {}).setdefault("skipped_leagues", []).append({
            "season": self.save["world"].get("current_year"),
            "leagues": skipped,
            "reason": "insufficient_club_pack",
        })
        self.save.setdefault("history", {}).setdefault("inactive_leagues", []).append({
            "season": self.save["world"].get("current_year"),
            "leagues": inactive,
        })
        return results

    def simulate_full_season(self):
        """Connected domestic + cup + continental pipeline."""
        return SeasonPipeline(self.save, self).run()

    def advance_season(self):
        year=self.save["world"]["current_year"]
        league_results=self.simulate_all_leagues()
        for country_id in self.save['world'].get('countries',{}):
            PromotionRelegation(self.save.get('simulation',{}).get('promotion_relegation_places',4)).apply_country(self.save,country_id)
        economy_reports=self.club_economy.settle_season(league_results=league_results)
        self.investor.settle_owned_club_returns(economy_reports)
        self.selection_economy.settle_season()
        self._quarterly_events(year)
        self.save["history"].setdefault("seasons",{})[str(year)]={
            "league_champions":{lid:rows[0]["club_id"] for lid,rows in league_results.items()},
            "club_count":len(self.save["world"]["clubs"])
        }
        self.save["world"]["current_year"]=year+1
        self.save["world"]["current_round"]=0
        self._advance_national_teams(year)
        self.national_cycle.advance_cycle(year, seed=year)
        return league_results

    def _advance_national_teams(self,year):
        for tid in self.save["world"].get("national_teams",{}): self.selection_development.cycle(tid)
        self.save.setdefault("history",{}).setdefault("national_team_development_seasons",{})[str(year)]={tid:{"strength":round(t.get("strength",0),2),"infrastructure":round(self.selection_development.infrastructure_score(t),2)} for tid,t in self.save["world"].get("national_teams",{}).items()}
        self.selection_career.generate_invitations()

    def _evolve_clubs(self,clubs,table):
        rank={row["club_id"]:i for i,row in enumerate(table)}
        n=max(1,len(table))
        for c in clubs:
            r=rank[c["id"]]
            performance=(n-1-r)/(n-1) if n>1 else 1
            self.sporting_strength.update_after_season(c, r + 1, n, appearances=1)
            self.club_objectives.generate(c["id"], self.save["world"]["current_year"])
            self.club_objectives.evaluate(c["id"], {"rank": r + 1}, self.save["world"]["current_year"])
            achievement = 100.0 if r == 0 else max(0.0, 100.0 - (r / max(1, n - 1)) * 100.0)
            self.club_identity.update(c, c["sporting_strength"], c.get("prestige", 50), achievement, self.save["world"]["current_year"])
            if c.get("management_spending"):
                self.active_management_effects.apply_season(c["id"], self.save["world"]["current_year"])
                self.management_integration.apply(c["id"], self.save["world"]["current_year"])
                self.management_maturity.evaluate(c["id"], self.save["world"]["current_year"])
                self.management_cycle.evaluate(c["id"], self.save["world"]["current_year"])
                self.strategic_decisions.evaluate(c["id"], self.save["world"]["current_year"])
                self.strategic_planning.review(c["id"], self.save["world"]["current_year"])
                self.strategic_governance.evaluate(c["id"], self.save["world"]["current_year"])
                self.strategic_review.review(c["id"], c.get("strategic_governance"), self.save["world"]["current_year"])
                actions = c.get("strategic_review_actions", [])
                if actions:
                    idx = len(actions) - 1
                    self.strategic_action_lifecycle.initialize(c["id"], idx, self.save["world"]["current_year"])
                    self.strategic_action_lifecycle.advance(c["id"], self.save["world"]["current_year"])
                    self.strategic_effectiveness.evaluate(c["id"], self.save["world"]["current_year"])

    def _quarterly_events(self,year):
        clubs=list(self.save["world"]["clubs"].values())
        if not clubs:return
        for q in range(1,5):
            # weighted by club size/exposure, but every club keeps a non-zero chance
            weights=[0.5+max(1,c.get("prestige",50))/100 for c in clubs]
            c=self.rng.choices(clubs,weights=weights,k=1)[0]
            roll=self.rng.random()
            if roll < .35:
                impact=-self.rng.uniform(1,4); kind="financial_crisis"
            elif roll < .70:
                impact=self.rng.uniform(0.5,2.5); kind="investment_success"
            else:
                impact=self.rng.uniform(-1.5,1.5); kind="administrative_event"
            c["cash"]=max(0,c.get("cash",10)+impact)
            self.save.setdefault("history",{}).setdefault("events",[]).append({
                "season":year,"quarter":q,"club_id":c["id"],"type":kind,"impact":round(impact,2)
            })
