"""V85: deterministic importer for 20 new country league/club packs."""
import copy,json
from pathlib import Path
class V85LeagueClubImporter:
    REQUIRED_LEAGUE_KEYS={"id","country_id","level","name","data_status"}
    REQUIRED_CLUB_KEYS={"id","country_id","league_id","name","data_status"}
    def __init__(self,catalog,completeness,manifest): self.catalog=catalog; self.completeness=completeness; self.manifest=manifest
    def _validate_tier_policy(self,p):
        if p.get("status")=="reviewed_no_national_league":
            return [] if p.get("target_divisions")==0 and not p.get("leagues") else [f"{p['country_id']}: no-national-league pack must contain zero leagues"]
        levels=sorted(x.get("level") for x in p.get("leagues",[])); real=int(p.get("real_levels_checked",len(levels))); g=p.get("league_system_group")
        if g=="small" and levels!=[1]: return [f"{p['country_id']}: small league system must contain exactly division 1"]
        if g=="intermediate" and real>=2 and levels!=[1,2]: return [f"{p['country_id']}: intermediate league system must contain divisions 1 and 2"]
        if g in ("top_confederation","top_five"):
            if real<=2 and levels!=list(range(1,real+1)): return [f"{p['country_id']}: top group must preserve all real levels"]
            if real>=3 and not (3<=len(levels)<=5): return [f"{p['country_id']}: top group must contain 3-5 divisions"]
        return []
    def validate(self):
        errors=[]
        for p in self.manifest.get("packs",[]):
            errors+=self._validate_tier_policy(p); cid=p["country_id"]; lids=set()
            for l in p.get("leagues",[]):
                miss=self.REQUIRED_LEAGUE_KEYS-set(l)
                if miss: errors.append(f"{cid}: league missing {sorted(miss)}")
                if l["id"] in self.catalog["leagues"]: errors.append(f"{cid}: duplicate league id {l['id']}")
                lids.add(l["id"])
            for c in p.get("clubs",[]):
                miss=self.REQUIRED_CLUB_KEYS-set(c)
                if miss: errors.append(f"{cid}: club missing {sorted(miss)}")
                if c["id"] in self.catalog["clubs"]: errors.append(f"{cid}: duplicate club id {c['id']}")
                if c["league_id"] not in lids and c["league_id"] not in self.catalog["leagues"]: errors.append(f"{cid}: unknown league {c['league_id']}")
        return errors
    def apply(self):
        e=self.validate()
        if e: raise ValueError("; ".join(e))
        applied=[]
        for p in self.manifest.get("packs",[]):
            if p.get("status") not in ("verified","partial"): continue
            cid=p["country_id"]
            for l in p.get("leagues",[]): self.catalog["leagues"][l["id"]]=copy.deepcopy(l)
            for c in p.get("clubs",[]): self.catalog["clubs"][c["id"]]=copy.deepcopy(c)
            self.catalog["associations"][cid]["league_pack_status"]="verified"; self.catalog["associations"][cid]["club_pack_status"]="verified" if p.get("status")=="verified" else "partial"; applied.append(cid)
        self.catalog["version"]="V85"; self.completeness["version"]="V85"; return applied
