"""V209 — Persistent legacy of the user's investor and selection careers."""
from __future__ import annotations
from copy import deepcopy

class V209CareerLegacy:
    VERSION='V209'
    def __init__(self,save):
        self.save=save; self.history=save.setdefault('history',{})
        self.legacy=self.history.setdefault('career_legacy_v209',{'seasons':[],'selection':{},'investor':{}})

    def close_season(self,season=None):
        year=int(self.save.setdefault('world',{}).get('current_year',2026) if season is None else season)
        careers=self.save.setdefault('careers',{})
        sel=careers.get('selection',{}); inv=careers.get('investor',{})
        row={'version':self.VERSION,'season':year,'selection':{'team_id':sel.get('current_team_id'),'prestige':round(float(sel.get('manager_prestige',0)),3),'tier':self._tier(sel.get('manager_prestige',0))},'investor':{'cash':round(float(inv.get('cash',0)),2),'owned_clubs':list(inv.get('owned_clubs',[])),'transactions':len(inv.get('transactions',[]))}}
        existing=[x for x in self.legacy['seasons'] if int(x.get('season',-1))!=year]; existing.append(row); existing.sort(key=lambda x:x['season']); self.legacy['seasons']=existing
        self.legacy['selection']={'best_prestige':max([float(x['selection']['prestige']) for x in existing] or [0]),'seasons':len(existing)}
        self.legacy['investor']={'max_owned_clubs':max([len(x['investor']['owned_clubs']) for x in existing] or [0]),'max_transactions':max([int(x['investor']['transactions']) for x in existing] or [0])}
        self.history['career_legacy_v209_version']=self.VERSION; return deepcopy(row)

    @staticmethod
    def _tier(p):
        p=float(p); return 'EMERGING' if p<20 else 'REGIONAL' if p<40 else 'INTERNATIONAL' if p<60 else 'ELITE' if p<80 else 'WORLD'
    def snapshot(self): return deepcopy(self.legacy)
    def validate(self):
        years=[int(x.get('season')) for x in self.legacy.get('seasons',[])]
        return [] if years==sorted(set(years)) else ['V209 duplicate or unordered career season']
