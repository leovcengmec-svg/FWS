"""V113 — Continental Entry Qualification.

Executes the V112 qualification order before the league phase:
1) coefficient-driven direct places, capped at six per league/association;
2) remaining places are filled through existing preliminary rounds;
3) only the resulting field enters the league phase.

V113 deliberately does not invent a league-phase match schedule. That is a
separate format decision and remains configurable for a later version.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib

from .match_engine import MatchEngine
from .v112_continental_competition_framework import V112ContinentalCompetitionFramework


class V113ContinentalEntryQualification(V112ContinentalCompetitionFramework):
    VERSION = "V113"

    def __init__(self, save):
        super().__init__(save)

    @staticmethod
    def _club_row(row):
        if isinstance(row, dict):
            return row.get("club_id"), row
        return row, {"club_id": row}

    @staticmethod
    def _rank_table(table):
        def key(row):
            return (
                -int(row.get("position", 10**9)),
                -int(row.get("points", 0)),
                -int(row.get("goal_difference", row.get("gd", 0))),
                -int(row.get("goals_for", row.get("gf", 0))),
                str(row.get("club_id", "")),
            )
        # When an explicit position exists, lower position must rank first.
        return sorted(table, key=lambda r: (
            int(r.get("position", 10**9)),
            -int(r.get("points", 0)),
            -int(r.get("goal_difference", r.get("gd", 0))),
            -int(r.get("goals_for", r.get("gf", 0))),
            str(r.get("club_id", "")),
        ))

    @staticmethod
    def _league_sort(leagues):
        return sorted(
            leagues,
            key=lambda l: (
                -float(l.get("coefficient", 1.0)),
                str(l.get("id", "")),
            ),
        )

    @staticmethod
    def _preliminary_candidates(leagues, tables, allocations, needed, rounds, assigned):
        """Take clubs immediately behind direct places, never fabricate clubs."""
        if needed <= 0:
            return []

        by_league = {l["id"]: l for l in leagues}
        # Use the smallest deterministic pool that can supply the requested
        # winners. One preliminary round already converts two entrants into one
        # winner; additional configured rounds are a maximum depth, not a demand
        # to manufacture a 2**N-sized field. This prevents large competitions
        # from becoming artificially impossible when the world has fewer clubs.
        target_pool = max(needed, needed * 2)

        candidates = []
        for alloc in allocations:
            lid = alloc["league_id"]
            table = tables.get(lid, [])
            direct_n = int(alloc["direct_slots"])
            for row in table[direct_n:]:
                club_id = row.get("club_id")
                if not club_id or club_id in assigned:
                    continue
                candidates.append({
                    "club_id": club_id,
                    "league_id": lid,
                    "source": "preliminary",
                    "position": int(row.get("position", len(candidates) + 1)),
                    "league_coefficient": float(by_league.get(lid, {}).get("coefficient", 1.0)),
                })
                if len(candidates) >= target_pool:
                    return candidates
        return candidates

    @staticmethod
    def _play_preliminary(entries, slots, competition_id, season, seed, rounds):
        """Deterministic single-leg preliminary rounds with byes when required."""
        if slots <= 0 or not entries:
            return [], []

        current = list(entries)
        matches = []
        total_rounds = max(0, int(rounds))
        round_no = 1

        while len(current) > slots and round_no <= total_rounds:
            winners = []
            # Pair clubs in stable order. If odd, the last club receives a bye.
            pair_limit = len(current) - (len(current) % 2)
            for i in range(0, pair_limit, 2):
                home = current[i]
                away = current[i + 1]
                match_seed = int(seed) + round_no * 1009 + i
                engine = MatchEngine(match_seed)
                home_club = {
                    "id": home["club_id"],
                    "attack": max(1.0, min(99.0, home.get("league_coefficient", 50.0))),
                    "defense": max(1.0, min(99.0, home.get("league_coefficient", 50.0))),
                    "prestige": max(1.0, min(99.0, home.get("league_coefficient", 50.0))),
                }
                away_club = {
                    "id": away["club_id"],
                    "attack": max(1.0, min(99.0, away.get("league_coefficient", 50.0))),
                    "defense": max(1.0, min(99.0, away.get("league_coefficient", 50.0))),
                    "prestige": max(1.0, min(99.0, away.get("league_coefficient", 50.0))),
                }
                result = engine.play(competition_id, season, round_no, home_club, away_club)
                if result.home_goals > result.away_goals:
                    winner = home
                elif result.away_goals > result.home_goals:
                    winner = away
                else:
                    digest = hashlib.sha256(
                        f"{seed}:{competition_id}:{season}:{round_no}:{home['club_id']}:{away['club_id']}".encode()
                    ).digest()
                    winner = home if digest[0] % 2 == 0 else away
                winners.append(winner)
                matches.append({
                    "competition_id": competition_id,
                    "season": season,
                    "round_no": round_no,
                    "home_id": home["club_id"],
                    "away_id": away["club_id"],
                    "home_goals": result.home_goals,
                    "away_goals": result.away_goals,
                    "winner_id": winner["club_id"],
                })
            if len(current) % 2:
                winners.append(current[-1])
            current = winners
            round_no += 1

        # If the configured number of rounds cannot reduce to the target, do
        # not invent additional rounds. The caller records a partial field.
        return current[:max(slots, 0)], matches

    def build_entry_field(
        self,
        competition,
        leagues,
        tables,
        *,
        season=2026,
        seed=113,
        already_assigned=None,
    ):
        """Build direct + preliminary qualifiers for one competition.

        Returns a deterministic qualification record. Existing cup-winner or
        special-access rules are intentionally not replaced here; they can be
        layered later without changing the V112 order.
        """
        already_assigned = set(already_assigned or set())
        size = int(competition.get("size", competition.get("default_size", 0)))
        conf = competition.get("confederation")

        eligible = [
            l for l in leagues
            if (not conf or l.get("confederation") == conf)
        ]
        eligible = self._league_sort(eligible)

        allocations = self.allocate_direct_places(size, eligible, max_direct=6)

        direct = []
        direct_ids = set(already_assigned)
        for alloc in allocations:
            lid = alloc["league_id"]
            table = self._rank_table(tables.get(lid, []))
            for row in table[:int(alloc["direct_slots"])]:
                club_id = row.get("club_id")
                if not club_id or club_id in direct_ids:
                    continue
                direct.append({
                    "club_id": club_id,
                    "league_id": lid,
                    "source": "direct",
                    "position": int(row.get("position", len(direct) + 1)),
                })
                direct_ids.add(club_id)
                if len(direct) >= size:
                    break
            if len(direct) >= size:
                break

        needed = max(0, size - len(direct))
        qualifying_rounds = int(
            competition.get(
                "qualifying_rounds",
                self.save.get("continental", {}).get("qualifying_rounds", 0),
            )
        )

        prelim_candidates = self._preliminary_candidates(
            eligible, tables, allocations, needed, qualifying_rounds, direct_ids
        )
        prelim_winners, prelim_matches = self._play_preliminary(
            prelim_candidates,
            needed,
            competition.get("id", "CONTINENTAL"),
            int(season),
            int(seed),
            qualifying_rounds,
        )

        entries = direct + [
            {
                "club_id": x["club_id"],
                "league_id": x["league_id"],
                "source": "preliminary",
                "position": x.get("position"),
            }
            for x in prelim_winners
            if x["club_id"] not in direct_ids
        ]
        entries = entries[:size]

        return {
            "version": self.VERSION,
            "competition_id": competition.get("id"),
            "season": int(season),
            "competition_size": size,
            "direct_slots_total": len(direct),
            "preliminary_slots_needed": needed,
            "preliminary_candidates": len(prelim_candidates),
            "preliminary_winners": len(prelim_winners),
            "entry_count": len(entries),
            "field_complete": len(entries) == size,
            "direct_allocations": deepcopy(allocations),
            "entries": deepcopy(entries),
            "preliminary_matches": deepcopy(prelim_matches),
            "qualification_order": [
                "direct_entry",
                "entry_preliminary",
                "league_phase",
            ],
            "league_phase_ready": len(entries) == size,
        }

    def apply_entry_qualification(
        self,
        competitions,
        leagues,
        tables,
        *,
        season=2026,
        seed=113,
    ):
        """Apply V113 to a set of competitions without mutating the catalog."""
        assigned_by_conf = {}
        results = {}

        for raw in competitions:
            comp = dict(raw)
            cid = comp.get("id")
            conf = comp.get("confederation")
            assigned = assigned_by_conf.setdefault(conf, set())
            result = self.build_entry_field(
                comp,
                leagues,
                tables,
                season=season,
                seed=int(seed) + len(results) * 7919,
                already_assigned=assigned,
            )
            results[cid] = result
            assigned.update(x["club_id"] for x in result["entries"])

        world = self.save.setdefault("world", {})
        world["continental_entry_qualification"] = {
            "version": self.VERSION,
            "season": int(season),
            "seed": int(seed),
            "competitions": deepcopy(results),
        }
        return deepcopy(world["continental_entry_qualification"])

    def apply(self):
        # Preserve V112 registry and add only the executable qualification layer.
        result = super().apply()
        world = self.save.setdefault("world", {})
        world["continental_entry_qualification_framework"] = {
            "version": self.VERSION,
            "base_version": "V112",
            "stages": [
                "direct_entry",
                "entry_preliminary",
                "league_phase",
            ],
            "direct_minimum_per_league": 0,
            "direct_maximum_per_league": 6,
            "no_fabricated_clubs": True,
            "league_phase_is_not_executed_here": True,
        }
        self.save.setdefault("continental", {})["entry_qualification_version"] = self.VERSION
        return deepcopy(world["continental_entry_qualification_framework"])

    def validate(self):
        errors = super().validate()
        world = self.save.get("world", {})
        fw = world.get("continental_entry_qualification_framework", {})
        if fw and fw.get("version") != self.VERSION:
            errors.append("wrong V113 entry qualification framework version")
        execution = world.get("continental_entry_qualification")
        if execution:
            if execution.get("version") != self.VERSION:
                errors.append("wrong V113 entry qualification version")
            for cid, row in execution.get("competitions", {}).items():
                if row.get("entry_count", 0) > row.get("competition_size", 0):
                    errors.append(f"{cid} entry field exceeds competition size")
                if row.get("direct_slots_total", 0) > 6:
                    errors.append(f"{cid} direct slots exceed six")
                if row.get("preliminary_winners", 0) > row.get("preliminary_slots_needed", 0):
                    errors.append(f"{cid} preliminary winners exceed required slots")
        return errors
