from .group_stage import GroupStage

class LeaguePhase:
    """Single-table league phase where each club plays a configurable number of opponents."""
    def __init__(self, competition_id, clubs, engine, season, matches_per_club=8):
        self.id=competition_id; self.clubs=clubs; self.engine=engine; self.season=season
        self.matches_per_club=matches_per_club
        self.table={c["id"]:{"club_id":c["id"],"played":0,"wins":0,"draws":0,"losses":0,
                             "gf":0,"ga":0,"gd":0,"points":0} for c in clubs}
        self.matches=[]

    def play(self):
        n=len(self.clubs)
        # deterministic cyclic opponent selection, avoiding duplicate pairings
        pairs=set()
        for i,c in enumerate(self.clubs):
            made=0
            for step in range(1,n):
                j=(i+step)%n
                key=tuple(sorted((i,j)))
                if key in pairs: continue
                pairs.add(key)
                home,away=(c,self.clubs[j]) if (i+j)%2==0 else (self.clubs[j],c)
                r=self.engine.play(self.id,self.season,len(self.matches)+1,home,away)
                self.matches.append(r.__dict__)
                self._apply(r); made+=1
                if made>=self.matches_per_club: break
        return sorted(self.table.values(),key=lambda x:(-x["points"],-x["gd"],-x["gf"],x["club_id"]))

    def _apply(self,r):
        h=self.table[r.home_id]; a=self.table[r.away_id]
        h["played"]+=1;a["played"]+=1
        h["gf"]+=r.home_goals;h["ga"]+=r.away_goals
        a["gf"]+=r.away_goals;a["ga"]+=r.home_goals
        if r.home_goals>r.away_goals:h["wins"]+=1;h["points"]+=3;a["losses"]+=1
        elif r.home_goals<r.away_goals:a["wins"]+=1;a["points"]+=3;h["losses"]+=1
        else:h["draws"]+=1;a["draws"]+=1;h["points"]+=1;a["points"]+=1
        h["gd"]=h["gf"]-h["ga"];a["gd"]=a["gf"]-a["ga"]
