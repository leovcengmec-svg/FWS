"""V103 — Global Competition Calendar & Orchestration.

Creates one deterministic season calendar that links the existing domestic,
continental and proprietary world-club layers without replacing their engines.
It is an orchestration layer only: it does not invent clubs, competitions or
individual players.
"""
from __future__ import annotations
from copy import deepcopy
from .v102_global_club_world import V102GlobalClubWorld


class V103GlobalCalendar(V102GlobalClubWorld):
    VERSION = "V103"

    def build_global_calendar(self, season=None, super_world_years=4):
        world = self.save.setdefault("world", {})
        year = int(season if season is not None else world.get("current_year", 2026))
        years = int(super_world_years)
        if years <= 0:
            raise ValueError("super_world_years must be positive")

        # The calendar is deliberately declarative. Execution remains owned by
        # V100/V101/V102 and is therefore not duplicated here.
        events = [
            {"id": "DOMESTIC_SEASON", "phase": "domestic", "frequency": "annual", "order": 1},
            {"id": "CONTINENTAL_SEASON", "phase": "continental", "frequency": "annual", "order": 2},
            {"id": self.INTERCONTINENTAL_ID, "phase": "world_club", "frequency": "annual", "order": 3},
        ]
        super_world = (year % years == 0)
        if super_world:
            events.append({"id": self.SUPER_WORLD_ID, "phase": "world_club", "frequency": f"every_{years}_years", "order": 4})

        calendar = {
            "version": self.VERSION,
            "season": year,
            "super_world_years": years,
            "is_super_world_year": super_world,
            "events": events,
            "dependency_chain": [
                "DOMESTIC_SEASON",
                "CONTINENTAL_SEASON",
                self.INTERCONTINENTAL_ID,
            ] + ([self.SUPER_WORLD_ID] if super_world else []),
        }
        world["global_calendar"] = calendar
        world.setdefault("calendar_history", []).append(deepcopy(calendar))
        return deepcopy(calendar)

    def validate(self):
        errors = super().validate()
        cal = self.save.get("world", {}).get("global_calendar")
        if not cal:
            return errors
        if cal.get("version") != self.VERSION:
            errors.append("wrong global calendar version")
        events = cal.get("events", [])
        ids = [e.get("id") for e in events]
        if ids[:3] != ["DOMESTIC_SEASON", "CONTINENTAL_SEASON", self.INTERCONTINENTAL_ID]:
            errors.append("global calendar dependency order invalid")
        if cal.get("is_super_world_year") and self.SUPER_WORLD_ID not in ids:
            errors.append("super world event missing on quadrennial season")
        if not cal.get("is_super_world_year") and self.SUPER_WORLD_ID in ids:
            errors.append("super world event scheduled outside quadrennial season")
        if len(ids) != len(set(ids)):
            errors.append("duplicate global calendar event")
        return errors
