import json
from pathlib import Path
from .world_bootstrap import WorldBootstrap
from .world_catalog import WorldCatalog
from .world_asset_catalog import WorldAssetCatalog
from .v140_domestic_pyramid_rules import apply_catalog_policy

def load_seed(path):
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    save={
      "save_version":8,
      "world":{"start_year":2026,"current_year":2026,"current_round":0,
        "clubs":data["clubs"],"national_teams":data["national_teams"],
        "competitions":{},"leagues":data["leagues"],"countries":{c["id"]:c for c in data["countries"]}},
      "careers":{"club_control":[],"national_team_career":{"current_team_id":None,"history":[]}},
      "history":{"seasons":{},"season_matches":[],"league_champions":{},
        "continental_champions":{},"world_champions":[],"national_team_results":{},
        "club_rankings":{},"national_rankings":{},"events":[],"latest_tables":{}}
    }
    defaults_path = Path(path).resolve().parent.parent / "config" / "world_defaults.json"
    if defaults_path.exists():
        defaults=json.loads(defaults_path.read_text(encoding="utf-8"))
        save.setdefault("simulation", defaults.get("simulation", {}))
        save.setdefault("continental", defaults.get("continental", {}))
        save.setdefault("coefficients", defaults.get("coefficients", {}))
        save.setdefault("national", defaults.get("national", {}))
    WorldBootstrap(save).prepare()
    return save


def load_global_catalog(path):
    """Load V72 global catalog without mutating the active simulation seed."""
    return WorldCatalog.from_file(path)


def load_global_asset_catalog(path):
    """Load V72 asset catalog without mutating the active simulation seed."""
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    return WorldAssetCatalog(data.get("assets", {}))


def load_global_simulation(path):
    """Build a complete playable save from the canonical 211-association catalog.

    This is intentionally separate from ``load_seed``: the historical seed is a
    compact compatibility fixture, while the V133 world simulation requires the
    full canonical global catalog. No clubs, leagues or national teams are
    invented; all entities come from the verified catalog.
    """
    catalog = WorldCatalog.from_file(path)
    catalog.catalog = apply_catalog_policy(catalog.catalog)
    catalog.associations = catalog.catalog.get("associations", {})
    catalog.national_teams = catalog.catalog.get("national_teams", {})
    catalog.leagues = catalog.catalog.get("leagues", {})
    catalog.clubs = catalog.catalog.get("clubs", {})
    catalog.competitions = catalog.catalog.get("competitions", {})
    errors = catalog.validate()
    if errors:
        raise ValueError("Global catalog invalid: " + "; ".join(errors))

    import copy
    world = {
        "start_year": 2026,
        "current_year": 2026,
        "current_round": 0,
        "clubs": copy.deepcopy(catalog.clubs),
        "national_teams": {
            str(team.get("id", association_id)): {
                **copy.deepcopy(team),
                "association_id": team.get("association_id", association_id),
                "country_id": team.get("country_id", association_id),
            }
            for association_id, team in catalog.national_teams.items()
        },
        "competitions": copy.deepcopy(catalog.competitions),
        "leagues": copy.deepcopy(catalog.leagues),
        "countries": copy.deepcopy(catalog.associations),
        "associations": copy.deepcopy(catalog.associations),
        # V149 persistent final-division FIFO queues are part of the playable world,
        # not just catalog metadata, so integrity/promotion engines can preserve them.
        "final_division_waiting_queues": copy.deepcopy(catalog.catalog.get("final_division_waiting_queues", {})),
    }
    # Canonical catalog stores league membership on clubs; the playable world
    # stores the reverse index on each league as well.
    for league in world["leagues"].values():
        league["club_ids"] = []
    # BRA-STATE-ONLY is a registry bucket, not a playable league. Its 594
    # entries are real-club records awaiting verified annual state participation.
    # Treating the bucket as a round-robin league generated hundreds of thousands
    # of fictitious fixtures (and a multi-hundred-MB save) in a single season.
    # Keep every club in the world/catalog, but never schedule this registry bucket.
    registry_only_leagues = {"BRA-STATE-ONLY"}
    for club_id, club in world["clubs"].items():
        league_id = club.get("league_id")
        if league_id in registry_only_leagues:
            # A registry entry is not a league registration. Preserve the entity
            # and its registry metadata, but remove the synthetic league assignment
            # so world-integrity checks and schedulers agree it is unassigned.
            club["league_id"] = None
            club.setdefault("state_roster_status", "registry_or_annual_state_result_required")
            continue
        if league_id in world["leagues"]:
            world["leagues"][league_id]["club_ids"].append(club_id)
    for league_id in registry_only_leagues:
        if league_id in world["leagues"]:
            world["leagues"][league_id]["club_ids"] = []
            world["leagues"][league_id]["format"] = "registry_only"
            world["leagues"][league_id]["population_status"] = "not_scheduled"

    save = {
        "save_version": 8,
        "world": world,
        "careers": {
            "club_control": [],
            "national_team_career": {"current_team_id": None, "history": []},
        },
        "history": {
            "seasons": {}, "season_matches": [], "league_champions": {},
            "continental_champions": {}, "world_champions": [],
            "national_team_results": {}, "club_rankings": {},
            "national_rankings": {}, "events": [], "latest_tables": {},
        },
    }
    defaults_path = Path(path).resolve().parent.parent / "config" / "world_defaults.json"
    if defaults_path.exists():
        defaults = json.loads(defaults_path.read_text(encoding="utf-8"))
        save.setdefault("simulation", defaults.get("simulation", {}))
        save.setdefault("continental", defaults.get("continental", {}))
        save.setdefault("coefficients", defaults.get("coefficients", {}))
        save.setdefault("national", defaults.get("national", {}))
    WorldBootstrap(save).prepare()
    return save
