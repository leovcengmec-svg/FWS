"""Stable visual-asset registry for countries, clubs and national teams."""
from copy import deepcopy

class WorldAssetRegistry:
    SCHEMA_VERSION = 1

    def __init__(self, save):
        self.world = save.setdefault("world", {})
        self.assets = self.world.setdefault("assets", {})

    def register(self, owner_type, owner_id, kind, uri, checksum=None, source=None):
        if owner_type not in {"country", "club", "national_team", "league"}:
            raise ValueError("unsupported asset owner type")
        if kind not in {"logo", "flag", "banner", "icon"}:
            raise ValueError("unsupported asset kind")
        if not uri:
            raise ValueError("asset uri is required")
        key = f"{owner_type}:{owner_id}:{kind}"
        self.assets[key] = {
            "id": key, "owner_type": owner_type, "owner_id": owner_id,
            "kind": kind, "uri": uri, "checksum": checksum,
            "source": source, "schema_version": self.SCHEMA_VERSION,
        }
        return deepcopy(self.assets[key])

    def get(self, owner_type, owner_id, kind):
        return self.assets.get(f"{owner_type}:{owner_id}:{kind}")

    def validate(self):
        errors = []
        for key, asset in self.assets.items():
            if asset.get("id") != key:
                errors.append(f"asset key/id mismatch: {key}")
            if not asset.get("uri"):
                errors.append(f"asset {key} missing uri")
        return errors

    def summary(self):
        by_kind = {}
        for asset in self.assets.values():
            by_kind[asset["kind"]] = by_kind.get(asset["kind"], 0) + 1
        return {"total": len(self.assets), "by_kind": by_kind}
