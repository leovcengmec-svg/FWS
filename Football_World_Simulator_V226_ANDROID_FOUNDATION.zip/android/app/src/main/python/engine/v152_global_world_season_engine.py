"""V152 — Global World Season Engine.

V152 is the annual world-season boundary above V151. It keeps the approved
competition engines authoritative and composes them into one calendar-aware
season:

    V151 domestic + continental
        -> V119 intercontinental annual competition
        -> V157 Super World club calendar (2029/2033/2037..., when due)
        -> V158 national-team selection calendar
        -> global calendar / conflict audit
        -> one year advance

No new clubs, players, squads or player transfers are invented. When an
approved competition cannot close because its configured access field is
mathematically under-supplied by the current catalog, V152 records an explicit
configuration_pending result instead of fabricating entrants.
"""
from __future__ import annotations

import pickle

from copy import deepcopy
from datetime import date, timedelta

from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity
from .v151_global_competition_integration import V151GlobalCompetitionIntegration
from .v119_intercontinental_club_format import V119IntercontinentalClubFormat
from .v157_club_calendar import V157ClubCalendar
from .v162_qualification_integrity_audit import V162QualificationIntegrityAudit


class V152GlobalWorldSeasonEngine:
    VERSION = "V152"
    SCHEMA = 1
    SUPER_WORLD_CYCLE_YEARS = 4

    def __init__(self, save, seed=152):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("global_world_seasons", [])

    def _assert_no_player_layer(self):
        if "players" in self._world():
            raise ValueError("V152 must not contain an individual player layer")
        if "player_transfers" in self._history():
            raise ValueError("V152 must not contain a player transfer history")

    def _ensure_catalog_adapter(self):
        """Give legacy V119/V125 engines the canonical catalog view they expect.

        The playable global save intentionally keeps the catalog fields under
        ``world``. Older engines accept the same data through ``save['catalog']``.
        This adapter is a view, not a second source of truth.
        """
        world = self._world()
        if isinstance(self.save.get("catalog"), dict):
            return
        self.save["catalog"] = {
            "clubs": world.get("clubs", {}),
            "leagues": world.get("leagues", {}),
            "competitions": world.get("competitions", {}),
            "associations": world.get("associations", world.get("countries", {})),
            "national_teams": world.get("national_teams", {}),
        }

    def _build_calendar(self, season, national_result, intercontinental, super_world):
        """Build a declarative annual calendar and audit hard same-day conflicts.

        Existing match engines remain authoritative for results. The calendar
        records the annual dependency order and allocates deterministic event
        windows; it does not rewrite match results.
        """
        start = date(season, 8, 1)
        events = []
        cursor = start

        def add_event(event_id, phase, status, match_count=0, duration_days=1, reason=None):
            nonlocal cursor
            row = {
                "id": event_id,
                "phase": phase,
                "status": status,
                "start_date": cursor.isoformat(),
                "end_date": (cursor + timedelta(days=max(0, duration_days - 1))).isoformat(),
                "match_count": int(match_count),
            }
            if reason:
                row["reason"] = reason
            events.append(row)
            cursor += timedelta(days=max(1, duration_days))
            return row

        domestic = self._history().get("global_competition_cycles", [])
        last_v151 = next((r for r in reversed(domestic) if r.get("version") == "V151" and int(r.get("season", -1)) == season), None)
        domestic_matches = int((last_v151 or {}).get("continental", {}).get("matches_simulated", 0))
        add_event("DOMESTIC_AND_CONTINENTAL", "club", "completed", domestic_matches,
                  max(1, min(300, domestic_matches // 50 + 1)))

        ic_matches = self._match_count(intercontinental)
        add_event(
            "INTERCONTINENTAL_CLUB",
            "world_club",
            intercontinental.get("status", "unknown"),
            ic_matches,
            max(1, min(45, ic_matches // 3 + 1)),
            intercontinental.get("reason"),
        )

        sw_matches = self._match_count(super_world)
        add_event(
            "SUPER_WORLD_CLUB",
            "world_club",
            "not_due" if super_world is None else super_world.get("status", "unknown"),
            sw_matches,
            max(1, min(120, sw_matches // 6 + 1)),
            None,
        )

        national_matches = self._match_count(national_result)
        add_event(
            "NATIONAL_TEAM_CYCLE",
            "national_team",
            national_result.get("status", "unknown"),
            national_matches,
            max(1, min(180, national_matches // 40 + 1)),
        )

        # Calendar integrity is intentionally simple: event windows are ordered,
        # non-overlapping, and the whole season stays inside a broad annual band.
        conflicts = []
        for a, b in zip(events, events[1:]):
            if a["end_date"] >= b["start_date"]:
                conflicts.append({"a": a["id"], "b": b["id"], "type": "event_window_overlap"})

        calendar = {
            "version": self.VERSION,
            "season": season,
            "season_window": {"start": f"{season}-08-01", "end": f"{season + 1}-06-30"},
            "dependency_chain": [e["id"] for e in events],
            "events": events,
            "conflicts": conflicts,
            "status": "valid" if not conflicts else "conflict",
        }
        self._world()["global_world_calendar"] = deepcopy(calendar)
        self._history().setdefault("global_world_calendars", []).append(deepcopy(calendar))
        return calendar

    @staticmethod
    def _match_count(value):
        if not isinstance(value, dict):
            return 0
        total = 0
        for key in ("matches", "group_matches", "knockout_matches", "preliminary_matches", "playoff_matches", "windows"):
            val = value.get(key)
            if isinstance(val, list):
                if key == "windows":
                    total += sum(int(x.get("match_count", len(x.get("matches", [])))) for x in val if isinstance(x, dict))
                else:
                    total += len(val)
        for key in ("continental", "world_cup"):
            val = value.get(key)
            if isinstance(val, list):
                total += sum(V152GlobalWorldSeasonEngine._match_count(x) for x in val if isinstance(x, dict))
            elif isinstance(val, dict):
                total += V152GlobalWorldSeasonEngine._match_count(val)
        return total

    def _run_intercontinental(self, season):
        engine = V119IntercontinentalClubFormat(self.save)
        result = engine.run_intercontinental(season, seed=self.seed + 119)
        if result.get("status") == "completed":
            return result
        return {
            "version": self.VERSION,
            "competition_id": result.get("competition_id", "FWS_INTERCONTINENTAL"),
            "season": season,
            "status": "configuration_pending",
            "reason": "approved_intercontinental_access_field_under_supplied",
            "source_version": result.get("version", "V119"),
            "required": {
                "level1_direct_places": result.get("level1_direct_places", 6),
                "lower_level_places": result.get("lower_level_places", 17),
                "playoff_entries": 16,
            },
            "available": {
                "level1_direct": result.get("level1_direct_places", 0),
                "lower_entries": (
                    int(result.get("lower_preliminary_entries", 0))
                    + int(result.get("playoff_entries", 0))
                    - int(result.get("lower_preliminary_winners", 0))
                ),
                "playoff_entries": result.get("playoff_entries", 0),
            },
            "source_execution": deepcopy(result),
        }

    def _run_super_world(self, season):
        if not V157ClubCalendar.is_super_world_year(season):
            return None
        return V157ClubCalendar(self.save).run_super_world(
            season, cycle_years=self.SUPER_WORLD_CYCLE_YEARS, seed=self.seed + 157
        )

    def _run_national_cycle(self, season):
        return V162QualificationIntegrityAudit(self.save).advance_cycle(
            season, seed=self.seed + 158
        )

    def run_season(self, *, season=None, advance_year=True, club_context=None,
                   association_context=None, career_results=None):
        world = self._world()
        year = int(world.get("current_year", 2026) if season is None else season)
        if any(int(row.get("season", -1)) == year for row in self._ledger()):
            raise ValueError(f"V152 season {year} already integrated")

        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            self._assert_no_player_layer()
            WorldBootstrap(self.save).prepare()
            assert_world_integrity(self.save)
            self._ensure_catalog_adapter()

            # V151 owns domestic + continental club competitions and V133's
            # aggregate annual integration. It does not advance the year here.
            v151 = V151GlobalCompetitionIntegration(self.save, seed=self.seed + 151)
            sporting = v151.run_season(
                season=year,
                advance_year=False,
                club_context=club_context,
                association_context=association_context,
                career_results=career_results,
            )

            intercontinental = self._run_intercontinental(year)
            super_world = self._run_super_world(year)
            national = self._run_national_cycle(year)
            calendar = self._build_calendar(year, national, intercontinental, super_world)

            self._assert_no_player_layer()
            assert_world_integrity(self.save)
            # The compatibility catalog adapter is only a runtime view for
            # legacy V119/V125 engines; do not persist a duplicate catalog in
            # the playable save.
            self.save.pop("catalog", None)
            if calendar["status"] != "valid":
                raise ValueError("V152 global calendar conflict: " + str(calendar["conflicts"]))

            pending = [
                key for key, value in {
                    "intercontinental": intercontinental,
                    "super_world": super_world,
                    "national": national,
                }.items()
                if isinstance(value, dict) and value.get("status") == "configuration_pending"
            ]
            next_year = year + 1 if advance_year else year
            world["current_year"] = next_year
            world["current_round"] = 0
            world["global_world_season_status"] = "closed_with_pending_configuration" if pending else "closed"
            world["global_world_season_version"] = self.VERSION

            row = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "season": year,
                "status": world["global_world_season_status"],
                "next_year": next_year,
                "sporting": deepcopy(sporting),
                "intercontinental": deepcopy(intercontinental),
                "super_world": deepcopy(super_world),
                "national_team": deepcopy(national),
                "calendar": deepcopy(calendar),
                "pending_configuration": pending,
            }
            self._ledger().append(deepcopy(row))
            return deepcopy(row)
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        rows = self._ledger()
        seasons = [int(r.get("season", -1)) for r in rows]
        if len(seasons) != len(set(seasons)):
            errors.append("V152 seasons must be unique")
        for row in rows:
            if row.get("version") != self.VERSION:
                errors.append(f"V152 wrong version: {row.get('season')}")
            if row.get("status") not in ("closed", "closed_with_pending_configuration"):
                errors.append(f"V152 invalid status: {row.get('season')}")
            cal = row.get("calendar", {})
            if cal.get("version") != self.VERSION or cal.get("status") != "valid":
                errors.append(f"V152 invalid calendar: {row.get('season')}")
            if int(row.get("next_year", 0)) != int(row.get("season", 0)) + 1:
                errors.append(f"V152 year advance invalid: {row.get('season')}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("V152 player systems are forbidden")
        return errors
