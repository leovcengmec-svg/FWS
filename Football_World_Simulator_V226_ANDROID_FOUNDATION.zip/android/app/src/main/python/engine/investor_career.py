class InvestorCareer:
    def __init__(self, save, starting_cash=0.0):
        self.save=save
        self.career=save.setdefault("careers",{}).setdefault("investor",{
            "cash":starting_cash,"owned_clubs":[],"transactions":[],"created_clubs":[]})

    def can_buy(self, club_id):
        club=self.save["world"]["clubs"][club_id]
        return self.career["cash"] >= club.get("market_value", 0) and club_id not in self.career["owned_clubs"]

    def buy_club(self, club_id):
        club=self.save["world"]["clubs"][club_id]
        value=club.get("market_value", self._market_value(club))
        if self.career["cash"] < value:
            raise ValueError("capital insuficiente")
        self.career["cash"]-=value
        self.career["owned_clubs"].append(club_id)
        club["owner_type"]="user_investor"
        club["owner_id"]="player"
        self.career["transactions"].append({"type":"buy","club_id":club_id,"value":value,
                                            "season":self.save["world"]["current_year"]})
        return club

    def sell_club(self, club_id):
        if club_id not in self.career["owned_clubs"]: raise ValueError("clube não pertence ao investidor")
        club=self.save["world"]["clubs"][club_id]
        value=club.get("market_value",self._market_value(club))
        self.career["cash"]+=value
        self.career["owned_clubs"].remove(club_id)
        club["owner_type"]="ai"
        club["owner_id"]=None
        self.career["transactions"].append({"type":"sell","club_id":club_id,"value":value,
                                            "season":self.save["world"]["current_year"]})
        return value

    def invest(self, club_id, category, amount):
        if club_id not in self.career["owned_clubs"]: raise ValueError("clube não pertence ao investidor")
        if amount<=0 or self.career["cash"]<amount: raise ValueError("capital insuficiente")
        club=self.save["world"]["clubs"][club_id]
        self.career["cash"]-=amount
        # Spending creates weighted potential, not guaranteed growth.
        club.setdefault("investment",{})[category]=club.setdefault("investment",{}).get(category,0)+amount
        club["cash"]=club.get("cash",0)+amount
        self.career["transactions"].append({"type":"investment","club_id":club_id,"category":category,
                                            "amount":amount,"season":self.save["world"]["current_year"]})

    def _market_value(self, club):
        return round(max(0.1, club.get("prestige",30)*0.12 + club.get("cash",0)*0.8),2)


    def invest_in_selection(self, team_id, amount, category="training"):
        if amount <= 0: raise ValueError("valor do investimento deve ser positivo")
        if self.career["cash"] < amount: raise ValueError("capital insuficiente")
        from .selection_development import SelectionDevelopment
        self.career["cash"] -= amount
        result=SelectionDevelopment(self.save, __import__("random").Random()).invest(team_id,amount,category,investor_id="player")
        self.save.setdefault("history",{}).setdefault("investor_transactions",[]).append({"type":"selection_investment","team_id":team_id,"amount":amount,"category":category,"financial_return":0.0,"note":"capital sem retorno financeiro direto"})
        return result
    def settle_owned_club_returns(self, economy_reports=None, payout_rate=0.35):
        """Distribute part of positive owned-club profit to investor; losses do not create automatic income."""
        reports = {r["club_id"]: r for r in (economy_reports or [])}
        season = self.save["world"]["current_year"]
        total = 0.0
        for club_id in list(self.career.get("owned_clubs", [])):
            report = reports.get(club_id)
            if not report:
                continue
            profit = float(report.get("profit", 0.0))
            payout = round(max(0.0, profit) * max(0.0, min(1.0, payout_rate)), 2)
            if payout:
                self.career["cash"] += payout
                self.save["world"]["clubs"][club_id]["cash"] = max(0.0, self.save["world"]["clubs"][club_id].get("cash",0)-payout)
            total += payout
            self.career["transactions"].append({"type":"club_return","club_id":club_id,"amount":payout,"season":season,"source_profit":round(profit,2)})
        return round(total,2)

