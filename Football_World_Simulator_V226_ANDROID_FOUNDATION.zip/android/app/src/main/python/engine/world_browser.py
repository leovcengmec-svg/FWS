class WorldBrowser:
    def __init__(self,save): self.save=save
    def countries_by_confederation(self,conf):
        return [c for c in self.save["world"].get("countries",{}).values() if c.get("confederation")==conf]
    def divisions(self,country_id):
        return sorted([l for l in self.save["world"]["leagues"].values() if l["country_id"]==country_id],key=lambda x:x["level"])
    def club_profile(self,club_id):
        return self.save["world"]["clubs"].get(club_id)
    def fixtures(self, date_filter=None, competition_id=None):
        rows=self.save.get("calendar",{}).get("fixtures",[])
        if date_filter: rows=[x for x in rows if x["date"]==date_filter]
        if competition_id: rows=[x for x in rows if x["competition_id"]==competition_id]
        return rows

    def historical_champions(self,league_id):
        return self.save["history"].get("league_champions",{}).get(league_id,[])
