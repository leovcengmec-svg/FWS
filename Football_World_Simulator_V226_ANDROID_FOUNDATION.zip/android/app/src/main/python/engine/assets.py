from pathlib import Path
import uuid, shutil

class AssetManager:
    TYPES={"club":"clubs","league":"leagues","country":"countries","confederation":"confederations","user_club":"user_clubs"}
    EXTENSIONS={".png",".jpg",".jpeg",".webp",".svg"}

    def __init__(self, root):
        self.root=Path(root)
        self.root.mkdir(parents=True,exist_ok=True)

    def register(self, asset_type, entity_id, source_file):
        if asset_type not in self.TYPES: raise ValueError("invalid asset type")
        src=Path(source_file)
        if src.suffix.lower() not in self.EXTENSIONS: raise ValueError("unsupported image format")
        folder=self.root/self.TYPES[asset_type]
        folder.mkdir(parents=True,exist_ok=True)
        target=folder/f"{entity_id}{src.suffix.lower()}"
        shutil.copy2(src,target)
        return str(target)

    def path(self, asset_type, entity_id):
        folder=self.root/self.TYPES[asset_type]
        for ext in self.EXTENSIONS:
            p=folder/f"{entity_id}{ext}"
            if p.exists(): return str(p)
        return None

    def remove(self, asset_type, entity_id):
        p=self.path(asset_type,entity_id)
        if p: Path(p).unlink()
