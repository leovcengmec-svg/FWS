"""V216 — Long-horizon simulation foundation.
Aggregate-only: no players or player transfers.
"""
from __future__ import annotations
from copy import deepcopy
import random, math

class V216LongHorizon:
    VERSION="V216"; HORIZONS=(1,5,10,25,50,100)
    def __init__(self, save, seed=216):
        self.save=save; self.rng=random.Random(seed)
        self.history=save.setdefault("history",{}); self.world=save.setdefault("world",{})
    def _clubs(self):
        c=self.world.get("clubs",{})
        return c if isinstance(c,dict) else {}
    def _season_step(self, year):
        clubs=self._clubs()
        for cid,c in clubs.items():
            strength=float(c.get("sporting_strength",50)); form=float(c.get("sporting_form",50))
            cash=float(c.get("cash",100)); prestige=float(c.get("prestige",50))
            # Bounded aggregate evolution; no compounding runaway.
            drift=self.rng.uniform(-1.15,1.15)
            strength=max(1,min(99,strength+drift+((form-50)*.012)))
            form=max(0,min(100,form+self.rng.uniform(-4,4)))
            cash=max(0,cash*(1.0+self.rng.uniform(-.035,.055)))
            prestige=max(1,min(99,prestige+(strength-50)*.018+self.rng.uniform(-.8,.8)))
            c["sporting_strength"]=round(strength,4); c["sporting_form"]=round(form,4)
            c["cash"]=round(cash,4); c["prestige"]=round(prestige,4)
            c.setdefault("financial_history",[]).append({"season":year,"cash":c["cash"]})
        self.world["current_year"]=year
        self.history.setdefault("long_horizon_cycles",[]).append({"version":self.VERSION,"season":year,"clubs":len(clubs)})
    def run(self, seasons=1, start_year=None):
        start=int(self.world.get("current_year",2026) if start_year is None else start_year)
        for i in range(1,int(seasons)+1):
            self._season_step(start+i)
        return self.snapshot()
    def snapshot(self):
        return {"version":self.VERSION,"season":self.world.get("current_year"),"clubs":len(self._clubs()),
                "cycles":len(self.history.get("long_horizon_cycles",[]))}
    def validate(self):
        errors=[]
        if "players" in self.world: errors.append("player layer present")
        if "player_transfers" in self.history: errors.append("player transfer layer present")
        for cid,c in self._clubs().items():
            for k in ("sporting_strength","sporting_form","prestige","cash"):
                if not isinstance(c.get(k), (int,float)) or not math.isfinite(float(c[k])): errors.append(f"{cid}:{k}:nonfinite")
            if not 1<=float(c.get("sporting_strength",50))<=99: errors.append(f"{cid}:strength_bounds")
            if not 0<=float(c.get("sporting_form",50))<=100: errors.append(f"{cid}:form_bounds")
            if not 1<=float(c.get("prestige",50))<=99: errors.append(f"{cid}:prestige_bounds")
            if float(c.get("cash",0))<0: errors.append(f"{cid}:negative_cash")
        return errors
