"""V179 — Final playable world facade."""
from __future__ import annotations
from copy import deepcopy
import pickle
from .v164_global_season_motor import V164GlobalSeasonMotor
from .v176_world_intelligence_integration import V176WorldIntelligenceIntegration
from .v178_runtime_packaging import V178RuntimePackaging
from .v177_release_hardening import V177ReleaseHardening

class V179PlayableWorld:
    VERSION='V179'; SCHEMA=1
    PHASES=('club_selection','world_season','season_review','career_review')
    def __init__(self,save,seed=179): self.save=save; self.seed=int(seed)
    def _runtime(self): return self.save.setdefault('runtime',{})
    def start(self):
        V178RuntimePackaging(self.save).start()
        clubs=self.save.get('world',{}).get('clubs',{})
        self._runtime().update({'playable_version':self.VERSION,'phase':'club_selection','turn':0,
                                'available_clubs':sorted(clubs)})
        return self.status()
    def choose_club(self,club_id):
        clubs=self.save.get('world',{}).get('clubs',{})
        if club_id not in clubs: raise ValueError('unknown club')
        rt=self._runtime(); rt['controlled_club_id']=club_id; rt['phase']='world_season'; rt['turn']=0
        self.save.setdefault('careers',{}).setdefault('club_control',[]).append({'club_id':club_id,'version':self.VERSION})
        return self.status()
    def play_world_season(self,season=None,run_intelligence=True):
        rt=self._runtime()
        if rt.get('phase')!='world_season': raise RuntimeError('choose a club first')
        snapshot=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        try:
            result=V164GlobalSeasonMotor(self.save,seed=self.seed).run_season(season=season,advance_year=True)
            intelligence=None
            if run_intelligence: intelligence=V176WorldIntelligenceIntegration(self.save,self.seed+176).run_after_season(result)
            rt['phase']='season_review'; rt['turn']=int(rt.get('turn',0))+1
            rt['last_season']=int(result['season']); rt['last_intelligence']=deepcopy(intelligence)
            return {'season':result,'intelligence':intelligence,'status':'completed'}
        except Exception:
            restored=pickle.loads(snapshot); self.save.clear(); self.save.update(restored); raise
    def finish_review(self):
        rt=self._runtime()
        if rt.get('phase')!='season_review': raise RuntimeError('season review is not available')
        rt['phase']='career_review'; return self.status()
    def status(self):
        rt=self._runtime(); return {'version':self.VERSION,'phase':rt.get('phase'),'controlled_club_id':rt.get('controlled_club_id'),
            'turn':int(rt.get('turn',0)),'last_season':rt.get('last_season')}
    def validate(self):
        errors=V177ReleaseHardening(self.save).validate()
        rt=self._runtime()
        if rt.get('phase') not in (None,)+self.PHASES: errors.append('invalid_playable_phase')
        cid=rt.get('controlled_club_id')
        if cid is not None and cid not in self.save.get('world',{}).get('clubs',{}): errors.append('unknown_controlled_club')
        return sorted(set(errors))
