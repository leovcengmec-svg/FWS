import math

class ClubEconomy:
    """Seasonal club economy: revenue, costs, profit and market value."""
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('club_economy', [])

    def settle_season(self, league_results=None, continental_participants=None, prize_money=None):
        from .brand import BrandEngine
        from .commercial_market import CommercialMarket
        brand_engine = BrandEngine(self.save)
        commercial_market = CommercialMarket(self.save)
        year = self.save['world']['current_year']
        tables = self.save.setdefault('history', {}).setdefault('latest_tables', {})
        continental_participants = continental_participants or set()
        prize_money = prize_money or {}
        reports = []
        for club_id, club in self.save['world'].get('clubs', {}).items():
            table = tables.get(club.get('league_id'), [])
            pos = next((i+1 for i, r in enumerate(table) if r['club_id'] == club_id), len(table) or 1)
            n = max(1, len(table))
            placement_factor = max(0.15, (n-pos+1)/n)
            prestige = float(club.get('prestige', 30))
            capacity = float(club.get('stadium_capacity', 5000 + prestige*500))
            attendance = min(0.95, max(0.35, 0.42 + prestige/180))
            match_count = max(2, (n-1)*2)
            ticket = capacity * attendance * float(club.get('ticket_price', 8.0)) * match_count / 1000.0
            brand = brand_engine.ensure_club(club)
            commercial = commercial_market.season_club(club_id, pos, n, club_id in continental_participants)
            sponsorship = max(0.2, prestige*0.09 + placement_factor*2.0 + float(brand.get('commercial_strength', 20.0))*0.025)
            sponsorship += commercial['sponsorship_revenue']
            broadcast = commercial['broadcast_revenue']
            continental = 0.0
            if club_id in continental_participants:
                continental = 2.0 + prestige*0.04
            prize = float(prize_money.get(club_id, 0.0))
            revenue = ticket + sponsorship + broadcast + continental + prize
            infrastructure_capacity = max(0.0, min(100.0, float(club.get('infrastructure_score', 40.0))))
            reserve_strength = max(0.0, min(100.0, float(club.get('reserve_strength', 40.0))))
            debt_capacity = max(0.0, min(100.0, float(club.get('debt_management_capacity', 40.0))))
            # Better infrastructure raises operating efficiency; reserve/debt
            # capacity softens financial friction without creating free money.
            operating = max(0.8, prestige*0.055 + capacity/100000*0.8)
            operating *= 1.0 - (infrastructure_capacity-40.0)*0.0015
            investment = sum(float(v) for v in club.get('investment', {}).values())
            financing_friction = max(0.0, float(club.get('debt', 0.0) or 0.0)) * 0.01
            financing_friction *= max(0.50, 1.0 - debt_capacity/200.0)
            reserve_relief = max(0.0, reserve_strength-40.0) * 0.003
            maturity = max(0.0, min(100.0, float(club.get('management_maturity', 40.0))))
            resilience = max(0.0, min(100.0, float(club.get('management_resilience', 40.0))))
            resilience_relief = max(0.0, resilience-40.0) * 0.0015
            costs = max(0.1, operating + investment*0.12 + financing_friction - reserve_relief - resilience_relief)
            profit = revenue - costs
            club['cash'] = max(0.0, float(club.get('cash', 0)) + profit)
            old_value = float(club.get('market_value', 0) or 0)
            base = max(0.1, prestige*0.12 + club['cash']*0.8)
            performance = 0.85 + placement_factor*0.35
            structure = 1.0 + min(0.25, investment/1000.0)
            club['market_value'] = round(max(0.1, base*performance*structure), 2)
            club['last_economy'] = {'season': year, 'revenue': round(revenue,2), 'broadcast_revenue': round(broadcast,2), 'sponsorship_revenue': round(sponsorship,2), 'costs': round(costs,2), 'profit': round(profit,2), 'cash': round(club['cash'],2), 'market_value': club['market_value'], 'league_position': pos, 'infrastructure_capacity': round(infrastructure_capacity,2), 'reserve_strength': round(reserve_strength,2), 'debt_management_capacity': round(debt_capacity,2), 'management_maturity': round(maturity,2), 'management_resilience': round(resilience,2)}
            brand_engine.season_club(club_id, pos, n, club_id in continental_participants)
            reports.append({'club_id':club_id, **club['last_economy']})
        self.history.append({'season':year, 'clubs':reports})
        return reports

class SelectionEconomy:
    """Federation finances. National teams do not generate investor returns."""
    def __init__(self, save, rng=None):
        self.save = save
        self.rng = rng
        self.history = save.setdefault('history', {}).setdefault('selection_economy', [])

    def settle_season(self):
        year = self.save['world']['current_year']
        reports = []
        from .commercial_market import CommercialMarket
        commercial_market = CommercialMarket(self.save)
        for team_id, team in self.save['world'].get('national_teams', {}).items():
            from .selection_development import SelectionDevelopment
            dev = SelectionDevelopment(self.save, self.rng)
            dev.ensure_profile(team)
            level = dev.infrastructure_score(team)
            federation_income = 1.0 + level*0.025 + float(team.get('prestige', 20))*0.02
            operating = 0.7 + level*0.018
            result_bonus = max(0.0, float(team.get('recent_result_bonus', 0)))
            balance = federation_income + result_bonus - operating
            team['federation_cash'] = max(0.0, float(team.get('federation_cash', 8.0)) + balance)
            # The federation can reinvest part of its own budget organically.
            organic = min(team['federation_cash']*0.08, 1.5)
            team['federation_cash'] -= organic
            team['development_budget'] = max(1.0, min(100.0, team.get('development_budget',8.0) + organic*0.5))
            commercial = commercial_market.season_selection(team_id)
            federation_income += commercial['media_value'] + commercial['sponsorship_value']
            reports.append({'team_id':team_id,'income':round(federation_income,2),'operating_cost':round(operating,2),'balance':round(balance,2),'federation_cash':round(team['federation_cash'],2),'organic_reinvestment':round(organic,2)})
        self.history.append({'season':year,'teams':reports})
        return reports
