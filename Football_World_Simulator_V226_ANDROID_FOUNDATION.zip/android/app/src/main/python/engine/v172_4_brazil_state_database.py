"""V172.4 — Brazil persistent state-club registry and Access pool hardening.

V172.3 correctly made the Brazilian calendar state-first, but its persistent
catalog still contained only 607 records and just 259 clubs outside A-F.
V172.4 separates the *current state-division roster* from the broader real-club
registry. Registry clubs are real clubs from the state football ecosystem, but
are NOT treated as having a current 2026 division or state performance until a
seasonal state result exists. This prevents invented division memberships while
making annual Access rotation possible over time.
"""
from __future__ import annotations
import re
from copy import deepcopy

VERSION = "V172.4"
ACCESS_SIZE = 256
MAX_STATE_DIVISIONS = 3
NATIONAL_LEVELS = {f"BRA-BR-{i}" for i in range(1,7)}
REQUIRED_ES = {"Aracruz FC ES","Linhares FC ES","Bagos FC ES","Vila do Riacho FC ES","Barra do Riacho FC ES"}

class V1724BrazilStateDatabase:
    VERSION = VERSION

    def __init__(self, save=None):
        self.save = save if save is not None else {}

    @staticmethod
    def _slug(name: str) -> str:
        s = re.sub(r"[^a-z0-9]+", "-", name.lower(), flags=re.I).strip("-")
        return s

    @classmethod
    def build_registry(cls, catalog, additions):
        """Append verified real-club registry records without inventing divisions."""
        records = list(catalog.get("club_records", []))
        by_key = {(x.get("state_code"), str(x.get("name","")).casefold()): x for x in records}
        added=[]
        for row in additions:
            state=row["state_code"]; name=row["name"]
            # ES naming rule is absolute for every new ES record.
            if state == "ES" and not name.endswith(" ES"):
                name = name.replace("-ES", "") + " ES"
            key=(state,name.casefold())
            if key in by_key:
                continue
            cid=f"BRA-STATE-REG-{state.lower()}-{cls._slug(name)}"
            # Collision-safe deterministic ID.
            if any(x.get("id")==cid for x in records):
                i=2
                while any(x.get("id")==f"{cid}-{i}" for x in records): i+=1
                cid=f"{cid}-{i}"
            rec={
                "id":cid,
                "name":name,
                "country_id":"BRA",
                "league_id":None,
                "season":2026,
                "data_source":"BRAZIL_STATE_CLUB_REGISTRY",
                "real_world_status":"registry_real_club",
                "state_code":state,
                "state_competition_id":None,
                "state_competition_name":None,
                "state_division_level":None,
                "state_roster_source":"List_of_football_clubs_in_Brazil",
                "state_roster_status":"registry_only_until_state_result",
                "eligible_for_access_without_result":False,
                "attack":50.0,"defense":50.0,"prestige":35.0,"sporting_strength":50.0,
                "rating_basis":"registry_neutral_v1",
                "rating_is_simulation_value":True,
            }
            records.append(rec); by_key[key]=rec; added.append(rec)
        out=deepcopy(catalog)
        out["club_records"]=records
        out["all_club_ids"]=[x["id"] for x in records]
        out["club_total"]=len(records)
        out["registry_only_club_ids"]=[x["id"] for x in records if x.get("state_roster_status")=="registry_only_until_state_result"]
        out["registry_real_club_count"]=len(out["registry_only_club_ids"])
        out["state_registry"]={}
        for x in records:
            out["state_registry"].setdefault(x.get("state_code"),[]).append(x["id"])
        out["national_access"]["selection_mode"]="annual_state_performance"
        out["national_access"]["eligibility_requires_current_state_result"]=True
        out["national_access"]["four_extra_rule"]=False
        out["version"]=VERSION
        out["source_registry_policy"]={
            "current_divisions": "preserved from V172.3 and never fabricated by registry enrichment",
            "registry": "real state clubs listed in public Brazilian football club registry",
            "performance_gate": "only clubs with a current state championship result can enter annual Access ranking",
            "max_state_divisions": MAX_STATE_DIVISIONS,
        }
        return out, added

    @staticmethod
    def rank_access_candidates(state_results, national_club_ids, eligible_ids):
        national=set(national_club_ids); rows=[]
        for cid,result in state_results.items():
            if cid not in eligible_ids or cid in national:
                continue
            # A club without an actual state result must never be ranked.
            if not result.get("state_result_valid", True):
                continue
            score=float(result.get("performance_score",0.0))
            rows.append((score,float(result.get("points",0)),float(result.get("goal_difference",0)),float(result.get("goals_for",0)),cid))
        rows.sort(key=lambda x:(-x[0],-x[1],-x[2],-x[3],x[4]))
        return [x[4] for x in rows[:ACCESS_SIZE]]

    def run(self,catalog,state_results=None,national_club_ids=None,season=2026):
        world=self.save.setdefault("world",{}); history=self.save.setdefault("history",{})
        national=set(national_club_ids or [])
        eligible=set(catalog.get("all_club_ids",[]))
        access=[]; status="awaiting_state_results"
        if state_results is not None:
            access=self.rank_access_candidates(state_results,national,eligible)
            if len(access)!=ACCESS_SIZE:
                raise ValueError(f"state_performance_must_select_{ACCESS_SIZE}_clubs")
            status="qualified"
        pool=[cid for cid in eligible if cid not in national]
        # Canonical national league state: Access is a 256-slot competition, not a fixed roster.
        leagues=world.setdefault("leagues", {})
        access_league=leagues.setdefault("BRA-ACCESS", {"id":"BRA-ACCESS","name":"Divisão de Acesso Nacional","country_id":"BRA","level":7,"tier":"access"})
        access_league["club_ids"]=list(access)
        access_league["population_status"]="ready" if len(access)==ACCESS_SIZE else "awaiting_current_state_results"
        access_league["selection_mode"]="annual_state_performance"
        access_league["eligible_population_source"]="Brazil state registry"
        access_league["fixed_roster"]=False
        state_db=history.setdefault("brazil_state_database",{})
        state_db.update({
            "version":VERSION,"season":int(season),"status":status,
            "club_total":len(eligible),"national_A_to_F_excluded":len(national),
            "eligible_population_without_national":len(pool),
            "registry_only_clubs":len(catalog.get("registry_only_club_ids",[])),
            "access_club_ids":access,
        })
        world["brazil_state_database_version"]=VERSION
        world["brazil_state_database"]={
            "club_total":len(eligible),
            "state_count":len(catalog.get("states",{})),
            "max_state_divisions":MAX_STATE_DIVISIONS,
            "access": {"size":ACCESS_SIZE,"status":status,"annual_reselection":True,
                       "source":"current_state_championship_performance",
                       "requires_state_result":True,"excludes_national_series_A_to_F":True,
                       "club_ids":access},
            "sequence":["STATE_CHAMPIONSHIPS","ACCESS_SELECTION_256","NATIONAL_LEAGUES","CONTINENTAL","INTERCONTINENTAL","OTHER"],
        }
        return deepcopy(world["brazil_state_database"])

    @staticmethod
    def validate_catalog(catalog):
        errors=[]
        if catalog.get("version")!=VERSION: errors.append("invalid_version")
        if len(catalog.get("states",{}))!=27: errors.append("all_27_ufs_required")
        if catalog.get("club_total",0)<700: errors.append("persistent_brazil_registry_too_small")
        ids=[x.get("id") for x in catalog.get("club_records",[])]
        if len(ids)!=len(set(ids)): errors.append("duplicate_club_id")
        if set(catalog.get("es_requested_names",[])) != REQUIRED_ES: errors.append("requested_es_names_missing")
        for uf,row in catalog.get("states",{}).items():
            if len(row.get("divisions",[]))>MAX_STATE_DIVISIONS: errors.append(f"too_many_divisions:{uf}")
            divids=[cid for d in row.get("divisions",[]) for cid in d.get("club_ids",[])]
            if len(divids)!=len(set(divids)): errors.append(f"duplicate_state_club:{uf}")
        access=catalog.get("national_access",{})
        if access.get("selection_mode")!="annual_state_performance": errors.append("access_not_dynamic")
        if access.get("size")!=ACCESS_SIZE: errors.append("access_size_not_256")
        if access.get("four_extra_rule") is not False: errors.append("four_extra_rule_not_disabled")
        return errors
