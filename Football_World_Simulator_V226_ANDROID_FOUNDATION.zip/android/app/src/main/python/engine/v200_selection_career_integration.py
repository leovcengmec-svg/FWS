"""V200 — Integrated selection-career gate."""
from __future__ import annotations
from .v196_selection_career import V196SelectionCareer
from .v197_selection_contract import V197SelectionContract
from .v198_selection_decisions import V198SelectionDecisions
from .v199_selection_performance import V199SelectionPerformance
class V200SelectionCareerIntegration:
    VERSION='V200'; CHAIN=['V196','V197','V198','V199','V200']
    def __init__(self,save):
        self.save=save; self.career=V196SelectionCareer(save); self.contract=V197SelectionContract(save); self.decisions=V198SelectionDecisions(save); self.performance=V199SelectionPerformance(save)
    def offers(self): return self.career.generate_offers()
    def accept(self,team_id,seasons=1):
        row=self.career.accept(team_id); self.contract.sign(team_id,seasons); return row
    def decline(self,team_id): return self.career.decline(team_id)
    def manage(self,strategy='balanced',intensity=50,rotation_policy='balanced',focus='competition'):
        self.decisions.set_strategy(strategy,intensity,rotation_policy); self.decisions.prepare(focus=focus); return self.snapshot()
    def record_match(self,result_quality,opponent_strength=50,competition='match',qualified=None,title=False):
        tid=self.career.career.get('current_team_id')
        return self.performance.record(tid,result_quality,opponent_strength,competition,qualified,title)
    def close_season(self): return self.performance.season_close()
    def snapshot(self):
        return {'version':self.VERSION,'career':self.career.snapshot(),'contract':self.contract.active(),'management':self.decisions.snapshot(),'season':self.performance.season_close()}
    def validate(self): return self.career.validate()+self.contract.validate()+self.decisions.validate()+self.performance.validate()
