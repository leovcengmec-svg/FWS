"""Season objectives and board confidence for managed clubs."""
class ClubObjectivesEngine:
    OBJECTIVE_TYPES = ("sporting", "financial", "strategic", "development")
    def __init__(self, save):
        self.save=save; self.history=save.setdefault("history",{}).setdefault("club_objectives",[])
    @staticmethod
    def _clamp(v,lo=0.0,hi=100.0): return round(max(lo,min(hi,float(v))),4)
    def _club(self,club_id):
        c=self.save.get("world",{}).get("clubs",{}).get(club_id)
        if not c: raise ValueError("clube inexistente")
        return c
    def _league_size(self,club):
        for league in self.save.get("world",{}).get("leagues",{}).values():
            if club.get("id") in league.get("club_ids",[]): return max(1,len(league.get("club_ids",[])))
        return 1
    def generate(self,club_id,season=None):
        c=self._club(club_id); season=self.save["world"].get("current_year") if season is None else int(season)
        if c.get("season_objectives",{}).get("season")==season: return c["season_objectives"]
        n=self._league_size(c); strength=self._clamp(c.get("sporting_strength",50)); prestige=self._clamp(c.get("prestige",50)); cash=float(c.get("cash",0)); quality=self._clamp(c.get("strategic_quality",50)); focus=c.get("strategic_focus","balanced")
        target_rank=max(1,min(n,int(round(n-(strength/100.0)*(n-1)))))
        objs=[
            {"type":"sporting","metric":"league_rank","target":target_rank,"direction":"lte","weight":35},
            {"type":"financial","metric":"cash_floor","target":round(max(0,cash*.15),2),"direction":"gte","weight":25},
            {"type":"strategic","metric":"strategic_quality","target":self._clamp(quality+(8 if focus!="balanced" else 5)),"direction":"gte","weight":25},
            {"type":"development","metric":"management_maturity","target":self._clamp(c.get("management_maturity",0)+3),"direction":"gte","weight":15},
        ]
        if prestige<35: objs[0]["target"]=min(n,objs[0]["target"]+max(1,n//8))
        if focus=="sporting": objs[0]["weight"],objs[2]["weight"]=45,15
        elif focus=="commercial": objs[1]["weight"],objs[2]["weight"]=35,15
        elif focus in ("development","consolidation"): objs[3]["weight"],objs[0]["weight"]=25,25
        total=sum(x["weight"] for x in objs)
        for x in objs: x["weight"]=round(x["weight"]*100/total,2); x["status"]="pending"
        row={"season":season,"generated_from":{"sporting_strength":strength,"prestige":prestige,"cash":round(cash,2),"strategic_quality":quality,"focus":focus},"objectives":objs,"board_confidence":50.0,"board_status":"stable"}
        c["season_objectives"]=row; self.history.append({"type":"generated","club_id":club_id,"season":season,"objectives":objs}); return row
    def evaluate(self,club_id,table_row=None,season=None):
        c=self._club(club_id); season=self.save["world"].get("current_year") if season is None else int(season); plan=self.generate(club_id,season)
        rank=None if table_row is None else int(table_row.get("rank",table_row.get("position",0)))
        vals={"league_rank":rank,"cash_floor":float(c.get("cash",0)),"strategic_quality":float(c.get("strategic_quality",0)),"management_maturity":float(c.get("management_maturity",0))}
        weighted=0; achieved=0; evaluated=[]
        for obj in plan["objectives"]:
            value=vals.get(obj["metric"])
            if value is None: ratio=0; status="pending"
            elif obj["direction"]=="lte":
                ratio=1 if value<=obj["target"] else max(0,obj["target"]/max(value,1e-9)); status="achieved" if value<=obj["target"] else "at_risk"
            else:
                ratio=min(1,value/max(float(obj["target"]),1e-9)); status="achieved" if value>=obj["target"] else ("at_risk" if ratio>=.85 else "behind")
            ratio=self._clamp(ratio*100); weighted+=ratio*float(obj["weight"])/100; achieved+=int(status=="achieved")
            evaluated.append({**obj,"value":value,"achievement":ratio,"status":status})
        confidence=self._clamp(20+weighted*.8); status="strong" if confidence>=75 else "stable" if confidence>=55 else "under_pressure" if confidence>=35 else "critical"
        result={"season":season,"objective_count":len(evaluated),"achieved":achieved,"achievement_rate":round(achieved/len(evaluated)*100,2) if evaluated else 0,"board_confidence":confidence,"board_status":status,"objectives":evaluated}
        c["season_objectives"].update({"objectives":evaluated,"board_confidence":confidence,"board_status":status}); c.setdefault("season_objectives_history",[]).append(result); self.history.append({"type":"evaluation","club_id":club_id,**result}); return result
    def snapshot(self,club_id):
        c=self._club(club_id); row=c.get("season_objectives",{}); return {"club_id":club_id,"season":row.get("season"),"board_confidence":row.get("board_confidence",50.0),"board_status":row.get("board_status","uninitialized"),"objectives":row.get("objectives",[])}
