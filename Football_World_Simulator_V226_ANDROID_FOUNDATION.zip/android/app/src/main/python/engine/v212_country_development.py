"""V212 — World Depth: country football ecosystem development."""
from __future__ import annotations
from copy import deepcopy

class V212CountryDevelopment:
    VERSION='V212'
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}); self.data=self.history.setdefault('country_depth',{})
    def build(self,season=None):
        w=self.save.setdefault('world',{}); year=int(w.get('current_year',2026) if season is None else season)
        clubs=w.get('clubs',{}); countries=w.get('countries',w.get('associations',{})); out={}
        buckets={}
        for cid,c in clubs.items():
            key=str(c.get('country_id') or c.get('country_code') or c.get('association_id') or c.get('country') or 'WORLD')
            buckets.setdefault(key,[]).append(c)
        keys=set(buckets)|set(countries)
        for key in sorted(keys):
            items=buckets.get(key,[]); assoc=countries.get(key,{}) if isinstance(countries,dict) else {}
            strength=sum(float(c.get('sporting_strength',50)) for c in items)/len(items) if items else 0
            prestige=sum(float(c.get('prestige',50)) for c in items)/len(items) if items else 0
            levels=max([int(c.get('division_level',0) or 0) for c in items] or [0])
            structure=min(100, len(items)*2 + levels*8)
            development=round(min(100,strength*.45+prestige*.25+structure*.30),3)
            out[key]={'country_id':key,'name':assoc.get('name',key) if isinstance(assoc,dict) else key,'season':year,'clubs':len(items),'average_strength':round(strength,3),'average_prestige':round(prestige,3),'structure_score':round(structure,3),'development_score':development}
        self.data['version']=self.VERSION; self.data['season']=year; self.data['countries']=out; self.history.setdefault('country_depth_cycles',[]).append({'version':self.VERSION,'season':year,'countries':len(out)})
        return deepcopy(out)
    def country(self,country_id): return deepcopy(self.data.get('countries',{}).get(str(country_id),{}))
    def validate(self): return [] if isinstance(self.data.get('countries',{}),dict) else ['V212 invalid countries']
