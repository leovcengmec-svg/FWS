"""Strategic focus and trade-off layer for long-term club management.

A focus is an explicit executive choice. It does not create cash or modify a
match directly; it measures how the season's management allocation aligns with
that choice and records the opportunity cost created by concentrating resources.
"""

class StrategicDecisionEngine:
    FOCUS_WEIGHTS = {
        "balanced": {"infrastructure":1,"commercial":1,"youth_base":1,"scouting":1,"sporting":1,"debt":1,"reserve":1},
        "sporting": {"sporting":3,"youth_base":2,"scouting":2,"infrastructure":1,"commercial":1,"debt":1,"reserve":1},
        "commercial": {"commercial":3,"infrastructure":2,"sporting":1,"youth_base":1,"scouting":1,"debt":1,"reserve":1},
        "development": {"youth_base":3,"scouting":3,"sporting":1,"infrastructure":1,"commercial":1,"debt":1,"reserve":1},
        "consolidation": {"reserve":3,"debt":3,"infrastructure":1,"commercial":1,"youth_base":1,"scouting":1,"sporting":1},
    }

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("strategic_decisions", [])

    @staticmethod
    def _clamp(v, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(v))), 4)

    def set_focus(self, club_id, focus, season=None):
        if focus not in self.FOCUS_WEIGHTS:
            raise ValueError("foco estratégico inválido")
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        season = self.save.get("world", {}).get("current_year") if season is None else season
        club = clubs[club_id]
        club["strategic_focus"] = focus
        row = {"club_id":club_id,"season":season,"focus":focus,"type":"focus_set"}
        self.history.append(row)
        club.setdefault("strategic_decision_history", []).append(row)
        return row

    def evaluate(self, club_id, season=None):
        clubs = self.save.get("world", {}).get("clubs", {})
        if club_id not in clubs:
            raise ValueError("clube inexistente")
        club = clubs[club_id]
        season = self.save.get("world", {}).get("current_year") if season is None else season
        focus = club.get("strategic_focus", "balanced")
        weights = self.FOCUS_WEIGHTS[focus]
        spending = club.get("management_spending", {})
        total = sum(max(0.0, float(spending.get(k, 0))) for k in weights)
        if total <= 0:
            alignment = 50.0
            concentration = 0.0
        else:
            weighted = sum(max(0.0, float(spending.get(k, 0))) * weights[k] for k in weights)
            alignment = self._clamp((weighted / total) * 50.0)
            concentration = self._clamp(max(spending.values()) / total * 100.0 if spending else 0.0)
        tradeoff = self._clamp(concentration * 0.45)
        strategic_quality = self._clamp(alignment - tradeoff * 0.35 + 17.5)
        row = {"club_id":club_id,"season":season,"focus":focus,
               "alignment":alignment,"concentration":concentration,
               "tradeoff_cost":tradeoff,"strategic_quality":strategic_quality,
               "spending":{k:round(float(spending.get(k,0)),2) for k in weights}}
        club["strategic_alignment"] = alignment
        club["strategic_tradeoff_cost"] = tradeoff
        club["strategic_quality"] = strategic_quality
        club.setdefault("strategic_decision_history", []).append(row)
        self.history.append(row)
        return row
