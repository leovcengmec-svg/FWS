from .selection_development import SelectionDevelopment

class SelectionCareer:
    def __init__(self,save,rng=None):
        self.save=save; self.career=save.setdefault("careers",{}).setdefault("selection",{"manager_prestige":0.0,"current_team_id":None,"history":[],"invitations":[],"declined":[]}); self.development=SelectionDevelopment(save,rng)
    def tier(self,prestige=None):
        p=self.career["manager_prestige"] if prestige is None else prestige
        return "EMERGING" if p<20 else "REGIONAL" if p<40 else "INTERNATIONAL" if p<60 else "ELITE" if p<80 else "WORLD"
    def eligible_invites(self):
        p=self.career["manager_prestige"]; return [t["id"] for t in self.save["world"].get("national_teams",{}).values() if t.get("manager_prestige_required",10)<=p]
    def generate_invitations(self):
        cur=self.career.get("current_team_id"); self.career["invitations"]=[x for x in sorted(set(self.eligible_invites())) if x!=cur]; return self.career["invitations"]
    def accept_invitation(self,team_id):
        if team_id not in self.career.get("invitations",[]): raise ValueError("seleção não enviou convite")
        old=self.career.get("current_team_id")
        if old: self.career["history"].append({"team_id":old,"ended_season":self.save["world"]["current_year"]})
        self.career["current_team_id"]=team_id; self.career["invitations"].remove(team_id); self.career["history"].append({"team_id":team_id,"started_season":self.save["world"]["current_year"]}); return team_id
    def finish_cycle(self,result_quality,opponent_strength=50):
        self.career["manager_prestige"]=max(0,min(100,self.career["manager_prestige"]+(result_quality-opponent_strength)*.12)); cur=self.career.get("current_team_id")
        if cur: self.development.cycle(cur,result_quality,opponent_strength)
        self.generate_invitations(); return self.career["manager_prestige"]
    def develop_selection(self,team_id,result_quality=None,opponent_strength=None): return self.development.cycle(team_id,result_quality,opponent_strength)
