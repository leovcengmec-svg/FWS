"""V172.2 — Brazil state pyramids and national Access reallocation."""
from __future__ import annotations

from copy import deepcopy

VERSION = "V172.2"
BRAZIL_TOTAL_CLUBS = 607
ACCESS_SIZE = 256
MAX_STATE_DIVISIONS = 3

class V1722BrazilStateStructure:
    VERSION = VERSION
    def __init__(self, save):
        self.save = save

    def run(self, catalog=None):
        world = self.save.setdefault("world", {})
        state_db = self.save.setdefault("history", {}).setdefault("brazil_state_structure", {})
        if catalog is not None:
            world["brazil_state_structure_version"] = self.VERSION
            world["brazil_state_structure"] = deepcopy(catalog)
        state_db["version"] = self.VERSION
        state_db["status"] = "ready"
        return deepcopy(state_db)

    @staticmethod
    def validate_catalog(catalog):
        errors = []
        if catalog.get("version") != VERSION:
            errors.append("invalid_version")
        if catalog.get("club_total") != BRAZIL_TOTAL_CLUBS:
            errors.append("brazil_club_total_must_be_607")
        if catalog.get("national_access_rule", {}).get("size") != ACCESS_SIZE:
            errors.append("national_access_size_must_be_256")
        if catalog.get("national_access_rule", {}).get("four_extra_rule") is not False:
            errors.append("brazil_four_extra_rule_must_be_disabled")
        if len(catalog.get("states", {})) != 27:
            errors.append("all_27_ufs_required")
        for state, row in catalog.get("states", {}).items():
            if row.get("max_divisions", 0) > MAX_STATE_DIVISIONS:
                errors.append(f"state_divisions_gt_3:{state}")
            ids=[]
            for div in row.get("divisions", []): ids.extend(div.get("club_ids", []))
            if len(ids) != len(set(ids)):
                errors.append(f"duplicate_state_club:{state}")
            if len(ids) != row.get("club_count"):
                errors.append(f"state_count_mismatch:{state}")
        if catalog.get("es", {}).get("requested_names_present") is not True:
            errors.append("requested_es_names_missing")
        if len(catalog.get("national_access", {}).get("club_ids", [])) != ACCESS_SIZE:
            errors.append("access_club_ids_not_256")
        return errors
