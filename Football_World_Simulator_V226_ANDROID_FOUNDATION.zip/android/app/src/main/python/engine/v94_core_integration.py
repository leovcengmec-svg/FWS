"""V94 Core Integration/API: one deterministic orchestration boundary."""
from __future__ import annotations
from copy import deepcopy
from .world_dynamics import WorldDynamics
from .v90_ai_behavior import AIBehaviorEngine
from .v92_media_reputation import V92MediaReputation
from .v93_historical_world import V93HistoricalWorld
from .v91_economy_market import V91EconomyMarket

class EventBus:
    def __init__(self): self.events=[]
    def emit(self,event_type,payload):
        self.events.append({'type':event_type,'payload':deepcopy(payload)}); return self.events[-1]

class V94Core:
    VERSION='V94'; SCHEMA=1
    def __init__(self,catalog,seed=94,cup_registry=None):
        self.catalog=catalog; self.seed=int(seed); self.cup_registry=cup_registry or {}; self.bus=EventBus()
    def start(self,season=2026):
        world=WorldDynamics(self.catalog,self.seed).initialize_season(season)
        ai=AIBehaviorEngine(self.catalog,self.seed).initialize_world(world,season)
        return {'version':self.VERSION,'world':world,'ai':ai,'events':[]}
    def execute_league(self,state,league_id):
        WorldDynamics(self.catalog,self.seed).simulate_league(state['world'],league_id)
        row=state['world']['leagues_state'][league_id]
        self.bus.emit('league_completed',{'league_id':league_id,'season':state['world']['season'],'standings':row.get('standings',[])})
        return row
    def close_season(self,state):
        world=state['world']; season=world['season']
        completed={lid:r.get('standings',[]) for lid,r in world['leagues_state'].items() if r.get('status')=='completed'}
        movements=WorldDynamics(self.catalog,self.seed).apply_promotion_relegation(world)
        V93HistoricalWorld(state).close_season(season,completed,{}, {}, movements)
        self.bus.emit('season_completed',{'season':season,'league_count':len(completed),'standings':deepcopy(completed)})
        state['events']=deepcopy(self.bus.events)
        return state
    def validate(self,state):
        errors=[]
        if state.get('version')!=self.VERSION: errors.append('wrong version')
        if state.get('world',{}).get('clubs')!=len(self.catalog.get('clubs',{})): errors.append('club count mismatch')
        if state.get('world',{}).get('leagues')!=len(self.catalog.get('leagues',{})): errors.append('league count mismatch')
        errors.extend(V93HistoricalWorld(state).validate())
        return errors
