"""V185 — Integrated interface experience gate."""
from __future__ import annotations
from copy import deepcopy
from .v181_interface_shell import V181InterfaceShell
from .v182_career_hub import V182CareerHub
from .v183_notifications_calendar import V183NotificationsCalendar
from .v184_world_navigation import V184WorldNavigation
from .v177_release_hardening import V177ReleaseHardening

class V185ExperienceIntegration:
    VERSION='V185'; CHAIN=['V181','V182','V183','V184','V185']
    def __init__(self,save,assets_root=None):
        self.save=save; self.ui=V181InterfaceShell(save); self.career=V182CareerHub(save,assets_root); self.events=V183NotificationsCalendar(save); self.world=V184WorldNavigation(save)
    def start(self):
        self.ui.start(); self.save.setdefault('runtime',{})['experience_version']=self.VERSION
        return self.status()
    def status(self):
        return {'version':self.VERSION,'screen':self.save.get('runtime',{}).get('interface',{}).get('screen','home'),
                'career':self.career.snapshot(),'actions':self.career.actions(),'world':self.world.world_summary(),
                'unread_notifications':len(self.events.inbox(True))}
    def validate(self):
        errors=V177ReleaseHardening(self.save).validate()
        if self.save.get('runtime',{}).get('experience_version') not in (None,self.VERSION): errors.append('invalid_experience_version')
        if 'players' in self.save.get('world',{}): errors.append('player_system_forbidden')
        return sorted(set(errors))
