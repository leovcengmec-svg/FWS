"""V218 — Sporting continuity: competitions, prestige and selection invitations."""
from __future__ import annotations
from copy import deepcopy
class V218SportingContinuity:
    VERSION="V218"
    def __init__(self,save): self.save=save; self.world=save.setdefault("world",{}); self.history=save.setdefault("history",{})
    def run(self,season=None):
        year=int(self.world.get("current_year",2026) if season is None else season)
        clubs=self.world.get("clubs",{}) if isinstance(self.world.get("clubs",{}),dict) else {}
        comps=self.world.get("competitions",{}) if isinstance(self.world.get("competitions",{}),dict) else {}
        champions={}
        for cid,comp in comps.items():
            members=[(k,c) for k,c in clubs.items() if c.get("competition_id")==cid or c.get("league_id")==cid]
            if not members: continue
            champ=max(members,key=lambda x:(float(x[1].get("sporting_strength",50)),float(x[1].get("prestige",50))))
            champions[cid]=champ[0]
            comp.setdefault("history",[]).append({"season":year,"champion_id":champ[0]})
            clubs[champ[0]]["prestige"]=round(min(99,float(clubs[champ[0]].get("prestige",50))+.75),4)
        selections=self.world.get("national_teams",{}) if isinstance(self.world.get("national_teams",{}),dict) else {}
        invites=[]
        manager=self.save.get("careers",{}).get("selection",{}) if isinstance(self.save.get("careers",{}),dict) else {}
        mp=float(manager.get("manager_prestige",0))
        for sid,s in selections.items():
            threshold=float(s.get("prestige_threshold",50))
            if mp>=threshold: invites.append(sid)
        row={"version":self.VERSION,"season":year,"champions":champions,"selection_invites":invites,"clubs":len(clubs),"competitions":len(comps)}
        self.history.setdefault("sporting_continuity_cycles",[]).append(row)
        self.world["sporting_continuity_version"]=self.VERSION
        return deepcopy(row)
    def validate(self):
        errors=[]
        for cid,c in (self.world.get("clubs",{}) or {}).items():
            p=float(c.get("prestige",50))
            if not 1<=p<=99: errors.append(f"{cid}:prestige_bounds")
        return errors
