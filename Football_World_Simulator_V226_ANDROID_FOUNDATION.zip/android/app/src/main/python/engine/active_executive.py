"""Executive management views and decisions for the active club/selection."""
from engine.active_management import ActiveManagement
from engine.active_management_effects import ActiveManagementEffects
from engine.strategic_decisions import StrategicDecisionEngine


class ActiveExecutive:
    CLUB_CATEGORIES = ("infrastructure", "commercial", "youth_base", "scouting", "sporting", "debt", "reserve")
    SELECTION_CATEGORIES = ("development", "technical", "youth", "scouting", "federation_management")

    def __init__(self, save):
        self.save = save
        self.active = ActiveManagement(save)
        self.effects = ActiveManagementEffects(save)
        self.strategic = StrategicDecisionEngine(save)
        from engine.strategic_planning import StrategicPlanningEngine
        self.planning = StrategicPlanningEngine(save)
        from engine.strategic_governance import StrategicGovernance
        self.governance = StrategicGovernance(save)
        from engine.strategic_review import StrategicReviewEngine
        from engine.strategic_action_lifecycle import StrategicActionLifecycle
        from engine.strategic_effectiveness import StrategicEffectiveness
        self.review = StrategicReviewEngine(save)
        self.action_lifecycle = StrategicActionLifecycle(save)
        self.effectiveness = StrategicEffectiveness(save)
        from engine.club_objectives import ClubObjectivesEngine
        self.objectives = ClubObjectivesEngine(save)
        self.state = save.setdefault("careers", {}).setdefault("active_executive", {
            "club_objectives": {}, "selection_objectives": {}, "decisions": []
        })

    def _club(self, club_id=None):
        club_id = club_id or self.active.active_entities()["club_id"]
        if not club_id or club_id not in self.active.investor.get("owned_clubs", []):
            raise ValueError("nenhum clube próprio está sob gestão ativa")
        club = self.save["world"].get("clubs", {}).get(club_id)
        if not club:
            raise ValueError("clube inexistente")
        return club_id, club

    def club_snapshot(self, club_id=None):
        club_id, c = self._club(club_id)
        spending = c.get("management_spending", {})
        return {
            "club_id": club_id, "name": c.get("name"), "cash": round(float(c.get("cash", 0)), 2),
            "prestige": c.get("prestige", 0), "sporting_strength": c.get("sporting_strength", 0),
            "identity_score": c.get("identity_score", 0), "management_spending": dict(spending),
            "objective": self.state["club_objectives"].get(club_id),
        }

    def set_club_objective(self, objective):
        club_id, _ = self._club()
        if not objective or not isinstance(objective, str):
            raise ValueError("objetivo inválido")
        self.state["club_objectives"][club_id] = objective
        self.state["decisions"].append({"type": "club_objective", "club_id": club_id,
                                         "objective": objective, "season": self.save["world"].get("current_year")})
        return objective

    def set_strategic_focus(self, focus):
        club_id, _ = self._club()
        row = self.strategic.set_focus(club_id, focus, self.save["world"].get("current_year"))
        self.state["decisions"].append({"type": "strategic_focus", **row})
        return row

    def strategic_plan(self, focus, horizon=3, target_quality=70.0):
        club_id, _ = self._club()
        row = self.planning.create_plan(club_id, focus, horizon, target_quality, self.save["world"].get("current_year"))
        self.state["decisions"].append({"type":"strategic_plan", **row})
        return row

    def strategic_plan_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.planning.snapshot(club_id)

    def strategic_governance_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.governance.snapshot(club_id)

    def strategic_review(self, club_id=None):
        club_id, _ = self._club(club_id)
        governance = self.governance.snapshot(club_id)
        return self.review.review(club_id, governance, self.save["world"].get("current_year"))

    def strategic_review_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.review.snapshot(club_id)

    def execute_strategic_action(self, action_id, club_id=None):
        club_id, _ = self._club(club_id)
        row = self.review.execute_action(club_id, action_id, self.save["world"].get("current_year"))
        self.state["decisions"].append({"type": "strategic_action", **row})
        return row

    def strategic_action_lifecycle_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.action_lifecycle.snapshot(club_id)

    def initialize_strategic_action(self, action_id, club_id=None):
        club_id, _ = self._club(club_id)
        return self.action_lifecycle.initialize(club_id, action_id, self.save["world"].get("current_year"))

    def club_objectives_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.objectives.snapshot(club_id)

    def evaluate_club_objectives(self, club_id=None, rank=None, season=None):
        club_id, _ = self._club(club_id)
        return self.objectives.evaluate(club_id, {"rank": rank} if rank is not None else None, self.save["world"].get("current_year") if season is None else season)

    def strategic_effectiveness_snapshot(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.effectiveness.snapshot(club_id)

    def evaluate_strategic_effectiveness(self, club_id=None, season=None):
        club_id, _ = self._club(club_id)
        return self.effectiveness.evaluate(club_id, self.save["world"].get("current_year") if season is None else season)

    def advance_strategic_actions(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.action_lifecycle.advance(club_id, self.save["world"].get("current_year"))

    def rebaseline_strategic_plan(self, new_target_quality, reason="executive_review", club_id=None):
        club_id, _ = self._club(club_id)
        row = self.review.rebaseline(club_id, new_target_quality, reason, self.save["world"].get("current_year"))
        self.state["decisions"].append({"type": "strategic_rebaseline", **row})
        return row

    def strategic_snapshot(self, club_id=None):
        club_id, club = self._club(club_id)
        return {"club_id": club_id, "focus": club.get("strategic_focus", "balanced"),
                "alignment": club.get("strategic_alignment", 50.0),
                "tradeoff_cost": club.get("strategic_tradeoff_cost", 0.0),
                "strategic_quality": club.get("strategic_quality", 50.0)}

    def allocate_club_budget(self, allocations):
        club_id, club = self._club()
        if not allocations or any(k not in self.CLUB_CATEGORIES for k in allocations):
            raise ValueError("categoria de orçamento inválida")
        values = {k: float(v) for k, v in allocations.items()}
        if any(v < 0 for v in values.values()):
            raise ValueError("valores não podem ser negativos")
        total = round(sum(values.values()), 2)
        cash = round(float(club.get("cash", 0)), 2)
        if total > cash:
            raise ValueError("orçamento superior ao caixa do clube")
        plan = {"club_id": club_id, "season": self.save["world"].get("current_year"),
                "total": total, "allocations": {k: round(v, 2) for k, v in values.items()}}
        club.setdefault("management_budget_plans", []).append(plan)
        self.state["decisions"].append({"type": "club_budget_plan", **plan})
        return plan

    def execute_budget(self, plan):
        club_id, club = self._club(plan.get("club_id"))
        if plan.get("club_id") != club_id:
            raise ValueError("plano pertence a outro clube")
        total = round(float(plan.get("total", 0)), 2)
        cash = round(float(club.get("cash", 0)), 2)
        if total <= 0 or total > cash:
            raise ValueError("caixa insuficiente para executar o orçamento")
        club["cash"] = round(cash - total, 2)
        if plan.get("status") == "executed":
            raise ValueError("plano já executado")
        plan["status"] = "executed"
        for category, amount in plan.get("allocations", {}).items():
            club.setdefault("management_spending", {})[category] = round(
                club.setdefault("management_spending", {}).get(category, 0) + float(amount), 2)
        result = {"club_id": club_id, "season": self.save["world"].get("current_year"),
                  "total": total, "allocations": dict(plan.get("allocations", {}))}
        club.setdefault("management_executions", []).append(result)
        self.state["decisions"].append({"type": "club_budget_execution", **result})
        return result

    def apply_club_season_effects(self, club_id=None, season=None):
        club_id, _ = self._club(club_id)
        return self.effects.apply_season(club_id, season)

    def club_management_effects(self, club_id=None):
        club_id, _ = self._club(club_id)
        return self.effects.snapshot(club_id)

    def selection_snapshot(self):
        team_id = self.active.active_entities()["selection_id"]
        if not team_id:
            raise ValueError("nenhuma seleção está sob gestão ativa")
        team = self.save["world"].get("national_teams", {}).get(team_id)
        if not team:
            raise ValueError("seleção inexistente")
        return {"selection_id": team_id, "name": team.get("name"),
                "strength": team.get("strength", 0),
                "objective": self.state["selection_objectives"].get(team_id)}

    def set_selection_objective(self, objective):
        team_id = self.active.active_entities()["selection_id"]
        if not team_id:
            raise ValueError("nenhuma seleção está sob gestão ativa")
        if not objective or not isinstance(objective, str):
            raise ValueError("objetivo inválido")
        self.state["selection_objectives"][team_id] = objective
        self.state["decisions"].append({"type": "selection_objective", "selection_id": team_id,
                                         "objective": objective, "season": self.save["world"].get("current_year")})
        return objective

    def executive_dashboard(self):
        entities = self.active.active_entities()
        return {
            "active_club": self.club_snapshot(entities["club_id"]) if entities["club_id"] else None,
            "active_selection": self.selection_snapshot() if entities["selection_id"] else None,
            "simultaneous_management": entities["simultaneous_management"],
            "owned_clubs": self.active.owned_clubs_overview(),
            "season": self.save["world"].get("current_year"),
            "club_objectives": self.club_objectives_snapshot(entities["club_id"]) if entities["club_id"] else None,
        }
