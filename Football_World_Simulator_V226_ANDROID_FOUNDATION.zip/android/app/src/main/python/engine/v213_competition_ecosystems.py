"""V213 — World Depth: competition ecosystem health."""
from __future__ import annotations
from copy import deepcopy

class V213CompetitionEcosystems:
    VERSION='V213'
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}); self.data=self.history.setdefault('competition_depth',{})
    def build(self,season=None):
        w=self.save.setdefault('world',{}); year=int(w.get('current_year',2026) if season is None else season); comps=w.get('competitions',{}); out={}
        for cid,c in sorted(comps.items()):
            size=float(c.get('size',c.get('field_size',c.get('club_count',0))) or 0); international=bool(c.get('confederation') or c.get('type') in ('continental','intercontinental'))
            stability=50.0; identity=65.0 if c.get('name') else 45.0; scale=min(100,size*2 if size else 20)
            health=round(min(100,stability*.25+identity*.25+scale*.50),3)
            out[cid]={'competition_id':cid,'name':c.get('name',cid),'season':year,'field_size':round(size,3),'international':international,'scale_score':round(scale,3),'identity_score':identity,'health_score':health}
        self.data.update({'version':self.VERSION,'season':year,'competitions':out}); self.history.setdefault('competition_depth_cycles',[]).append({'version':self.VERSION,'season':year,'competitions':len(out)})
        return deepcopy(out)
    def competition(self,competition_id): return deepcopy(self.data.get('competitions',{}).get(str(competition_id),{}))
    def validate(self): return [] if isinstance(self.data.get('competitions',{}),dict) else ['V213 invalid competitions']
