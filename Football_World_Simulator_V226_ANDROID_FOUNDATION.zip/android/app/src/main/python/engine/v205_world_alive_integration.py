"""V205 — Integrated World Alive seasonal gate."""
from __future__ import annotations
from .v201_world_events import V201WorldEvents
from .v202_world_reactions import V202WorldReactions
from .v203_world_memory import V203WorldMemory
from .v204_world_narrative import V204WorldNarrative
class V205WorldAliveIntegration:
    VERSION='V205'; CHAIN=['V201','V202','V203','V204','V205']
    def __init__(self,save,seed=201): self.save=save; self.events=V201WorldEvents(save,seed); self.reactions=V202WorldReactions(save); self.memory=V203WorldMemory(save); self.narrative=V204WorldNarrative(save)
    def run(self,season=None):
        year=int(self.save.setdefault('world',{}).get('current_year',2026) if season is None else season)
        existing=self.save.setdefault('history',{}).get('world_alive_cycles',[])
        prior=next((r for r in reversed(existing) if int(r.get('season',-1))==year),None)
        if prior is not None:
            return dict(prior, idempotent_replay=True)
        events=self.events.generate(year); reactions=self.reactions.apply(year); memory=self.memory.close_season(year); narrative=self.narrative.build(year)
        row={'version':self.VERSION,'season':year,'events':len(events),'reactions':len(reactions),'memory_records':len(memory),'news':len(narrative['news']),'player_layer_forbidden':True,'chain':list(self.CHAIN)}
        self.save.setdefault('history',{}).setdefault('world_alive_cycles',[]).append(row); self.save['world']['world_alive_status']='ready'; self.save['world']['world_alive_version']=self.VERSION; return row
    def snapshot(self): return {'version':self.VERSION,'world_alive_status':self.save.setdefault('world',{}).get('world_alive_status'),'events':self.save.setdefault('history',{}).get('world_events',[])[-10:],'news':self.save.setdefault('history',{}).get('world_narratives',[])[-1:]}
    def validate(self): return self.events.validate()+self.reactions.validate()+self.memory.validate()+self.narrative.validate()
