"""V217 — Long-horizon economic stability and inflation guard."""
from __future__ import annotations
from copy import deepcopy
import math
class V217EconomicStability:
    VERSION="V217"
    def __init__(self,save): self.save=save; self.world=save.setdefault("world",{}); self.history=save.setdefault("history",{})
    def run(self,season=None):
        year=int(self.world.get("current_year",2026) if season is None else season)
        clubs=self.world.get("clubs",{}) if isinstance(self.world.get("clubs",{}),dict) else {}
        prices=self.world.setdefault("economy",{}); prices.setdefault("inflation_index",100.0); prices.setdefault("wealth_index",100.0)
        prev=prices["inflation_index"]
        # Stable macro drift, explicitly bounded to avoid exponential runaway.
        prices["inflation_index"]=round(max(70,min(250,prev*1.025)),6)
        avg_cash=sum(float(c.get("cash",0)) for c in clubs.values())/len(clubs) if clubs else 0
        prices["wealth_index"]=round(max(1,min(1000000,100+avg_cash)),4)
        row={"version":self.VERSION,"season":year,"inflation_index":prices["inflation_index"],"wealth_index":prices["wealth_index"],"average_cash":round(avg_cash,4)}
        self.history.setdefault("economic_stability_cycles",[]).append(row)
        self.world["economic_stability_version"]=self.VERSION
        return deepcopy(row)
    def validate(self):
        p=self.world.get("economy",{})
        errors=[]
        x=float(p.get("inflation_index",100))
        if not math.isfinite(x) or not 70<=x<=250: errors.append("inflation index out of bounds")
        return errors
