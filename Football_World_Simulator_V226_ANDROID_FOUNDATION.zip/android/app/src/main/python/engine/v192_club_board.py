"""V192 — Club board decisions and their bounded operational effects.

Board decisions are part of the aggregate club model; they do not introduce
individual players, squads or transfer-market entities.
"""

class V192ClubBoard:
    DECISIONS = {
        "invest_infrastructure": "infrastructure",
        "increase_commercial": "commercial",
        "financial_consolidation": "financial",
        "sporting_development": "sporting",
    }

    def __init__(self, save):
        self.save = save
        self.history = save.setdefault("history", {}).setdefault("club_board", [])

    def confidence(self, club_id, achievement_rate=None):
        club = self.save["world"]["clubs"][club_id]
        current = float(club.get("board_confidence", 50))
        rate = 50 if achievement_rate is None else float(achievement_rate)
        value = max(0, min(100, round(current * .45 + rate * .55, 4)))
        status = "strong" if value >= 75 else "stable" if value >= 55 else "under_pressure" if value >= 35 else "critical"
        club["board_confidence"] = value
        club["board_status"] = status
        row = {"club_id": club_id, "season": self.save["world"].get("current_year"), "confidence": value, "status": status}
        self.history.append(row)
        return row

    def decision(self, club_id, decision, reason=""):
        if decision not in self.DECISIONS:
            raise ValueError("decisão de diretoria inválida")
        club = self.save["world"]["clubs"][club_id]
        area = self.DECISIONS[decision]
        effects = {}

        # Apply small, bounded changes to aggregate club attributes. Financial
        # decisions do not fabricate cash: they improve the club's stability
        # indicator and leave actual cash/debt accounting to the finance engine.
        if area == "infrastructure":
            # Keep the canonical infrastructure field consumed by the market and
            # economy engines in sync with the board-facing quality indicator.
            old = float(club.get("infrastructure_score", club.get("infrastructure_quality", 40)))
            new = round(min(100, old + 2), 4)
            club["infrastructure_score"] = new
            club["infrastructure_quality"] = new
            effects["infrastructure_score"] = new - old
            readiness = float(club.get("management_readiness", 50))
            club["management_readiness"] = round(min(100, readiness + 1), 4)
            effects["management_readiness"] = club["management_readiness"] - readiness
        elif area == "commercial":
            key = "commercial_strength"
            old = float(club.get(key, 40))
            club[key] = round(min(100, old + 2), 4)
            effects[key] = club[key] - old
        elif area == "financial":
            # These bounded indicators are consumed by existing financial and
            # management calculations; cash/debt ledgers remain authoritative.
            key = "financial_stability"
            old = float(club.get(key, 50))
            club[key] = round(min(100, old + 2), 4)
            effects[key] = club[key] - old
            resilience = float(club.get("management_resilience", 40))
            club["management_resilience"] = round(min(100, resilience + 1), 4)
            effects["management_resilience"] = club["management_resilience"] - resilience
        else:
            key = "sporting_strength"
            old = float(club.get(key, 50))
            club[key] = round(min(100, old + 1), 4)
            effects[key] = club[key] - old
            maturity = float(club.get("management_maturity", 40))
            club["management_maturity"] = round(min(100, maturity + 1), 4)
            effects["management_maturity"] = club["management_maturity"] - maturity

        row = {
            "club_id": club_id,
            "season": self.save["world"].get("current_year"),
            "decision": decision,
            "reason": reason,
            "effects": effects,
        }
        club.setdefault("board_decisions", []).append(row)
        self.history.append(row)
        return row

    def validate(self):
        errors = []
        for row in self.history:
            if row.get("decision") and row["decision"] not in self.DECISIONS:
                errors.append(f"invalid_decision:{row.get('club_id')}:{row.get('decision')}")
        return errors
