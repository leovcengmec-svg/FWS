class QualificationEngine:
    def __init__(self, access_engine):
        self.access=access_engine

    def build_entries(self, competition, leagues, tables, cup_winners):
        confederation = competition.get("confederation")
        eligible = [l for l in leagues if l.get("confederation") == confederation] if confederation else list(leagues)
        allocations=self.access.allocate(competition["size"],eligible)
        entries=[]
        for row in allocations:
            lid=row["league_id"]; table=tables.get(lid,[])
            for pos in range(min(row["direct_slots"],len(table))):
                entries.append({"club_id":table[pos]["club_id"],"source":"league","position":pos+1,"league_id":lid})
            if lid in cup_winners and len(entries)<competition["size"]:
                entries.append({"club_id":cup_winners[lid],"source":"cup","league_id":lid})
        seen=set(); unique=[]
        for e in entries:
            if e["club_id"] not in seen:
                seen.add(e["club_id"]); unique.append(e)
        return unique[:competition["size"]]

    def qualifying_rounds(self, entries, rounds):
        rounds_out=[]
        current=entries[:]
        for r in range(1,rounds+1):
            current=current[::2] if len(current)>1 else current
            rounds_out.append({"round":r,"remaining":len(current)})
        return rounds_out
