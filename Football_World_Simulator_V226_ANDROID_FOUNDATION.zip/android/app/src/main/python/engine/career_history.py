class WorldHistory:
    def __init__(self, save):
        self.save=save
        self.save.setdefault("history",{})

    def record_league_champion(self, league_id, season, club_id):
        self.save["history"].setdefault("league_champions",{}).setdefault(league_id,[]).append(
            {"season":season,"club_id":club_id})

    def record_continental_champion(self, competition_id, season, club_id):
        self.save["history"].setdefault("continental_champions",{}).setdefault(competition_id,[]).append(
            {"season":season,"club_id":club_id})

    def record_world_champion(self, season, national_team_id):
        self.save["history"].setdefault("world_champions",[]).append(
            {"season":season,"national_team_id":national_team_id})

    def league_champion_ranking(self, league_id):
        rows=self.save["history"].get("league_champions",{}).get(league_id,[])
        counts={}
        for r in rows: counts[r["club_id"]]=counts.get(r["club_id"],0)+1
        return sorted(counts.items(),key=lambda x:(-x[1],x[0]))

class NationalTeamCareer:
    def __init__(self, save):
        self.save=save
        self.career=save.setdefault("careers",{}).setdefault(
            "national_team_career",{"current_team_id":None,"history":[]})

    def take_control(self,team_id,season):
        current=self.career.get("current_team_id")
        if current and current!=team_id:
            self.career["history"].append({"team_id":current,"ended_season":season})
        self.career["current_team_id"]=team_id
        self.career["history"].append({"team_id":team_id,"started_season":season})

    def release_control(self,season):
        current=self.career.get("current_team_id")
        if current:
            self.career["history"].append({"team_id":current,"ended_season":season})
        self.career["current_team_id"]=None
