"""V91 Global Economy + Market.

Composes the existing finance/commercial/club-market engines. It adds cup
prize income and a club-level transfer-market foundation without inventing
individual players before a player registry exists.
"""
from __future__ import annotations
import hashlib
from copy import deepcopy
from .economy import ClubEconomy, SelectionEconomy
from .market import ClubMarket

class V91EconomyMarket:
    VERSION='V91'
    SCHEMA=1
    def __init__(self, save, cup_registry=None, seed=91):
        self.save=save; self.cup_registry=cup_registry or {}; self.seed=int(seed)
        self.history=save.setdefault('history',{})

    @classmethod
    def from_catalog(cls, catalog, cup_registry=None, season=2026, seed=91):
        """Build a simulation save from the closed 211-association world catalog."""
        countries=deepcopy(catalog.get('associations',{}))
        leagues=deepcopy(catalog.get('leagues',{}))
        clubs=deepcopy(catalog.get('clubs',{}))
        national_teams=deepcopy(catalog.get('national_teams',{}))
        for c in clubs.values():
            c.setdefault('cash',0.0); c.setdefault('market_value',max(0.1,float(c.get('prestige',20))*0.12))
        save={'world':{'current_year':int(season),'clubs':clubs,'leagues':leagues,
                       'countries':countries,'national_teams':national_teams},
              'history':{'latest_tables':{}},'simulation':{}}
        return cls(save,cup_registry,seed)

    def _cup_prizes(self):
        prizes={}
        champions=self.history.get('cup_champions',{})
        countries=self.cup_registry.get('countries',{}) if self.cup_registry else {}
        for cid,row in countries.items():
            cups={c['id']:c for c in row.get('cups',[])}
            for cup_id,rows in champions.items():
                if cup_id not in cups or not rows: continue
                cup=cups[cup_id]; latest=rows[-1]; club_id=latest.get('club_id')
                if not club_id: continue
                # Prize scale is simulation currency units, bounded by field size.
                participants=sum(1 for c in self.save['world'].get('clubs',{}).values()
                                 if c.get('league_id') in {l['id'] for l in self.save['world'].get('leagues',{}).values()
                                    if l.get('country_id')==cid and int(cup.get('min_level',1))<=int(l.get('level',99))<=int(cup.get('max_level',99))})
                base=1.5 + min(6.0, participants*0.025)
                if cup.get('primary_for_continental'): base*=1.35
                prizes[club_id]=round(prizes.get(club_id,0.0)+base,2)
        return prizes

    def _ai_policy(self, club, decision=None):
        intent=(decision or {}).get('intent','consolidate')
        profit=float(club.get('last_economy',{}).get('profit',0.0))
        cash=max(0.0,float(club.get('cash',0.0)))
        available=max(0.0, cash*0.12 + max(0.0,profit)*0.30)
        weights={
            'compete': {'transfer':.55,'scouting':.20,'youth':.10,'infrastructure':.15},
            'develop': {'transfer':.15,'scouting':.30,'youth':.40,'infrastructure':.15},
            'consolidate': {'transfer':.10,'scouting':.10,'youth':.20,'infrastructure':.60},
            'rebuild': {'transfer':.20,'scouting':.30,'youth':.30,'infrastructure':.20},
            'scout': {'transfer':.20,'scouting':.55,'youth':.20,'infrastructure':.05},
        }.get(intent, {'transfer':.25,'scouting':.25,'youth':.25,'infrastructure':.25})
        budget={k:round(available*v,2) for k,v in weights.items()}
        club['economic_profile']={'season':self.save['world']['current_year'],'intent':intent,'available_budget':round(available,2),'allocation':budget}
        club['transfer_budget']=budget['transfer']
        return club['economic_profile']

    def settle_season(self, ai_state=None, continental_participants=None):
        year=self.save['world']['current_year']
        prizes=self._cup_prizes()
        economy=ClubEconomy(self.save)
        club_reports=economy.settle_season(continental_participants=continental_participants or set(), prize_money=prizes)
        selection_reports=SelectionEconomy(self.save).settle_season()
        decisions=(ai_state or {}).get('decisions',{})
        for cid,club in self.save['world'].get('clubs',{}).items():
            self._ai_policy(club,decisions.get(cid))
        market_reports=ClubMarket(self.save).refresh_market()
        index=self.global_market_index(market_reports)
        row={'season':year,'club_economy_reports':len(club_reports),'selection_economy_reports':len(selection_reports),
             'cup_prize_total':round(sum(prizes.values()),2),'market_reports':len(market_reports),'market_index':index}
        self.history.setdefault('global_economy_market',[]).append(row)
        return row

    def global_market_index(self, reports=None):
        reports=reports if reports is not None else ClubMarket(self.save).refresh_market()
        values=[float(r.get('market_value',0.0)) for r in reports if float(r.get('market_value',0.0))>0]
        if not values: return {'clubs':0,'average_value':0.0,'median_value':0.0,'distressed_rate':0.0}
        values.sort(); mid=len(values)//2
        median=values[mid] if len(values)%2 else (values[mid-1]+values[mid])/2
        distressed=sum(1 for r in reports if r.get('status')=='distressed')
        return {'clubs':len(values),'average_value':round(sum(values)/len(values),3),'median_value':round(median,3),'distressed_rate':round(distressed/len(values),4)}

    def validate(self):
        errors=[]
        clubs=self.save.get('world',{}).get('clubs',{})
        for cid,c in clubs.items():
            if float(c.get('cash',0.0))<0: errors.append(f'negative cash {cid}')
            if float(c.get('market_value',0.0))<0: errors.append(f'negative market value {cid}')
            if float(c.get('transfer_budget',0.0))<0: errors.append(f'negative transfer budget {cid}')
        return errors
