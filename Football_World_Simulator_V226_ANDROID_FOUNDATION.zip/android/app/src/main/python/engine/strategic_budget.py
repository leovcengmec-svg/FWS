class StrategicBudget:
    """Allocates capital by strategic area; spending changes capacity, not guaranteed results."""
    CLUB_AREAS = {
        'training': 'training', 'youth': 'youth', 'stadium': 'stadium',
        'marketing': 'marketing', 'football': 'football', 'management': 'management'
    }
    SELECTION_AREAS = {
        'training': 'training', 'technical': 'technical', 'youth': 'youth',
        'scouting': 'scouting', 'management': 'management'
    }

    def __init__(self, save, rng=None):
        import random
        self.save, self.rng = save, rng or random.Random()
        self.history = save.setdefault('history', {}).setdefault('strategic_budgets', [])

    def _check(self, amount):
        if amount <= 0:
            raise ValueError('valor deve ser positivo')

    def plan_club(self, club_id, allocations):
        club = self.save['world']['clubs'][club_id]
        total = sum(float(v) for v in allocations.values())
        self._check(total)
        club.setdefault('strategic_budget', {})
        for area, amount in allocations.items():
            if area not in self.CLUB_AREAS: raise ValueError(f'área de clube inválida: {area}')
            amount = float(amount)
            self._check(amount)
            club['strategic_budget'][area] = club['strategic_budget'].get(area, 0.0) + amount
        club['cash'] = max(0.0, float(club.get('cash', 0)) - total)
        club['investment'] = club.setdefault('investment', {})
        for area, amount in allocations.items():
            club['investment'][area] = club['investment'].get(area, 0.0) + float(amount)
        self._apply_club_effects(club, allocations)
        record = {'type':'club_budget','club_id':club_id,'allocations':{k:round(float(v),2) for k,v in allocations.items()},'total':round(total,2),'season':self.save['world']['current_year']}
        self.history.append(record)
        return record

    def _apply_club_effects(self, club, allocations):
        # Immediate effects are deliberately modest; the season engine still decides results.
        for area, amount in allocations.items():
            gain = (float(amount) ** 0.5) * 0.08
            if area == 'football':
                club['attack'] = min(99, club.get('attack', 50) + gain)
                club['defense'] = min(99, club.get('defense', 50) + gain * .85)
            elif area == 'training':
                club['training_level'] = min(100, club.get('training_level', 40) + gain)
            elif area == 'youth':
                club['youth_level'] = min(100, club.get('youth_level', 40) + gain)
            elif area == 'stadium':
                club['stadium_capacity'] = int(club.get('stadium_capacity', 5000) + amount * 25)
            elif area == 'marketing':
                club['marketing_level'] = min(100, club.get('marketing_level', 40) + gain)
            elif area == 'management':
                club['management_level'] = min(100, club.get('management_level', 40) + gain)

    def plan_selection(self, team_id, allocations, investor=None):
        team = self.save['world']['national_teams'][team_id]
        total = sum(float(v) for v in allocations.values()); self._check(total)
        if investor is not None:
            if investor.career['cash'] < total: raise ValueError('capital insuficiente')
            investor.career['cash'] -= total
        from .selection_development import SelectionDevelopment
        for area, amount in allocations.items():
            if area not in self.SELECTION_AREAS: raise ValueError(f'área de seleção inválida: {area}')
            SelectionDevelopment(self.save, self.rng).invest(team_id, float(amount), area, investor_id='player' if investor else None)
        record={'type':'selection_budget','team_id':team_id,'allocations':{k:round(float(v),2) for k,v in allocations.items()},'total':round(total,2),'financial_return':0.0,'season':self.save['world']['current_year']}
        self.history.append(record)
        return record
