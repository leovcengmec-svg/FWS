"""V144 — whole-catalog integrity audit."""
from collections import defaultdict, Counter
BRAZIL_ALIASES={'BRA_D2','BRA_D3','BRA_D4'}

def audit(catalog):
    clubs=catalog.get('clubs',{}); leagues=catalog.get('leagues',{}); assocs=catalog.get('associations',{})
    issues=[]
    active=[c for c in clubs.values() if c.get('active',True)]
    # ID/name duplicates among active clubs
    seen_ids=set(); dup_ids=[]
    names=defaultdict(list)
    for c in active:
        cid=c.get('id')
        if cid in seen_ids: dup_ids.append(cid)
        seen_ids.add(cid)
        names[(c.get('country_id'), c.get('name','').strip().casefold())].append(cid)
        lid=c.get('league_id')
        if lid not in leagues: issues.append({'type':'club_missing_league','club_id':cid,'league_id':lid})
        else:
            if leagues[lid].get('country_id') != c.get('country_id'):
                issues.append({'type':'club_league_country_mismatch','club_id':cid,'league_id':lid,'club_country':c.get('country_id'),'league_country':leagues[lid].get('country_id')})
    duplicate_names={k:v for k,v in names.items() if len(v)>1}
    # League-side references
    reverse=defaultdict(list)
    for lid,l in leagues.items():
        for cid in l.get('club_ids',[]) or []:
            reverse[lid].append(cid)
            if cid not in clubs:
                issues.append({'type':'league_missing_club','league_id':lid,'club_id':cid})
            elif lid not in BRAZIL_ALIASES and clubs[cid].get('league_id') != lid and clubs[cid].get('active',True):
                issues.append({'type':'league_club_reverse_divergence','league_id':lid,'club_id':cid,'club_league':clubs[cid].get('league_id')})
    # declared counts vs active reality
    count_mismatch=[]
    for lid,l in leagues.items():
        n=sum(1 for c in active if c.get('league_id')==lid)
        if lid not in BRAZIL_ALIASES and l.get('club_count') != n: count_mismatch.append((lid,l.get('club_count'),n))
    # levels per country
    levels=defaultdict(list)
    for lid,l in leagues.items():
        if lid in BRAZIL_ALIASES: continue
        levels[l.get('country_id')].append((l.get('level'),lid))
    missing_level=[]; duplicate_level=[]
    for country, rows in levels.items():
        vals=[x[0] for x in rows if isinstance(x[0],int)]
        if not vals: continue
        expected=set(range(1,max(vals)+1)); got=set(vals)
        for lv in sorted(expected-got): missing_level.append((country,lv))
        for lv,n in Counter(vals).items():
            if n>1: duplicate_level.append((country,lv,n))
    return {
      'active_clubs':len(active),'leagues':len(leagues),'associations':len(assocs),
      'duplicate_active_ids':len(dup_ids),'duplicate_active_names':len(duplicate_names),
      'issues_total':len(issues),'club_count_mismatches':len(count_mismatch),
      'missing_levels':len(missing_level),'duplicate_levels':len(duplicate_level),
      'issue_samples':issues[:100],'duplicate_name_samples':list(duplicate_names.items())[:50],
      'club_count_mismatch_samples':count_mismatch[:100],
      'missing_level_samples':missing_level[:100],'duplicate_level_samples':duplicate_level[:100]
    }
