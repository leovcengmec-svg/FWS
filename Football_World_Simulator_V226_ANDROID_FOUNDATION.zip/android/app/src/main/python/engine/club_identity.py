"""Dynamic sporting identity and competitive tier for clubs.

Identity is descriptive: it summarizes sporting strength, prestige and recent
achievement. It does not move cash, ownership or directly alter match results.
"""

class ClubIdentityEngine:
    TIERS = ("local", "regional", "national", "continental", "elite")

    def __init__(self, strength_weight=.60, prestige_weight=.25, history_weight=.15):
        self.strength_weight = float(strength_weight)
        self.prestige_weight = float(prestige_weight)
        self.history_weight = float(history_weight)

    @staticmethod
    def _clamp(v, lo=0.0, hi=99.0):
        return round(max(lo, min(hi, float(v))), 3)

    def initialize(self, club):
        club.setdefault("identity_score", 50.0)
        club.setdefault("identity_tier", self.tier(club["identity_score"]))
        club.setdefault("competitive_level", club["identity_tier"])
        club.setdefault("identity_history", [])
        return club

    def tier(self, score):
        s = float(score)
        if s >= 85: return "elite"
        if s >= 70: return "continental"
        if s >= 55: return "national"
        if s >= 40: return "regional"
        return "local"

    def update(self, club, sporting_strength, prestige=None, achievement_score=50.0, season=None):
        self.initialize(club)
        prestige = club.get("prestige", 50) if prestige is None else prestige
        target = (
            float(sporting_strength) * self.strength_weight
            + float(prestige) * self.prestige_weight
            + float(achievement_score) * self.history_weight
        )
        old = float(club["identity_score"])
        new = self._clamp(old * .75 + target * .25)
        tier = self.tier(new)
        club["identity_score"] = new
        club["identity_tier"] = tier
        club["competitive_level"] = tier
        entry = {"season": season, "score": new, "tier": tier,
                 "achievement_score": round(float(achievement_score), 3)}
        club["identity_history"].append(entry)
        return {"old": old, "new": new, "delta": round(new-old, 3), "tier": tier}

    def profile(self, club):
        self.initialize(club)
        return {"club_id": club.get("id"), "score": club["identity_score"],
                "tier": club["identity_tier"], "competitive_level": club["competitive_level"]}
