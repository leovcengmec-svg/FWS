class FinancialRisk:
    """V33: risk exposure between investor liquidity and owned-club obligations."""
    def __init__(self, save):
        from .investor_finance import InvestorFinance
        self.save = save
        self.finance = InvestorFinance(save)

    def _clubs(self):
        clubs = self.save.get('world', {}).get('clubs', {})
        return [clubs[cid] for cid in self.finance.career.get('owned_clubs', []) if cid in clubs]

    def snapshot(self):
        clubs = self._clubs()
        cash = float(self.finance.available_cash())
        total_value = sum(float(c.get('market_value', 0) or 0) for c in clubs)
        club_debt = sum(float(c.get('debt', 0) or 0) for c in clubs)
        distress = sum(1 for c in clubs if c.get('financial_status') in {'distressed','at_risk','crisis','insolvent'})
        avg_flow = sum(float(r.get('flow', 0) or 0) for r in self.finance.history[-8:]) / max(1, len(self.finance.history[-8:]))
        exposure_ratio = None if cash <= 0 else round(total_value / cash, 4)
        debt_ratio = None if total_value <= 0 else round(club_debt / total_value, 4)
        if distress or club_debt > total_value * .50:
            level = 'high'
        elif (exposure_ratio is not None and exposure_ratio > 10) or avg_flow < 0:
            level = 'medium'
        else:
            level = 'low'
        return {
            'owned_clubs': len(clubs),
            'owned_club_value': round(total_value, 2),
            'owned_club_debt': round(club_debt, 2),
            'available_cash': round(cash, 2),
            'club_value_to_available_cash': exposure_ratio,
            'club_debt_to_value': debt_ratio,
            'clubs_in_distress': distress,
            'average_weekly_flow': round(avg_flow, 2),
            'risk_level': level,
        }

    def alerts(self):
        s = self.snapshot()
        alerts = []
        if s['clubs_in_distress']:
            alerts.append('owned_club_distress')
        if s['club_debt_to_value'] is not None and s['club_debt_to_value'] > .50:
            alerts.append('high_club_debt')
        if s['club_value_to_available_cash'] is not None and s['club_value_to_available_cash'] > 10:
            alerts.append('high_asset_exposure')
        if s['average_weekly_flow'] < 0:
            alerts.append('negative_investor_flow')
        return alerts
