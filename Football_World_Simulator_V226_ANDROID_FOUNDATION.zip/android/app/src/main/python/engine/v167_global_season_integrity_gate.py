"""V167 — Global Season Integrity Gate.

V167 is the mandatory acceptance boundary above V166. It validates the
existing season motor/checkpoint/reconciliation layers before and after a
season run. It never replaces sporting engines and never introduces players.
"""
from __future__ import annotations
from copy import deepcopy
import pickle

from .v164_global_season_motor import V164GlobalSeasonMotor
from .v165_global_season_checkpoint import V165GlobalSeasonCheckpoint
from .v166_global_season_reconciliation import V166GlobalSeasonReconciliation
from .world_integrity import assert_world_integrity


class V167GlobalSeasonIntegrityGate:
    VERSION = "V167"
    SCHEMA = 1

    def __init__(self, save, seed=167):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("global_season_integrity_gate", [])

    def _forbidden(self):
        return "players" in self._world() or "player_transfers" in self._history()

    def preflight(self, season):
        """Validate all previously closed state before executing `season`."""
        errors = []
        if self._forbidden():
            errors.append("player_system_forbidden")

        errors.extend(V164GlobalSeasonMotor(self.save).validate())
        errors.extend(V165GlobalSeasonCheckpoint(self.save).validate())
        errors.extend(V166GlobalSeasonReconciliation(self.save).validate())

        year = int(season)
        current_year = int(self._world().get("current_year", 2026))
        if current_year != year:
            errors.append(f"world_year_mismatch:{current_year}!={year}")

        checkpoints = self._history().get("global_season_checkpoints", [])
        if any(int(r.get("season", -1)) == year for r in checkpoints):
            errors.append(f"season_already_closed:{year}")

        reconciliations = self._history().get("global_season_reconciliation", [])
        if any(int(r.get("season", -1)) == year for r in reconciliations):
            errors.append(f"season_already_reconciled:{year}")

        return errors

    def run_season(self, *, season=None, advance_year=True, club_context=None,
                   association_context=None, career_results=None):
        year = int(self._world().get("current_year", 2026) if season is None else season)
        errors = self.preflight(year)
        if errors:
            raise ValueError("V167 integrity gate preflight failed: " + "; ".join(errors))

        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            result = V166GlobalSeasonReconciliation(self.save, seed=self.seed + 166).run_season(
                season=year,
                advance_year=advance_year,
                club_context=club_context,
                association_context=association_context,
                career_results=career_results,
            )
            assert_world_integrity(self.save)

            post_errors = []
            post_errors.extend(V164GlobalSeasonMotor(self.save).validate())
            post_errors.extend(V165GlobalSeasonCheckpoint(self.save).validate())
            post_errors.extend(V166GlobalSeasonReconciliation(self.save).validate())
            if self._forbidden():
                post_errors.append("player_system_forbidden")
            if int(self._world().get("current_year", year)) != year + 1:
                post_errors.append("world_year_not_advanced")
            if post_errors:
                raise ValueError("V167 integrity gate postflight failed: " + "; ".join(post_errors))

            reconciliation = result.get("season_reconciliation", {})
            gate_row = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "season": year,
                "status": "accepted",
                "checkpoint_fingerprint": reconciliation.get("checkpoint_fingerprint"),
                "previous_checkpoint_fingerprint": reconciliation.get("previous_checkpoint_fingerprint"),
                "reconciliation_chain": reconciliation.get("chain", []),
                "world_year_before": year,
                "world_year_after": int(self._world().get("current_year", year)),
                "source_versions": ["V164", "V165", "V166"],
                "player_layer_forbidden": True,
            }
            self._ledger().append(deepcopy(gate_row))
            self._world()["global_season_integrity_gate_version"] = self.VERSION
            self._world()["global_season_integrity_gate_status"] = "accepted"

            result = deepcopy(result)
            result["season_integrity_gate"] = deepcopy(gate_row)
            return result
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        if self._forbidden():
            errors.append("player_system_forbidden")

        gate_rows = self._ledger()
        reconciliations = {
            int(r.get("season", -1)): r
            for r in self._history().get("global_season_reconciliation", [])
        }
        seen = set()
        for row in gate_rows:
            season = int(row.get("season", -1))
            if season in seen:
                errors.append(f"gate_duplicate:{season}")
            seen.add(season)
            if row.get("version") != self.VERSION:
                errors.append(f"wrong_version:{season}")
            if row.get("status") != "accepted":
                errors.append(f"gate_not_accepted:{season}")
            if row.get("source_versions") != ["V164", "V165", "V166"]:
                errors.append(f"source_chain_invalid:{season}")
            reconciliation = reconciliations.get(season)
            if reconciliation is None:
                errors.append(f"gate_missing_reconciliation:{season}")
            else:
                if row.get("checkpoint_fingerprint") != reconciliation.get("checkpoint_fingerprint"):
                    errors.append(f"gate_fingerprint_mismatch:{season}")
                if row.get("reconciliation_chain") != reconciliation.get("chain"):
                    errors.append(f"gate_chain_mismatch:{season}")
            if row.get("world_year_after") != season + 1:
                errors.append(f"gate_year_invalid:{season}")
        return errors
