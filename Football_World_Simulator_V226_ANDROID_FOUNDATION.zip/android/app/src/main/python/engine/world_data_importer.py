"""Deterministic import/merge service for the production world database."""
import copy
from .world_data_schema import validate_dataset

class WorldDataImporter:
    SCHEMA_VERSION = 1

    def __init__(self, save):
        self.save = save
        self.world = save.setdefault("world", {})

    def validate(self, dataset):
        return validate_dataset(dataset)

    def import_dataset(self, dataset, mode="replace_world_data"):
        errors = self.validate(dataset)
        if errors:
            raise ValueError("World dataset invalid: " + "; ".join(errors))
        if mode not in {"replace_world_data", "merge"}:
            raise ValueError("unsupported import mode")
        keys = ("countries", "leagues", "clubs", "national_teams")
        if mode == "replace_world_data":
            for key in keys:
                self.world[key] = {row["id"]: copy.deepcopy(row) for row in dataset.get(key, [])}
        else:
            for key in keys:
                target = self.world.setdefault(key, {})
                for row in dataset.get(key, []):
                    rid = row["id"]
                    if rid in target:
                        raise ValueError(f"duplicate import id {key}:{rid}")
                    target[rid] = copy.deepcopy(row)
        self._rebuild_league_club_links()
        self.world.setdefault("database", {})["schema_version"] = self.SCHEMA_VERSION
        self.world["database"]["source"] = dataset.get("metadata", {}).get("source", "unspecified")
        self.world["database"]["dataset_version"] = dataset.get("metadata", {}).get("version", "unspecified")
        return {k: len(self.world.get(k, {})) for k in keys}

    def _rebuild_league_club_links(self):
        for league in self.world.get("leagues", {}).values():
            league["club_ids"] = []
        for club in self.world.get("clubs", {}).values():
            league = self.world.get("leagues", {}).get(club.get("league_id"))
            if league is not None:
                league.setdefault("club_ids", []).append(club["id"])
        for league in self.world.get("leagues", {}).values():
            league["club_ids"] = sorted(set(league.get("club_ids", [])))


    def import_league_pack(self, dataset):
        """Import a real-world league/club pack into an existing association world.

        The pack is intentionally scoped: countries and national teams already come
        from the canonical association registry and are not replaced.
        """
        errors = validate_dataset(dataset, required_collections=("leagues", "clubs"))
        if errors:
            raise ValueError("League pack invalid: " + "; ".join(errors))
        countries = self.world.get("countries", {})
        leagues = self.world.setdefault("leagues", {})
        clubs = self.world.setdefault("clubs", {})
        for league in dataset.get("leagues", []):
            if league["country_id"] not in countries:
                raise ValueError(f"league references unknown world country: {league['country_id']}")
            if league["id"] in leagues:
                raise ValueError(f"duplicate league import id: {league['id']}")
        for club in dataset.get("clubs", []):
            if club["country_id"] not in countries:
                raise ValueError(f"club references unknown world country: {club['country_id']}")
            if club["league_id"] not in {x["id"] for x in dataset.get("leagues", [])}:
                raise ValueError(f"club references league outside pack: {club['id']}")
            if club["id"] in clubs:
                raise ValueError(f"duplicate club import id: {club['id']}")
        for league in dataset.get("leagues", []):
            leagues[league["id"]] = copy.deepcopy(league)
            leagues[league["id"]].setdefault("club_ids", [])
        for club in dataset.get("clubs", []):
            clubs[club["id"]] = copy.deepcopy(club)
            leagues[club["league_id"]].setdefault("club_ids", []).append(club["id"])
        for league in leagues.values():
            league["club_ids"] = sorted(set(league.get("club_ids", [])))
        db = self.world.setdefault("database", {})
        packs = db.setdefault("loaded_packs", [])
        packs.append({"id": dataset.get("metadata", {}).get("version", "unspecified"),
                      "source": dataset.get("metadata", {}).get("source", "unspecified"),
                      "scope": dataset.get("metadata", {}).get("scope", "unspecified"),
                      "season": dataset.get("metadata", {}).get("season")})
        return {"leagues": len(dataset.get("leagues", [])), "clubs": len(dataset.get("clubs", []))}
