"""V173 — World Intelligence Core.

Adds the first autonomous decision layer of Grande Atualização 2.  Decisions are
simulation intents only: no player layer, player transfers, or immediate cash/
ownership mutations are introduced.  The engine consumes the existing world
state and produces deterministic, bounded intents for clubs, associations and
competitions.  V174-V176 are responsible for applying those intents.
"""
from __future__ import annotations
import hashlib
import pickle
from copy import deepcopy

class V173WorldIntelligenceCore:
    VERSION = "V173"
    SCHEMA = 1
    CLUB_INTENTS = ("compete", "develop", "consolidate", "rebuild", "expand")
    ASSOCIATION_INTENTS = ("protect_competition", "develop_pathway", "stabilize", "expand_calendar")
    COMPETITION_INTENTS = ("preserve_balance", "increase_competitiveness", "protect_identity", "expand_reach")

    def __init__(self, save, seed=173):
        self.save = save
        self.seed = int(seed)

    def _world(self): return self.save.setdefault("world", {})
    def _history(self): return self.save.setdefault("history", {})

    def _noise(self, key):
        d = hashlib.sha256(f"{self.seed}:{key}".encode()).digest()
        return int.from_bytes(d[:8], "big") / float(2**64 - 1)

    @staticmethod
    def _clamp(value, lo=0.0, hi=100.0):
        return round(max(lo, min(hi, float(value))), 3)

    def _club_decision(self, club, season):
        strength = float(club.get("sporting_strength", club.get("attack", 50.0)))
        prestige = float(club.get("prestige", 50.0))
        cash = float(club.get("cash", 50.0))
        stability = float(club.get("management_stability", 50.0))
        n = self._noise(f"club:{club.get('id')}:{season}")
        ambition = self._clamp(.45 * strength + .30 * prestige + .15 * stability + .10 * n * 100)
        resilience = self._clamp(.55 * stability + .30 * min(cash, 100) + .15 * prestige)
        if strength < 40 and resilience >= 50:
            intent = "rebuild"
        elif resilience < 35:
            intent = "consolidate"
        elif ambition >= 72 and strength >= 60:
            intent = "compete"
        elif strength < 62:
            intent = "develop"
        else:
            intent = "expand" if n >= .78 else "compete"
        priorities = {
            "compete": {"sporting": .50, "development": .15, "stability": .20, "reach": .15},
            "develop": {"sporting": .25, "development": .45, "stability": .20, "reach": .10},
            "consolidate": {"sporting": .15, "development": .15, "stability": .60, "reach": .10},
            "rebuild": {"sporting": .20, "development": .40, "stability": .30, "reach": .10},
            "expand": {"sporting": .30, "development": .20, "stability": .15, "reach": .35},
        }[intent]
        return {"entity_id": club.get("id"), "entity_type": "club", "season": int(season),
                "intent": intent, "ambition": ambition, "resilience": resilience,
                "confidence": round(.55 + n * .40, 3), "priorities": priorities,
                "effects_deferred_to": ["V174", "V175"]}

    def _association_decision(self, association, season):
        aid = association.get("id")
        n = self._noise(f"association:{aid}:{season}")
        coefficient = float(association.get("coefficient", 50.0))
        leagues = int(association.get("division_levels", 1) or 1)
        pressure = self._clamp((100 - coefficient) * .55 + min(leagues, 5) * 6 + n * 12)
        if pressure >= 65:
            intent = "develop_pathway"
        elif coefficient >= 70:
            intent = "protect_competition"
        elif leagues <= 1:
            intent = "expand_calendar"
        else:
            intent = "stabilize"
        return {"entity_id": aid, "entity_type": "association", "season": int(season),
                "intent": intent, "pressure": pressure, "confidence": round(.60 + n * .35, 3),
                "effects_deferred_to": ["V174", "V176"]}

    def _competition_decision(self, competition, season):
        cid = competition.get("id")
        n = self._noise(f"competition:{cid}:{season}")
        size = float(competition.get("size", competition.get("field_size", competition.get("club_count", 16))) or 16)
        international = bool(competition.get("confederation") or competition.get("type") in ("continental", "intercontinental"))
        if international and size >= 36:
            intent = "preserve_balance"
        elif size < 16:
            intent = "increase_competitiveness"
        elif n >= .75:
            intent = "expand_reach"
        else:
            intent = "protect_identity"
        return {"entity_id": cid, "entity_type": "competition", "season": int(season),
                "intent": intent, "field_size_signal": round(size, 3),
                "confidence": round(.58 + n * .37, 3),
                "effects_deferred_to": ["V175", "V176"]}

    def run(self, season=None, *, apply=False):
        """Generate one deterministic intelligence cycle.

        ``apply`` is intentionally restricted to recording the decision ledger;
        V173 never mutates sporting/economic source values.  This keeps V173
        composable with the already validated V164-V172 season pipeline.
        """
        world = self._world(); history = self._history()
        year = int(world.get("current_year", 2026) - 1 if season is None else season)
        if "players" in world or "player_transfers" in history:
            raise ValueError("V173 refuses forbidden player systems")
        clubs = world.get("clubs", {})
        associations = world.get("associations", world.get("countries", {}))
        competitions = world.get("competitions", {})
        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            club_decisions = {cid: self._club_decision(c, year) for cid, c in sorted(clubs.items())}
            association_decisions = {aid: self._association_decision(a, year) for aid, a in sorted(associations.items())}
            competition_decisions = {cid: self._competition_decision(c, year) for cid, c in sorted(competitions.items())}
            row = {"version": self.VERSION, "schema": self.SCHEMA, "season": year,
                   "status": "completed", "apply_mode": "ledger_only",
                   "clubs": club_decisions, "associations": association_decisions,
                   "competitions": competition_decisions,
                   "counts": {"clubs": len(club_decisions), "associations": len(association_decisions), "competitions": len(competition_decisions)},
                   "player_layer_forbidden": True,
                   "downstream_consumers": ["V174", "V175", "V176"]}
            history.setdefault("world_intelligence_cycles", []).append(deepcopy(row))
            world["world_intelligence_version"] = self.VERSION
            world["world_intelligence_status"] = "ready_for_v174_v176"
            world["world_intelligence_last_season"] = year
            world["world_intelligence_pending_effects"] = True
            return deepcopy(row)
        except Exception:
            self.save.clear(); self.save.update(pickle.loads(snapshot)); raise

    def validate(self):
        world = self._world(); history = self._history(); errors=[]
        if "players" in world or "player_transfers" in history: errors.append("player_system_forbidden")
        cycles = history.get("world_intelligence_cycles", [])
        for row in cycles:
            if row.get("version") != self.VERSION or row.get("status") != "completed": errors.append("invalid_cycle")
            counts=row.get("counts", {})
            if counts.get("clubs") != len(row.get("clubs", {})): errors.append("club_count_mismatch")
            if counts.get("associations") != len(row.get("associations", {})): errors.append("association_count_mismatch")
            if counts.get("competitions") != len(row.get("competitions", {})): errors.append("competition_count_mismatch")
            for decision in list(row.get("clubs", {}).values()) + list(row.get("associations", {}).values()) + list(row.get("competitions", {}).values()):
                if not 0 <= float(decision.get("confidence", 0)) <= 1: errors.append("confidence_out_of_range")
        return sorted(set(errors))
