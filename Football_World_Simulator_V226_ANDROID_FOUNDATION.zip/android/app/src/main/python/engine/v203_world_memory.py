"""V203 — World Alive: persistent reputation and legacy memory."""
from __future__ import annotations
from copy import deepcopy
class V203WorldMemory:
    VERSION='V203'
    def __init__(self,save): self.save=save
    def close_season(self,season=None):
        w=self.save.setdefault('world',{}); h=self.save.setdefault('history',{}); year=int(w.get('current_year',2026) if season is None else season)
        memory=w.setdefault('world_memory',{}); out=[]
        for cid,c in sorted(w.get('clubs',{}).items()):
            events=[e for e in h.get('world_events',[]) if e.get('entity_id')==cid and int(e.get('season',-1))==year]
            reactions=[r for r in h.get('world_reactions',[]) if r.get('entity_id')==cid and int(r.get('season',-1))==year]
            rec=memory.setdefault(cid,{'seasons':0,'events':0,'major_events':0,'trajectory':[]})
            rec['seasons']+=1; rec['events']+=len(events); rec['major_events']+=sum(e.get('severity')=='major' for e in events)
            rec['trajectory'].append({'season':year,'prestige':round(float(c.get('prestige',50)),3),'sporting_strength':round(float(c.get('sporting_strength',50)),3),'events':len(events),'reactions':len(reactions)})
            rec['trajectory']=rec['trajectory'][-10:]; out.append({'club_id':cid,'season':year,'events':len(events),'prestige':c.get('prestige',50)})
        h.setdefault('world_memory_cycles',[]).append({'version':self.VERSION,'season':year,'clubs':len(out)})
        w['world_memory_version']=self.VERSION; return deepcopy(out)
    def snapshot(self,club_id): return deepcopy(self.save.setdefault('world',{}).setdefault('world_memory',{}).get(club_id,{}))
    def validate(self): return []
