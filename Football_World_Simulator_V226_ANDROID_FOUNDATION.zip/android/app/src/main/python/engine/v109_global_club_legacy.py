"""V109 — Global Club World Legacy.

Persists the sporting legacy created by the annual Intercontinental and
quadrennial Super World competitions. Historical legacy is deliberately kept
separate from the current global ranking: titles and participation records are
memory, not a direct replacement for current sporting strength.
"""
from __future__ import annotations
from copy import deepcopy

from .v108_global_club_world_draw import V108GlobalClubWorldDraw


class V109GlobalClubLegacy(V108GlobalClubWorldDraw):
    VERSION = "V109"

    def record_global_club_legacy(self, execution=None, competition_type=None):
        execution = execution or self.save.get("world", {}).get("super_world_execution")
        if not execution:
            raise ValueError("global club world execution is required")
        year = int(execution.get("season", self.save.get("world", {}).get("current_year", 2026)))
        competition_type = competition_type or execution.get("competition_type", "super_world")
        champion = execution.get("champion")
        participants = execution.get("participants")
        if participants is None:
            participants = len({c.get("id") for g in execution.get("groups", []) for c in g.get("clubs", []) if c.get("id")})
        # Keep the historical record compact and append-only. Do not overwrite
        # prior seasons and do not mutate the real-world catalog.
        record = {
            "version": self.VERSION,
            "season": year,
            "competition": competition_type,
            "champion": champion,
            "participants": int(participants),
            "finalists": self._finalists(execution),
        }
        world = self.save.setdefault("world", {})
        history = world.setdefault("global_club_world_legacy", [])
        history.append(deepcopy(record))

        club_legacy = world.setdefault("club_global_legacy", {})
        participant_ids = self._participant_ids(execution)
        for cid in participant_ids:
            item = club_legacy.setdefault(cid, {
                "club_id": cid,
                "global_participations": 0,
                "global_titles": 0,
                "global_runner_ups": 0,
                "global_final_appearances": 0,
                "last_global_season": None,
            })
            item["global_participations"] += 1
            item["last_global_season"] = year
        if champion:
            item = club_legacy.setdefault(champion, {
                "club_id": champion,
                "global_participations": 0,
                "global_titles": 0,
                "global_runner_ups": 0,
                "global_final_appearances": 0,
                "last_global_season": None,
            })
            item["global_titles"] += 1
            item["global_final_appearances"] += 1
        for cid in record["finalists"]:
            item = club_legacy.setdefault(cid, {
                "club_id": cid,
                "global_participations": 0,
                "global_titles": 0,
                "global_runner_ups": 0,
                "global_final_appearances": 0,
                "last_global_season": None,
            })
            # Champion was already marked as a finalist above; the appearance
            # counter must remain one final appearance per season.
            if cid != champion:
                item["global_final_appearances"] += 1
                item["global_runner_ups"] += 1

        self.save.setdefault("history", {}).setdefault("global_club_world_legacy", []).append(deepcopy(record))
        return deepcopy(record)

    @staticmethod
    def _participant_ids(execution):
        ids = []
        seen = set()
        for group in execution.get("groups", []):
            for club in group.get("clubs", []):
                cid = club.get("id")
                if cid and cid not in seen:
                    seen.add(cid); ids.append(cid)
        return ids

    @staticmethod
    def _finalists(execution):
        knockout = execution.get("knockout_matches", [])
        final = [m for m in knockout if int(m.get("round_no", 0)) == 5]
        if not final:
            return []
        match = final[-1]
        return [x for x in (match.get("home_id"), match.get("away_id")) if x]

    def legacy_profile(self, club_id):
        return deepcopy(self.save.get("world", {}).get("club_global_legacy", {}).get(club_id, {
            "club_id": club_id,
            "global_participations": 0,
            "global_titles": 0,
            "global_runner_ups": 0,
            "global_final_appearances": 0,
            "last_global_season": None,
        }))

    def run_super_world(self, season=None, cycle_years=4, seed=109):
        execution = super().run_super_world(season, cycle_years, seed)
        if not execution:
            return None
        execution = deepcopy(execution)
        execution["version"] = self.VERSION
        self.save.setdefault("world", {})["super_world_execution"] = deepcopy(execution)
        self.save.setdefault("history", {}).setdefault("super_world", []).append(deepcopy(execution))
        self.record_global_club_legacy(execution, "super_world")
        return deepcopy(execution)

    def validate(self):
        errors = super().validate()
        state = self.save.get("world", {}).get("global_club_world_legacy")
        if state:
            seen_seasons = set()
            for row in state:
                if row.get("version") != self.VERSION:
                    errors.append("wrong global club legacy version")
                season = row.get("season")
                if season in seen_seasons:
                    errors.append("duplicate global club legacy season")
                seen_seasons.add(season)
                if int(row.get("participants", 0)) != 64:
                    errors.append("Super World legacy record must contain 64 participants")
            profiles = self.save.get("world", {}).get("club_global_legacy", {})
            for cid, profile in profiles.items():
                if profile.get("club_id") != cid:
                    errors.append("global club legacy profile id mismatch")
                if profile.get("global_titles", 0) > profile.get("global_participations", 0):
                    errors.append("global club legacy titles exceed participations")
        return errors
