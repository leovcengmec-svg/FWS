"""V177 — Finalization hardening and runtime invariants."""
from __future__ import annotations
import hashlib, json, pickle
from copy import deepcopy

class V177ReleaseHardening:
    VERSION='V177'; SCHEMA=1
    REQUIRED_WORLD=('clubs','leagues','competitions','countries','national_teams')
    def __init__(self,save): self.save=save
    def _world(self): return self.save.setdefault('world',{})
    def _history(self): return self.save.setdefault('history',{})
    def audit(self):
        w=self._world(); h=self._history(); errors=[]
        for k in self.REQUIRED_WORLD:
            if not isinstance(w.get(k),dict): errors.append(f'missing_world:{k}')
        if 'players' in w or 'player_transfers' in h: errors.append('player_system_forbidden')
        clubs=w.get('clubs',{})
        ids=list(clubs)
        if len(ids)!=len(set(ids)): errors.append('duplicate_club_ids')
        for cid,c in clubs.items():
            if not c.get('name'): errors.append(f'club_without_name:{cid}')
        return sorted(set(errors))
    def snapshot_signature(self):
        body=pickle.dumps(self.save,protocol=pickle.HIGHEST_PROTOCOL)
        return hashlib.sha256(body).hexdigest()
    def run(self):
        errors=self.audit()
        if errors: raise ValueError('V177 hardening failed: '+'; '.join(errors))
        row={'version':self.VERSION,'schema':self.SCHEMA,'status':'validated',
             'signature':self.snapshot_signature(),'counts':{
                 'clubs':len(self._world().get('clubs',{})),
                 'leagues':len(self._world().get('leagues',{})),
                 'competitions':len(self._world().get('competitions',{})),
                 'associations':len(self._world().get('countries',{}))}}
        self._history().setdefault('release_hardening',[]).append(deepcopy(row))
        self._world()['release_hardening_version']=self.VERSION
        self._world()['release_hardening_status']='validated'
        return deepcopy(row)
    def validate(self):
        return self.audit()
