"""FIFA member-association layer for the production world database.

The simulator keeps the development seed separate from the production association
registry.  This module turns the 211-association registry into deterministic
country and men's national-team records without inventing clubs or leagues.
"""
import json
from pathlib import Path

EXPECTED_ASSOCIATIONS = 211
CONFEDERATIONS = ("AFC", "CAF", "CONCACAF", "CONMEBOL", "OFC", "UEFA")


def load_association_registry(path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    associations = payload.get("associations", {})
    errors = []
    if payload.get("target_fifa_associations") != EXPECTED_ASSOCIATIONS:
        errors.append("registry target must be 211")
    if len(associations) != EXPECTED_ASSOCIATIONS:
        errors.append(f"registry contains {len(associations)} associations, expected {EXPECTED_ASSOCIATIONS}")
    seen = set()
    for aid, row in associations.items():
        if aid in seen:
            errors.append(f"duplicate association {aid}")
        seen.add(aid)
        if row.get("id") != aid:
            errors.append(f"association key/id mismatch {aid}")
        if not row.get("name"):
            errors.append(f"association {aid} missing name")
        if row.get("confederation") not in CONFEDERATIONS:
            errors.append(f"association {aid} has invalid confederation")
    if errors:
        raise ValueError("Invalid association registry: " + "; ".join(errors))
    return payload


def build_association_world(path):
    payload = load_association_registry(path)
    associations = payload["associations"]
    countries = {}
    national_teams = {}
    for aid, row in sorted(associations.items()):
        countries[aid] = {
            "id": aid,
            "name": row["name"],
            "confederation": row["confederation"],
            "association_id": aid,
            "active": bool(row.get("active", True)),
            "data_source": "FIFA_MEMBER_ASSOCIATIONS_REGISTRY",
        }
        national_teams[f"NT_{aid}"] = {
            "id": f"NT_{aid}",
            "name": row["name"],
            "country_id": aid,
            "confederation": row["confederation"],
            "association_id": aid,
            "data_source": "FIFA_MEMBER_ASSOCIATIONS_REGISTRY",
        }
    return {
        "metadata": {
            "source": "FIFA Member Associations",
            "registry_version": payload.get("schema_version"),
            "association_count": len(associations),
            "confederation_count": len(CONFEDERATIONS),
        },
        "countries": countries,
        "national_teams": national_teams,
    }
