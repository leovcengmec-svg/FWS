from collections import defaultdict

class CoefficientEngine:
    def __init__(self, window=5, decay=0.75):
        self.window=window
        self.decay=decay

    def update_league(self, save, league_id, season_points):
        league=save["world"]["leagues"][league_id]
        hist=save.setdefault("history",{}).setdefault("coefficient_points",{}).setdefault(league_id,[])
        hist.append({"season":save["world"]["current_year"],"points":float(season_points)})
        if len(hist)>self.window: del hist[:-self.window]
        weights=[self.decay**i for i in range(len(hist)-1,-1,-1)]
        weighted=sum(h["points"]*w for h,w in zip(hist,weights))
        denom=sum(weights) or 1
        league["coefficient"]=round(max(1.0,weighted/denom),3)
        return league["coefficient"]

    def confederation_ranking(self, save, confederation):
        rows=[]
        for l in save["world"]["leagues"].values():
            country=save["world"].get("countries",{}).get(l["country_id"],{})
            if country.get("confederation")==confederation:
                rows.append((l["id"],l.get("coefficient",1.0)))
        return sorted(rows,key=lambda x:(-x[1],x[0]))
