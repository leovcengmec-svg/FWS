"""V100 — Autonomous World Cycle.

Closes the autonomous world pulse on top of the existing V89 world dynamics
and V99 adaptive feedback layers. It reuses the aggregate match engine, does
not create individual players, a second sporting engine, or synthetic clubs.
"""
from __future__ import annotations
from copy import deepcopy

from .v99_adaptive_world_feedback import V99AdaptiveWorldFeedback
from .world_dynamics import WorldDynamics


class V100AutonomousWorldCycle(V99AdaptiveWorldFeedback):
    VERSION = "V100"

    def advance_world_cycle(self, season=None, seed=100, max_leagues=None):
        """Execute one deterministic global world pulse using the existing V89 engine."""
        world = self.save.setdefault("world", {})
        catalog = self._catalog_from_save()
        if not catalog.get("clubs") or not catalog.get("leagues"):
            raise ValueError("catálogo mundial incompleto")
        year = int(season if season is not None else world.get("current_year", 2026))
        dynamics = WorldDynamics(catalog, seed=int(seed))
        state = dynamics.initialize_season(year)

        league_ids = sorted(state["leagues_state"])
        if max_leagues is not None:
            league_ids = league_ids[:max(0, int(max_leagues))]
        completed = 0
        matches = 0
        for offset, lid in enumerate(league_ids):
            row = state["leagues_state"][lid]
            if len(row.get("club_ids", [])) < 2:
                continue
            dynamics.simulate_league(state, lid, seed_offset=offset)
            completed += 1
            matches += sum(int(x.get("played", 0)) for x in row.get("standings", [])) // 2

        movements = dynamics.apply_promotion_relegation(state)
        active_club = self.active.active.active_entities().get("club_id")
        active_row = None
        if active_club:
            for row in state["leagues_state"].values():
                for pos, item in enumerate(row.get("standings", []), start=1):
                    if item.get("club_id") == active_club:
                        active_row = {"league_id": row["league_id"], "position": pos, **deepcopy(item)}
                        break
                if active_row:
                    break

        # Keep generated season state separate from the verified catalog.
        world["current_year"] = year
        world["autonomous_cycle"] = {
            "version": self.VERSION,
            "season": year,
            "seed": int(seed),
            "leagues_processed": len(league_ids),
            "leagues_completed": completed,
            "matches_simulated": matches,
            "promotion_relegation_pairs": len(movements),
            "active_club_result": active_row,
            "state": state,
        }

        # Feed only the active club's observable sporting result into the
        # already existing adaptive state; no new sporting formula is added.
        if active_row and active_club in world.get("clubs", {}):
            club = world["clubs"][active_club]
            previous = float(club.get("adaptive_momentum", 50.0))
            table = active_row
            position = int(table.get("position", 1))
            total = max(1, len(next((r.get("standings", []) for r in state["leagues_state"].values() if r.get("league_id") == active_row["league_id"]), [])))
            placement_score = 100.0 if total == 1 else 100.0 * (total - position) / (total - 1)
            club["adaptive_momentum"] = self._clamp(previous * 0.7 + placement_score * 0.3)
            club["adaptive_pressure"] = self._clamp(100.0 - float(club.get("board_confidence", 50.0)))
            club["adaptive_priority"] = club.get("adaptive_priority", "balanced")

        return deepcopy(world["autonomous_cycle"])

    def _catalog_from_save(self):
        """Use an embedded catalog when available; otherwise fail explicitly."""
        catalog = self.save.get("catalog")
        if isinstance(catalog, dict):
            return catalog
        # V97+ saves can carry a canonical world catalog under world.catalog.
        catalog = self.save.get("world", {}).get("catalog")
        if isinstance(catalog, dict):
            return catalog
        raise ValueError("catálogo mundial não encontrado no save")

    def autonomous_cycle_snapshot(self):
        return deepcopy(self.save.get("world", {}).get("autonomous_cycle"))

    def validate(self):
        errors = super().validate()
        cycle = self.save.get("world", {}).get("autonomous_cycle")
        if cycle:
            if cycle.get("version") != self.VERSION:
                errors.append("wrong autonomous cycle version")
            if int(cycle.get("leagues_completed", 0)) > int(cycle.get("leagues_processed", 0)):
                errors.append("completed leagues exceed processed leagues")
            if int(cycle.get("matches_simulated", 0)) < 0:
                errors.append("negative match count")
        return errors
