"""V154 — Long-Run World Simulation.

Runs the already-approved V152 global season boundary repeatedly without
redesigning any competition architecture. V154 is a validation/orchestration
layer: V112/V118/V119/V124 remain authoritative for continental access and
formats, while V152 remains authoritative for one annual world cycle.
"""
from __future__ import annotations

import pickle
from copy import deepcopy
from .v152_global_world_season_engine import V152GlobalWorldSeasonEngine
from .v164_global_season_motor import V164GlobalSeasonMotor
from .world_bootstrap import WorldBootstrap
from .world_integrity import assert_world_integrity


class V154LongRunWorldSimulation:
    VERSION = "V154"
    SCHEMA = 1
    DEFAULT_SEASONS = 10

    def __init__(self, save, seed=154):
        self.save = save
        self.seed = int(seed)

    def _world(self):
        return self.save.setdefault("world", {})

    def _history(self):
        return self.save.setdefault("history", {})

    def _ledger(self):
        return self._history().setdefault("long_run_world_simulations", [])

    def _audit_year(self, season):
        world = self._world()
        history = self._history()
        errors = []
        clubs = world.get("clubs", {})
        leagues = world.get("leagues", {})
        countries = world.get("countries", {})
        competitions = world.get("competitions", {})

        if "players" in world or "player_transfers" in history:
            errors.append("individual player layer detected")
        if len(countries) != 211:
            errors.append(f"country_count_changed:{len(countries)}")
        if len(leagues) != 353:
            errors.append(f"league_count_changed:{len(leagues)}")
        if len(clubs) < 5530:
            errors.append(f"club_count_below_baseline:{len(clubs)}")

        # No duplicate IDs is structurally guaranteed by dict storage; verify
        # league membership and domestic club references remain resolvable.
        for lid, league in leagues.items():
            for cid in league.get("club_ids", []):
                if cid not in clubs:
                    errors.append(f"missing_club_reference:{lid}:{cid}")
                    break
        for cid, club in clubs.items():
            league_id = club.get("league_id")
            if league_id and league_id not in leagues:
                errors.append(f"missing_league_reference:{cid}:{league_id}")

        cycle = history.get("global_world_seasons", [])
        row = next((r for r in reversed(cycle) if int(r.get("season", -1)) == season), None)
        if not row:
            errors.append(f"missing_v152_cycle:{season}")
        else:
            if row.get("calendar", {}).get("status") != "valid":
                errors.append(f"invalid_calendar:{season}")
            if int(row.get("next_year", -1)) != season + 1:
                errors.append(f"invalid_next_year:{season}")
            continental = row.get("sporting", {}).get("continental", {})
            if continental.get("competitions_processed", 0) <= 0:
                errors.append(f"no_continental_competitions:{season}")
            inter = row.get("intercontinental", {})
            if inter.get("status") != "completed":
                errors.append(f"intercontinental_not_completed:{season}")
            if int(inter.get("level1_direct_places", 6)) != 6:
                errors.append(f"intercontinental_level1_not_6:{season}")
            if int(inter.get("lower_level_places", 17)) != 17:
                errors.append(f"intercontinental_lower_not_17:{season}")

        # Every enabled continental competition that was processed must have a
        # champion. This uses the V151 execution already stored in the annual row.
        comp_rows = history.get("continental_season", [])
        annual = next((r for r in reversed(comp_rows) if int(r.get("season", -1)) == season), None)
        if annual:
            for cid, result in annual.get("competitions", {}).items():
                if result.get("status") == "completed" and not result.get("champion"):
                    errors.append(f"completed_without_champion:{season}:{cid}")

        return errors

    def run(self, *, start_season=None, seasons=DEFAULT_SEASONS, seed=None):
        world = self._world()
        start = int(world.get("current_year", 2026) if start_season is None else start_season)
        count = int(seasons)
        if count < 1:
            raise ValueError("V154 seasons must be >= 1")
        if any(int(r.get("start_season", -1)) == start and int(r.get("seasons_requested", 0)) == count for r in self._ledger()):
            raise ValueError(f"V154 simulation already recorded for {start}+{count}")

        snapshot = pickle.dumps(self.save, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            WorldBootstrap(self.save).prepare()
            assert_world_integrity(self.save)
            baseline = {
                "countries": len(world.get("countries", {})),
                "leagues": len(world.get("leagues", {})),
                "clubs": len(world.get("clubs", {})),
            }
            if baseline != {"countries": 211, "leagues": 353, "clubs": 5530}:
                raise ValueError(f"unexpected world baseline: {baseline}")

            season_rows = []
            audits = []
            engine_seed = self.seed if seed is None else int(seed)
            for offset in range(count):
                season = start + offset
                row = V164GlobalSeasonMotor(self.save, seed=engine_seed + offset).run_season(
                    season=season, advance_year=True
                )
                errors = self._audit_year(season)
                audits.append({"season": season, "status": "PASS" if not errors else "FAIL", "errors": errors})
                if errors:
                    raise ValueError("V154 audit failed: " + "; ".join(errors))
                season_rows.append({
                    "season": season,
                    "next_year": row["next_year"],
                    "status": row["status"],
                    "continental_competitions": row["sporting"]["continental"].get("competitions_processed", 0),
                    "continental_completed": row["sporting"]["continental"].get("competitions_completed", 0),
                    "continental_matches": row["sporting"]["continental"].get("matches_simulated", 0),
                    "intercontinental": row["intercontinental"].get("status"),
                    "super_world": None if row.get("super_world") is None else row["super_world"].get("status"),
                    "national_team": row["national_team"].get("status"),
                })

            final_year = start + count
            if int(world.get("current_year")) != final_year:
                raise ValueError(f"V154 final year mismatch: {world.get('current_year')} != {final_year}")
            assert_world_integrity(self.save)
            result = {
                "version": self.VERSION,
                "schema": self.SCHEMA,
                "status": "completed",
                "start_season": start,
                "seasons_requested": count,
                "final_current_year": final_year,
                "baseline": baseline,
                "final_counts": {
                    "countries": len(world.get("countries", {})),
                    "leagues": len(world.get("leagues", {})),
                    "clubs": len(world.get("clubs", {})),
                },
                "seasons": season_rows,
                "audits": audits,
                "architecture_source": ["V112", "V118", "V119", "V124", "V151", "V152", "V164"],
            }
            self._ledger().append(deepcopy(result))
            world["long_run_world_status"] = "validated"
            world["long_run_world_version"] = self.VERSION
            return deepcopy(result)
        except Exception:
            restored = pickle.loads(snapshot)
            self.save.clear()
            self.save.update(restored)
            raise

    def validate(self):
        errors = []
        for row in self._ledger():
            if row.get("version") != self.VERSION:
                errors.append(f"wrong V154 version:{row.get('start_season')}")
            if row.get("status") != "completed":
                errors.append(f"V154 run not completed:{row.get('start_season')}")
            if row.get("final_counts", {}).get("countries") != 211:
                errors.append("V154 country count invariant failed")
            if row.get("final_counts", {}).get("leagues") != 353:
                errors.append("V154 league count invariant failed")
            if row.get("final_counts", {}).get("clubs", 0) < 5530:
                errors.append("V154 club count invariant failed")
            for audit in row.get("audits", []):
                if audit.get("status") != "PASS" or audit.get("errors"):
                    errors.append(f"V154 audit failed:{audit.get('season')}")
        if "players" in self._world() or "player_transfers" in self._history():
            errors.append("V154 player systems are forbidden")
        return errors
