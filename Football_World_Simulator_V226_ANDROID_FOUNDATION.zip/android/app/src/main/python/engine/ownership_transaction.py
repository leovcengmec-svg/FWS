class OwnershipTransaction:
    """Atomic ownership settlement with fees, affordability checks and audit history."""
    def __init__(self, save):
        self.save = save
        self.history = save.setdefault('history', {}).setdefault('ownership_transactions', [])
        self.career = save.setdefault('careers', {}).setdefault('investor', {})
        self.career.setdefault('cash', 0.0)
        self.career.setdefault('owned_clubs', [])
        self.career.setdefault('transactions', [])
        self.rules = save.setdefault('config_runtime', {}).setdefault('investor_finance', {})
        self.rules.setdefault('transaction_fee_rate', 0.01)

    def _club(self, club_id):
        clubs = self.save.setdefault('world', {}).setdefault('clubs', {})
        if club_id not in clubs:
            raise ValueError('clube inexistente')
        return clubs[club_id]

    def quote(self, club_id, price=None):
        club = self._club(club_id)
        base = float(club.get('market_value', 0.1) or 0.1)
        price = base if price is None else float(price)
        if price <= 0:
            raise ValueError('preço inválido')
        fee = price * float(self.rules.get('transaction_fee_rate', 0.01))
        return {'club_id': club_id, 'price': round(price, 2), 'fee': round(fee, 2),
                'buyer_total': round(price + fee, 2), 'seller_net': round(price - fee, 2)}

    def buy_from_market(self, club_id, price=None):
        club = self._club(club_id)
        if club_id in self.career.get('owned_clubs', []):
            raise ValueError('clube já pertence ao investidor')
        quote = self.quote(club_id, price)
        if float(self.career.get('cash', 0.0)) < quote['buyer_total']:
            raise ValueError('capital insuficiente incluindo taxa')
        old_owner = club.get('owner_id')
        self.career['cash'] = round(float(self.career['cash']) - quote['buyer_total'], 2)
        self.career['owned_clubs'].append(club_id)
        club['owner_type'] = 'user_investor'
        club['owner_id'] = 'player'
        event = {'season': self.save.get('world', {}).get('current_year'), 'type': 'purchase',
                 'club_id': club_id, 'price': quote['price'], 'fee': quote['fee'],
                 'total': quote['buyer_total'], 'old_owner': old_owner, 'new_owner': 'player'}
        self.history.append(event)
        self.career['transactions'].append(event.copy())
        return event

    def sell_to_market(self, club_id, price=None):
        if club_id not in self.career.get('owned_clubs', []):
            raise ValueError('clube não pertence ao investidor')
        club = self._club(club_id)
        quote = self.quote(club_id, price)
        old_owner = club.get('owner_id')
        self.career['cash'] = round(float(self.career['cash']) + quote['seller_net'], 2)
        self.career['owned_clubs'].remove(club_id)
        club['owner_type'] = 'ai'
        club['owner_id'] = None
        event = {'season': self.save.get('world', {}).get('current_year'), 'type': 'sale',
                 'club_id': club_id, 'price': quote['price'], 'fee': quote['fee'],
                 'net_proceeds': quote['seller_net'], 'old_owner': old_owner, 'new_owner': None}
        self.history.append(event)
        self.career['transactions'].append(event.copy())
        return event
