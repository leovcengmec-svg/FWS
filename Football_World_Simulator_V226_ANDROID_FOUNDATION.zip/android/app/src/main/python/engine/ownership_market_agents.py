class OwnershipMarketAgents:
    """AI buyer layer for the ownership marketplace.

    Agents generate offers only. No cash, ownership or sporting state changes
    occur until an accepted offer is explicitly settled by V35.
    """
    DEFAULT_PROFILES = {
        'strategic': {'capital': 500.0, 'appetite': 1.20, 'discount': 0.02},
        'balanced': {'capital': 250.0, 'appetite': 0.85, 'discount': 0.08},
        'opportunistic': {'capital': 150.0, 'appetite': 0.65, 'discount': 0.15},
    }

    def __init__(self, save, marketplace, profiles=None):
        self.save = save
        self.marketplace = marketplace
        self.agents = save.setdefault('runtime', {}).setdefault(
            'ownership_market_agents', profiles or self.DEFAULT_PROFILES.copy()
        )

    def _club(self, club_id):
        return self.save['world']['clubs'][club_id]

    def _active_listing(self, listing_id):
        listing = self.marketplace._listing(listing_id)
        if listing['status'] != 'active':
            raise ValueError('anúncio não está ativo')
        return listing

    def evaluate_listing(self, listing_id):
        listing = self._active_listing(listing_id)
        club = self._club(listing['club_id'])
        value = max(0.1, float(club.get('market_value', listing['asking_price']) or 0.1))
        results = []
        for agent_id in sorted(self.agents):
            p = self.agents[agent_id]
            capital = float(p.get('capital', 0))
            appetite = max(0.0, float(p.get('appetite', 0)))
            discount = max(0.0, min(0.5, float(p.get('discount', 0))))
            budget = capital * appetite
            price = round(min(float(listing['asking_price']), value * (1.0 - discount)), 2)
            eligible = price > 0 and price <= budget
            results.append({
                'agent': agent_id, 'listing_id': listing_id,
                'club_id': listing['club_id'], 'reference_value': round(value, 2),
                'budget': round(budget, 2), 'suggested_price': price,
                'eligible': eligible
            })
        return results

    def generate_offers(self, listing_id, max_offers=None):
        evaluations = [x for x in self.evaluate_listing(listing_id) if x['eligible']]
        if max_offers is not None:
            evaluations = evaluations[:max(0, int(max_offers))]
        created = []
        existing = {
            o['buyer'] for o in self.marketplace.offers
            if o['listing_id'] == listing_id and o['status'] == 'pending'
        }
        for item in evaluations:
            if item['agent'] in existing:
                continue
            created.append(self.marketplace.make_offer(
                listing_id, buyer=item['agent'], price=item['suggested_price']))
        return created
