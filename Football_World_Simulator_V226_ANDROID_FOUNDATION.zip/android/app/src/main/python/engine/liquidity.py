class Liquidity:
    """V29: separates cash, protected reserve, spendable cash and net worth."""
    def __init__(self, save):
        from .investor_finance import InvestorFinance
        self.finance = InvestorFinance(save)

    def available_cash(self):
        return self.finance.available_cash()

    def reserve(self):
        return float(self.finance.career.get('reserve', 0.0))

    def net_worth(self):
        return self.finance.calculate_net_worth()

    def snapshot(self):
        c = self.finance.career
        return {
            'cash': round(float(c.get('cash', 0.0)), 2),
            'reserve': round(float(c.get('reserve', 0.0)), 2),
            'available_cash': self.available_cash(),
            'net_worth': self.net_worth(),
        }
