"""V226 Android runtime entrypoint.

The authoritative simulation remains the V225 Python engine. This module is a
thin adapter: Android calls the existing career and world layers instead of
reimplementing game rules in Java.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from engine.save_io import load_world, save_world
from engine.world_database import load_global_simulation
from engine.world_simulator import WorldSimulator
from engine.v131_integrated_career import V131IntegratedCareer
from engine.market import ClubMarket
from engine.v186_investor_finance import V186InvestorFinance
from engine.create_club_career import CreateClubCareer
from engine.v195_club_management_integration import V195ClubManagementIntegration
from engine.v164_global_season_motor import V164GlobalSeasonMotor
from engine.v205_world_alive_integration import V205WorldAliveIntegration
from engine.v210_history_legacy_integration import V210HistoryLegacyIntegration
from engine.v200_selection_career_integration import V200SelectionCareerIntegration

BASE = Path(__file__).resolve().parent
CATALOG = BASE / "data" / "global_world_catalog.json"
SAVE_PATH = Path(os.environ["HOME"]) / "fws_save_v226.json"
USER_ASSETS = Path(os.environ["HOME"]) / "fws_user_assets"
SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
STARTING_CAPITAL = 3.0
CAREER_OPPORTUNITIES = (
    {"id": "market_report", "name": "Análise de mercado", "description": "Prepare um relatório comercial para uma organização esportiva.", "icon": "📊", "reward": 0.65},
    {"id": "sponsor_broker", "name": "Captação de patrocínio", "description": "Conecte uma marca regional a uma propriedade esportiva.", "icon": "🤝", "reward": 0.95},
    {"id": "football_consulting", "name": "Consultoria de gestão", "description": "Ajude uma entidade a planejar sua estrutura e orçamento.", "icon": "💼", "reward": 0.75},
)


def _materialize_market_values(save):
    # Reuse the authoritative V225 market engine for first-season valuations.
    market = ClubMarket(save)
    for club_id in save.get("world", {}).get("clubs", {}):
        market.revalue_club(club_id)
    return save


def _fresh_save():
    save = load_global_simulation(CATALOG)
    _materialize_market_values(save)
    V131IntegratedCareer(save).initialize(starting_cash=STARTING_CAPITAL, manager_prestige=0.0)
    investor = save.setdefault("careers", {}).setdefault("investor", {})
    investor.setdefault("career_income_total", 0.0)
    investor.setdefault("completed_opportunities", {})
    return save


def _load():
    if SAVE_PATH.exists():
        return load_world(SAVE_PATH)
    save = _fresh_save()
    save_world(save, SAVE_PATH)
    return save


def _career(save):
    return V131IntegratedCareer(save)


def _summary(save):
    world = save.get("world", {})
    careers = save.get("careers", {})
    integrated = careers.get("integrated", {})
    investor = careers.get("investor", {})
    selection = careers.get("selection", {})
    return {
        "engine": "V225",
        "android": "V226",
        "year": world.get("current_year", 2026),
        "round": world.get("current_round", 0),
        "associations": len(world.get("countries", {})),
        "national_teams": len(world.get("national_teams", {})),
        "leagues": len(world.get("leagues", {})),
        "clubs": len(world.get("clubs", {})),
        "capital": round(float(investor.get("cash", 0.0)), 2),
        "owned_clubs": list(investor.get("owned_clubs", [])),
        "career_status": integrated.get("status", "available"),
        "prestige": integrated.get("prestige", selection.get("manager_prestige", 0.0)),
        "tier": integrated.get("tier", "EMERGING"),
        "active_club_id": integrated.get("active_club_id"),
        "active_selection_id": integrated.get("active_selection_id"),
    }


def engine_status():
    return json.dumps(_summary(_load()), ensure_ascii=False)


def reset_session():
    save = _fresh_save()
    save_world(save, SAVE_PATH)
    return json.dumps(_summary(save), ensure_ascii=False)


def career_status():
    save = _load()
    snapshot = _career(save).career_snapshot()
    snapshot["capital"] = round(float(save.get("careers", {}).get("investor", {}).get("cash", 0.0)), 2)
    snapshot["year"] = int(save.get("world", {}).get("current_year", 2026))
    snapshot["round"] = int(save.get("world", {}).get("current_round", 0))
    return json.dumps(snapshot, ensure_ascii=False)


def club_market(limit=50):
    save = _load()
    _materialize_market_values(save)
    save_world(save, SAVE_PATH)
    career = _career(save)
    investor = save.get("careers", {}).get("investor", {})
    owned = set(investor.get("owned_clubs", []))
    clubs = []
    for club_id, club in save.get("world", {}).get("clubs", {}).items():
        if club_id in owned:
            continue
        value = round(float(club.get("market_value", 0.0)), 2)
        if value <= 0:
            continue
        clubs.append({
            "id": club_id,
            "name": club.get("name", club_id),
            "country_id": club.get("country_id"),
            "league_id": club.get("league_id"),
            "market_value": value,
            "prestige": round(float(club.get("prestige", 0.0)), 2),
            "cash": round(float(club.get("cash", 0.0)), 2),
            "can_buy": career.investor.can_buy(club_id),
        })
    clubs.sort(key=lambda x: (x["can_buy"] is False, x["market_value"], x["name"]))
    return json.dumps({"capital": round(float(investor.get("cash", 0.0)), 2), "clubs": clubs[:max(1, int(limit))]}, ensure_ascii=False)


def buy_club(club_id):
    save = _load()
    club = save.get("world", {}).get("clubs", {}).get(str(club_id))
    if club is None:
        raise ValueError("clube inexistente")
    if float(club.get("market_value", 0.0)) <= 0:
        raise ValueError("clube sem valor de mercado válido")
    career = _career(save)
    result = career.buy_club(str(club_id))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "club_id": result["id"], "club": result, "career": _summary(save)}, ensure_ascii=False)


def activate_owned_club(club_id):
    save = _load()
    career = _career(save)
    owned = set(save.get("careers", {}).get("investor", {}).get("owned_clubs", []))
    club_id = str(club_id)
    if club_id not in owned:
        raise ValueError("o clube não pertence ao investidor")
    result = career.activate_owned_club(club_id)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "active_club_id": result, "career": career.career_snapshot()}, ensure_ascii=False)


def selection_invitations():
    """Expose legacy-eligible invitations through the V196/V197 career ledger."""
    save = _load()
    career = _career(save)
    invitations = list(career.make_selection_invitations())
    selection_engine = V200SelectionCareerIntegration(save)
    # Keep the existing V131 invitation eligibility rule authoritative, while
    # recording the same offers in the newer career lifecycle instead of
    # presenting two conflicting lists to the player.
    selection_state = save.setdefault("careers", {}).setdefault("selection", {})
    offers = selection_state.setdefault("offers", {})
    year = int(save.get("world", {}).get("current_year", 2026))
    teams = save.get("world", {}).get("national_teams", {})
    rows = []
    for team_id in invitations:
        team = teams.get(team_id, {})
        offer = offers.get(team_id)
        if not isinstance(offer, dict) or offer.get("status") not in ("accepted", "declined"):
            offers[team_id] = {
                "team_id": team_id, "season": year,
                "required_prestige": float(team.get("manager_prestige_required", 10)),
                "status": "pending",
            }
        rows.append({
            "id": team_id,
            "name": team.get("name", team_id),
            "country_id": team.get("country_id"),
            "required_prestige": team.get("manager_prestige_required", 10),
        })
    save_world(save, SAVE_PATH)
    return json.dumps({
        "prestige": float(save.get("careers", {}).get("selection", {}).get("manager_prestige", 0.0)),
        "tier": selection_engine.career.tier(),
        "invitations": rows,
    }, ensure_ascii=False)


def accept_selection(team_id):
    save = _load()
    team_id = str(team_id)
    career = _career(save)
    selection_state = save.setdefault("careers", {}).setdefault("selection", {})
    previous_team_id = selection_state.get("current_team_id")
    engine = V200SelectionCareerIntegration(save)
    # Close the previous appointment before V131 switches the active role; a
    # manager must not retain two active national-team contracts at once.
    if previous_team_id and previous_team_id != team_id:
        engine.contract.leave(previous_team_id, reason="replaced_by_invitation")
    result = career.accept_selection_invitation(team_id)
    # Complete the newer lifecycle alongside V131: appointment, contract and
    # offer status must move together when the player accepts an invitation.
    offers = selection_state.setdefault("offers", {})
    offer = offers.get(team_id)
    if not isinstance(offer, dict):
        team = save.get("world", {}).get("national_teams", {}).get(team_id, {})
        offer = {"team_id": team_id, "season": int(save.get("world", {}).get("current_year", 2026)),
                 "required_prestige": float(team.get("manager_prestige_required", 10)), "status": "pending"}
        offers[team_id] = offer
    offer["status"] = "accepted"
    offer["accepted_season"] = int(save.get("world", {}).get("current_year", 2026))
    if not engine.contract.active(team_id):
        engine.contract.sign(team_id, seasons=1)
    # V131 remains the source of active-role synchronization for the unified career.
    career._sync_roles()
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "selection_id": result,
                       "contract": engine.contract.active(team_id),
                       "career": _summary(save)}, ensure_ascii=False)



def decline_selection(team_id):
    """Decline a real V196 offer and persist the decision in the career ledger."""
    save = _load()
    team_id = str(team_id)
    engine = V200SelectionCareerIntegration(save)
    offers = save.get("careers", {}).get("selection", {}).get("offers", {})
    if team_id not in offers:
        # Bridge offers already surfaced by the legacy eligibility rule into V196
        # only when the same national team still satisfies the prestige gate.
        team = save.get("world", {}).get("national_teams", {}).get(team_id)
        if team is None:
            raise ValueError("seleção inexistente")
        prestige = float(save.get("careers", {}).get("selection", {}).get("manager_prestige", 0.0))
        if float(team.get("manager_prestige_required", 10)) > prestige:
            raise ValueError("prestígio insuficiente para este convite")
        offers[team_id] = {
            "team_id": team_id,
            "season": int(save.get("world", {}).get("current_year", 2026)),
            "required_prestige": float(team.get("manager_prestige_required", 10)),
            "status": "pending",
        }
    result = engine.career.decline(team_id)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "declined": team_id, "result": result,
                       "career": _summary(save)}, ensure_ascii=False)


def selection_management_status():
    """Expose the V196-V200 selection-career management state to Android."""
    save = _load()
    engine = V200SelectionCareerIntegration(save)
    current = save.get("careers", {}).get("selection", {}).get("current_team_id")
    if not current:
        return json.dumps({"active": False, "message": "Nenhuma seleção sob gestão"}, ensure_ascii=False)
    contract = engine.contract.active(current)
    team = save.get("world", {}).get("national_teams", {}).get(current, {})
    decision = team.get("selection_management", {})
    preparation = team.get("selection_preparation", {})
    return json.dumps({
        "active": True, "team_id": current, "team_name": team.get("name", current),
        "contract": contract, "management": decision, "preparation": preparation,
        "career": engine.career.snapshot(),
    }, ensure_ascii=False)


def manage_selection(strategy="balanced", intensity=50, rotation_policy="balanced", focus="competition"):
    """Persist decisions only for the national team currently managed by the career."""
    save = _load()
    selection = save.get("careers", {}).get("selection", {})
    team_id = selection.get("current_team_id")
    teams = save.get("world", {}).get("national_teams", {})
    if not team_id:
        raise ValueError("nenhuma seleção está sob gestão")
    if team_id not in teams:
        raise ValueError("a seleção ativa não existe no mundo salvo")
    engine = V200SelectionCareerIntegration(save)
    # Do not call V200.manage(): its returned snapshot currently invokes
    # performance.season_close(), which is a season lifecycle operation and must
    # never run merely because the user edits a tactical preference.
    strategy_row = engine.decisions.set_strategy(
        strategy=str(strategy), intensity=int(intensity),
        rotation_policy=str(rotation_policy),
    )
    preparation_row = engine.decisions.prepare(focus=str(focus))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "strategy": strategy_row, "preparation": preparation_row}, ensure_ascii=False)


def renew_selection_contract(seasons=1):
    """Renew the active national-team contract through the V197 engine."""
    save = _load()
    engine = V200SelectionCareerIntegration(save)
    team_id = save.get("careers", {}).get("selection", {}).get("current_team_id")
    if not team_id:
        raise ValueError("nenhuma seleção está sob gestão")
    contract = engine.contract.renew(team_id, seasons=max(1, int(seasons)))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "contract": contract}, ensure_ascii=False)


def leave_selection_career():
    """End the current selection appointment and contract without deleting history."""
    save = _load()
    engine = V200SelectionCareerIntegration(save)
    team_id = save.get("careers", {}).get("selection", {}).get("current_team_id")
    if not team_id:
        raise ValueError("nenhuma seleção está sob gestão")
    contract = engine.contract.leave(team_id, reason="voluntary")
    career_profile = _career(save)
    career = save.setdefault("careers", {}).setdefault("selection", {})
    career.setdefault("history", []).append({
        "team_id": team_id,
        "ended_season": int(save.get("world", {}).get("current_year", 2026)),
        "type": "selection_exit",
    })
    career["current_team_id"] = None
    offers = career.setdefault("offers", {})
    if team_id in offers and isinstance(offers[team_id], dict):
        offers[team_id]["status"] = "ended"
        offers[team_id]["ended_season"] = int(save.get("world", {}).get("current_year", 2026))
    career_profile._sync_roles()
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "previous_selection_id": team_id, "contract": contract, "career": engine.career.snapshot()}, ensure_ascii=False)


def advance_season():
    """Run one whole-world season as a single persisted transaction.

    V164 itself rolls back its sporting phase. This outer boundary also protects
    later economy, club-management, selection, world-alive and legacy phases:
    a failure in any downstream integration leaves the previous save untouched.
    """
    save = _load()
    import pickle
    snapshot = pickle.dumps(save, protocol=pickle.HIGHEST_PROTOCOL)
    try:
        return _advance_season_in_save(save)
    except Exception:
        restored = pickle.loads(snapshot)
        save.clear()
        save.update(restored)
        raise


def _advance_season_in_save(save):
    """Advance through the integrated global season engine, then settle the investor economy.

    V164 is the atomic global-season entry point. It delegates the annual sporting,
    continental, intercontinental and national calendar to V152 and advances the year
    exactly once. We deliberately do not call WorldSimulator.advance_season
    afterward, because that would simulate domestic leagues and advance national teams twice.
    """
    before = int(save["world"].get("current_year", 2026))
    sim = WorldSimulator(save, seed=before)
    report = V164GlobalSeasonMotor(save, seed=before).run_season(
        season=before, advance_year=True
    )

    # V151's sporting phase writes the authoritative league tables. Settle economy
    # against those tables while the season report still refers to the completed year.
    league_results = save.get("history", {}).get("latest_tables", {})
    # Economic ledgers read world.current_year internally, while V152 has already
    # advanced it. Temporarily restore the completed season for settlement, then
    # restore the next-year value without advancing the calendar a second time.
    next_year = int(save["world"].get("current_year", before + 1))
    save["world"]["current_year"] = before
    economy_reports = sim.club_economy.settle_season(league_results=league_results)
    sim.investor.settle_owned_club_returns(economy_reports)
    sim.selection_economy.settle_season()
    sim._quarterly_events(before)

    # Close the managed national-team performance ledger against the completed
    # year. This is a read/summary operation; it does not invent match outcomes.
    selection_engine = V200SelectionCareerIntegration(save)
    selection_report = selection_engine.performance.season_close(
        save.get("careers", {}).get("selection", {}).get("current_team_id")
    )

    # Close the V195 management cycle for clubs owned by the investor. The
    # performance modifier and focus effects are calculated after the completed
    # season, so they influence the next campaign rather than rewriting results
    # from the season that has just finished. Passing the completed year explicitly
    # avoids recording the management review under next_year.
    management = V195ClubManagementIntegration(save)
    management_reports = []
    owned_clubs = list(save.get("careers", {}).get("investor", {}).get("owned_clubs", []))
    for club_id in owned_clubs:
        if club_id in save.get("world", {}).get("clubs", {}):
            management_reports.append(management.close_season(club_id))

    # Close the autonomous world layer and the historical/legacy layer once the
    # sporting and financial ledgers for the completed year are settled. Both
    # integrations are idempotent per season, so a recovered/replayed save does
    # not duplicate world events, eras, records or Hall-of-Fame entries.
    world_alive_report = V205WorldAliveIntegration(save, seed=before).run(season=before)
    history_legacy_report = V210HistoryLegacyIntegration(save).close(season=before)

    save["world"]["current_year"] = next_year
    selection_team = save.get("careers", {}).get("selection", {}).get("current_team_id")
    selection_contract = V200SelectionCareerIntegration(save).contract.active(selection_team) if selection_team else None
    save.setdefault("history", {}).setdefault("selection_season_closures", []).append({
        "version": "V200",
        "season": before,
        "performance": selection_report,
        "contract_status_next_season": selection_contract.get("status") if selection_contract else "no_contract",
    })
    save.setdefault("history", {}).setdefault("seasons", {})[str(before)] = {
        "league_champions": {
            lid: rows[0]["club_id"] for lid, rows in league_results.items()
            if isinstance(rows, list) and rows and isinstance(rows[0], dict) and rows[0].get("club_id")
        },
        "club_count": len(save.get("world", {}).get("clubs", {})),
        "global_season_status": report.get("status", "unknown"),
        "pending_configuration": report.get("pending_configuration", []),
    }
    # Gate persistence on cross-system invariants. A season is not considered
    # integrated merely because the sporting engine returned successfully: the
    # calendar, career references, ownership ledger and forbidden player layer
    # must still agree after economy, management, autonomous-world and history
    # integrations have closed.
    _validate_integrated_state(save, completed_season=before, expected_next_year=next_year)

    summary = _summary(save)
    summary["completed_season"] = before
    summary["simulated_leagues"] = len(report.get("sporting", {}).get("leagues", [])) if isinstance(report.get("sporting", {}).get("leagues"), list) else len(league_results)
    summary["global_season_status"] = report.get("status", "unknown")
    summary["pending_configuration"] = report.get("pending_configuration", [])
    summary["season_motor"] = "V164"
    summary["season_phases"] = report.get("season_motor", {}).get("phases", [])
    summary["managed_clubs_reviewed"] = len(management_reports)
    summary["management_reviews"] = management_reports
    summary["world_alive"] = world_alive_report
    summary["history_legacy"] = history_legacy_report
    summary["selection_season"] = selection_report
    summary["selection_contract_next_season"] = selection_contract
    payload = json.dumps(summary, ensure_ascii=False)
    save_world(save, SAVE_PATH)
    return payload


def _validate_integrated_state(save, completed_season=None, expected_next_year=None):
    """Fail closed if cross-system career/world references diverge before save."""
    world = save.get("world", {})
    careers = save.get("careers", {})
    investor = careers.get("investor", {})
    integrated = careers.get("integrated", {})
    selection = careers.get("selection", {})
    clubs = world.get("clubs", {})
    teams = world.get("national_teams", {})
    errors = []

    if expected_next_year is not None and int(world.get("current_year", -1)) != int(expected_next_year):
        errors.append("calendar_year_mismatch")
    if completed_season is not None and expected_next_year is not None:
        if int(expected_next_year) != int(completed_season) + 1:
            errors.append("completed_season_successor_mismatch")
        if int(world.get("current_year", -1)) <= int(completed_season):
            errors.append("calendar_did_not_advance_past_completed_season")
    owned = investor.get("owned_clubs", [])
    if len(owned) != len(set(owned)):
        errors.append("duplicate_owned_clubs")
    if any(club_id not in clubs for club_id in owned):
        errors.append("owned_club_missing_from_world")
    active_club = integrated.get("active_club_id")
    if active_club and active_club not in owned:
        errors.append("active_club_not_owned")
    active_selection = selection.get("current_team_id")
    if active_selection and active_selection not in teams:
        errors.append("active_selection_missing_from_world")
    integrated_selection = integrated.get("active_selection_id")
    if active_selection != integrated_selection:
        errors.append("active_selection_career_mismatch")
    created = investor.get("created_clubs", [])
    if len(created) != len(set(created)):
        errors.append("duplicate_created_clubs")
    if any(club_id not in clubs for club_id in created):
        errors.append("created_club_missing_from_world")
    if any(club_id not in owned for club_id in created):
        errors.append("created_club_not_owned")
    history = save.get("history", {})
    if "players" in world or "player_transfers" in history:
        errors.append("forbidden_player_layer_present")
    if completed_season is not None:
        # Validate the authoritative table output against the world catalog.
        # Some competitions legitimately have no table row; only reject concrete
        # club references that point outside the current world.
        latest_tables = history.get("latest_tables", {})
        if isinstance(latest_tables, dict):
            for league_id, table_rows in latest_tables.items():
                if not isinstance(table_rows, list):
                    errors.append("league_table_shape_invalid:" + str(league_id))
                    continue
                for table_row in table_rows:
                    if not isinstance(table_row, dict):
                        errors.append("league_table_row_invalid:" + str(league_id))
                        continue
                    club_id = table_row.get("club_id")
                    if club_id is not None and club_id not in clubs:
                        errors.append("league_table_club_missing_from_world:" + str(league_id))
                        break
        rows = [row for row in history.get("global_season_motor", [])
                if int(row.get("season", -1)) == int(completed_season)]
        if len(rows) != 1 or rows[0].get("status") != "completed":
            errors.append("global_season_motor_not_closed_exactly_once")
        closures = [row for row in history.get("selection_season_closures", [])
                    if int(row.get("season", -1)) == int(completed_season)]
        if len(closures) != 1:
            errors.append("selection_season_closure_not_recorded_exactly_once")
    if errors:
        raise ValueError("integrated state validation failed: " + "; ".join(errors))
    return {"ok": True, "owned_clubs": len(owned), "active_selection": bool(active_selection)}


def has_saved_career():
    return json.dumps({"has_save": SAVE_PATH.exists()}, ensure_ascii=False)


def career_opportunities():
    save = _load()
    investor = save.setdefault("careers", {}).setdefault("investor", {})
    year = int(save.get("world", {}).get("current_year", 2026))
    completed_by_year = investor.setdefault("completed_opportunities", {})
    completed = set(completed_by_year.get(str(year), []))
    rows = []
    for item in CAREER_OPPORTUNITIES:
        row = dict(item)
        row["completed"] = item["id"] in completed
        rows.append(row)
    return json.dumps({
        "season": year,
        "capital": round(float(investor.get("cash", 0.0)), 2),
        "career_income_total": round(float(investor.get("career_income_total", 0.0)), 2),
        "opportunities": rows,
    }, ensure_ascii=False)


def complete_career_opportunity(opportunity_id):
    save = _load()
    investor = save.setdefault("careers", {}).setdefault("investor", {})
    year = int(save.get("world", {}).get("current_year", 2026))
    definition = next((item for item in CAREER_OPPORTUNITIES if item["id"] == str(opportunity_id)), None)
    if definition is None:
        raise ValueError("oportunidade de carreira inexistente")
    completed_by_year = investor.setdefault("completed_opportunities", {})
    completed = completed_by_year.setdefault(str(year), [])
    if str(opportunity_id) in completed:
        raise ValueError("esta oportunidade já foi concluída nesta temporada")
    reward = float(definition["reward"])
    finance = V186InvestorFinance(save)
    finance.deposit(reward, reason="career_opportunity:" + str(opportunity_id))
    completed.append(str(opportunity_id))
    investor["career_income_total"] = round(float(investor.get("career_income_total", 0.0)) + reward, 2)
    investor.setdefault("transactions", []).append({
        "type": "career_income", "opportunity_id": str(opportunity_id),
        "amount": round(reward, 2), "season": year,
        "reason": definition["name"],
    })
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "reward": reward,
                       "capital": round(float(investor.get("cash", 0.0)), 2),
                       "career_income_total": investor["career_income_total"],
                       "season": year}, ensure_ascii=False)


def create_club_from_zero(name, country_id, city, state_code=""):
    # This endpoint is reached only from the New Game → Create Club from Zero flow.
    # It starts a fresh integrated career before registering the founder's club.
    save = _fresh_save()
    name = str(name).strip()
    city = str(city).strip()
    country_id = str(country_id).strip().upper()
    state_code = str(state_code).strip().upper()
    if not name or not city:
        raise ValueError("informe o nome do clube e a cidade")
    if country_id not in save.get("world", {}).get("countries", {}):
        # Some catalog versions store association records separately from countries.
        if country_id not in save.get("world", {}).get("associations", {}):
            raise ValueError("país/associação não encontrado")
    slug = "".join(ch.lower() if ch.isalnum() else "-" for ch in name).strip("-")
    club_id = "USER-" + country_id + "-" + slug[:48]
    USER_ASSETS.mkdir(parents=True, exist_ok=True)
    creator = CreateClubCareer(save, USER_ASSETS)
    club = creator.create_from_zero(club_id, name, country_id, city,
                                    {"primary": "green", "secondary": "gold"},
                                    starting_cash=2.0, state_code=state_code or None)
    # Keep the user as investor/owner and refresh the dynamic valuation with the existing V225 market layer.
    _materialize_market_values(save)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "club_id": club_id, "club_name": club.get("name"),
                       "league_id": club.get("league_id"), "career": _summary(save)}, ensure_ascii=False)


def finance_status():
    save = _load()
    investor = save.get("careers", {}).get("investor", {})
    history = save.get("history", {})
    tx = investor.get("transactions", [])
    income_total = float(investor.get("career_income_total", 0.0))
    returns = sum(float(row.get("amount", row.get("value", 0.0))) for row in tx
                  if row.get("type") in ("club_return", "dividend", "profit_distribution"))
    return json.dumps({
        "capital": round(float(investor.get("cash", 0.0)), 2),
        "owned_clubs": len(investor.get("owned_clubs", [])),
        "career_income_total": round(income_total, 2),
        "club_returns_total": round(returns, 2),
        "transaction_count": len(tx),
        "season": int(save.get("world", {}).get("current_year", 2026)),
        "finance_entries": len(history.get("investor_finance", [])),
    }, ensure_ascii=False)


def history_summary():
    save = _load()
    history = save.get("history", {})
    matches = history.get("season_matches", [])[-30:]
    out = []
    clubs = save.get("world", {}).get("clubs", {})
    for match in reversed(matches):
        row = dict(match)
        row["home_name"] = clubs.get(row.get("home_id"), {}).get("name", row.get("home_id", "Casa"))
        row["away_name"] = clubs.get(row.get("away_id"), {}).get("name", row.get("away_id", "Visitante"))
        out.append(row)
    seasons = history.get("season_matches", [])
    tx = save.get("careers", {}).get("investor", {}).get("transactions", [])
    return json.dumps({
        "year": int(save.get("world", {}).get("current_year", 2026)),
        "match_count": len(seasons),
        "transaction_count": len(tx),
        "seasons_simulated": len(history.get("season_summaries", [])),
        "matches": out,
    }, ensure_ascii=False)


def club_detail(club_id):
    save = _load()
    club = save.get("world", {}).get("clubs", {}).get(str(club_id))
    if club is None:
        raise ValueError("clube não encontrado")
    return json.dumps(club, ensure_ascii=False)


def invest_in_club(club_id, amount, category="commercial"):
    save = _load()
    career = _career(save)
    result = career.investor.invest(str(club_id), str(category), float(amount))
    _materialize_market_values(save)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "club_id": str(club_id), "amount": float(amount),
                       "category": str(category), "capital": round(float(save.get("careers", {}).get("investor", {}).get("cash", 0.0)), 2),
                       "market_value": save.get("world", {}).get("clubs", {}).get(str(club_id), {}).get("market_value", 0.0),
                       "result": result}, ensure_ascii=False)


def invest_in_selection(amount, category="training"):
    save = _load()
    career = _career(save)
    result = career.invest_in_selection(float(amount), str(category))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "amount": float(amount), "category": str(category),
                       "capital": round(float(save.get("careers", {}).get("investor", {}).get("cash", 0.0)), 2),
                       "result": result}, ensure_ascii=False)


def club_management_status(club_id):
    """Return the authoritative management snapshot for a club owned by the career."""
    save = _load()
    club_id = str(club_id)
    owned = set(save.get("careers", {}).get("investor", {}).get("owned_clubs", []))
    if club_id not in owned:
        raise ValueError("a gestão só está disponível para clubes do investidor")
    management = V195ClubManagementIntegration(save)
    return json.dumps(management.snapshot(club_id), ensure_ascii=False)


def manage_owned_club(club_id, focus="", decision=""):
    """Apply strategy/board choices through the existing V195 integration layer."""
    save = _load()
    club_id = str(club_id)
    owned = set(save.get("careers", {}).get("investor", {}).get("owned_clubs", []))
    if club_id not in owned:
        raise ValueError("a gestão só está disponível para clubes do investidor")
    focus = str(focus or "").strip()
    decision = str(decision or "").strip()
    if focus not in ("", "sporting", "commercial", "development", "consolidation"):
        raise ValueError("foco estratégico inválido")
    if decision not in ("", "invest_infrastructure", "increase_commercial", "financial_consolidation", "sporting_development"):
        raise ValueError("decisão administrativa inválida")
    management = V195ClubManagementIntegration(save)
    snapshot = management.manage(club_id, focus=focus or None, decision=decision or None)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "management": snapshot}, ensure_ascii=False)


def league_standings(league_id):
    """Expose the latest authoritative table produced by the world simulation."""
    save = _load()
    league_id = str(league_id)
    league = save.get("world", {}).get("leagues", {}).get(league_id)
    if league is None:
        raise ValueError("competição não encontrada")
    table = save.get("history", {}).get("latest_tables", {}).get(league_id, [])
    clubs = save.get("world", {}).get("clubs", {})
    rows = []
    for position, entry in enumerate(table, 1):
        row = dict(entry)
        row["position"] = position
        row["club_name"] = clubs.get(row.get("club_id"), {}).get("name", row.get("club_id", "Clube"))
        rows.append(row)
    return json.dumps({"league_id": league_id, "league_name": league.get("name", league_id),
                       "season": int(save.get("world", {}).get("current_year", 2026)) - (1 if table else 0),
                       "has_table": bool(table), "standings": rows}, ensure_ascii=False)


def world_activity_summary():
    """Summarize actual world evolution from the persisted save, not catalog placeholders."""
    save = _load()
    world = save.get("world", {})
    history = save.get("history", {})
    seasons = history.get("seasons", {})
    return json.dumps({
        "year": int(world.get("current_year", 2026)),
        "round": int(world.get("current_round", 0)),
        "countries": len(world.get("countries", {})),
        "national_teams": len(world.get("national_teams", {})),
        "leagues": len(world.get("leagues", {})),
        "clubs": len(world.get("clubs", {})),
        "seasons_completed": len(seasons),
        "events": len(history.get("events", [])),
        "matches_recorded": len(history.get("season_matches", [])),
        "latest_season": max(seasons.keys(), default=None),
        "world_alive_status": world.get("world_alive_status", "not_started"),
        "world_alive_cycles": len(history.get("world_alive_cycles", [])),
        "history_legacy_status": world.get("history_legacy_status", "not_started"),
        "history_legacy_cycles": len(history.get("history_legacy_cycles", [])),
        "global_season_motor_status": world.get("global_season_motor_status", "not_started"),
        "latest_news": _latest_world_news(save, limit=5),
        "hall_of_fame": _legacy_summary(save),
        "selection_career": _selection_career_summary(save),
    }, ensure_ascii=False)


def _latest_world_news(save, limit=5):
    """Return recent V204 headlines enriched with real catalog names."""
    history = save.get("history", {})
    world = save.get("world", {})
    names = {}
    for group in (world.get("clubs", {}), world.get("national_teams", {}), world.get("countries", {})):
        for entity_id, entity in group.items():
            names[entity_id] = entity.get("name", entity_id)
    out = []
    for narrative in reversed(history.get("world_narratives", [])):
        for item in reversed(narrative.get("news", [])):
            row = dict(item)
            row["entity_name"] = names.get(row.get("entity_id"), row.get("entity_id", "Futebol mundial"))
            if row.get("entity_id") and row.get("headline"):
                row["headline"] = row["headline"].replace(str(row["entity_id"]), str(row["entity_name"]), 1)
            out.append(row)
            if len(out) >= max(1, int(limit)):
                return out
    return out


def _legacy_summary(save):
    history = save.get("history", {})
    hof = history.get("hall_of_fame", {})
    records = hof.get("records", []) if isinstance(hof, dict) else []
    return {
        "cycles": len(history.get("history_legacy_cycles", [])),
        "club_entries": len(hof.get("clubs", [])) if isinstance(hof, dict) else 0,
        "selection_entries": len(hof.get("selections", [])) if isinstance(hof, dict) else 0,
        "manager_entries": len(hof.get("managers", [])) if isinstance(hof, dict) else 0,
        "records": records[:5],
    }


def _selection_career_summary(save):
    career = save.get("careers", {}).get("selection", {})
    current_id = career.get("current_team_id")
    teams = save.get("world", {}).get("national_teams", {})
    team = teams.get(current_id, {}) if current_id else {}
    return {
        "active": bool(current_id),
        "team_id": current_id,
        "team_name": team.get("name", current_id) if current_id else None,
        "prestige": float(career.get("manager_prestige", 0.0)),
        "appointments": len(career.get("history", [])),
        "contract": career.get("contracts", {}).get(current_id) if current_id else None,
    }
