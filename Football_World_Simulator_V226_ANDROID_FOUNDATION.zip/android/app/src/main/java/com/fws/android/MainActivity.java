package com.fws.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.res.ColorStateList;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Football World Simulator — Android game presentation layer.
 * One integrated investor/club/selection career; the V225 engine remains authoritative.
 */
public class MainActivity extends Activity {
    private enum Screen { MAIN, NEW_GAME, CAREER, OPPORTUNITIES, MARKET, MY_CLUBS, WORLD, COUNTRY, LEAGUES, CLUBS, CLUB, COMPETITIONS, CALENDAR, FINANCE, SELECTIONS, MATCH, HISTORY, SETTINGS, CREATE_CLUB, LOAD }
    private Screen currentScreen = Screen.MAIN;
    private WorldRepository world;
    private String selectedCountry = "BRA";
    private String selectedLeague = "";
    private String selectedClub = "";
    private static final int BG = 0xFF07140E;
    private static final int PANEL = 0xFF11251B;
    private static final int PANEL_2 = 0xFF183426;
    private static final int GREEN = 0xFF16852D;
    private static final int GREEN_LIGHT = 0xFF40C463;
    private static final int GOLD = 0xFFFFC84D;
    private static final int TEXT = 0xFFF4F7F4;
    private static final int MUTED = 0xFFB3C4B8;
    private static final int RED = 0xFFB92E36;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF06100A);
        getWindow().setNavigationBarColor(0xFF06100A);
        world = WorldRepository.get(this);
        showMainMenu();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true); return t;
    }

    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1f); }
    private void gap(LinearLayout parent, int heightDp) { View v = new View(this); parent.addView(v, lp(1, dp(heightDp))); }

    private TextView action(String icon, String title, String subtitle, boolean primary, View.OnClickListener listener) {
        LinearLayout shell = column(); shell.setPadding(dp(15), dp(13), dp(14), dp(13));
        shell.setBackground(shape(primary ? GREEN : PANEL_2, 14, primary ? 0xFF3AA953 : 0xFF294B36));
        LinearLayout r = row();
        TextView ico = text(icon, 25, primary ? TEXT : GOLD, true); ico.setGravity(Gravity.CENTER); r.addView(ico, lp(dp(42), dp(42)));
        LinearLayout words = column(); words.setPadding(dp(10), 0, dp(4), 0);
        words.addView(text(title, 16, TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) { gap(words, 2); words.addView(text(subtitle, 12, primary ? 0xFFE3F5E7 : MUTED, false)); }
        r.addView(words, weighted()); r.addView(text("›", 27, primary ? TEXT : MUTED, false));
        shell.addView(r); shell.setClickable(true); shell.setFocusable(true); shell.setOnClickListener(listener);
        return wrap(shell);
    }

    // Return a TextView-compatible clickable card wrapper for convenient layout insertion.
    private TextView wrap(View view) {
        TextView marker = new TextView(this); marker.setVisibility(View.GONE); marker.setTag(view); return marker;
    }
    private void addAction(LinearLayout parent, String icon, String title, String subtitle, boolean primary, View.OnClickListener listener) {
        TextView marker = action(icon, title, subtitle, primary, listener);
        View real = (View) marker.getTag(); parent.addView(real, lp(-1, -2)); gap(parent, 9);
    }

    private void addSectionLabel(LinearLayout parent, String title, String trailing) {
        LinearLayout r = row(); TextView left = text(title.toUpperCase(Locale.ROOT), 13, 0xFFDAE9DD, true); r.addView(left, weighted());
        if (trailing != null && !trailing.isEmpty()) r.addView(text(trailing, 11, MUTED, false));
        parent.addView(r); gap(parent, 9);
    }

    private void addMetric(LinearLayout parent, String icon, String label, String value) {
        LinearLayout card = column(); card.setPadding(dp(12), dp(12), dp(12), dp(12)); card.setBackground(shape(PANEL, 13, 0xFF274634));
        card.addView(text(icon, 19, GOLD, true)); gap(card, 5); card.addView(text(value, 18, TEXT, true)); gap(card, 2); card.addView(text(label, 11, MUTED, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f); p.setMargins(dp(3), 0, dp(3), 0); parent.addView(card, p);
    }

    /** Native flag emoji comes from each association's ISO 3166-1 alpha-2 code.
     * Generated placeholder shields are deliberately not presented as official crests. */
    private String countryFlagEmoji(String countryId) {
        if (countryId == null || countryId.isEmpty() || world == null) return "🏳️";
        // Unicode subdivision-flag sequences for the three constituent UK nations.
        if ("ENG".equals(countryId)) return subdivisionFlag("gbeng");
        if ("SCO".equals(countryId)) return subdivisionFlag("gbsct");
        if ("WAL".equals(countryId)) return subdivisionFlag("gbwls");
        // Northern Ireland has no separate standard emoji flag; the UK flag is used.
        JSONObject association = world.association(countryId);
        String iso = association == null ? "" : association.optString("iso_alpha2", "").toUpperCase(Locale.ROOT);
        if (iso.length() != 2 || iso.charAt(0) < 'A' || iso.charAt(0) > 'Z' || iso.charAt(1) < 'A' || iso.charAt(1) > 'Z') return "🏳️";
        int first = 0x1F1E6 + (iso.charAt(0) - 'A');
        int second = 0x1F1E6 + (iso.charAt(1) - 'A');
        return new String(Character.toChars(first)) + new String(Character.toChars(second));
    }

    private String subdivisionFlag(String tagCode) {
        StringBuilder flag = new StringBuilder(new String(Character.toChars(0x1F3F4)));
        for (int i = 0; i < tagCode.length(); i++) flag.append(Character.toChars(0xE0000 + tagCode.charAt(i)));
        flag.append(Character.toChars(0xE007F));
        return flag.toString();
    }

    private String identityGlyph(String type, String id, String fallbackIcon) {
        if ("country".equals(type)) return countryFlagEmoji(id);
        if ("national_team".equals(type)) {
            String countryId = id == null ? "" : id.startsWith("NT_") ? id.substring(3) : id;
            JSONObject team = world == null ? null : world.nationalTeam(id);
            if (team != null) countryId = team.optString("country_id", countryId);
            return countryFlagEmoji(countryId);
        }
        if ("club".equals(type)) return "⚽";
        if ("league".equals(type) || "competition".equals(type)) return "🏆";
        if ("confederation".equals(type)) return "🌐";
        return fallbackIcon == null || fallbackIcon.isEmpty() ? "⚽" : fallbackIcon;
    }

    private void addEntity(LinearLayout parent, String type, String id, String name, String detail, String icon, View.OnClickListener listener) {
        LinearLayout card = row(); card.setPadding(dp(12), dp(10), dp(12), dp(10)); card.setBackground(shape(PANEL, 13, 0xFF254532));
        FrameLayout badge = new FrameLayout(this); badge.setBackground(shape(PANEL_2, 12, 0xFF355B40));
        Drawable artwork = AssetResolver.load(this, type, id);
        if (artwork != null) {
            ImageView image = new ImageView(this); image.setImageDrawable(artwork); image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setPadding(dp(4), dp(4), dp(4), dp(4)); badge.addView(image, new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView glyph = text(identityGlyph(type, id, icon), ("country".equals(type) || "national_team".equals(type)) ? 31 : 29, GOLD, true);
            glyph.setGravity(Gravity.CENTER); badge.addView(glyph, new FrameLayout.LayoutParams(-1, -1));
        }
        // National teams show their real country flag as the main image and overlay the
        // verified federation/selection crest when a matched source image was found.
        if ("national_team".equals(type) && AssetResolver.hasVerifiedArtwork(this, "national_team_crest", id)) {
            Drawable crest = AssetResolver.load(this, "national_team_crest", id);
            if (crest != null) {
                ImageView emblem = new ImageView(this); emblem.setImageDrawable(crest); emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);
                emblem.setPadding(dp(2), dp(2), dp(2), dp(2)); emblem.setBackground(shape(PANEL, 5, GOLD));
                FrameLayout.LayoutParams emblemLp = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM | Gravity.END);
                badge.addView(emblem, emblemLp);
            }
        }
        card.addView(badge, lp(dp(62), dp(62)));
        LinearLayout info = column(); info.setPadding(dp(12), 0, dp(4), 0); info.addView(text(name, 15, TEXT, true));
        if (detail != null && !detail.isEmpty()) { gap(info, 3); info.addView(text(detail, 11, MUTED, false)); }
        if ("national_team".equals(type) && !AssetResolver.hasVerifiedArtwork(this, "national_team_crest", id)) { gap(info, 2); info.addView(text("Bandeira nacional • emblema a confirmar", 9, GOLD, true)); }
        else if ("national_team".equals(type)) { gap(info, 2); info.addView(text("Bandeira + emblema com fonte verificada", 9, GREEN_LIGHT, true)); }
        card.addView(info, weighted()); TextView arrow = text("›", 25, GREEN_LIGHT, true); card.addView(arrow);
        card.setOnClickListener(listener); card.setClickable(true); card.setFocusable(true); parent.addView(card, lp(-1, -2)); gap(parent, 8);
    }

    private void addHeroIdentity(LinearLayout parent, String type, String id, String name, String detail, String fallbackIcon) {
        LinearLayout hero = column(); hero.setGravity(Gravity.CENTER); hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.setBackground(shape(0xFF143B22, 17, 0xFF2D7040));
        FrameLayout badge = new FrameLayout(this); badge.setBackground(shape(PANEL_2, 18, 0xFF426A4B));
        Drawable artwork = AssetResolver.load(this, type, id);
        if (artwork != null) {
            ImageView image = new ImageView(this); image.setImageDrawable(artwork); image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setPadding(dp(6), dp(6), dp(6), dp(6)); badge.addView(image, new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView glyph = text(identityGlyph(type, id, fallbackIcon), ("country".equals(type) || "national_team".equals(type)) ? 58 : 52, GOLD, true);
            glyph.setGravity(Gravity.CENTER); badge.addView(glyph, new FrameLayout.LayoutParams(-1, -1));
        }
        if ("national_team".equals(type) && AssetResolver.hasVerifiedArtwork(this, "national_team_crest", id)) {
            Drawable crest = AssetResolver.load(this, "national_team_crest", id);
            if (crest != null) {
                ImageView emblem = new ImageView(this); emblem.setImageDrawable(crest); emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);
                emblem.setPadding(dp(3), dp(3), dp(3), dp(3)); emblem.setBackground(shape(PANEL, 7, GOLD));
                badge.addView(emblem, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END));
            }
        }
        hero.addView(badge, lp(dp(116), dp(116))); gap(hero, 10); TextView title = text(name, 20, TEXT, true); title.setGravity(Gravity.CENTER); hero.addView(title);
        if (detail != null && !detail.isEmpty()) { gap(hero, 4); TextView sub = text(detail, 11, MUTED, false); sub.setGravity(Gravity.CENTER); hero.addView(sub); }
        if (("club".equals(type) || "league".equals(type) || "competition".equals(type) || "confederation".equals(type))
                && !AssetResolver.hasVerifiedArtwork(this, type, id)) {
            gap(hero, 5); TextView provisional = text("IMAGEM OFICIAL A CONFIRMAR", 9, GOLD, true); provisional.setGravity(Gravity.CENTER); hero.addView(provisional);
        } else if ("national_team".equals(type) && !AssetResolver.hasVerifiedArtwork(this, "national_team_crest", id)) {
            gap(hero, 5); TextView provisional = text("BANDEIRA NACIONAL • EMBLEMA A CONFIRMAR", 9, GOLD, true); provisional.setGravity(Gravity.CENTER); hero.addView(provisional);
        } else if ("national_team".equals(type)) {
            gap(hero, 5); TextView verified = text("BANDEIRA + EMBLEMA COM FONTE VERIFICADA", 9, GREEN_LIGHT, true); verified.setGravity(Gravity.CENTER); hero.addView(verified);
        }
        parent.addView(hero, lp(-1, -2)); gap(parent, 13);
    }

    private void addBackAndTitle(LinearLayout body, String title, String subtitle, boolean back) {
        if (back) {
            TextView b = text("‹  VOLTAR", 13, GREEN_LIGHT, true); b.setPadding(0, 0, 0, dp(12)); b.setOnClickListener(v -> onBackPressed()); body.addView(b);
        }
        body.addView(text(title, 25, TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) { gap(body, 4); body.addView(text(subtitle, 12, MUTED, false)); }
        gap(body, 16);
    }

    private void showPage(Screen screen, String title, String subtitle, boolean back, boolean nav) {
        currentScreen = screen;
        LinearLayout outer = column(); outer.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false);
        LinearLayout body = column(); body.setPadding(dp(16), dp(16), dp(16), dp(18));
        addBackAndTitle(body, title, subtitle, back); scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        if (nav) outer.addView(bottomNav(), lp(-1, -2));
        setContentView(outer); body.setTag("page_body");
    }

    private LinearLayout pageBody() {
        ViewGroup contentRoot = (ViewGroup) findViewById(android.R.id.content);
        ViewGroup outer = (ViewGroup) contentRoot.getChildAt(0);
        if (outer instanceof LinearLayout) {
            View scroll = ((LinearLayout) outer).getChildAt(0);
            if (scroll instanceof ScrollView) return (LinearLayout) ((ScrollView) scroll).getChildAt(0);
        }
        return null;
    }

    private LinearLayout bottomNav() {
        LinearLayout nav = row(); nav.setPadding(dp(4), dp(7), dp(4), dp(7)); nav.setBackgroundColor(0xFF0B1C12);
        addNavItem(nav, "⌂", "Carreira", () -> showCareer());
        addNavItem(nav, "🌍", "Mundo", () -> showWorld());
        addNavItem(nav, "🏆", "Torneios", () -> showCompetitions());
        addNavItem(nav, "💰", "Finanças", () -> showFinance());
        addNavItem(nav, "☰", "Mais", () -> showMore());
        return nav;
    }
    private void addNavItem(LinearLayout nav, String icon, String label, Runnable click) {
        LinearLayout item = column(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2), dp(2), dp(2), dp(2));
        item.addView(text(icon, 18, GOLD, true)); item.addView(text(label, 9, MUTED, false)); item.setOnClickListener(v -> click.run());
        nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private void showMainMenu() {
        currentScreen = Screen.MAIN;
        FrameLayout frame = new FrameLayout(this); frame.addView(new PitchBackground(this), new FrameLayout.LayoutParams(-1, -1));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = column(); content.setGravity(Gravity.CENTER_HORIZONTAL); content.setPadding(dp(24), dp(35), dp(24), dp(24));
        LinearLayout logoMark=column(); logoMark.setGravity(Gravity.CENTER); logoMark.setBackground(shape(0xCC0B2114,22,0xFFB99539));
        TextView ball = text("⚽", 43, TEXT, true); ball.setGravity(Gravity.CENTER); logoMark.addView(ball,lp(-1,dp(60)));
        TextView mark = text("FWS  •  WORLD FOOTBALL", 9, GOLD, true); mark.setGravity(Gravity.CENTER); logoMark.addView(mark); content.addView(logoMark,lp(dp(190),dp(91))); gap(content,13);
        TextView title = text("FOOTBALL WORLD", 25, TEXT, true); title.setGravity(Gravity.CENTER); content.addView(title);
        TextView title2 = text("SIMULATOR", 21, GOLD, true); title2.setGravity(Gravity.CENTER); content.addView(title2);
        TextView tagline = text("SEU MUNDO • SUA CARREIRA • SEU LEGADO", 10, 0xFFD8E9DB, true); tagline.setGravity(Gravity.CENTER); content.addView(tagline); gap(content, 34);
        addAction(content, "＋", "Novo jogo", "Comece sua história no futebol", true, v -> showNewGame());
        addAction(content, "◷", "Continuar carreira", "Volte de onde parou", false, v -> continueCareer());
        addAction(content, "↥", "Carregar jogo", "Abrir uma carreira salva", false, v -> showLoadGame());
        gap(content, 18); addAction(content, "⚙", "Configurações", "Preferências do jogo", false, v -> showSettings());
        TextView footer = text("MUNDO DO FUTEBOL EM MOVIMENTO", 10, 0xBFFFFFFF, true); footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(22), 0, dp(6)); content.addView(footer);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -1)); frame.addView(scroll, new FrameLayout.LayoutParams(-1, -1)); setContentView(frame);
    }

    private class PitchBackground extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        PitchBackground(Activity a) { super(a); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,0,h, new int[]{0xFF030907,0xFF07150D,0xFF092716,0xFF116B22}, null, Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(0x18FFFFFF); for(int i=0;i<8;i++){float y=h*.42f+i*h*.075f; p.setColor((i%2==0)?0x14FFFFFF:0x08000000); c.drawRect(0,y,w,Math.min(h,y+h*.075f),p);}
            p.setColor(0x55FFFFFF); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); float top=h*.60f; c.drawRect(w*.04f,top,w*.96f,h*.98f,p); c.drawCircle(w*.5f,top+(h*.38f)/2f,Math.min(w*.19f,h*.13f),p); c.drawLine(w*.5f,top,w*.5f,h*.98f,p); c.drawRect(w*.31f,top,w*.69f,top+h*.10f,p); c.drawRect(w*.31f,h*.98f-h*.11f,w*.69f,h*.98f,p); p.setStyle(Paint.Style.FILL);
            p.setColor(0x22FFFFFF); for(int i=0;i<5;i++){float x=w*(.12f+i*.19f); c.drawCircle(x,h*.14f,dp(18),p);}
        }
    }

    private void showNewGame() {
        showPage(Screen.NEW_GAME, "NOVA CARREIRA", "Uma única carreira. Um mundo inteiro de futebol.", true, false);
        LinearLayout b=pageBody();
        addAction(b, "▶", "Iniciar normal", "Comece como investidor e construa seu patrimônio", true, v -> initializeCareer());
        addAction(b, "＋", "Criar clube do zero", "Fundar seu clube e entrar no mesmo universo", false, v -> showCreateClub());
        gap(b, 12); b.addView(text("Investimentos, clubes, gestão e seleções fazem parte da mesma carreira.", 12, MUTED, false));
    }

    private void initializeCareer() {
        try { FwsPythonRuntime.reset(this); Toast.makeText(this, "Carreira iniciada!", Toast.LENGTH_SHORT).show(); showCareer(); }
        catch (Throwable e) { friendlyError("Não foi possível iniciar a carreira", e); }
    }
    private void continueCareer() {
        try { if (!FwsPythonRuntime.hasSave(this)) { showNewGame(); return; } showCareer(); }
        catch (Throwable e) { friendlyError("Não foi possível abrir a carreira", e); }
    }
    private void showLoadGame() {
        showPage(Screen.LOAD, "CARREGAR JOGO", "Sua carreira é salva automaticamente neste dispositivo.", true, false);
        LinearLayout b=pageBody();
        try { if (FwsPythonRuntime.hasSave(this)) addAction(b,"↻","Carregar carreira atual","Temporada salva disponível",true,v -> showCareer());
              else addEntity(b,"competition","","Nenhuma carreira salva","Inicie uma nova carreira para começar.","⚽",v -> showNewGame()); }
        catch (Throwable e) { addAction(b,"▶","Nova carreira","Começar uma nova jornada",true,v -> showNewGame()); }
    }

    private JSONObject career() throws Exception { return new JSONObject(FwsPythonRuntime.careerStatus(this)); }
    private String money(double value) { return String.format(new Locale("pt","BR"), "R$ %.2f mi", value); }
    private void showCareer() {
        try {
            JSONObject c=career(); int season=c.optInt("year",2026);
            showPage(Screen.CAREER,"SUA CARREIRA","TEMPORADA "+season+"  •  "+c.optString("tier","EMERGENTE"),false,true);
            LinearLayout b=pageBody();
            LinearLayout seasonCard=column(); seasonCard.setPadding(dp(16),dp(16),dp(16),dp(16)); seasonCard.setBackground(shape(0xFF123A20,18,0xFFB99539));
            LinearLayout seasonHead=row(); LinearLayout seasonWords=column(); seasonWords.addView(text("CENTRAL DA CARREIRA",11,GOLD,true)); gap(seasonWords,4); seasonWords.addView(text("Temporada "+season,24,TEXT,true)); seasonWords.addView(text(c.optString("tier","EMERGENTE")+" • Universo ativo",11,MUTED,false)); seasonHead.addView(seasonWords,weighted());
            TextView seasonMark=text("FWS",23,GOLD,true); seasonMark.setGravity(Gravity.CENTER); seasonMark.setBackground(shape(0xFF0B2114,12,0xFFB99539)); seasonHead.addView(seasonMark,lp(dp(68),dp(58))); seasonCard.addView(seasonHead); gap(seasonCard,14);
            LinearLayout metrics=row(); addMetric(metrics,"💰","Capital disponível",money(c.optDouble("capital",0))); addMetric(metrics,"⭐","Prestígio",String.format(Locale.getDefault(),"%.0f",c.optDouble("prestige",0))); seasonCard.addView(metrics); gap(seasonCard,9);
            LinearLayout stats=row(); JSONArray owned=c.optJSONArray("owned_clubs"); addMetric(stats,"⚽","Clubes",String.valueOf(owned==null?0:owned.length())); addMetric(stats,"🏳️","Seleções",c.optString("active_selection_id","").isEmpty()?"0":"1"); seasonCard.addView(stats); b.addView(seasonCard); gap(b,14);
            String activeClub=c.optString("active_club_id",""); String activeSelection=c.optString("active_selection_id","");
            if(!activeClub.isEmpty()) { JSONObject club=world.club(activeClub); if(club!=null) addEntity(b,"club",activeClub,club.optString("name",activeClub),"Clube sob gestão • "+club.optString("country_id",""),"⚽",v -> showClub(activeClub)); }
            else if(!activeSelection.isEmpty()) { JSONObject team=world.nationalTeam(activeSelection); if(team!=null) addEntity(b,"national_team",activeSelection,team.optString("name",activeSelection),"Seleção sob gestão","🏳️",v -> showSelectionDetails(activeSelection)); }
            else { LinearLayout investor=row(); investor.setPadding(dp(12),dp(11),dp(12),dp(11)); investor.setBackground(shape(PANEL,13,0xFF294B36)); TextView icon=text("💼",27,GOLD,true); investor.addView(icon,lp(dp(44),dp(44))); LinearLayout words=column(); words.addView(text("Investidor independente",14,TEXT,true)); words.addView(text("Construa patrimônio e receba oportunidades no mundo do futebol.",11,MUTED,false)); investor.addView(words,weighted()); b.addView(investor); gap(b,10); }
            addAction(b,"▶","Avançar temporada","Simular competições e evolução do mundo",true,v -> showCalendar());
            addSectionLabel(b,"Sua próxima jogada","CARREIRA");
            addAction(b,"💼","Oportunidades","Ganhe dinheiro nesta temporada",false,v -> showOpportunities());
            addAction(b,"🏟️","Mercado de clubes","Veja os clubes e seus valores de mercado",false,v -> showMarket());
            addAction(b,"🛡️","Meus clubes","Gestão, identidade e patrimônio",false,v -> showMyClubs());
            addAction(b,"🏳️","Seleções","Convites conquistados por prestígio",false,v -> showSelections());
            addSectionLabel(b,"Mundo do futebol","EXPLORAR");
            addAction(b,"🌍","Mundo","Países, ligas e clubes",false,v -> showWorld());
            addAction(b,"🏆","Competições","Torneios nacionais, continentais e mundiais",false,v -> showCompetitions());
            addAction(b,"💰","Finanças","Capital, receitas e histórico de operações",false,v -> showFinance());
            addAction(b,"📜","História e legado","Veja a evolução da carreira e do mundo",false,v -> showHistory());
        } catch(Throwable e) { friendlyError("Não foi possível carregar sua carreira",e); showMainMenu(); }
    }

    private void showOpportunities() {
        try { JSONObject payload=new JSONObject(FwsPythonRuntime.careerOpportunities(this)); showPage(Screen.OPPORTUNITIES,"OPORTUNIDADES","Trabalhos de carreira • Temporada "+payload.optInt("season",2026),true,true); LinearLayout b=pageBody();
            addMetricRow(b,"💰","Capital atual",money(payload.optDouble("capital",0))); gap(b,14); addSectionLabel(b,"Ganhe dinheiro","DISPONÍVEL NESTA TEMPORADA"); JSONArray a=payload.optJSONArray("opportunities");
            if(a==null||a.length()==0) addEntity(b,"competition","","Sem oportunidades","Novas atividades aparecem na próxima temporada.","💼",v -> showCareer());
            else for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i); String id=o.optString("id"); String name=o.optString("name"); String desc=o.optString("description"); double reward=o.optDouble("reward",0); boolean done=o.optBoolean("completed");
                LinearLayout card=column(); card.setPadding(dp(14),dp(14),dp(14),dp(14)); card.setBackground(shape(PANEL,14,0xFF2A4A35)); LinearLayout top=row(); top.addView(text(o.optString("icon","💼"),26,GOLD,true),lp(dp(42),dp(42))); LinearLayout info=column(); info.addView(text(name,15,TEXT,true)); gap(info,3); info.addView(text(desc,11,MUTED,false)); top.addView(info,weighted()); top.addView(text("+"+String.format(Locale.getDefault(),"%.2f",reward)+" mi",13,GREEN_LIGHT,true)); card.addView(top); gap(card,10);
                addAction(card,done?"✓":"＋",done?"Concluído":"Executar trabalho",done?"Renda recebida":"Pagamento ao concluir",!done,v -> completeOpportunity(id)); b.addView(card,lp(-1,-2)); gap(b,9);
            }
            addAction(b,"📈","Ver mercado de clubes","Planeje sua próxima aquisição",false,v -> showMarket());
        } catch(Throwable e){friendlyError("Não foi possível carregar as oportunidades",e);}
    }
    private void addMetricRow(LinearLayout parent,String icon,String label,String value){LinearLayout r=row();addMetric(r,icon,label,value);parent.addView(r);}
    private void completeOpportunity(String id){try{JSONObject result=new JSONObject(FwsPythonRuntime.completeOpportunity(this,id)); Toast.makeText(this,"Receita recebida: "+money(result.optDouble("reward",0)),Toast.LENGTH_LONG).show(); showOpportunities();}catch(Throwable e){friendlyError("Não foi possível concluir a oportunidade",e);}}

    private void showMarket(){
        try{JSONObject p=new JSONObject(FwsPythonRuntime.clubMarket(this,80));showPage(Screen.MARKET,"MERCADO DE CLUBES","Escudos • valor de mercado • possibilidade de compra",true,true);LinearLayout b=pageBody();addMetricRow(b,"💰","Seu capital",money(p.optDouble("capital",0)));gap(b,12);addAction(b,"💼","Ganhar dinheiro","Complete oportunidades antes de comprar",true,v -> showOpportunities());addSectionLabel(b,"Clubes disponíveis","80 DESTAQUES");JSONArray clubs=p.optJSONArray("clubs");if(clubs!=null)for(int i=0;i<clubs.length();i++){JSONObject c=clubs.getJSONObject(i);String id=c.optString("id");String name=c.optString("name");double value=c.optDouble("market_value",0);double missing=Math.max(0,value-p.optDouble("capital",0));String detail=money(value)+"  •  "+c.optString("country_id","");LinearLayout card=column();card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackground(shape(PANEL,14,0xFF274633));addEntity(card,"club",id,name,detail,"⚽",v -> {selectedClub=id;showClub(id);});if(c.optBoolean("can_buy"))addAction(card,"✓","Comprar e assumir","Aquisição imediata",true,v -> buyClub(id));else addAction(card,"🔒","Faltam "+money(missing),"Continue sua progressão financeira",false,v -> showOpportunities());b.addView(card,lp(-1,-2));gap(b,8);}}
        catch(Throwable e){friendlyError("Não foi possível abrir o mercado",e);}}

    private void buyClub(String id){try{FwsPythonRuntime.buyClub(this,id);Toast.makeText(this,"Clube adquirido! Agora você pode assumir a gestão.",Toast.LENGTH_LONG).show();showMyClubs();}catch(Throwable e){friendlyError("Compra não concluída",e);}}
    private void showMyClubs(){try{JSONObject c=career();JSONArray ids=c.optJSONArray("owned_clubs");showPage(Screen.MY_CLUBS,"MEUS CLUBES","Seu portfólio futebolístico",true,true);LinearLayout b=pageBody();if(ids==null||ids.length()==0){addAction(b,"🏟️","Ainda não possui um clube","Construa seu capital e escolha uma oportunidade de compra",true,v -> showMarket());addAction(b,"💼","Ganhar dinheiro","Atividades disponíveis nesta temporada",false,v -> showOpportunities());return;}for(int i=0;i<ids.length();i++){String id=ids.optString(i);JSONObject club;try{club=new JSONObject(FwsPythonRuntime.clubDetail(this,id));}catch(Exception ex){club=world.club(id);}if(club==null)continue;addEntity(b,"club",id,club.optString("name",id),club.optString("country_id","")+"  •  "+club.optString("league_id",""),"⚽",v -> showClub(id));}}catch(Throwable e){friendlyError("Não foi possível carregar seus clubes",e);}}
    private void showClub(String id) {
        selectedClub=id; JSONObject c;
        try { c=new JSONObject(FwsPythonRuntime.clubDetail(this,id)); } catch(Exception ex) { c=world.club(id); }
        if(c==null){Toast.makeText(this,"Clube não encontrado no catálogo visual.",Toast.LENGTH_SHORT).show();return;}
        showPage(Screen.CLUB,c.optString("name",id),c.optString("country_id","")+" • "+c.optString("league_id",""),true,true);
        LinearLayout b=pageBody(); addHeroIdentity(b,"club",id,c.optString("name",id),c.optString("country_id","")+" • "+c.optString("league_id",""),"⚽");
        boolean owned=false, active=false;
        try { JSONObject cs=career(); JSONArray ownedIds=cs.optJSONArray("owned_clubs"); if(ownedIds!=null)for(int i=0;i<ownedIds.length();i++)if(id.equals(ownedIds.optString(i)))owned=true; active=id.equals(cs.optString("active_club_id","")); } catch(Exception ignored) {}
        if(owned) {
            addAction(b,active?"✓":"🏟️",active?"Gestão ativa":"Assumir gestão","Administrar este clube na sua carreira",true,v -> activateClub(id));
            addAction(b,"📈","Investir no clube","Infraestrutura, área desportiva ou comercial",false,v -> showInvestmentDialog("club",id));
            addAction(b,"🧭","Gestão estratégica","Defina a prioridade e registre uma decisão administrativa",true,v -> showClubManagement(id));
        } else {
            addAction(b,"💰","Ver valor de mercado","Consultar possibilidade de compra",false,v -> showMarket());
        }
        addAction(b,"📊","Visão do clube","Reputação, estrutura e identidade",false,v -> showClubInfo(id));
        addAction(b,"🏆","Competições","Acompanhar ligas e torneios",false,v -> showLeagues());
        addAction(b,"📜","Histórico","Campanhas e legado",false,v -> showHistory());
    }
    private void activateClub(String id){try{FwsPythonRuntime.activateOwnedClub(this,id);Toast.makeText(this,"Você assumiu a gestão do clube.",Toast.LENGTH_LONG).show();showClub(id);}catch(Throwable e){friendlyError("Não foi possível assumir a gestão",e);}}
    private void showClubManagement(String id) {
        try {
            JSONObject snapshot = new JSONObject(FwsPythonRuntime.clubManagementStatus(this, id));
            showPage(Screen.CLUB, "GESTÃO DO CLUBE", snapshot.optString("club_id", id), true, true);
            LinearLayout b = pageBody();
            addMetricRow(b, "🧭", "Foco atual", snapshot.optString("focus", "balanced"));
            addMetricRow(b, "🤝", "Confiança da diretoria", String.format(Locale.getDefault(), "%.0f%%", snapshot.optDouble("board_confidence", 50)));
            gap(b, 12);
            addSectionLabel(b, "Prioridade estratégica", "ESCOLHA UMA LINHA DE GESTÃO");
            String[] labels = {"Desportivo", "Comercial", "Desenvolvimento", "Consolidação"};
            String[] focuses = {"sporting", "commercial", "development", "consolidation"};
            for (int i = 0; i < labels.length; i++) {
                final String focus = focuses[i];
                addAction(b, "⚽", labels[i], "Aplicar foco estratégico pelo motor de gestão", true, v -> applyClubManagement(id, focus, ""));
            }
            addSectionLabel(b, "Decisões administrativas", "EFEITOS REGISTRADOS NO HISTÓRICO");
            String[] decisionLabels = {"Investir em infraestrutura", "Ampliar área comercial", "Consolidar finanças", "Desenvolver área desportiva"};
            String[] decisions = {"invest_infrastructure", "increase_commercial", "financial_consolidation", "sporting_development"};
            for (int i = 0; i < decisions.length; i++) {
                final String decision = decisions[i];
                addAction(b, "📋", decisionLabels[i], "Registrar decisão na diretoria", false, v -> applyClubManagement(id, "", decision));
            }
        } catch (Throwable e) { friendlyError("Não foi possível abrir a gestão estratégica", e); }
    }
    private void applyClubManagement(String id, String focus, String decision) {
        try {
            FwsPythonRuntime.manageOwnedClub(this, id, focus, decision);
            Toast.makeText(this, "Decisão registrada pelo motor de gestão.", Toast.LENGTH_LONG).show();
            showClubManagement(id);
        } catch (Throwable e) { friendlyError("A decisão não pôde ser aplicada", e); }
    }

    private void showInvestmentDialog(String type,String id) {
        LinearLayout form=column(); form.setPadding(dp(18),dp(8),dp(18),dp(4));
        TextView hint=text("Valor em milhões (mi)",12,MUTED,false); form.addView(hint); gap(form,5);
        EditText amount=new EditText(this); amount.setSingleLine(true); amount.setInputType(8194); amount.setText("0,50"); amount.setHint("Ex.: 0,50"); styleEdit(amount); form.addView(amount,lp(-1,dp(48))); gap(form,8);
        String[] categories={"Comercial","Infraestrutura","Desportivo","Estabilidade"}; String[] keys={"commercial","infrastructure","sport","stability"};
        Spinner category=new Spinner(this); category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,categories)); form.addView(category,lp(-1,dp(48)));
        new AlertDialog.Builder(this).setTitle(type.equals("club")?"Investir no clube":"Investir na seleção").setView(form).setNegativeButton("Cancelar",null).setPositiveButton("Investir",(d,w)->{
            try { String raw=amount.getText().toString().trim().replace(',','.'); double value=Double.parseDouble(raw); if(value<=0)throw new IllegalArgumentException("O valor precisa ser maior que zero."); String key=keys[category.getSelectedItemPosition()];
                if(type.equals("club"))FwsPythonRuntime.investInClub(this,id,value,key);else FwsPythonRuntime.investInSelection(this,value,key);
                Toast.makeText(this,"Investimento registrado pelo motor.",Toast.LENGTH_LONG).show(); if(type.equals("club"))showClub(id);else showSelections();
            } catch(Throwable e){friendlyError("Investimento não concluído",e);}
        }).show();
    }
    private void showClubInfo(String id){JSONObject c;try{c=new JSONObject(FwsPythonRuntime.clubDetail(this,id));}catch(Exception ex){c=world.club(id);}if(c==null)return;showPage(Screen.CLUB,"VISÃO DO CLUBE",c.optString("name",id),true,true);LinearLayout b=pageBody();addEntity(b,"club",id,c.optString("name",id),"País: "+c.optString("country_id","")+"\nLiga: "+c.optString("league_id",""),"⚽",v -> showClub(id));addEntity(b,"league",c.optString("league_id",""),c.optString("league_id","Competição"),"Estrutura nacional", "🏆",v -> showLeagues());addAction(b,"↻","Atualizar visão","Recarregar dados do catálogo",false,v -> showClubInfo(id));}

    private void showWorld(){showPage(Screen.WORLD,"MUNDO DO FUTEBOL","211 associações • países, ligas e clubes",false,true);LinearLayout b=pageBody();try{JSONObject activity=new JSONObject(FwsPythonRuntime.worldActivitySummary(this));addMetricRow(b,"📅","Temporada atual",String.valueOf(activity.optInt("year",year())));addMetricRow(b,"🏟️","Partidas registradas",String.valueOf(activity.optInt("matches_recorded",0)));addMetricRow(b,"📚","Temporadas concluídas",String.valueOf(activity.optInt("seasons_completed",0)));addMetricRow(b,"🌐","Mundo autônomo",activity.optString("world_alive_status","not_started").equals("ready")?"Ativo":"Aguardando ciclo");addMetricRow(b,"🏛️","História e legado",activity.optString("history_legacy_status","not_started").equals("ready")?"Integrados":"Aguardando temporada");JSONObject legacy=activity.optJSONObject("hall_of_fame");if(legacy!=null)addMetricRow(b,"🏆","Registros históricos",String.valueOf(legacy.optInt("club_entries",0)+legacy.optInt("selection_entries",0)));JSONObject selection=activity.optJSONObject("selection_career");if(selection!=null&&selection.optBoolean("active",false))addMetricRow(b,"🏳️","Seleção sob gestão",selection.optString("team_name","Seleção")+" • prestígio "+selection.optDouble("prestige",0));JSONArray news=activity.optJSONArray("latest_news");if(news!=null&&news.length()>0){gap(b,8);addSectionLabel(b,"Últimas notícias do mundo","Motor V204");for(int i=0;i<Math.min(news.length(),5);i++){JSONObject item=news.optJSONObject(i);if(item==null)continue;addEntity(b,"competition",item.optString("entity_id",""),item.optString("entity_name","Futebol mundial"),item.optString("headline","Acontecimento mundial")+" • "+item.optInt("season",year()),"📰",v -> showHistory());}}gap(b,10);}catch(Throwable ignored){}addAction(b,"🇧🇷","Brasil","Série A até F • estaduais e acesso",true,v -> showCountry("BRA"));addAction(b,"🌎","Todos os países","Explore as associações do mundo",false,v -> showCountries());addAction(b,"🏆","Ligas e divisões","353 estruturas catalogadas",false,v -> showLeagues());addAction(b,"⚽","Clubes","Explore o catálogo mundial",false,v -> showAllClubs());addAction(b,"🏳️","Seleções","Identidade e convites de seleções",false,v -> showSelections());}
    private void showCountries(){showPage(Screen.WORLD,"PAÍSES E ASSOCIAÇÕES","Bandeiras • confederações • futebol nacional",true,true);LinearLayout b=pageBody();for(JSONObject a:world.associationEntries()){String id=a.optString("id");addEntity(b,"country",id,a.optString("name",id),a.optString("confederation","")+" • Associação nacional","🌍",v -> showCountry(id));}}
    private void showCountry(String id){selectedCountry=id;JSONObject a=world.association(id);String name=a==null?id:a.optString("name",id);showPage(Screen.COUNTRY,name,name+" • Futebol nacional",true,true);LinearLayout b=pageBody();addEntity(b,"country",id,name,a==null?"":a.optString("confederation","")+" • Associação", "🌍",v -> {});String nt=world.nationalTeamIdForCountry(id);JSONObject team=world.nationalTeam(nt);if(team!=null)addEntity(b,"national_team",nt,team.optString("name",name),"Seleção nacional • carreira por convite","🏳️",v -> showSelections());addSectionLabel(b,"Competições nacionais",null);List<JSONObject> leagues=world.leaguesForCountry(id);if(leagues.isEmpty())b.addView(text("Não há divisões carregadas para este país.",12,MUTED,false));for(JSONObject l:leagues){String lid=l.optString("id");addEntity(b,"league",lid,l.optString("name",lid),"Divisão "+l.optInt("level",1)+" • "+l.optInt("club_count",l.optJSONArray("club_ids")==null?0:l.optJSONArray("club_ids").length())+" clubes","🏆",v -> showLeague(lid));}}
    private void showLeagues(){showPage(Screen.LEAGUES,"LIGAS E DIVISÕES","Estruturas nacionais do mundo",true,true);LinearLayout b=pageBody();for(JSONObject l:world.leagueEntries()){String id=l.optString("id");String country=l.optString("country_id","");addEntity(b,"league",id,l.optString("name",id),country+" • Divisão "+l.optInt("level",1),"🏆",v -> showLeague(id));}}
    private void showLeague(String id){selectedLeague=id;JSONObject l=world.league(id);if(l==null)return;showPage(Screen.CLUBS,l.optString("name",id),l.optString("country_id","")+" • Temporada "+year(),true,true);LinearLayout b=pageBody();addHeroIdentity(b,"league",id,l.optString("name",id),l.optInt("club_count",0)+" clubes cadastrados • "+l.optString("country_id",""),"🏆");try{JSONObject table=new JSONObject(FwsPythonRuntime.leagueStandings(this,id));if(table.optBoolean("has_table",false)){JSONArray rows=table.optJSONArray("standings");addSectionLabel(b,"Classificação • "+table.optInt("season",year()),rows==null?"":String.valueOf(rows.length())+" clubes");if(rows!=null){int limit=Math.min(rows.length(),10);for(int i=0;i<limit;i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;String cid=row.optString("club_id","");String label=row.optInt("position",i+1)+". "+row.optString("club_name",cid);String stats="PTS "+row.optInt("points")+" • J "+row.optInt("played")+" • SG "+row.optInt("gd");addEntity(b,"club",cid,label,stats,"⚽",v -> showClub(cid));}}}else{addSectionLabel(b,"Classificação","Ainda não simulada nesta carreira");b.addView(text("A tabela aparecerá após a primeira temporada simulada para esta divisão.",12,MUTED,false));}}catch(Throwable ignored){}JSONArray ids=l.optJSONArray("club_ids");if(ids==null||ids.length()==0){b.addView(text("Esta divisão ainda não possui um grupo de clubes preenchido. O jogo não inventará clubes para completar lacunas.",12,MUTED,false));return;}addSectionLabel(b,"Clubes participantes",String.valueOf(ids.length()));for(int i=0;i<ids.length();i++){String cid=ids.optString(i);JSONObject c=world.club(cid);if(c!=null)addEntity(b,"club",cid,c.optString("name",cid),id+" • "+l.optString("country_id",""),"⚽",v -> showClub(cid));}}
    private void showAllClubs(){
        showPage(Screen.CLUBS,"CLUBES DO MUNDO","Pesquise por nome • escudos e identidades",true,true);
        LinearLayout b=pageBody(); EditText query=new EditText(this); query.setSingleLine(true); query.setHint("Buscar clube"); styleEdit(query); b.addView(query,lp(-1,dp(50))); gap(b,8);
        LinearLayout results=column(); addAction(b,"⌕","Buscar","Mostrar até 100 resultados",true,v -> renderClubSearch(results,query.getText().toString()));
        gap(b,5); b.addView(results,lp(-1,-2)); renderClubSearch(results,"");
    }
    private void renderClubSearch(LinearLayout results,String query){
        results.removeAllViews(); String q=query==null?"":query.trim().toLowerCase(Locale.ROOT); int shown=0;
        for(JSONObject c:world.clubEntries()) { String name=c.optString("name",c.optString("id")); if(!q.isEmpty()&&!name.toLowerCase(Locale.ROOT).contains(q))continue; String id=c.optString("id"); addEntity(results,"club",id,name,c.optString("country_id","")+" • "+c.optString("league_id",""),"⚽",v -> showClub(id)); shown++; if(shown>=100)break; }
        if(shown==0)results.addView(text("Nenhum clube encontrado.",12,MUTED,false));
    }
    private void showCompetitions(){showPage(Screen.COMPETITIONS,"COMPETIÇÕES","Nacionais • continentais • mundiais",false,true);LinearLayout b=pageBody();for(JSONObject c:world.competitionEntries()){String id=c.optString("id");addEntity(b,"competition",id,c.optString("name",prettyId(id)),c.optString("confederation","")+" • "+c.optString("type","Competição"),"🏆",v -> showCompetition(id));}addAction(b,"📅","Calendário mundial","Avance a temporada e processe os resultados",false,v -> showCalendar());}
    private String prettyId(String id){return id.replace('_',' ').replace('-',' ');}
    private void showCompetition(String id){JSONObject c=world.competition(id);showPage(Screen.COMPETITIONS,c==null?prettyId(id):c.optString("name",prettyId(id)),"🏆 Competição futebolística",true,true);LinearLayout b=pageBody();addHeroIdentity(b,"competition",id,c==null?prettyId(id):c.optString("name",id),c==null?"":c.optString("confederation","")+" • "+c.optString("type",""),"🏆");addAction(b,"📅","Ver calendário","Partidas e fases disponíveis no mundo simulado",false,v -> showCalendar());addAction(b,"🌍","Explorar participantes","Consulte países, ligas e clubes",false,v -> showWorld());}

    private void showSelections(){try{JSONObject p=new JSONObject(FwsPythonRuntime.selectionInvitations(this));showPage(Screen.SELECTIONS,"SELEÇÕES","Convites por prestígio • parte da sua carreira integrada",false,true);LinearLayout b=pageBody();addMetricRow(b,"⭐","Prestígio",String.format(Locale.getDefault(),"%.0f",p.optDouble("prestige",0)));gap(b,12);String active=career().optString("active_selection_id","");JSONObject team=world.nationalTeam(active);if(team!=null)addEntity(b,"national_team",active,team.optString("name",active),"Seleção que você administra atualmente","🏳️",v -> showSelectionDetails(active));addSectionLabel(b,"Convites disponíveis","SEM ESCOLHA LIVRE");JSONArray invites=p.optJSONArray("invitations");if(invites==null||invites.length()==0){addEntity(b,"competition","","Nenhum convite no momento","Seu prestígio precisa alcançar o nível exigido pelas seleções.","🏳️",v -> showCareer());addAction(b,"📈","Evoluir carreira","Invista, compre clubes e construa reputação",false,v -> showOpportunities());}else for(int i=0;i<invites.length();i++){JSONObject t=invites.getJSONObject(i);String id=t.optString("id"),name=t.optString("name",id);addEntity(b,"national_team",id,name,"Prestígio mínimo: "+t.optInt("required_prestige",10),"🏳️",v -> showInvitationOptions(id,name));}}catch(Throwable e){friendlyError("Não foi possível consultar convites",e);}}
    private void showInvitationOptions(String id,String name){new AlertDialog.Builder(this).setTitle(name).setMessage("Você recebeu um convite para assumir esta seleção. Aceite para iniciar o vínculo ou recuse para registrar a decisão.").setNegativeButton("Recusar",(d,w)->declineSelection(id)).setNeutralButton("Voltar",null).setPositiveButton("Aceitar",(d,w)->acceptSelection(id)).show();}
    private void acceptSelection(String id){try{FwsPythonRuntime.acceptSelection(this,id);Toast.makeText(this,"Convite aceito. Seleção integrada à sua carreira.",Toast.LENGTH_LONG).show();showSelections();}catch(Throwable e){friendlyError("Não foi possível aceitar o convite",e);}}
    private void declineSelection(String id){try{FwsPythonRuntime.declineSelection(this,id);Toast.makeText(this,"Convite recusado e registrado no histórico.",Toast.LENGTH_LONG).show();showSelections();}catch(Throwable e){friendlyError("Não foi possível recusar o convite",e);}}
    private void showSelectionDetails(String id){JSONObject t=world.nationalTeam(id);showPage(Screen.SELECTIONS,t==null?id:t.optString("name",id),"Seleção nacional • carreira integrada",true,true);LinearLayout b=pageBody();addHeroIdentity(b,"national_team",id,t==null?id:t.optString("name",id),t==null?"":t.optString("country_id",""),"🏳️");addAction(b,"📈","Investir na seleção","Desenvolvimento e estrutura nacional",false,v -> showInvestmentDialog("selection",id));addAction(b,"🧭","Gestão da seleção","Estratégia, intensidade e preparação",true,v -> showSelectionManagement());addAction(b,"🏆","Competições internacionais","Consulte o calendário mundial",false,v -> showCompetitions());}

    private void showSelectionManagement() {
        try {
            JSONObject state = new JSONObject(FwsPythonRuntime.selectionManagementStatus(this));
            if (!state.optBoolean("active", false)) { friendlyError("Nenhuma seleção sob gestão", new IllegalStateException(state.optString("message", "Aceite um convite primeiro."))); return; }
            JSONObject management = state.optJSONObject("management"); if (management == null) management = new JSONObject();
            final JSONObject managementState = management;
            JSONObject prep = state.optJSONObject("preparation"); if (prep == null) prep = new JSONObject();
            showPage(Screen.SELECTIONS, "GESTÃO DA SELEÇÃO", state.optString("team_name", "Seleção nacional"), true, true);
            LinearLayout b = pageBody();
            JSONObject contract = state.optJSONObject("contract");
            addMetricRow(b, "📄", "Contrato até", contract == null ? "Sem contrato ativo" : String.valueOf(contract.optInt("end_season", year())));
            addMetricRow(b, "🧠", "Estratégia atual", management.optString("strategy", "balanced"));
            addMetricRow(b, "🎯", "Intensidade", management.optInt("intensity", 50) + "%");
            addMetricRow(b, "📅", "Foco de preparação", prep.optString("focus", "competition"));
            gap(b, 12); addSectionLabel(b, "Estratégia", "DECISÕES AGREGADAS DA SELEÇÃO");
            String[] labels = {"Equilibrada", "Ofensiva", "Conservadora", "Desenvolvimento"};
            String[] strategies = {"balanced", "aggressive", "conservative", "development"};
            for (int i=0;i<labels.length;i++) { final String strategy=strategies[i]; addAction(b, "🧭", labels[i], "Registrar estratégia com intensidade 50", true, v -> applySelectionManagement(strategy, 50, "balanced", "competition")); }
            addSectionLabel(b, "Preparação", "OBJETIVO DA TEMPORADA");
            String[] prepLabels = {"Competições", "Classificação", "Desenvolvimento", "Amistosos"};
            String[] focuses = {"competition", "qualification", "development", "friendlies"};
            for (int i=0;i<prepLabels.length;i++) { final String focus=focuses[i]; addAction(b, "📋", prepLabels[i], "Registrar foco de preparação", false, v -> applySelectionManagement(managementState.optString("strategy", "balanced"), managementState.optInt("intensity",50), managementState.optString("rotation_policy","balanced"), focus)); }
            gap(b, 12); addSectionLabel(b, "Contrato e carreira", "GESTÃO PROFISSIONAL");
            addAction(b, "📄", "Renovar contrato por 1 temporada", "Prorrogar vínculo com esta seleção", true, v -> renewSelectionContract());
            addAction(b, "↩️", "Encerrar vínculo com a seleção", "Registrar saída sem apagar o histórico", false, v -> leaveSelectionCareer());
        } catch (Throwable e) { friendlyError("Não foi possível abrir a gestão da seleção", e); }
    }
    private void renewSelectionContract() {
        try { FwsPythonRuntime.renewSelectionContract(this, 1); Toast.makeText(this, "Renovação registrada pelo motor.", Toast.LENGTH_LONG).show(); showSelectionManagement(); }
        catch (Throwable e) { friendlyError("Não foi possível renovar o contrato", e); }
    }
    private void leaveSelectionCareer() {
        new AlertDialog.Builder(this).setTitle("Encerrar vínculo?")
            .setMessage("A saída será registrada no histórico da carreira. Você poderá receber novos convites conforme seu prestígio.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Encerrar", (dialog, which) -> {
                try { FwsPythonRuntime.leaveSelectionCareer(this); Toast.makeText(this, "Saída registrada no histórico.", Toast.LENGTH_LONG).show(); showSelections(); }
                catch (Throwable e) { friendlyError("Não foi possível encerrar o vínculo", e); }
            }).show();
    }

    private void applySelectionManagement(String strategy, int intensity, String rotation, String focus) {
        try { FwsPythonRuntime.manageSelection(this, strategy, intensity, rotation, focus); Toast.makeText(this, "Decisões da seleção registradas pelo motor.", Toast.LENGTH_LONG).show(); showSelectionManagement(); }
        catch (Throwable e) { friendlyError("Não foi possível registrar as decisões da seleção", e); }
    }

    private void showCalendar(){try{JSONObject c=career();showPage(Screen.CALENDAR,"CALENDÁRIO","Temporada "+c.optInt("year",2026)+" • rodada "+c.optInt("round",0),false,true);LinearLayout b=pageBody();addMetricRow(b,"📅","Temporada",String.valueOf(c.optInt("year",2026)));gap(b,12);addEntity(b,"competition","","Mundo em andamento","Ligas, promoções, economia, reputação e história evoluem em conjunto.","🌍",v -> showWorld());addAction(b,"▶","Avançar temporada","Simular a temporada mundial pelo motor",true,v -> advanceSeason());addAction(b,"⚽","Central de partidas","Consultar resultados da simulação",false,v -> showMatch());}catch(Throwable e){friendlyError("Não foi possível abrir o calendário",e);}}
    private void advanceSeason() {
        new AlertDialog.Builder(this)
            .setTitle("Avançar temporada?")
            .setMessage("O mundo inteiro será simulado. Esta ação altera resultados, economia, classificações e histórico da carreira.")
            .setNegativeButton("Cancelar", (dialog, which) -> { })
            .setPositiveButton("Simular", (dialog, which) -> runSeasonInBackground())
            .show();
    }

    /** The world simulation is expensive; never execute it on Android's UI thread. */
    private void runSeasonInBackground() {
        AlertDialog progress = new AlertDialog.Builder(this)
            .setTitle("Simulando temporada")
            .setMessage("O motor está processando competições, economia e evolução mundial. Isso pode levar alguns minutos. Não feche o jogo.")
            .setCancelable(false)
            .create();
        progress.show();

        Thread worker = new Thread(() -> {
            String payload = null;
            Throwable failure = null;
            try {
                payload = FwsPythonRuntime.advanceSeason(MainActivity.this);
            } catch (Throwable error) {
                failure = error;
            }
            final String resultJson = payload;
            final Throwable resultError = failure;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (progress.isShowing()) progress.dismiss();
                if (resultError != null) {
                    friendlyError("A temporada não pôde ser concluída", resultError);
                    return;
                }
                try {
                    JSONObject result = new JSONObject(resultJson);
                    String status = result.optString("global_season_status", "unknown");
                    if (!"completed".equalsIgnoreCase(status)) {
                        String pending = result.optJSONArray("pending_configuration") == null
                            ? "" : result.optJSONArray("pending_configuration").toString();
                        friendlyError("Temporada não validada",
                            new IllegalStateException("O motor não confirmou o fechamento integral. Estado: " + status + (pending.isEmpty() ? "" : "\nPendências: " + pending)));
                        return;
                    }
                    Toast.makeText(MainActivity.this,
                        "Temporada concluída: " + result.optInt("completed_season", year()),
                        Toast.LENGTH_LONG).show();
                    showCareer();
                } catch (Throwable error) {
                    friendlyError("Não foi possível interpretar o resultado da temporada", error);
                }
            });
        }, "fws-global-season");
        worker.start();
    }
    private int year(){try{return career().optInt("year",2026);}catch(Exception e){return 2026;}}
    private void showMatch(){showPage(Screen.MATCH,"CENTRAL DE PARTIDAS","Resultados agregados do mundo do futebol",true,true);LinearLayout b=pageBody();try{JSONObject h=new JSONObject(FwsPythonRuntime.historySummary(this));JSONArray matches=h.optJSONArray("matches");if(matches==null||matches.length()==0)addEntity(b,"competition","","A temporada ainda não tem resultados recentes","Avance a temporada para simular as competições.","⚽",v -> showCalendar());else for(int i=0;i<matches.length();i++){JSONObject m=matches.getJSONObject(i);String home=m.optString("home_name",m.optString("home_id","Casa"));String away=m.optString("away_name",m.optString("away_id","Visitante"));addEntity(b,"competition","",home+"  "+m.optInt("home_goals",0)+" × "+m.optInt("away_goals",0)+"  "+away,m.optString("league_id","")+" • "+m.optInt("season",year()),"⚽",v -> showHistory());}}catch(Throwable e){addAction(b,"📅","Avançar temporada","Gerar resultados do mundo",true,v -> showCalendar());}}

    private void showFinance(){try{JSONObject f=new JSONObject(FwsPythonRuntime.financeStatus(this));showPage(Screen.FINANCE,"FINANÇAS","Seu patrimônio e sua progressão econômica",false,true);LinearLayout b=pageBody();LinearLayout r=row();addMetric(r,"💰","Capital",money(f.optDouble("capital",0)));addMetric(r,"🏟️","Clubes",String.valueOf(f.optInt("owned_clubs",0)));b.addView(r);gap(b,12);addEntity(b,"competition","","Receitas de carreira",money(f.optDouble("career_income_total",0))+" • trabalhos concluídos","💼",v -> showOpportunities());addEntity(b,"competition","","Rendimentos de clubes",money(f.optDouble("club_returns_total",0))+" • lucros distribuídos pelo motor","📈",v -> showMyClubs());addEntity(b,"competition","","Transações",String.valueOf(f.optInt("transaction_count",0))+" operações registradas","📒",v -> showHistory());addAction(b,"💼","Oportunidades de renda","Conclua trabalhos disponíveis nesta temporada",true,v -> showOpportunities());addAction(b,"🏟️","Mercado de clubes","Veja valores e planeje sua aquisição",false,v -> showMarket());}catch(Throwable e){friendlyError("Não foi possível carregar as finanças",e);}}
    private void showHistory(){try{JSONObject h=new JSONObject(FwsPythonRuntime.historySummary(this));showPage(Screen.HISTORY,"HISTÓRIA E LEGADO","A evolução da carreira e do mundo",true,true);LinearLayout b=pageBody();addEntity(b,"competition","","Temporada atual",String.valueOf(h.optInt("year",year())),"📅",v -> showCalendar());addEntity(b,"competition","","Resultados registrados",String.valueOf(h.optInt("match_count",0))+" partidas agregadas","⚽",v -> showMatch());addEntity(b,"competition","","Transações financeiras",String.valueOf(h.optInt("transaction_count",0))+" registros","💰",v -> showFinance());addEntity(b,"competition","","Temporadas simuladas",String.valueOf(h.optInt("seasons_simulated",0)),"🏆",v -> showCalendar());}catch(Throwable e){friendlyError("Não foi possível abrir o histórico",e);}}

    private void showMore(){showPage(Screen.SETTINGS,"CENTRAL DO JOGO","Ferramentas e informações de carreira",false,true);LinearLayout b=pageBody();addAction(b,"📅","Calendário","Avançar temporada",false,v -> showCalendar());addAction(b,"📜","História e legado","Resultados e transações",false,v -> showHistory());addAction(b,"⚙","Configurações","Preferências do jogo",false,v -> showSettings());addAction(b,"⌂","Tela inicial","Voltar ao menu principal",false,v -> showMainMenu());}
    private void showSettings(){showPage(Screen.SETTINGS,"CONFIGURAÇÕES","Preferências da experiência de jogo",true,false);LinearLayout b=pageBody();addEntity(b,"competition","","Idioma","Português (Brasil)","文",v -> Toast.makeText(this,"Português (Brasil)",Toast.LENGTH_SHORT).show());addEntity(b,"competition","","Salvamento","Carreira salva automaticamente neste dispositivo","💾",v -> Toast.makeText(this,"O progresso é salvo automaticamente.",Toast.LENGTH_SHORT).show());addEntity(b,"competition","","Identidade visual","Campo, escudos, bandeiras e competições","⚽",v -> Toast.makeText(this,"Identidade visual do FWS",Toast.LENGTH_SHORT).show());addEntity(b,"competition","","Diagnóstico","Informações técnicas ficam fora da experiência normal","⚙",v -> showDiagnostic());}
    private void showDiagnostic(){try{String status=FwsPythonRuntime.status(this);new AlertDialog.Builder(this).setTitle("Diagnóstico").setMessage(status).setPositiveButton("OK",null).show();}catch(Throwable e){friendlyError("Diagnóstico indisponível",e);}}

    private void showCreateClub(){showPage(Screen.CREATE_CLUB,"CRIAR CLUBE DO ZERO","Fundar um clube e entrar na mesma carreira integrada",true,false);LinearLayout b=pageBody();
        b.addView(text("IDENTIDADE DO CLUBE",12,GOLD,true));gap(b,8);EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Nome do clube");styleEdit(name);b.addView(name,lp(-1,dp(52)));gap(b,8);EditText city=new EditText(this);city.setSingleLine(true);city.setHint("Cidade");styleEdit(city);b.addView(city,lp(-1,dp(52)));gap(b,8);
        List<JSONObject> countries=world.associationEntries();List<String> labels=new ArrayList<>();List<String> ids=new ArrayList<>();for(JSONObject a:countries){String id=a.optString("id");ids.add(id);labels.add(a.optString("name",id)+" ("+id+")");}int brazil=ids.indexOf("BRA");Spinner country=new Spinner(this);ArrayAdapter<String> ca=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);country.setAdapter(ca);if(brazil>=0)country.setSelection(brazil);b.addView(country,lp(-1,dp(50)));gap(b,8);
        String[] states={"AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"};Spinner state=new Spinner(this);state.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,states));b.addView(state,lp(-1,dp(50)));gap(b,10);b.addView(text("Clubes brasileiros entram pela estrutura estadual cadastrada e podem buscar acesso às divisões nacionais.",11,MUTED,false));gap(b,14);
        addAction(b,"＋","Fundar clube","Criar identidade e registrar no mundo",true,v->{String nm=name.getText().toString().trim(),ct=city.getText().toString().trim();if(nm.isEmpty()||ct.isEmpty()){Toast.makeText(this,"Informe o nome e a cidade.",Toast.LENGTH_SHORT).show();return;}int pos=country.getSelectedItemPosition();String countryId=ids.get(Math.max(0,pos));String stateCode=countryId.equals("BRA")?states[state.getSelectedItemPosition()]:"";try{FwsPythonRuntime.createClub(this,nm,countryId,ct,stateCode);Toast.makeText(this,"Clube fundado! Bem-vindo ao mundo do FWS.",Toast.LENGTH_LONG).show();showCareer();}catch(Throwable e){friendlyError("Não foi possível fundar o clube",e);}});
    }
    private void styleEdit(EditText e){e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(shape(PANEL_2,10,0xFF31573B));e.setTextSize(14);}

    private void friendlyError(String title,Throwable error){String message=error.getMessage();if(message==null||message.trim().isEmpty())message=error.getClass().getSimpleName();new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",(d,w)->{}).show();}

    @Override public void onBackPressed(){switch(currentScreen){case MAIN:super.onBackPressed();break;case NEW_GAME:case LOAD:showMainMenu();break;case CAREER:showMainMenu();break;case WORLD:case COMPETITIONS:case CALENDAR:case FINANCE:case HISTORY:case SELECTIONS:case SETTINGS:case OPPORTUNITIES:case MARKET:case MY_CLUBS:showCareer();break;case COUNTRY:showCountries();break;case LEAGUES:showWorld();break;case CLUBS:showLeagues();break;case CLUB:showMyClubs();break;case CREATE_CLUB:showNewGame();break;case MATCH:showCalendar();break;default:showCareer();break;}}
}
