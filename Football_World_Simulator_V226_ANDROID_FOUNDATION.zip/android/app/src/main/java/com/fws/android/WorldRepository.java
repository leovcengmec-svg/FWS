package com.fws.android;

import android.content.Context;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Iterator;

/** Read-only Android projection of the authoritative V225 world catalog. */
public final class WorldRepository {
    private static WorldRepository instance;
    private final JSONObject root;

    private WorldRepository(Context context) {
        root = load(context);
    }

    public static synchronized WorldRepository get(Context context) {
        if (instance == null) instance = new WorldRepository(context.getApplicationContext());
        return instance;
    }

    private JSONObject load(Context context) {
        try (InputStream in = context.getAssets().open("global_world_catalog.json");
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            return new JSONObject(text.toString());
        } catch (Exception e) {
            throw new IllegalStateException("Não foi possível carregar o catálogo mundial V225.", e);
        }
    }

    public int count(String section) {
        JSONObject object = root.optJSONObject(section);
        return object == null ? 0 : object.length();
    }

    public String version() { return root.optString("version", "V225"); }

    public JSONObject club(String id) {
        JSONObject clubs = root.optJSONObject("clubs");
        return clubs == null ? null : clubs.optJSONObject(id);
    }

    public JSONObject nationalTeam(String id) {
        JSONObject teams = root.optJSONObject("national_teams");
        return teams == null ? null : teams.optJSONObject(id);
    }

    public JSONObject association(String id) {
        JSONObject associations = root.optJSONObject("associations");
        return associations == null ? null : associations.optJSONObject(id);
    }

    public List<String> associationLines() {
        return sortedLines(root.optJSONObject("associations"), "name", "id", "confederation");
    }

    public List<String> clubLines(int limit) {
        return sortedLines(root.optJSONObject("clubs"), "name", "id", "country_id").subList(0,
                Math.min(limit, count("clubs")));
    }

    public List<String> leagueLines(int limit) {
        return sortedLines(root.optJSONObject("leagues"), "name", "id", "country_id").subList(0,
                Math.min(limit, count("leagues")));
    }

    public List<String> competitionLines() {
        return sortedLines(root.optJSONObject("competitions"), "id", "id", "confederation");
    }

    public String nationalTeamIdForCountry(String countryId) {
        JSONObject teams = root.optJSONObject("national_teams");
        JSONObject team = teams == null ? null : teams.optJSONObject(countryId);
        return team == null ? "" : team.optString("id", "NT_" + countryId);
    }

    private List<String> sortedLines(JSONObject object, String nameKey, String idKey, String extraKey) {
        if (object == null) return Collections.emptyList();
        List<String> result = new ArrayList<>();
        for (Iterator<String> it = object.keys(); it.hasNext();) {
            String id = it.next();
            JSONObject item = object.optJSONObject(id);
            if (item == null) continue;
            String name = item.optString(nameKey, id);
            String extra = item.optString(extraKey, "");
            result.add(name + "\n" + id + (extra.isEmpty() ? "" : " • " + extra));
        }
        result.sort(Comparator.comparing(String::toLowerCase));
        return result;
    }
}
