package com.fws.android;

import android.content.Context;
import android.graphics.drawable.Drawable;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Resolves only artwork explicitly registered as verified in identity/verified_assets.json.
 * The previous generated ID-in-a-shield images were provisional and are intentionally not
 * treated as official club crests, national emblems, league badges, or competition logos.
 */
public final class AssetResolver {
    private static JSONObject verifiedAssets;
    private AssetResolver() {}

    private static synchronized JSONObject manifest(Context context) {
        if (verifiedAssets != null) return verifiedAssets;
        try (InputStream in = context.getAssets().open("identity/verified_assets.json");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return verifiedAssets = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
        } catch (Exception ignored) {
            return verifiedAssets = new JSONObject();
        }
    }

    public static Drawable load(Context context, String type, String id) {
        if (context == null || type == null || id == null || id.isEmpty()) return null;
        JSONObject assets = manifest(context).optJSONObject("assets");
        if (assets == null) return null;
        String path = assets.optString(type + ":" + id, "");
        if (path.isEmpty() || !path.startsWith("identity/") || path.contains("..")) return null;
        try (InputStream in = context.getAssets().open(path)) {
            return Drawable.createFromStream(in, path);
        } catch (Exception ignored) {
            return null;
        }
    }
    /** True only for an image acquired from a recorded, license-checked source; national flags
     * mapped as a fallback do not count as verified club/team/competition artwork. */
    public static boolean hasVerifiedArtwork(Context context, String type, String id) {
        if (context == null || type == null || id == null || id.isEmpty()) return false;
        JSONObject assets = manifest(context).optJSONObject("assets");
        if (assets == null) return false;
        String path = assets.optString(type + ":" + id, "");
        if (!path.startsWith("identity/real_") || path.contains("..")) return false;
        try (InputStream in = context.getAssets().open(path)) {
            return in.read() >= 0;
        } catch (Exception ignored) {
            return false;
        }
    }

}
