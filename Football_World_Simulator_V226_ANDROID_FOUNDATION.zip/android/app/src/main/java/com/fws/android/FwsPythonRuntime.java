package com.fws.android;

import android.content.Context;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/** Thin Android adapter over the authoritative V225 Python engine. */
public final class FwsPythonRuntime {
    private FwsPythonRuntime() {}

    private static void ensureStarted(Context context) {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(context.getApplicationContext()));
        }
    }

    private static PyObject module(Context context) {
        ensureStarted(context);
        return Python.getInstance().getModule("runtime_api");
    }

    private static String call(Context context, String method, Object... args) {
        PyObject result = module(context).callAttr(method, args);
        return result.toString();
    }

    public static String status(Context context) { return call(context, "engine_status"); }
    public static String reset(Context context) { return call(context, "reset_session"); }
    public static String careerStatus(Context context) { return call(context, "career_status"); }
    public static String clubMarket(Context context, int limit) { return call(context, "club_market", limit); }
    public static String buyClub(Context context, String clubId) { return call(context, "buy_club", clubId); }
    public static String selectionInvitations(Context context) { return call(context, "selection_invitations"); }
    public static String activateOwnedClub(Context context, String clubId) { return call(context, "activate_owned_club", clubId); }
    public static String acceptSelection(Context context, String teamId) { return call(context, "accept_selection", teamId); }
    public static String advanceSeason(Context context) { return call(context, "advance_season"); }
}
