package com.fws.android;

import android.content.Context;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/** Thin Android adapter over the authoritative V225 Python engine. */
public final class FwsPythonRuntime {
    private FwsPythonRuntime() {}

    private static void ensureStarted(Context context) {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(context.getApplicationContext()));
        }
    }

    private static PyObject module(Context context) {
        ensureStarted(context);
        return Python.getInstance().getModule("runtime_api");
    }

    private static String call(Context context, String method, Object... args) {
        PyObject result = module(context).callAttr(method, args);
        return result.toString();
    }

    public static String status(Context context) { return call(context, "engine_status"); }
    public static String reset(Context context) { return call(context, "reset_session"); }
    public static String careerStatus(Context context) { return call(context, "career_status"); }
    public static String clubMarket(Context context, int limit) { return call(context, "club_market", limit); }
    public static String buyClub(Context context, String clubId) { return call(context, "buy_club", clubId); }
    public static String selectionInvitations(Context context) { return call(context, "selection_invitations"); }
    public static String activateOwnedClub(Context context, String clubId) { return call(context, "activate_owned_club", clubId); }
    public static String acceptSelection(Context context, String teamId) { return call(context, "accept_selection", teamId); }
    public static String declineSelection(Context context, String teamId) { return call(context, "decline_selection", teamId); }
    public static String selectionManagementStatus(Context context) { return call(context, "selection_management_status"); }
    public static String manageSelection(Context context, String strategy, int intensity, String rotationPolicy, String focus) { return call(context, "manage_selection", strategy, intensity, rotationPolicy, focus); }
    public static String renewSelectionContract(Context context, int seasons) { return call(context, "renew_selection_contract", seasons); }
    public static String leaveSelectionCareer(Context context) { return call(context, "leave_selection_career"); }
    public static String advanceSeason(Context context) { return call(context, "advance_season"); }
    public static boolean hasSave(Context context) {
        try { return new org.json.JSONObject(call(context, "has_saved_career")).optBoolean("has_save", false); }
        catch (Exception ignored) { return false; }
    }
    public static String careerOpportunities(Context context) { return call(context, "career_opportunities"); }
    public static String completeOpportunity(Context context, String id) { return call(context, "complete_career_opportunity", id); }
    public static String createClub(Context context, String name, String countryId, String city, String stateCode) {
        return call(context, "create_club_from_zero", name, countryId, city, stateCode);
    }
    public static String financeStatus(Context context) { return call(context, "finance_status"); }
    public static String historySummary(Context context) { return call(context, "history_summary"); }
    public static String clubDetail(Context context, String clubId) { return call(context, "club_detail", clubId); }
    public static String investInClub(Context context, String clubId, double amount, String category) { return call(context, "invest_in_club", clubId, amount, category); }
    public static String investInSelection(Context context, double amount, String category) { return call(context, "invest_in_selection", amount, category); }
    public static String clubManagementStatus(Context context, String clubId) { return call(context, "club_management_status", clubId); }
    public static String manageOwnedClub(Context context, String clubId, String focus, String decision) { return call(context, "manage_owned_club", clubId, focus, decision); }
    public static String leagueStandings(Context context, String leagueId) { return call(context, "league_standings", leagueId); }
    public static String worldActivitySummary(Context context) { return call(context, "world_activity_summary"); }
}
