# Flag artwork attribution

The country flag PNGs in `identity/countries/` were rendered from the `worldflags` LaTeX/TikZ package by Wilhelm Haager. The package is distributed under the LaTeX Project Public License 1.3 or later.

- Package: https://ctan.org/pkg/worldflags
- Author/maintainer: Wilhelm Haager
- License: LPPL 1.3 or later
- Rendering: generated locally as raster PNGs for offline Android use; no external network request is required by the game.

These are country flags, not national football federation emblems. Where a country flag image was unavailable in the installed package version, the UI falls back to a Unicode national/subdivision flag sequence. Club crests, national-team emblems, league logos and competition logos are not falsely represented as official artwork.
