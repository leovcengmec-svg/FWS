# FWS identity artwork policy

The display bundle includes 194 offline-rendered country flag PNGs in `countries/`, sourced from the open-source `worldflags` LaTeX/TikZ package. The source and license are documented in `ATTRIBUTION_WORLD_FLAGS.md`. The 17 country entries without a suitable flag file in the installed package version (including Wales, whose subdivision flag uses Unicode fallback) render using a native Unicode flag sequence where supported.

Country flags are not the same as national football federation emblems. National-team tiles may use the country flag as identity context and explicitly label the team emblem as unverified. Authentic club crests, national-team emblems, league logos and competition marks are not bundled yet; generated ID-in-shield placeholders were removed instead of being passed off as official.

`verified_assets.json` is the only allowlist for artwork displayed as an image. Register an asset only after confirming its entity mapping, source and permitted use.


## Online acquisition of real crests and logos

`tools/sync_verified_identity_assets.py` searches Wikimedia Commons for catalog-linked club crests, national-team/federation marks, league logos, competition logos and confederation marks. It no longer rejects images based on license category: a strong entity/title match is the primary selection requirement. When available, source page, author and declared license are recorded in `asset_sources.json` and `ATTRIBUTION_REAL_ASSETS.md`. Files with unclear metadata may still be considered for this private-use build, but inclusion does not grant rights to redistribute them or remove trademark/copyright obligations. Artwork is converted to compact transparent WebP and registered in `verified_assets.json`.

The GitHub Actions workflow runs a priority pass on ordinary pushes and a full catalog pass when started manually with **workflow_dispatch**. The app remains offline-capable after build; it does not fetch images while the user plays. Missing or ambiguous results remain neutral placeholders and are recorded in the audit rather than being mislabeled as official. Wikimedia Commons does not host every copyrighted football crest, so this process cannot guarantee every club has a freely redistributable logo.
