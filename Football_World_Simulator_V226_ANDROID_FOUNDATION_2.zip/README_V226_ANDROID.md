
## V226 career dashboard integration
- Club Dashboard now reads the live V131 career snapshot through the Android Python bridge.
- It displays capital, prestige/tier, owned clubs, active club and identity asset.
- Owned clubs can be appointed as the active managed club through `V131IntegratedCareer.activate_owned_club()`.
- Selection Dashboard now reads live prestige/tier, active selection, career history and invitation count.
- Selection invitations remain controlled by the authoritative V225 invitation rules.
- No individual-player or transfer system was introduced.
