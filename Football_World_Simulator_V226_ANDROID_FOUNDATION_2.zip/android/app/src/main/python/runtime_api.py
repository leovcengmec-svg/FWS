"""V226 Android runtime entrypoint.

The authoritative simulation remains the V225 Python engine. This module is a
thin adapter: Android calls the existing career and world layers instead of
reimplementing game rules in Java.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from engine.save_io import load_world, save_world
from engine.world_database import load_global_simulation
from engine.world_simulator import WorldSimulator
from engine.v131_integrated_career import V131IntegratedCareer
from engine.market import ClubMarket

BASE = Path(__file__).resolve().parent
CATALOG = BASE / "data" / "global_world_catalog.json"
SAVE_PATH = Path(os.environ["HOME"]) / "fws_save_v226.json"


def _materialize_market_values(save):
    # Reuse the authoritative V225 market engine for first-season valuations.
    market = ClubMarket(save)
    for club_id in save.get("world", {}).get("clubs", {}):
        market.revalue_club(club_id)
    return save


def _fresh_save():
    save = load_global_simulation(CATALOG)
    _materialize_market_values(save)
    V131IntegratedCareer(save).initialize()
    return save


def _load():
    if SAVE_PATH.exists():
        return load_world(SAVE_PATH)
    save = _fresh_save()
    save_world(save, SAVE_PATH)
    return save


def _career(save):
    return V131IntegratedCareer(save)


def _summary(save):
    world = save.get("world", {})
    careers = save.get("careers", {})
    integrated = careers.get("integrated", {})
    investor = careers.get("investor", {})
    selection = careers.get("selection", {})
    return {
        "engine": "V225",
        "android": "V226",
        "year": world.get("current_year", 2026),
        "round": world.get("current_round", 0),
        "associations": len(world.get("countries", {})),
        "national_teams": len(world.get("national_teams", {})),
        "leagues": len(world.get("leagues", {})),
        "clubs": len(world.get("clubs", {})),
        "capital": round(float(investor.get("cash", 0.0)), 2),
        "owned_clubs": list(investor.get("owned_clubs", [])),
        "career_status": integrated.get("status", "available"),
        "prestige": integrated.get("prestige", selection.get("manager_prestige", 0.0)),
        "tier": integrated.get("tier", "EMERGING"),
        "active_club_id": integrated.get("active_club_id"),
        "active_selection_id": integrated.get("active_selection_id"),
    }


def engine_status():
    return json.dumps(_summary(_load()), ensure_ascii=False)


def reset_session():
    save = _fresh_save()
    save_world(save, SAVE_PATH)
    return json.dumps(_summary(save), ensure_ascii=False)


def career_status():
    save = _load()
    snapshot = _career(save).career_snapshot()
    snapshot["capital"] = round(float(save.get("careers", {}).get("investor", {}).get("cash", 0.0)), 2)
    snapshot["year"] = int(save.get("world", {}).get("current_year", 2026))
    snapshot["round"] = int(save.get("world", {}).get("current_round", 0))
    return json.dumps(snapshot, ensure_ascii=False)


def club_market(limit=50):
    save = _load()
    _materialize_market_values(save)
    save_world(save, SAVE_PATH)
    career = _career(save)
    investor = save.get("careers", {}).get("investor", {})
    owned = set(investor.get("owned_clubs", []))
    clubs = []
    for club_id, club in save.get("world", {}).get("clubs", {}).items():
        if club_id in owned:
            continue
        value = round(float(club.get("market_value", 0.0)), 2)
        if value <= 0:
            continue
        clubs.append({
            "id": club_id,
            "name": club.get("name", club_id),
            "country_id": club.get("country_id"),
            "league_id": club.get("league_id"),
            "market_value": value,
            "prestige": round(float(club.get("prestige", 0.0)), 2),
            "cash": round(float(club.get("cash", 0.0)), 2),
            "can_buy": career.investor.can_buy(club_id),
        })
    clubs.sort(key=lambda x: (x["can_buy"] is False, x["market_value"], x["name"]))
    return json.dumps({"capital": round(float(investor.get("cash", 0.0)), 2), "clubs": clubs[:max(1, int(limit))]}, ensure_ascii=False)


def buy_club(club_id):
    save = _load()
    club = save.get("world", {}).get("clubs", {}).get(str(club_id))
    if club is None:
        raise ValueError("clube inexistente")
    if float(club.get("market_value", 0.0)) <= 0:
        raise ValueError("clube sem valor de mercado válido")
    career = _career(save)
    result = career.buy_club(str(club_id))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "club_id": result["id"], "club": result, "career": _summary(save)}, ensure_ascii=False)


def activate_owned_club(club_id):
    save = _load()
    career = _career(save)
    owned = set(save.get("careers", {}).get("investor", {}).get("owned_clubs", []))
    club_id = str(club_id)
    if club_id not in owned:
        raise ValueError("o clube não pertence ao investidor")
    result = career.activate_owned_club(club_id)
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "active_club_id": result, "career": career.career_snapshot()}, ensure_ascii=False)


def selection_invitations():
    save = _load()
    career = _career(save)
    invitations = career.make_selection_invitations()
    teams = save.get("world", {}).get("national_teams", {})
    rows = []
    for team_id in invitations:
        team = teams.get(team_id, {})
        rows.append({
            "id": team_id,
            "name": team.get("name", team_id),
            "country_id": team.get("country_id"),
            "required_prestige": team.get("manager_prestige_required", 10),
        })
    return json.dumps({
        "prestige": float(save.get("careers", {}).get("selection", {}).get("manager_prestige", 0.0)),
        "tier": career.selection.tier(),
        "invitations": rows,
    }, ensure_ascii=False)


def accept_selection(team_id):
    save = _load()
    career = _career(save)
    result = career.accept_selection_invitation(str(team_id))
    save_world(save, SAVE_PATH)
    return json.dumps({"ok": True, "selection_id": result, "career": _summary(save)}, ensure_ascii=False)


def advance_season():
    save = _load()
    before = int(save["world"].get("current_year", 2026))
    sim = WorldSimulator(save, seed=before)
    results = sim.advance_season()
    save_world(save, SAVE_PATH)
    summary = _summary(save)
    summary["completed_season"] = before
    summary["simulated_leagues"] = len(results)
    summary["skipped_leagues"] = len(save.get("history", {}).get("skipped_leagues", [])[-1].get("leagues", [])) if save.get("history", {}).get("skipped_leagues") else 0
    return json.dumps(summary, ensure_ascii=False)
