class V192ClubBoard:
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}).setdefault('club_board',[])
    def confidence(self,club_id,achievement_rate=None):
        c=self.save['world']['clubs'][club_id]; current=float(c.get('board_confidence',50)); rate=50 if achievement_rate is None else float(achievement_rate); value=max(0,min(100,round(current*.45+rate*.55,4)))
        status='strong' if value>=75 else 'stable' if value>=55 else 'under_pressure' if value>=35 else 'critical'; c['board_confidence']=value; c['board_status']=status
        r={'club_id':club_id,'season':self.save['world'].get('current_year'),'confidence':value,'status':status}; self.history.append(r); return r
    def decision(self,club_id,decision,reason=''):
        c=self.save['world']['clubs'][club_id]; r={'club_id':club_id,'season':self.save['world'].get('current_year'),'decision':decision,'reason':reason}; c.setdefault('board_decisions',[]).append(r); self.history.append(r); return r
    def validate(self): return []
