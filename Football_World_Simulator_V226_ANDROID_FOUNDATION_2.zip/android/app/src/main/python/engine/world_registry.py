"""Canonical registry/indexes for the football world.

This layer does not change sporting outcomes. It turns the seed/save structures into
validated, indexed world data that can be consumed consistently by domestic,
continental, calendar and career systems.
"""
from collections import defaultdict

CONFEDERATIONS = ("AFC", "CAF", "CONCACAF", "CONMEBOL", "OFC", "UEFA")


class WorldRegistry:
    def __init__(self, save):
        self.save = save
        self.world = save.setdefault("world", {})
        self.countries = self.world.setdefault("countries", {})
        self.leagues = self.world.setdefault("leagues", {})
        self.clubs = self.world.setdefault("clubs", {})
        self.national_teams = self.world.setdefault("national_teams", {})
        self.competitions = self.world.setdefault("competitions", {})

    def country(self, country_id):
        return self.countries[country_id]

    def leagues_for_country(self, country_id):
        return sorted(
            (l for l in self.leagues.values() if l.get("country_id") == country_id),
            key=lambda x: (x.get("level", 999), x.get("id", "")),
        )

    def top_league(self, country_id):
        rows = self.leagues_for_country(country_id)
        return rows[0] if rows else None

    def clubs_for_league(self, league_id):
        league = self.leagues[league_id]
        return [self.clubs[cid] for cid in league.get("club_ids", []) if cid in self.clubs]

    def leagues_for_confederation(self, confederation):
        country_ids = {c["id"] for c in self.countries.values() if c.get("confederation") == confederation}
        return [l for l in self.leagues.values() if l.get("country_id") in country_ids]

    def clubs_for_confederation(self, confederation):
        country_ids = {c["id"] for c in self.countries.values() if c.get("confederation") == confederation}
        return [c for c in self.clubs.values() if c.get("country_id") in country_ids]

    def division_map(self, country_id):
        return {l.get("level"): l["id"] for l in self.leagues_for_country(country_id)}

    def rebuild_indexes(self):
        by_country = defaultdict(list)
        by_conf = defaultdict(list)
        for league in self.leagues.values():
            by_country[league.get("country_id")].append(league["id"])
            country = self.countries.get(league.get("country_id"), {})
            if country.get("confederation"):
                by_conf[country["confederation"]].append(league["id"])
        by_league = defaultdict(list)
        for club in self.clubs.values():
            if club.get("league_id"):
                by_league[club["league_id"]].append(club["id"])
        self.world["indexes"] = {
            "leagues_by_country": {k: sorted(v) for k, v in by_country.items()},
            "leagues_by_confederation": {k: sorted(v) for k, v in by_conf.items()},
            "clubs_by_league": {k: sorted(v) for k, v in by_league.items()},
        }
        return self.world["indexes"]

    def validate(self, require_sporting_data=True):
        errors = []
        if not self.countries:
            errors.append("world.countries is empty")
        for cid, country in self.countries.items():
            if country.get("id") != cid:
                errors.append(f"country key/id mismatch: {cid}")
            if country.get("confederation") not in CONFEDERATIONS:
                errors.append(f"country {cid} has invalid confederation")
        for lid, league in self.leagues.items():
            if league.get("id") != lid:
                errors.append(f"league key/id mismatch: {lid}")
            if league.get("country_id") not in self.countries:
                errors.append(f"league {lid} references unknown country")
            ids = league.get("club_ids", [])
            if len(ids) != len(set(ids)):
                errors.append(f"league {lid} contains duplicate clubs")
            for cid in ids:
                if cid not in self.clubs:
                    errors.append(f"league {lid} references unknown club {cid}")
                elif self.clubs[cid].get("league_id") != lid:
                    errors.append(f"club {cid} disagrees with league {lid}")
        seen = {}
        for cid, club in self.clubs.items():
            if club.get("id") != cid:
                errors.append(f"club key/id mismatch: {cid}")
            lid = club.get("league_id")
            waiting = self.world.get("final_division_waiting_queues", {}) if isinstance(self.world, dict) else {}
            queued = any(cid in q.get("club_ids", []) for q in waiting.values() if isinstance(q, dict))
            out_of_pyramid = lid is None and (queued or club.get("waiting_for_league") is not None or club.get("domestic_status") in {"external_verified_real", "relegated_from_final_division"})
            if lid not in self.leagues and not out_of_pyramid:
                errors.append(f"club {cid} references unknown league {lid}")
            else:
                seen.setdefault(cid, 0)
                seen[cid] += 1
            if require_sporting_data:
                for field in ("attack", "defense", "prestige"):
                    if field not in club:
                        errors.append(f"club {cid} missing {field}")
        # Every club must appear in exactly one domestic league.
        occurrences = defaultdict(int)
        for league in self.leagues.values():
            for cid in league.get("club_ids", []):
                occurrences[cid] += 1
        for cid in self.clubs:
            waiting = self.world.get("final_division_waiting_queues", {}) if isinstance(self.world, dict) else {}
            queued = any(cid in q.get("club_ids", []) for q in waiting.values() if isinstance(q, dict))
            out_of_pyramid = self.clubs[cid].get("league_id") is None and (queued or self.clubs[cid].get("waiting_for_league") is not None or self.clubs[cid].get("domestic_status") in {"external_verified_real", "relegated_from_final_division"})
            if out_of_pyramid:
                continue
            if occurrences[cid] != 1:
                errors.append(f"club {cid} appears in {occurrences[cid]} leagues")
        for tid, team in self.national_teams.items():
            if team.get("id") != tid:
                errors.append(f"national team key/id mismatch: {tid}")
            if team.get("confederation") not in CONFEDERATIONS:
                errors.append(f"national team {tid} has invalid confederation")
        return errors

    def summary(self):
        return {
            "countries": len(self.countries),
            "associations_with_leagues": len({l.get("country_id") for l in self.leagues.values()}),
            "leagues": len(self.leagues),
            "clubs": len(self.clubs),
            "national_teams": len(self.national_teams),
            "competitions": len(self.competitions),
            "confederations": {c: len(self.leagues_for_confederation(c)) for c in CONFEDERATIONS},
        }
