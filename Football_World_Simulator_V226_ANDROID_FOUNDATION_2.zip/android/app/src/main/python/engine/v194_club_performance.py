class V194ClubPerformance:
    def __init__(self,save): self.save=save; self.history=save.setdefault('history',{}).setdefault('club_performance_management',[])
    def apply(self,club_id,season=None):
        c=self.save['world']['clubs'][club_id]; season=self.save['world'].get('current_year') if season is None else season
        focus=c.get('strategic_focus','balanced'); quality=float(c.get('strategic_quality',50)); readiness=float(c.get('management_effects',{}).get('management_readiness',0)); confidence=float(c.get('board_confidence',50));
        modifier=1+(quality-50)*0.0005+(readiness-50)*0.0003+(confidence-50)*0.0002; modifier=max(.9,min(1.1,modifier)); c['management_performance_modifier']=round(modifier,6)
        if focus=='sporting': c['sporting_strength']=max(0,min(100,round(float(c.get('sporting_strength',50))+0.6*(modifier-1)*100,4)))
        elif focus=='development': c['management_maturity']=max(0,min(100,round(float(c.get('management_maturity',40))+0.5,4)))
        elif focus=='commercial': c['commercial_strength']=max(0,min(100,round(float(c.get('commercial_strength',40))+0.5,4)))
        r={'club_id':club_id,'season':season,'focus':focus,'modifier':c['management_performance_modifier']}; self.history.append(r); return r
    def validate(self): return []
