import json
from pathlib import Path

def save_world(save,path):
    Path(path).write_text(json.dumps(save,ensure_ascii=False,indent=2),encoding="utf-8")

def load_world(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
