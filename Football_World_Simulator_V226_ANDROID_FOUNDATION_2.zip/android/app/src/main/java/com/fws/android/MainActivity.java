package com.fws.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private enum Screen { MAIN, NEW_GAME, CLUB_MODE, SELECTION_MODE, CREATE_CLUB, CLUB_DASHBOARD, SELECTION_DASHBOARD, WORLD, CALENDAR, COMPETITIONS, MATCH, FINANCE, HISTORY, SETTINGS, LOAD, MORE }
    private Screen currentScreen = Screen.MAIN;
    private WorldRepository world;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        world = WorldRepository.get(this);
        showMainMenu();
    }

    private void showMainMenu() {
        currentScreen = Screen.MAIN;
        setContentView(R.layout.activity_main);
        findViewById(R.id.btn_new).setOnClickListener(v -> showNewGame());
        findViewById(R.id.btn_load).setOnClickListener(v -> showLoadGame());
        findViewById(R.id.btn_settings).setOnClickListener(v -> showSettings());
    }

    private void showNewGame() {
        currentScreen = Screen.NEW_GAME;
        setContentView(R.layout.screen_new_game);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btn_club_mode).setOnClickListener(v -> showClubMode());
        findViewById(R.id.btn_selection_mode).setOnClickListener(v -> showSelectionMode());
        findViewById(R.id.btn_create_club).setOnClickListener(v -> showCreateClub());
        addRuntimeNewGameAction();
    }

    private void showClubMode() {
        currentScreen = Screen.CLUB_MODE;
        setContentView(R.layout.screen_mode_club);
        findViewById(R.id.btn_back).setOnClickListener(v -> showNewGame());
        findViewById(R.id.btn_club_market).setOnClickListener(v -> showClubMarket());
        findViewById(R.id.btn_club_dashboard).setOnClickListener(v -> showClubDashboard());
    }

    private void showSelectionMode() {
        currentScreen = Screen.SELECTION_MODE;
        setContentView(R.layout.screen_mode_selection);
        findViewById(R.id.btn_back).setOnClickListener(v -> showNewGame());
        findViewById(R.id.btn_invites).setOnClickListener(v -> showSelectionCatalog());
        findViewById(R.id.btn_selection_dashboard).setOnClickListener(v -> showSelectionDashboard());
    }

    private void showCreateClub() {
        currentScreen = Screen.CREATE_CLUB;
        setContentView(R.layout.screen_create_club);
        findViewById(R.id.btn_back).setOnClickListener(v -> showNewGame());
        findViewById(R.id.btn_country).setOnClickListener(v -> showSectionFrom(Screen.CREATE_CLUB, "PAÍS", "O catálogo real das 211 associações será conectado ao banco mundial."));
        findViewById(R.id.btn_league).setOnClickListener(v -> showSectionFrom(Screen.CREATE_CLUB, "LIGA / DIVISÃO", "A estrutura real da associação escolhida será fornecida pelo motor."));
        findViewById(R.id.btn_identity).setOnClickListener(v -> showSectionFrom(Screen.CREATE_CLUB, "IDENTIDADE", "Nome, cidade, estádio e identidade visual serão persistidos no fluxo definitivo."));
        findViewById(R.id.btn_create).setOnClickListener(v -> showSectionFrom(Screen.CREATE_CLUB, "CLUBE CRIADO", "O comando definitivo de criação será executado pelo motor V225 nesta etapa de integração."));
    }

    private void showLoadGame() {
        currentScreen = Screen.LOAD;
        showSectionFrom(Screen.MAIN, "CARREGAR JOGO", "Nenhum save foi carregado ainda.\n\nA camada de persistência do V225 será conectada sem alterar o schema existente.");
    }

    private void showSettings() {
        currentScreen = Screen.SETTINGS;
        setContentView(R.layout.screen_settings);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
    }

    private void addRuntimeNewGameAction() {
        LinearLayout root = (LinearLayout) ((android.view.ViewGroup) findViewById(R.id.btn_create_club)).getParent();
        addAction(root, "INICIAR / REINICIAR CARREIRA V225", v -> initializeCareer());
    }

    private void initializeCareer() {
        try {
            String result = FwsPythonRuntime.reset(this);
            showEngineResult("NOVA CARREIRA", "SAVE REAL V225 INICIALIZADO", result);
        } catch (Throwable error) {
            showEngineResult("NOVA CARREIRA", "ERRO DE INICIALIZAÇÃO", error.toString());
        }
    }

    private void showClubMarket() {
        try {
            JSONObject payload = new JSONObject(FwsPythonRuntime.clubMarket(this, 50));
            setContentView(R.layout.screen_section);
            LinearLayout content = findViewById(R.id.section_content);
            addBack(content, Screen.CLUB_MODE);
            addTitle(content, "CLUBES DISPONÍVEIS", "Capital atual: " + payload.optDouble("capital", 0.0));
            JSONArray clubs = payload.getJSONArray("clubs");
            for (int i = 0; i < clubs.length(); i++) {
                JSONObject club = clubs.getJSONObject(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackgroundResource(R.drawable.bg_card);
                card.setPadding(dp(14), dp(14), dp(14), dp(14));
                addVisualHeader(card, "club", club.optString("id"), club.optString("name"),
                        club.optString("country_id"));
                TextView info = new TextView(this);
                info.setText("Valor: " + club.optDouble("market_value", 0.0) +
                        " • Prestígio: " + club.optDouble("prestige", 0.0));
                info.setTextColor(getColor(R.color.fws_text));
                info.setTextSize(14);
                card.addView(info);
                Button buy = new Button(this);
                buy.setText(club.optBoolean("can_buy") ? "COMPRAR / ASSUMIR" : "CAPITAL INSUFICIENTE");
                buy.setEnabled(club.optBoolean("can_buy"));
                final String clubId = club.optString("id");
                buy.setOnClickListener(v -> buyClub(clubId));
                card.addView(buy);
                content.addView(card, lp(dp(10)));
            }
        } catch (Throwable error) {
            showEngineResult("MERCADO DE CLUBES", "ERRO DE LEITURA DO MOTOR", error.toString());
        }
    }

    private void buyClub(String clubId) {
        try {
            String result = FwsPythonRuntime.buyClub(this, clubId);
            showEngineResult("CLUBE ASSUMIDO", "A compra foi executada pelo InvestorCareer V225", result);
        } catch (Throwable error) {
            showEngineResult("COMPRA", "OPERAÇÃO REJEITADA PELO MOTOR V225", error.toString());
        }
    }

    private void showSelectionCatalog() {
        try {
            JSONObject payload = new JSONObject(FwsPythonRuntime.selectionInvitations(this));
            setContentView(R.layout.screen_section);
            LinearLayout content = findViewById(R.id.section_content);
            addBack(content, Screen.SELECTION_MODE);
            addTitle(content, "CONVITES DE SELEÇÃO", "Prestígio: " + payload.optDouble("prestige", 0.0) + " • " + payload.optString("tier", "EMERGING"));
            JSONArray invites = payload.getJSONArray("invitations");
            if (invites.length() == 0) {
                addCard(content, "NENHUM CONVITE DISPONÍVEL\nO motor V225 exige que a seleção envie um convite compatível com seu prestígio.");
            }
            for (int i = 0; i < invites.length(); i++) {
                JSONObject team = invites.getJSONObject(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackgroundResource(R.drawable.bg_card);
                card.setPadding(dp(14), dp(14), dp(14), dp(14));
                String countryId = team.optString("country_id", "");
                addVisualHeader(card, "national_team", world.nationalTeamIdForCountry(countryId),
                        team.optString("name"), countryId);
                addAction(card, "ACEITAR • Prestígio mínimo: " + team.optInt("required_prestige", 10),
                        v -> acceptSelection(team.optString("id")));
                content.addView(card, lp(dp(10)));
            }
        } catch (Throwable error) {
            showEngineResult("CONVITES", "ERRO DE LEITURA DO MOTOR", error.toString());
        }
    }

    private void acceptSelection(String teamId) {
        try {
            String result = FwsPythonRuntime.acceptSelection(this, teamId);
            showEngineResult("SELEÇÃO ASSUMIDA", "O convite foi aceito pelo SelectionCareer V225", result);
        } catch (Throwable error) {
            showEngineResult("CONVITE", "OPERAÇÃO REJEITADA PELO MOTOR V225", error.toString());
        }
    }

    private void addBack(LinearLayout content, Screen previous) {
        TextView back = new TextView(this);
        back.setText("‹  VOLTAR");
        back.setTextColor(getColor(R.color.fws_primary));
        back.setTextSize(15);
        back.setPadding(0, 0, 0, dp(12));
        back.setOnClickListener(v -> restore(previous));
        content.addView(back);
    }

    private void showVisualList(Screen previous, String title, String subtitle, java.util.List<String> lines, String type) {
        setContentView(R.layout.screen_section);
        LinearLayout content = findViewById(R.id.section_content);
        addBack(content, previous);
        addTitle(content, title, subtitle);
        for (String line : lines) {
            String[] parts = line.split("\\n", 2);
            String name = parts.length > 0 ? parts[0] : line;
            String meta = parts.length > 1 ? parts[1] : "";
            String id = meta.split(" •", 2)[0].trim();
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_card);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            addVisualHeader(card, type, id, name, meta);
            content.addView(card, lp(dp(10)));
        }
    }

    private void addVisualHeader(LinearLayout parent, String type, String assetId, String name, String secondary) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView image = new ImageView(this);
        image.setImageDrawable(AssetResolver.load(this, type, assetId));
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        row.addView(image, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(12), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(getColor(R.color.fws_text));
        title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        text.addView(title);
        TextView sub = new TextView(this);
        sub.setText(secondary);
        sub.setTextColor(getColor(R.color.fws_text_secondary));
        sub.setTextSize(12);
        text.addView(sub);
        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        parent.addView(row);
    }

    private void showList(Screen previous, String title, String subtitle, java.util.List<String> lines) {
        setContentView(R.layout.screen_section);
        LinearLayout content = findViewById(R.id.section_content);
        TextView back = new TextView(this);
        back.setText("‹  VOLTAR");
        back.setTextColor(getColor(R.color.fws_primary));
        back.setTextSize(15);
        back.setPadding(0, 0, 0, dp(12));
        back.setOnClickListener(v -> restore(previous));
        content.addView(back);
        addTitle(content, title, subtitle);
        for (String line : lines) addCard(content, line);
    }

    private void showClubDashboard() {
        currentScreen = Screen.CLUB_DASHBOARD;
        try {
            JSONObject career = new JSONObject(FwsPythonRuntime.careerStatus(this));
            setContentView(R.layout.screen_dashboard);
            LinearLayout content = findViewById(R.id.content);
            addTitle(content, "DASHBOARD DO CLUBE", "CARREIRA V225 • " + career.optString("status", "available"));

            JSONObject active = world.club(career.optString("active_club_id", ""));
            if (active != null) {
                LinearLayout hero = new LinearLayout(this);
                hero.setOrientation(LinearLayout.VERTICAL);
                hero.setBackgroundResource(R.drawable.bg_card);
                hero.setPadding(dp(14), dp(14), dp(14), dp(14));
                addVisualHeader(hero, "club", career.optString("active_club_id"),
                        active.optString("name", career.optString("active_club_id")),
                        active.optString("country_id", ""));
                addCard(hero, "CLUBE ATIVO\nVocê está nomeado como gestor deste clube.");
                content.addView(hero, lp(dp(10)));
            } else {
                addCard(content, "NENHUM CLUBE ATIVO\nCompre um clube no mercado e depois escolha ASSUMIR para iniciar a gestão.");
            }

            addCard(content, "CAPITAL\n" + formatNumber(career.optDouble("capital", 0.0)));
            addCard(content, "PRESTÍGIO\n" + formatNumber(career.optDouble("prestige", 0.0)) + " • " + career.optString("tier", "EMERGING"));
            JSONArray ownedCount = career.optJSONArray("owned_clubs");
            addCard(content, "CLUBES POSSUÍDOS\n" + (ownedCount == null ? "0" : String.valueOf(ownedCount.length())));

            JSONArray owned = career.optJSONArray("owned_clubs");
            if (owned != null && owned.length() > 0) {
                addTitle(content, "MEUS CLUBES", "Escolha qual clube você quer administrar");
                for (int i = 0; i < owned.length(); i++) {
                    String clubId = owned.optString(i);
                    JSONObject club = world.club(clubId);
                    if (club == null) continue;
                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setBackgroundResource(R.drawable.bg_card);
                    card.setPadding(dp(14), dp(14), dp(14), dp(14));
                    addVisualHeader(card, "club", clubId, club.optString("name", clubId), club.optString("country_id", ""));
                    addAction(card, clubId.equals(career.optString("active_club_id")) ? "CLUBE ATIVO" : "ASSUMIR GESTÃO",
                            v -> activateOwnedClub(clubId));
                    content.addView(card, lp(dp(10)));
                }
            }
            wireDashboardNavigation();
        } catch (Throwable error) {
            showEngineResult("DASHBOARD DO CLUBE", "ERRO DE LEITURA DA CARREIRA", error.toString());
        }
    }

    private void activateOwnedClub(String clubId) {
        try {
            String result = FwsPythonRuntime.activateOwnedClub(this, clubId);
            showEngineResult("GESTÃO DO CLUBE", "Nomeação executada pelo V131IntegratedCareer", result);
        } catch (Throwable error) {
            showEngineResult("GESTÃO DO CLUBE", "OPERAÇÃO REJEITADA PELO MOTOR V225", error.toString());
        }
    }

    private void showSelectionDashboard() {
        currentScreen = Screen.SELECTION_DASHBOARD;
        try {
            JSONObject career = new JSONObject(FwsPythonRuntime.careerStatus(this));
            setContentView(R.layout.screen_dashboard);
            LinearLayout content = findViewById(R.id.content);
            addTitle(content, "DASHBOARD DA SELEÇÃO", "CARREIRA V225 • " + career.optString("status", "available"));

            JSONObject active = world.nationalTeam(career.optString("active_selection_id", ""));
            if (active != null) {
                LinearLayout hero = new LinearLayout(this);
                hero.setOrientation(LinearLayout.VERTICAL);
                hero.setBackgroundResource(R.drawable.bg_card);
                hero.setPadding(dp(14), dp(14), dp(14), dp(14));
                String countryId = active.optString("country_id", "");
                addVisualHeader(hero, "national_team", career.optString("active_selection_id"),
                        active.optString("name", career.optString("active_selection_id")), countryId);
                addCard(hero, "SELEÇÃO ATIVA\nVocê está nomeado como treinador desta seleção.");
                content.addView(hero, lp(dp(10)));
            } else {
                addCard(content, "NENHUMA SELEÇÃO ATIVA\nA carreira de seleção depende de convite compatível com seu prestígio.");
            }

            addCard(content, "PRESTÍGIO\n" + formatNumber(career.optDouble("prestige", 0.0)) + " • " + career.optString("tier", "EMERGING"));
            addCard(content, "HISTÓRICO DA CARREIRA\n" + career.optInt("history_count", 0) + " registros");
            JSONArray invites = career.optJSONArray("selection_invitations");
            addCard(content, "CONVITES DISPONÍVEIS\n" + (invites == null ? 0 : invites.length()));
            addAction(content, "VER CONVITES", v -> showSelectionCatalog());
            wireDashboardNavigation();
        } catch (Throwable error) {
            showEngineResult("DASHBOARD DA SELEÇÃO", "ERRO DE LEITURA DA CARREIRA", error.toString());
        }
    }

    private void wireDashboardNavigation() {
        findViewById(R.id.nav_home).setOnClickListener(v -> {
            if (currentScreen == Screen.SELECTION_DASHBOARD) showSelectionDashboard();
            else showClubDashboard();
        });
        findViewById(R.id.nav_world).setOnClickListener(v -> showWorld());
        findViewById(R.id.nav_calendar).setOnClickListener(v -> showCalendar());
        findViewById(R.id.nav_more).setOnClickListener(v -> showMore());
    }

    private String formatNumber(double value) {
        return String.format(java.util.Locale.US, "%.2f", value);
    }

    private void showDashboard(String title, String subtitle, String[] cards) {
        setContentView(R.layout.screen_dashboard);
        LinearLayout content = findViewById(R.id.content);
        addTitle(content, title, subtitle);
        for (String card : cards) addCard(content, card);
        wireDashboardNavigation();
    }

    private void showMore() {
        showSectionFrom(currentScreen, "MAIS", "", new String[]{
                "COMPETIÇÕES\nAbrir central de competições",
                "PARTIDA\nAbrir central de simulação",
                "FINANÇAS\nAbrir painel financeiro",
                "HISTÓRIA\nAbrir histórico e legado",
                "CONFIGURAÇÕES\nAbrir configurações"
        });
        LinearLayout content = findViewById(R.id.section_content);
        addAction(content, "ABRIR COMPETIÇÕES", v -> showCompetitions());
        addAction(content, "ABRIR PARTIDA", v -> showMatch());
        addAction(content, "ABRIR FINANÇAS", v -> showFinance());
        addAction(content, "ABRIR HISTÓRIA", v -> showHistory());
        addAction(content, "ABRIR CONFIGURAÇÕES", v -> showSettings());
        addAction(content, "STATUS DO MOTOR V225", v -> showEngineStatus());
        addAction(content, "SIMULAR PRÓXIMA TEMPORADA", v -> advanceEngineSeason());
    }


    private void showEngineStatus() {
        try {
            String result = FwsPythonRuntime.status(this);
            showEngineResult("MOTOR V225", "EXECUÇÃO REAL DO MOTOR PYTHON", result);
        } catch (Throwable error) {
            showEngineResult("MOTOR V225", "ERRO DE INTEGRAÇÃO", error.toString());
        }
    }

    private void advanceEngineSeason() {
        try {
            String result = FwsPythonRuntime.advanceSeason(this);
            showEngineResult("TEMPORADA SIMULADA", "A simulação foi executada pelo WorldSimulator V225", result);
        } catch (Throwable error) {
            showEngineResult("SIMULAÇÃO", "ERRO DE EXECUÇÃO", error.toString());
        }
    }

    private void showEngineResult(String title, String subtitle, String rawJson) {
        currentScreen = Screen.MORE;
        showSectionFrom(Screen.MAIN, title, subtitle, new String[]{rawJson});
    }

    private void showWorld() {
        currentScreen = Screen.WORLD;
        setContentView(R.layout.screen_world);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btn_countries).setOnClickListener(v -> showVisualList(Screen.WORLD, "PAÍSES E ASSOCIAÇÕES", "V225 • " + world.count("associations") + " associações", world.associationLines(), "country"));
        findViewById(R.id.btn_leagues).setOnClickListener(v -> showVisualList(Screen.WORLD, "LIGAS E DIVISÕES", "V225 • " + world.count("leagues") + " estruturas", world.leagueLines(100), "league"));
        findViewById(R.id.btn_clubs).setOnClickListener(v -> showVisualList(Screen.WORLD, "CLUBES", "V225 • " + world.count("clubs") + " clubes catalogados", world.clubLines(100), "club"));
        findViewById(R.id.btn_competitions).setOnClickListener(v -> showCompetitions());
        findViewById(R.id.btn_rankings).setOnClickListener(v -> showSectionFrom(Screen.WORLD, "RANKINGS", "Força, prestígio e evolução do mundo."));
    }

    private void showCalendar() {
        currentScreen = Screen.CALENDAR;
        showSectionFrom(Screen.CALENDAR, "CALENDÁRIO", "Temporada e próximos eventos", new String[]{
                "PRÓXIMA PARTIDA\nCompetição • data • local",
                "RODADA\nPartidas e situação da competição",
                "TEMPORADA\nProgresso anual e marcos",
                "EVENTOS\nCompetições nacionais e internacionais"
        });
    }

    private void showCompetitions() {
        currentScreen = Screen.COMPETITIONS;
        setContentView(R.layout.screen_competitions);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btn_national).setOnClickListener(v -> showSectionFrom(Screen.COMPETITIONS, "COMPETIÇÕES NACIONAIS", "Ligas, copas e divisões."));
        findViewById(R.id.btn_continental).setOnClickListener(v -> showSectionFrom(Screen.COMPETITIONS, "COMPETIÇÕES CONTINENTAIS", "Classificados diretos e pré-eliminatórias conforme as regras do mundo."));
        findViewById(R.id.btn_world).setOnClickListener(v -> showSectionFrom(Screen.COMPETITIONS, "COMPETIÇÕES MUNDIAIS", "Competições globais e calendário internacional."));
        findViewById(R.id.btn_match).setOnClickListener(v -> showMatch());
        LinearLayout root = (LinearLayout) ((android.view.ViewGroup) findViewById(R.id.btn_match)).getParent();
        addAction(root, "CATÁLOGO VISUAL DE COMPETIÇÕES", v -> showVisualList(Screen.COMPETITIONS, "COMPETIÇÕES", "Logos do catálogo V225", world.competitionLines(), "competition"));
    }

    private void showMatch() {
        currentScreen = Screen.MATCH;
        setContentView(R.layout.screen_match);
        findViewById(R.id.btn_back).setOnClickListener(v -> showCompetitions());
        findViewById(R.id.btn_pre_match).setOnClickListener(v -> showSectionFrom(Screen.MATCH, "PRÉ-JOGO", "Força, forma, contexto, estratégia e mando serão fornecidos pelo motor V225."));
        findViewById(R.id.btn_simulate).setOnClickListener(v -> showSectionFrom(Screen.MATCH, "SIMULAÇÃO", "O motor agregado de partidas será chamado aqui; não existe sistema de jogadores individuais."));
        findViewById(R.id.btn_result).setOnClickListener(v -> showSectionFrom(Screen.MATCH, "RESULTADO", "Resultado, consequências esportivas, econômicas e históricas serão recebidos do motor."));
    }

    private void showFinance() {
        currentScreen = Screen.FINANCE;
        setContentView(R.layout.screen_finance);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
    }

    private void showHistory() {
        currentScreen = Screen.HISTORY;
        setContentView(R.layout.screen_history);
        findViewById(R.id.btn_back).setOnClickListener(v -> showMainMenu());
    }

    private void showSectionFrom(Screen previous, String title, String subtitle) {
        showSectionFrom(previous, title, subtitle, new String[0]);
    }

    private void showSectionFrom(Screen previous, String title, String subtitle, String[] cards) {
        setContentView(R.layout.screen_section);
        LinearLayout content = findViewById(R.id.section_content);
        TextView back = new TextView(this);
        back.setText("‹  VOLTAR");
        back.setTextColor(getColor(R.color.fws_primary));
        back.setTextSize(15);
        back.setPadding(0, 0, 0, dp(12));
        back.setOnClickListener(v -> restore(previous));
        content.addView(back);
        addTitle(content, title, subtitle);
        for (String card : cards) addCard(content, card);
        if (cards.length == 0 && subtitle != null && !subtitle.isEmpty()) addCard(content, subtitle);
    }

    private void restore(Screen screen) {
        switch (screen) {
            case NEW_GAME: showNewGame(); break;
            case CLUB_MODE: showClubMode(); break;
            case SELECTION_MODE: showSelectionMode(); break;
            case CREATE_CLUB: showCreateClub(); break;
            case CLUB_DASHBOARD: showClubDashboard(); break;
            case SELECTION_DASHBOARD: showSelectionDashboard(); break;
            case WORLD: showWorld(); break;
            case CALENDAR: showCalendar(); break;
            case COMPETITIONS: showCompetitions(); break;
            case MATCH: showMatch(); break;
            case FINANCE: showFinance(); break;
            case HISTORY: showHistory(); break;
            case SETTINGS: showSettings(); break;
            default: showMainMenu(); break;
        }
    }

    private void addTitle(LinearLayout parent, String title, String subtitle) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(getColor(R.color.fws_text));
        t.setTextSize(25);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        parent.addView(t, lp(0));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = new TextView(this);
            s.setText(subtitle);
            s.setTextColor(getColor(R.color.fws_text_secondary));
            s.setTextSize(14);
            s.setPadding(0, dp(5), 0, dp(12));
            parent.addView(s, lp(0));
        }
    }

    private void addCard(LinearLayout parent, String text) {
        TextView card = new TextView(this);
        card.setText(text);
        card.setTextColor(getColor(R.color.fws_text));
        card.setTextSize(15);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        parent.addView(card, lp(dp(10)));
    }

    private void addAction(LinearLayout parent, String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(getColor(R.color.fws_text));
        b.setBackgroundResource(R.drawable.bg_button_secondary);
        b.setOnClickListener(listener);
        parent.addView(b, lp(dp(10)));
    }

    private LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, topMargin, 0, 0);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        restore(currentScreen == Screen.MAIN ? Screen.MAIN : Screen.MAIN);
    }
}
