package com.fws.android;

import android.content.Context;
import android.graphics.drawable.Drawable;
import java.io.InputStream;

/** Resolves the portable V226 identity assets by stable domain ID. */
public final class AssetResolver {
    private AssetResolver() {}

    public static Drawable load(Context context, String type, String id) {
        if (id == null || id.isEmpty()) return null;
        String path;
        switch (type) {
            case "club": path = "identity/clubs/" + id + ".png"; break;
            case "league": path = "identity/leagues/" + id + ".png"; break;
            case "country": path = "identity/countries/" + id + ".png"; break;
            case "national_team": path = "identity/national_teams/" + id + ".png"; break;
            case "competition": path = "identity/competitions/" + id + ".png"; break;
            case "confederation": path = "identity/confederations/" + id + ".png"; break;
            default: return null;
        }
        try (InputStream in = context.getAssets().open(path)) {
            return Drawable.createFromStream(in, path);
        } catch (Exception ignored) {
            return null;
        }
    }
}
